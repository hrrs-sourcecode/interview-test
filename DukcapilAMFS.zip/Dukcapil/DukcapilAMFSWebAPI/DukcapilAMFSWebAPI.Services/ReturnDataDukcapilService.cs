﻿using DukcapilAMFSWebAPI.DTO;
using DukcapilAMFSWebAPI.Repositories;
using DukcapilAMFSWebAPI.Repositories.Interface;
using DukcapilAMFSWebAPI.Services.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.Services
{
    public class ReturnDataDukcapilService : IReturnDataDukcapilService
    {
        private IReturnDataDukcapilRepository _returnDataDukcapilRepository;

        private string _userName = "";
        public ReturnDataDukcapilService(IReturnDataDukcapilRepository returnDataDukcapilRepository)
        {
            DebugLogger.WriteLog($"Service {this.GetType().Name} has been hit !");
            _returnDataDukcapilRepository = returnDataDukcapilRepository;
        }

        // Main Method
        public async Task<SubmitReturnDataDukcapilResponseAsync> SubmitReturnDataDukcapilAsync(SubmitReturnDataDukcapilRequestAsync request)
        {
            _userName = request.UserName;

            if (!IsUserAuthorized())
                throw new UnauthorizedAccessException($"User {_userName} is not authorized to do this action");

            SubmitReturnDataDukcapilResponseAsync result = new SubmitReturnDataDukcapilResponseAsync();
            ResultStatus rs = new ResultStatus();
            try
            {
                List<ReturnDataDukcapilResponse> listResponse = new List<ReturnDataDukcapilResponse>();
                List<ReturnDataDukcapil> listData = JsonConvert.DeserializeObject<List<ReturnDataDukcapil>>(request.Data.ToString());
                DebugLogger.WriteLog($"Total data : {listData.Count} has been hit !");
                await Task.Run(() =>
                {
                    foreach (ReturnDataDukcapil data in listData)
                    {
                        listResponse.Add(SubmitToDukcapil(data).Result);
                    }
                });

                rs = SaveToDB(listResponse);

                result.Messages = rs.Messages;
                result.IsSuccess = true;
            }
            catch (Exception ex)
            {
                result.Messages.Add(ex.Message);
                result.IsSuccess = false;
            }

            return result;
        }

        // Authorize User
        private bool IsUserAuthorized()
        {
            IUserAppsRepository repo = new UserAppsRepository();         
            return repo.UserAppsIsExist(_userName);
        }

        // 1. Post to Dukcapil 
        private async Task<ReturnDataDukcapilResponse> SubmitToDukcapil(ReturnDataDukcapil dt)
        {
            ReturnDataDukcapilResponse resp = new ReturnDataDukcapilResponse();

            dt.id_lembaga = ConfigurationManager.AppSettings["id_lembaga"];
            dt.nama_lembaga = ConfigurationManager.AppSettings["nama_lembaga"];

            var url = "";
            var token = "";

            ParamDetail dtl = JsonConvert.DeserializeObject<IList<ParamDetail>>(dt.param)[0];

            resp.NIK = dt.nik;
            resp.Policy_No = dt.policy_no ?? "";
            resp.App_Status = dtl.NO_PROFIL_ID == "0" ? "Bukan Nasabah" : "Nasabah";
            resp.MDM_ID = dtl.NO_PROFIL_ID;
            resp.User_Apps = _userName;

            try
            {
                url = ConfigurationManager.AppSettings["url_service_dukcapil_databalikan"]
                    + "?nik=" + dt.nik
                    + "&id_lembaga=" + dt.id_lembaga
                    + "&nama_lembaga=" + dt.nama_lembaga
                    + "&param=" + dt.param;

                ReportLogger.WriteLog($"({DateTime.Now.ToString("dd-MMM-yyyy(hh:mm:ss:fff)")}) Url : {url}");
                token = ConfigurationManager.AppSettings["ServiceToken"];

                //--------------------------------------------------
                HttpMessageHandler handler = new HttpClientHandler();

                HttpClient httpClient = new HttpClient(handler)
                {
                    BaseAddress = new Uri(url),
                    Timeout = new TimeSpan(0, 2, 0)                   
                };

                httpClient.DefaultRequestHeaders.Add("ContentType", "application/json");

                //This is the key section you were missing    
                //var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(token);
                //string val = System.Convert.ToBase64String(plainTextBytes);
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);

                DebugLogger.WriteLog($"Hit dukcapil async NIK : { dt.nik }");
                DebugLogger.WriteLog($"Hit dukcapil URL : { url }");
                HttpResponseMessage response = await httpClient.PostAsync(url, null);

                string content = string.Empty;
                using (StreamReader stream = new StreamReader(response.Content.ReadAsStreamAsync().Result))
                {
                    content = stream.ReadToEnd();
                }
                //--------------------------------------------------

                resp.Status = "success";

                if (content.ToLower().Replace("\"","") != "success")
                {
                    throw new Exception(content + content.ToLower().Replace("\"", ""));
                }
                ReportLogger.WriteLog($"Hit Dukcapil with NIK : { dt.nik } ( Result : success -- {content} )");
            }
            catch (Exception ex)
            {
                resp.Status = string.Format("failed, {0}", ex.Message);
                ReportLogger.WriteLog($"Hit Dukcapil with NIK : { dt.nik } ( Result : failed -- {ex.Message} )");
            }

            return resp;
        }

        // 2. Save to DB 
        private ResultStatus SaveToDB (IList<ReturnDataDukcapilResponse> listResponse)
        {
            return _returnDataDukcapilRepository.SaveReturnDataDukcapil(listResponse);
        }
    }
}
