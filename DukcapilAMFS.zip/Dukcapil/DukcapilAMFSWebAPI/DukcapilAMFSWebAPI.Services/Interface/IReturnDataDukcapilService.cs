﻿using DukcapilAMFSWebAPI.DTO;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.Services.Interface
{
    public interface IReturnDataDukcapilService
    {
        Task<SubmitReturnDataDukcapilResponseAsync> SubmitReturnDataDukcapilAsync(SubmitReturnDataDukcapilRequestAsync request);
    }

    public class SubmitReturnDataDukcapilResponseAsync : ResponseBase
    {

    }

    public class SubmitReturnDataDukcapilRequestAsync : RequestBase
    {

    }
}