﻿using DukcapilAMFSWebAPI.DTO;

namespace DukcapilAMFSWebAPI.Services.Interface
{
    public interface ICustomerVerificationService
    {
        string VerifyCustomer(RequestVerificationModel model);
    }
}