﻿using DukcapilAMFSWebAPI.DTO;
using System;
using Newtonsoft.Json;
using DukcapilAMFSWebAPI.Repositories.Interface;
using DukcapilAMFSWebAPI.Services.Interface;
using System.Collections.Generic;

namespace DukcapilAMFSWebAPI.Services
{
    public class CustomerVerificationService : ICustomerVerificationService
    {
        ICustomerVerificationRepository _customerVerificationRepository;
        public CustomerVerificationService(ICustomerVerificationRepository customerVerificationRepository)
        {
            DebugLogger.WriteLog($"Service : {this.GetType().Name} has been hit !");
            _customerVerificationRepository = customerVerificationRepository;
        }
        private bool CheckMandatory(RequestVerificationModel model, out string strErrReq)
        {
            //throw new NotImplementedException();
            strErrReq = string.Empty;
            bool bRet = true;
            if (string.IsNullOrEmpty(model.NIK.Trim()))
            {
                bRet = false; strErrReq = strErrReq + "NIK,";
            };
            if (string.IsNullOrEmpty(model.POLICY_NO.Trim()))
            {
                bRet = false; strErrReq = strErrReq + "POLICY_NO,";
            };
            if  (string.IsNullOrEmpty(model.Nama_lgkp.Trim()) && (string.IsNullOrEmpty(model.JENIS_KLMIN.Trim())) &&
                (string.IsNullOrEmpty(model.Tgl_lhr.Trim())) && (string.IsNullOrEmpty(model.Tmpt_lhr.Trim())) &&
                (string.IsNullOrEmpty(model.STATUS_KAWIN.Trim())) && (string.IsNullOrEmpty(model.PDDK_AKH.Trim())) &&
                (string.IsNullOrEmpty(model.Nama_lGKP_Ibu.Trim())) && (string.IsNullOrEmpty(model.JENIS_PKRJN.Trim())) &&
                (string.IsNullOrEmpty(model.PROP_NAME.Trim())) && (string.IsNullOrEmpty(model.KAB_NAME.Trim())) &&
                (string.IsNullOrEmpty(model.KEC_NAME.Trim())) && (string.IsNullOrEmpty(model.KEL_NAME.Trim())) &&
                (string.IsNullOrEmpty(model.ALAMAT.Trim())) && (model.NO_RT == null) && (model.NO_RW == null)
                )
            {
                bRet = false; strErrReq = strErrReq + "Data Lainnya,";
            };

            if (model.UserApps == null || string.IsNullOrEmpty(model.UserApps.Trim()))
            {
                bRet = false; strErrReq = strErrReq + "UserApps,";
            };
            if (model.PassApps == null || string.IsNullOrEmpty(model.PassApps.Trim()))
            {
                bRet = false; strErrReq = strErrReq + "PassApps,";
            };
            if (model.Descriptions == null || string.IsNullOrEmpty(model.Descriptions.Trim()))
            {
                bRet = false; strErrReq = strErrReq + "Descriptions,";
            };

            // remove last char of strErrReq -> ","
            if (strErrReq.Length > 1)
            {
                strErrReq = strErrReq.Remove(strErrReq.Length - 1);
            };

            return bRet;
        }

        public string VerifyCustomer(RequestVerificationModel model)
        {
            string strReturn = "";
            string strErrReq = "";

            try
            {
                if (!CheckMandatory(model, out strErrReq))
                    throw new Exception(string.Format("Cannot Except Data Empty for : {0}.", strErrReq));

                strReturn = _customerVerificationRepository.Verify(model);
            }
            catch (Exception ex)
            {
                strReturn = GenerateResponseOnFailedHit(ex.Message);
            }

            return strReturn;
        }

        private string GenerateResponseOnFailedHit(string msgError)
        {
            string strReturn = "";

            ResponseVerificationModel res = new ResponseVerificationModel();
            res.content = new List<ContentResponseVerificationModel>();
            res.content.Add(new ContentResponseVerificationModel { RESPON = msgError });
            res.lastPage = false;
            res.numberOfElements = 0;
            res.sort = 0;
            res.totalElements = 0;
            res.firstPage = false;
            res.number = 0;
            res.size = 0;
            strReturn = JsonConvert.SerializeObject(res);

            return strReturn;
        }
    }
}
