﻿using DukcapilAMFSWebAPI.DTO;
using System.Collections.Generic;

namespace DukcapilAMFSWebAPI.Repositories.Interface
{
    public interface IReturnDataDukcapilRepository
    {
        ResultStatus SaveReturnDataDukcapil(IList<ReturnDataDukcapilResponse> listResp);
    }
}