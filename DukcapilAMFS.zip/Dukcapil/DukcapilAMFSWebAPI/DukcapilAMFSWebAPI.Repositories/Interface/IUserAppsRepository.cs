﻿namespace DukcapilAMFSWebAPI.Repositories.Interface
{
    public interface IUserAppsRepository
    {
        bool UserAppsIsExist(string UserName);
    }
}