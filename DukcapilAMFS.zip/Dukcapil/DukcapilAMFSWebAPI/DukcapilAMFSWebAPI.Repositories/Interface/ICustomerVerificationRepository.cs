﻿using DukcapilAMFSWebAPI.DTO;
using System.Data;

namespace DukcapilAMFSWebAPI.Repositories.Interface
{
    public interface ICustomerVerificationRepository
    {
        string Verify(RequestVerificationModel model);
    }
}