﻿using DukcapilAMFSWebAPI.DTO;
using DukcapilAMFSWebAPI.Repositories.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.Repositories
{
    public class ReturnDataDukcapilRepository : IReturnDataDukcapilRepository
    {
        public ReturnDataDukcapilRepository()
        {
            DebugLogger.WriteLog($"Repository {this.GetType().Name} has been hit !");
        }
        private string _connectionString = ConfigurationManager.ConnectionStrings["DUKCAPIL_AMFS"].ToString();
        public ResultStatus SaveReturnDataDukcapil(IList<ReturnDataDukcapilResponse> listResp)
        {
            ResultStatus result = new ResultStatus();            
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                sqlConnection.Open();
                foreach (ReturnDataDukcapilResponse resp in listResp)
                {
                    string query = @"insert into NIK_DATABALIKAN([NIK],[Policy_No],[App_Status],[USER_APPS],[STATUS],[Created_Date],[MDM_ID])
					values (@NIK,@Policy_No,@App_Status,@User_Apps,@Status,@Created_Date,@MDM_ID)";

                    using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                    {
                        sqlCommand.CommandType = CommandType.Text;
                        sqlCommand.Parameters.AddWithValue("@NIK", resp.NIK);
                        sqlCommand.Parameters.AddWithValue("@MDM_ID", resp.MDM_ID);
                        sqlCommand.Parameters.AddWithValue("@Policy_No", resp.Policy_No);
                        sqlCommand.Parameters.AddWithValue("@App_Status", resp.App_Status);
                        sqlCommand.Parameters.AddWithValue("@Status", resp.Status);
                        sqlCommand.Parameters.AddWithValue("@User_Apps", resp.User_Apps);
                        sqlCommand.Parameters.AddWithValue("@Created_Date", DateTime.Now);
                        try
                        {
                            sqlCommand.ExecuteReader();
                            result.Messages.Add($"Successfully insert : {resp.NIK} to table NIK_DATABALIKAN");                            
                            result.IsSuccess = true;
                        }
                        catch (Exception ex)
                        {                           
                            result.Messages.Add(ex.Message);
                            result.IsSuccess = false;
                            DebugLogger.WriteLog(ex.Message);
                        }
                    }
                }
                sqlConnection.Close();
            }

            return result;
        }
    }
}
