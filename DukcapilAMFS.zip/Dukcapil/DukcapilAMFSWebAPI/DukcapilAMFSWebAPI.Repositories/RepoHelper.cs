﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.Repositories
{
    public abstract class RepoHelper
    {
        protected HttpClient GetClient(IList<KeyValuePair<string,string>> HeaderParamValueList = null)
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            if (HeaderParamValueList != null)
            {
                foreach(KeyValuePair<string, string> paramValue in HeaderParamValueList)
                {
                    client.DefaultRequestHeaders.Add(paramValue.Key, paramValue.Value);
                }                
            }

            return client;
        }

        protected async Task<TResult> PostAsync<TResult>(string url, HttpContent content, IList<KeyValuePair<string,string>> headerParamList = null)
        {
            HttpClient client = GetClient(headerParamList);
            
            Task<HttpResponseMessage> task = client.PostAsync(url, content);
            task.Wait();

            HttpResponseMessage response = task.Result;           

            DebugLogger.WriteLog("response " + JsonConvert.SerializeObject(response));
            if (!response.IsSuccessStatusCode)
            {
                DebugLogger.WriteLog("failed");
                DebugLogger.WriteLog(task.Exception.InnerException.Message);
                throw new Exception(task.Exception.InnerException.Message);
            }

            else
            {
                DebugLogger.WriteLog("success");
                DebugLogger.WriteLog(task.Exception.InnerException.Message);
                return JsonConvert.DeserializeObject<TResult>(response.Content.ReadAsStringAsync().Result);
            }

            return await response.Content.ReadAsAsync<TResult>(); 
        }
    }
}
