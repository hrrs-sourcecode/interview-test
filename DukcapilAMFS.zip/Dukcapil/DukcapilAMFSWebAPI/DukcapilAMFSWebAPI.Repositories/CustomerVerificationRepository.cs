﻿using DukcapilAMFSWebAPI.DTO;
using DukcapilAMFSWebAPI.Repositories.Interface;
using HastyAPI;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.Repositories
{
    public class CustomerVerificationRepository : ICustomerVerificationRepository
    {
        public CustomerVerificationRepository()
        {
            DebugLogger.WriteLog($"Repository : {this.GetType().Name} has been hit !");
        }

        public string Conn = ConfigurationManager.ConnectionStrings["DUKCAPIL_AMFS"].ToString();
        string const_sp_GET_DATA_USER_API = "sp_GET_DATA_USER_API";
        string const_sp_GET_DATA_MDM_ID_by_policy_no = "sp_GET_DATA_MDM_ID_by_policy_no";
        string const_sp_INSERT_LOGING = "sp_INSERT_LOGING";
        string const_sp_INSERT_NIK_GETDATA = "sp_INSERT_NIK_GETDATA";//for report verification
        string const_sp_INSERT_NIK_GETDATA_MDM = "sp_INSERT_NIK_GETDATA_MDM";//for AUTO MDM DATABALIKAN

        string const_sp_INSERT_NIK_GETDATA_MDM_NEW = "sp_INSERT_NIK_GETDATA_MDM_NEW";//for report and AUTO MDM DATABALIKAN NEW WEB SERVICE

        public string Verify(RequestVerificationModel model)
        {
            string strReturn = "";
            string _connectionString = ConfigurationManager.ConnectionStrings["DUKCAPIL_AMFS"].ToString();
            string _url = ConfigurationManager.AppSettings["url_service_dukcapil_getdata_amfs"].ToString();

            model.user_id = ConfigurationManager.AppSettings["api_user_id"].ToString();
            model.password = ConfigurationManager.AppSettings["api_password"].ToString();
            model.ip_user = ConfigurationManager.AppSettings["api_ip_address"].ToString();

            //DebugLogger.WriteLog(model.user_id + model.password + model.ip_user);

            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                try
                {
                    DataTable dt_User_API = GetDataUserApi(sqlConnection, "", model.UserApps.ToString(), model.PassApps.ToString(), model.Descriptions.ToString());

                    if (dt_User_API.Rows.Count <= 0)
                        throw new Exception(string.Format("User Apps is not Found : {0}.", model.UserApps.ToString()));

                    string result = new APIRequest(_url)
                        .WithData(JsonConvert.SerializeObject(model), "application/json")
                        .Post()
                        .Text;

                    if (result.Length <= 2)
                        throw new Exception(string.Format("No Data"));

                    ResponseVerificationModel objResponse = JsonConvert.DeserializeObject<ResponseVerificationModel>(result);
                    ContentResponseVerificationModel contentRes = objResponse.content[0];

                    if (!string.IsNullOrEmpty(contentRes.RESPON))
                        throw new Exception(contentRes.RESPON);

                    InsertNIKGetDataMDMNew(sqlConnection, model.POLICY_NO, model.NIK, "Data Ditemukan"
                        , model.Nama_lgkp, contentRes.NAMA_LGKP
                        , model.JENIS_KLMIN, contentRes.JENIS_KLMIN
                        , model.Tmpt_lhr, contentRes.TMPT_LHR
                        , model.Tgl_lhr, contentRes.TGL_LHR
                        , model.STATUS_KAWIN, contentRes.STATUS_KAWIN
                        , model.PDDK_AKH, contentRes.PDDK_AKH
                        , model.JENIS_PKRJN, contentRes.JENIS_PKRJN
                        , model.Nama_lGKP_Ibu, contentRes.NAMA_LGKP_IBU
                        , model.PROP_NAME, contentRes.PROP_NAME
                        , model.KAB_NAME, contentRes.KAB_NAME
                        , model.KEC_NAME, contentRes.KEC_NAME
                        , model.KEL_NAME, contentRes.KEL_NAME
                        , model.ALAMAT, contentRes.ALAMAT
                        , model.NO_RT, contentRes.NO_RT
                        , model.NO_RW, contentRes.NO_RW
                        , model.UserApps
                        , "With Data", "");

                    strReturn = result.ToString();
                }

                catch (Exception ex)
                {
                    InsertLogging(sqlConnection, model.UserApps.ToString(), "", model.NIK.ToString(), "", "Rest_API_Dukcapil_DirectVerificationNew", strReturn, ex.Message, 400);
                    throw new Exception(ex.Message);
                }
            }

            return strReturn;
        }

        private DataTable InsertLogging(SqlConnection sqlConnection, string USER_APPS, string USER, string NIK, string RESPONSE_BODY, string APPLICATION, string REQUEST_BODY, string Status, int RESPONSE_CODE)
        {
            DataTable dt = new DataTable();
            SqlParameter[] oParam = new SqlParameter[8];

            oParam[0] = new System.Data.SqlClient.SqlParameter("@USER_APPS", SqlDbType.VarChar);
            oParam[0].Value = System.Convert.ToString(USER_APPS);

            oParam[1] = new System.Data.SqlClient.SqlParameter("@USER", SqlDbType.VarChar);
            oParam[1].Value = System.Convert.ToString(USER);

            oParam[2] = new System.Data.SqlClient.SqlParameter("@NIK", SqlDbType.VarChar);
            oParam[2].Value = System.Convert.ToString(NIK);

            oParam[3] = new System.Data.SqlClient.SqlParameter("@RESPONSE_BODY", SqlDbType.VarChar);
            oParam[3].Value = System.Convert.ToString(RESPONSE_BODY);

            oParam[4] = new System.Data.SqlClient.SqlParameter("@APPLICATION", SqlDbType.VarChar);
            oParam[4].Value = System.Convert.ToString(APPLICATION);

            oParam[5] = new System.Data.SqlClient.SqlParameter("@REQUEST_BODY", SqlDbType.VarChar);
            oParam[5].Value = System.Convert.ToString(REQUEST_BODY);

            oParam[6] = new System.Data.SqlClient.SqlParameter("@STATUS", SqlDbType.VarChar);
            oParam[6].Value = System.Convert.ToString(Status);

            oParam[7] = new System.Data.SqlClient.SqlParameter("@RESPONSE_CODE", SqlDbType.Int);
            oParam[7].Value = System.Convert.ToString(RESPONSE_CODE);

            string query = const_sp_INSERT_LOGING;
            using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
            {
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddRange(oParam);
                SqlDataAdapter sqlda = new SqlDataAdapter(sqlCommand);
                sqlda.Fill(dt);
            }
            return dt;
        }

        private DataTable GetDataUserApi(SqlConnection sqlConnection,string strID, string strUserName, string strPassword, string strDescriptions)
        {
            DataTable dt = new DataTable();
            SqlParameter[] oParam = new SqlParameter[5];
            oParam[0] = new System.Data.SqlClient.SqlParameter("@ID", SqlDbType.VarChar);
            oParam[0].Value = System.Convert.ToString(strID);

            oParam[1] = new System.Data.SqlClient.SqlParameter("@User_Apps", SqlDbType.VarChar);
            oParam[1].Value = System.Convert.ToString(strUserName);

            oParam[2] = new System.Data.SqlClient.SqlParameter("@Password_Apps", SqlDbType.VarChar);
            oParam[2].Value = System.Convert.ToString(strPassword);

            oParam[3] = new System.Data.SqlClient.SqlParameter("@Descriptions_Apps", SqlDbType.VarChar);
            oParam[3].Value = System.Convert.ToString(strDescriptions);

            oParam[4] = new System.Data.SqlClient.SqlParameter("@Is_Active", SqlDbType.VarChar);
            oParam[4].Value = System.Convert.ToString(1); // default we search data with is_active = 1

            string query = const_sp_GET_DATA_USER_API;
            using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
            {
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddRange(oParam);
                SqlDataAdapter sqlda = new SqlDataAdapter(sqlCommand);
                sqlda.Fill(dt);
            }
            return dt;
        }

        private DataTable GetDataMDMIDByPolicyNo(SqlConnection sqlConnection, string strPolicy_No)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            SqlParameter[] oParam = new SqlParameter[1];
            oParam[0] = new System.Data.SqlClient.SqlParameter("@POLICY_NO", SqlDbType.VarChar);
            oParam[0].Value = System.Convert.ToString(strPolicy_No);

            string query = const_sp_GET_DATA_MDM_ID_by_policy_no;
            using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
            {
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddRange(oParam);
                SqlDataAdapter sqlda = new SqlDataAdapter(sqlCommand);
                sqlda.Fill(dt);
            }
            return dt;
        }

        private DataTable InsertNIKGetDataMDMNew(SqlConnection sqlConnection, string str_POLICY_NO, string str_NIK, string str_STATUS_RESPONSE_NIK, string str_NAMA_LGKP, string str_STATUS_RESPONSE_NAMA_LGKP
, string str_JENIS_KLMIN, string str_STATUS_RESPONSE_JENIS_KLMIN, string str_TMPT_LHR, string str_STATUS_RESPONSE_TMPT_LHR, string str_TGL_LHR
, string str_STATUS_RESPONSE_TGL_LHR, string str_STATUS_KAWIN, string str_STATUS_RESPONSE_STATUS_KAWIN, string str_PDDK_AKH, string str_STATUS_RESPONSE_PDDK_AKH
, string str_JENIS_PKRJN, string str_STATUS_RESPONSE_JENIS_PKRJN, string str_NAMA_LGKP_IBU, string str_STATUS_RESPONSE_NAMA_LGKP_IBU, string str_PROP_NAME
, string str_STATUS_RESPONSE_PROP_NAME, string str_KAB_NAME, string str_STATUS_RESPONSE_KAB_NAME, string str_KEC_NAME, string str_STATUS_RESPONSE_KEC_NAME
, string str_KEL_NAME, string str_STATUS_RESPONSE_KEL_NAME, string str_ALAMAT, string str_STATUS_RESPONSE_ALAMAT, int? i_NO_RT
, string str_STATUS_RESPONSE_NO_RT, int? i_NO_RW, string str_STATUS_RESPONSE_NO_RW, string str_USER_APPS, string str_STATUS_REQUEST
, string str_MDM_ID)
        {
            //string str_JENIS_KLMIN2 = str_JENIS_KLMIN.ToLower() == "M" ? "LAKI-LAKI" : "PEREMPUAN";
            //if (str_JENIS_KLMIN.Length == 0) str_JENIS_KLMIN2 = "";
            DataTable dt = new DataTable();
            SqlParameter[] oParam = new SqlParameter[36];


            oParam[0] = new System.Data.SqlClient.SqlParameter("@POLICY_NO", SqlDbType.VarChar);
            oParam[0].Value = System.Convert.ToString(str_POLICY_NO);
            oParam[1] = new System.Data.SqlClient.SqlParameter("@NIK", SqlDbType.VarChar);
            oParam[1].Value = System.Convert.ToString(str_NIK);
            oParam[2] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_NIK", SqlDbType.VarChar);
            oParam[2].Value = System.Convert.ToString(str_STATUS_RESPONSE_NIK);

            oParam[3] = new System.Data.SqlClient.SqlParameter("@USER_APPS", SqlDbType.VarChar);
            oParam[3].Value = System.Convert.ToString(str_USER_APPS);
            oParam[4] = new System.Data.SqlClient.SqlParameter("@STATUS_REQUEST", SqlDbType.VarChar);
            oParam[4].Value = System.Convert.ToString(str_STATUS_REQUEST);
            oParam[5] = new System.Data.SqlClient.SqlParameter("@MDM_ID", SqlDbType.VarChar);
            oParam[5].Value = string.IsNullOrEmpty(str_MDM_ID) ? null : System.Convert.ToString(str_MDM_ID);


            //for (int i = 3; i < 35; i++) oParam[i].IsNullable = true;

            oParam[6] = new System.Data.SqlClient.SqlParameter("@NAMA_LGKP", SqlDbType.VarChar);
            oParam[6].Value = string.IsNullOrEmpty(str_NAMA_LGKP) ? null : System.Convert.ToString(str_NAMA_LGKP);
            oParam[7] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_NAMA_LGKP", SqlDbType.VarChar);
            oParam[7].Value = string.IsNullOrEmpty(str_NAMA_LGKP) ? null : System.Convert.ToString(str_STATUS_RESPONSE_NAMA_LGKP);

            oParam[8] = new System.Data.SqlClient.SqlParameter("@JENIS_KLMIN", SqlDbType.VarChar);
            oParam[8].Value = string.IsNullOrEmpty(str_JENIS_KLMIN) ? null : System.Convert.ToString(str_JENIS_KLMIN);
            oParam[9] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_JENIS_KLMIN", SqlDbType.VarChar);
            oParam[9].Value = string.IsNullOrEmpty(str_JENIS_KLMIN) ? null : System.Convert.ToString(str_STATUS_RESPONSE_JENIS_KLMIN);

            oParam[10] = new System.Data.SqlClient.SqlParameter("@TMPT_LHR", SqlDbType.VarChar);
            oParam[10].Value = string.IsNullOrEmpty(str_TMPT_LHR) ? null : System.Convert.ToString(str_TMPT_LHR);
            oParam[11] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_TMPT_LHR", SqlDbType.VarChar);
            oParam[11].Value = string.IsNullOrEmpty(str_TMPT_LHR) ? null : System.Convert.ToString(str_STATUS_RESPONSE_TMPT_LHR);

            oParam[12] = new System.Data.SqlClient.SqlParameter("@TGL_LHR", SqlDbType.VarChar);
            oParam[12].Value = string.IsNullOrEmpty(str_TGL_LHR) ? null : System.Convert.ToString(str_TGL_LHR);
            oParam[13] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_TGL_LHR", SqlDbType.VarChar);
            oParam[13].Value = string.IsNullOrEmpty(str_TGL_LHR) ? null : System.Convert.ToString(str_STATUS_RESPONSE_TGL_LHR);

            oParam[14] = new System.Data.SqlClient.SqlParameter("@STATUS_KAWIN", SqlDbType.VarChar);
            oParam[14].Value = string.IsNullOrEmpty(str_STATUS_KAWIN) ? null : System.Convert.ToString(str_STATUS_KAWIN);
            oParam[15] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_STATUS_KAWIN", SqlDbType.VarChar);
            oParam[15].Value = string.IsNullOrEmpty(str_STATUS_KAWIN) ? null : System.Convert.ToString(str_STATUS_RESPONSE_STATUS_KAWIN);

            oParam[16] = new System.Data.SqlClient.SqlParameter("@PDDK_AKH", SqlDbType.VarChar);
            oParam[16].Value = string.IsNullOrEmpty(str_PDDK_AKH) ? null : System.Convert.ToString(str_PDDK_AKH);
            oParam[17] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_PDDK_AKH", SqlDbType.VarChar);
            oParam[17].Value = string.IsNullOrEmpty(str_PDDK_AKH) ? null : System.Convert.ToString(str_STATUS_RESPONSE_PDDK_AKH);

            oParam[18] = new System.Data.SqlClient.SqlParameter("@JENIS_PKRJN", SqlDbType.VarChar);
            oParam[18].Value = string.IsNullOrEmpty(str_JENIS_PKRJN) ? null : System.Convert.ToString(str_JENIS_PKRJN);
            oParam[19] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_JENIS_PKRJN", SqlDbType.VarChar);
            oParam[19].Value = string.IsNullOrEmpty(str_JENIS_PKRJN) ? null : System.Convert.ToString(str_STATUS_RESPONSE_JENIS_PKRJN);

            oParam[20] = new System.Data.SqlClient.SqlParameter("@NAMA_LGKP_IBU", SqlDbType.VarChar);
            oParam[20].Value = string.IsNullOrEmpty(str_NAMA_LGKP_IBU) ? null : System.Convert.ToString(str_NAMA_LGKP_IBU);
            oParam[21] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_NAMA_LGKP_IBU", SqlDbType.VarChar);
            oParam[21].Value = string.IsNullOrEmpty(str_NAMA_LGKP_IBU) ? null : System.Convert.ToString(str_STATUS_RESPONSE_NAMA_LGKP_IBU);

            oParam[22] = new System.Data.SqlClient.SqlParameter("@PROP_NAME", SqlDbType.VarChar);
            oParam[22].Value = string.IsNullOrEmpty(str_PROP_NAME) ? null : System.Convert.ToString(str_PROP_NAME);
            oParam[23] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_PROP_NAME", SqlDbType.VarChar);
            oParam[23].Value = string.IsNullOrEmpty(str_PROP_NAME) ? null : System.Convert.ToString(str_STATUS_RESPONSE_PROP_NAME);

            oParam[24] = new System.Data.SqlClient.SqlParameter("@KAB_NAME", SqlDbType.VarChar);
            oParam[24].Value = string.IsNullOrEmpty(str_KAB_NAME) ? null : System.Convert.ToString(str_KAB_NAME);
            oParam[25] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_KAB_NAME", SqlDbType.VarChar);
            oParam[25].Value = string.IsNullOrEmpty(str_KAB_NAME) ? null : System.Convert.ToString(str_STATUS_RESPONSE_KAB_NAME);

            oParam[26] = new System.Data.SqlClient.SqlParameter("@KEC_NAME", SqlDbType.VarChar);
            oParam[26].Value = string.IsNullOrEmpty(str_KEC_NAME) ? null : System.Convert.ToString(str_KEC_NAME);
            oParam[27] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_KEC_NAME", SqlDbType.VarChar);
            oParam[27].Value = string.IsNullOrEmpty(str_KEC_NAME) ? null : System.Convert.ToString(str_STATUS_RESPONSE_KEC_NAME);

            oParam[28] = new System.Data.SqlClient.SqlParameter("@KEL_NAME", SqlDbType.VarChar);
            oParam[28].Value = string.IsNullOrEmpty(str_KEL_NAME) ? null : System.Convert.ToString(str_KEL_NAME);
            oParam[29] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_KEL_NAME", SqlDbType.VarChar);
            oParam[29].Value = string.IsNullOrEmpty(str_KEL_NAME) ? null : System.Convert.ToString(str_STATUS_RESPONSE_KEL_NAME);

            oParam[30] = new System.Data.SqlClient.SqlParameter("@ALAMAT", SqlDbType.VarChar);
            oParam[30].Value = string.IsNullOrEmpty(str_ALAMAT) ? null : System.Convert.ToString(str_ALAMAT);
            oParam[31] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_ALAMAT", SqlDbType.VarChar);
            oParam[31].Value = string.IsNullOrEmpty(str_ALAMAT) ? null : System.Convert.ToString(str_STATUS_RESPONSE_ALAMAT);

            oParam[32] = new System.Data.SqlClient.SqlParameter("@NO_RT", SqlDbType.VarChar);
            oParam[32].Value = i_NO_RT == null ? null : System.Convert.ToString(i_NO_RT);
            oParam[33] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_NO_RT", SqlDbType.VarChar);
            oParam[33].Value = i_NO_RT == null ? null : System.Convert.ToString(str_STATUS_RESPONSE_NO_RT);

            oParam[34] = new System.Data.SqlClient.SqlParameter("@NO_RW", SqlDbType.VarChar);
            oParam[34].Value = i_NO_RW == null ? null : System.Convert.ToString(i_NO_RW);
            oParam[35] = new System.Data.SqlClient.SqlParameter("@STATUS_RESPONSE_NO_RW", SqlDbType.VarChar);
            oParam[35].Value = i_NO_RW == null ? null : System.Convert.ToString(str_STATUS_RESPONSE_NO_RW);

            string query = const_sp_INSERT_NIK_GETDATA_MDM_NEW;
            using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
            {
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddRange(oParam);
                SqlDataAdapter sqlda = new SqlDataAdapter(sqlCommand);
                sqlda.Fill(dt);
            }
            return dt;
        }
    }
}
