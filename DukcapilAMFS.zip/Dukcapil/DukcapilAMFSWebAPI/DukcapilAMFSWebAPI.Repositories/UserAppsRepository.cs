﻿using DukcapilAMFSWebAPI.DTO;
using DukcapilAMFSWebAPI.Repositories.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.Repositories
{
    public class UserAppsRepository : IUserAppsRepository
    {
        public UserAppsRepository()
        {
            DebugLogger.WriteLog($"Repository {this.GetType().Name} has been hit !");
        }
        private string _connectionString = ConfigurationManager.ConnectionStrings["DUKCAPIL_AMFS"].ToString();
        public bool UserAppsIsExist(string UserName)
        {
            ResultStatus result = new ResultStatus();
            bool status = false;
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                sqlConnection.Open();

                string query = @"sp_GET_DATA_USER_API";

                using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.Parameters.AddWithValue("@User_Apps", UserName);

                    try
                    {
                        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                        {
                            status = sqlDataReader.HasRows;
                        }
                    }
                    catch
                    {
                        status = false;
                    }
                }
                sqlConnection.Close();
            }

            return status;
        }
    }
}
