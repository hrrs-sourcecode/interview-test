﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.DTO
{
    public class ReturnDataDukcapil
    {
        public string nik { get; set; }
        public string policy_no { get; set; }
        public string id_lembaga { get; set; }
        public string nama_lembaga { get; set; }
        public string param { get; set; }
    }
}
