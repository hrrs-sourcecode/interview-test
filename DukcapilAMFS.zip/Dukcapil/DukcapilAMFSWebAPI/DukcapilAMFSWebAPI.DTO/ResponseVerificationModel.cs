﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.DTO
{
    public class ResponseVerificationModel
    {
        public List<ContentResponseVerificationModel> content { get; set; }
        public Boolean? lastPage { get; set; }
        public int? numberOfElements { get; set; }
        public int? sort { get; set; }
        public int? totalElements { get; set; }
        public Boolean? firstPage { get; set; }
        public int? number { get; set; }
        public int? size { get; set; }

    }
}
