﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.DTO
{
    public class RequestBase
    {
        public string UserName { get; set; }
        public object SearchCriteriaList { get; set; }
        public object Data { get; set; }
    }
}
