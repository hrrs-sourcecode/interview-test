﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.DTO
{
    public class RequestVerificationModel : CustomerVerificationModel
    {
        public string POLICY_NO { get; set; }
       
        /// <summary>  
        /// Name of User Application - from table user_api
        /// </summary>  
        [Required(ErrorMessage = "UserApps Cannot Empty...")]
        public string UserApps { get; set; }
        /// <summary>  
        /// Pass of User Application - from table user_api
        /// </summary>  
        [Required(ErrorMessage = "PassApps Cannot Empty...")]
        public string PassApps { get; set; }
        /// <summary>  
        /// Descriptions of Application - from table user_api
        /// </summary>  
        [Required(ErrorMessage = "Descriptions Cannot Empty...")]
        public string Descriptions { get; set; }
    }
}
