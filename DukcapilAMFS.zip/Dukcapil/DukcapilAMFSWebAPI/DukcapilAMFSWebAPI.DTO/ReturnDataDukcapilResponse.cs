﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI.DTO
{
    public class ReturnDataDukcapilResponse
    {
        public string NIK { get; set; }

        public string Policy_No { get; set; }

        public string App_Status { get; set; }

        public string User_Apps { get; set; }

        public string Status { get; set; }

        public DateTime Created_Date { get; set; }

        public DateTime? Updated_Date { get; set; }

        public string MDM_ID { get; set; }
    }
}
