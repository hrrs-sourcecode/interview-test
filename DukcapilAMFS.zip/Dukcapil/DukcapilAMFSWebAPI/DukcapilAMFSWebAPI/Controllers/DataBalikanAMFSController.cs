﻿using DukcapilAMFSWebAPI.DTO;
using DukcapilAMFSWebAPI.Repositories;
using DukcapilAMFSWebAPI.Services;
using DukcapilAMFSWebAPI.Services.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace DukcapilAMFSWebAPI.Controllers
{
    public class DataBalikanAMFSController : ApiController
    {
        public DataBalikanAMFSController()
        {
            Logger.WriteLog2File($"Controller {this.GetType().Name} has been hit !");
        }

        [HttpPost]
        public async Task<SubmitReturnDataDukcapilResponseAsync> SubmitReturnDataDukcapilAsync(SubmitReturnDataDukcapilRequestAsync model)
        {           
            SubmitReturnDataDukcapilResponseAsync result = new SubmitReturnDataDukcapilResponseAsync();           

            IReturnDataDukcapilService svc = new ReturnDataDukcapilService(new ReturnDataDukcapilRepository());
            result = await svc.SubmitReturnDataDukcapilAsync(model);

            if (!result.IsSuccess)
            {
                result.Messages.ForEach(msg => Logger.WriteLog2File(msg));
            }

            return result;
        }
    }
}
