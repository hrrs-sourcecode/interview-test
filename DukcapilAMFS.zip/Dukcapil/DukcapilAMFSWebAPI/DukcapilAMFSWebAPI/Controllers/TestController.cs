﻿using DukcapilAMFSWebAPI.DTO;
using DukcapilAMFSWebAPI.Repositories;
using DukcapilAMFSWebAPI.Services;
using DukcapilAMFSWebAPI.Services.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace DukcapilAMFSWebAPI.Controllers
{
    public class TestController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        //[HttpPost]
        //public string VerififyCustomer([FromBody]RequestVerificationModel model)
        //{
        //    ICustomerVerificationService svc = new CustomerVerificationService(new CustomerVerificationRepository());
        //    return svc.VerifyCustomer(model);
        //}

        public string POST(RequestVerificationModel model)
        {
            string result = "";
            Logger.WriteLog2File("svc started");
            try
            {
                ICustomerVerificationService svc = new CustomerVerificationService(new CustomerVerificationRepository());
                result = svc.VerifyCustomer(model);
            }
            catch (Exception ex)
            {
                Logger.WriteLog2File(ex.Message);
                Logger.WriteLog2File("svc error");
            }

            return result;
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
