﻿using DukcapilAMFSWebAPI.DTO;
using DukcapilAMFSWebAPI.Repositories;
using DukcapilAMFSWebAPI.Services;
using DukcapilAMFSWebAPI.Services.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace DukcapilAMFSWebAPI.Controllers
{
    public class DirectVerificationAMFSController : ApiController
    {
        public DirectVerificationAMFSController()
        {
            Logger.WriteLog2File($"Controller : {this.GetType().Name} has been hit !");
        }
        public string POST(RequestVerificationModel model)
        {
            string result = "";

            try
            {
                ICustomerVerificationService svc = new CustomerVerificationService(new CustomerVerificationRepository());            
                result = svc.VerifyCustomer(model);
            }
            catch (Exception ex)
            {
                Logger.WriteLog2File(ex.InnerException.Message);
                result = ex.Message;
            }

            return result;
        }
    }
}
