﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace DukcapilAMFSWebAPI
{
    public static class Logger
    {
        private static string GetVisitorIP()
        {
            string VisitorsIPAddr = string.Empty;

            if (HttpContext.Current != null)
            {
                if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
                {
                    VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
                }
                else if (HttpContext.Current.Request.UserHostAddress.Length != 0)
                {
                    VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
                }
            }
            return VisitorsIPAddr;
        }
        public static void WriteLog2File(string msg)
        {
            string _folderPath = System.Web.Hosting.HostingEnvironment.MapPath("~/Logs");
            string path = string.Format(@"{0}\{1}\{2}\Log-{3}.txt", _folderPath, DateTime.Now.ToString("yyyy"), DateTime.Now.ToString("MMMM"), DateTime.Now.ToString("yyyy-MM-dd"));
            FileInfo fileInfo = new FileInfo(path);
            fileInfo.Directory.Create();

            using (StreamWriter tw = new StreamWriter(path, true))
            {
                string user = GetVisitorIP();
                tw.WriteLine(msg);
            }
        }
    }
}