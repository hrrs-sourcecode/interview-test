﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Configuration;
using System.IO;
using System.Threading.Tasks;

namespace DukcapilAMFSWebAPI
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        private string _folderPath = "";
        private string _userIp = "";
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        private string GetVisitorIP()
        {
            string VisitorsIPAddr = string.Empty;

            if (HttpContext.Current != null)
            {
                if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
                {
                    VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
                }
                else if (HttpContext.Current.Request.UserHostAddress.Length != 0)
                {
                    VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
                }
            }
            return VisitorsIPAddr;
        }

        public WebApiApplication()
        {
            _folderPath = System.Web.Hosting.HostingEnvironment.MapPath("~/Logs");
            _userIp = GetVisitorIP();
        }

        protected void Application_BeginRequest(Object sender, EventArgs e)
        {
            if (HttpContext.Current.Request.HttpMethod == "POST")
            {
                string controllerName = HttpContext.Current.Request.Url.ToString().Split('/')[3];
                string actionName = HttpContext.Current.Request.Url.ToString().Split('/')[4];
                string dateTime = DateTime.Now.ToString("dd-MMM-yyyy (hh:mm:ss tt)").Replace('.', ':');

                Logger.WriteLog2File("===========================================================================");
                Logger.WriteLog2File(string.Format("Start Request {0}/{1} from IP: {2} on {3}", controllerName, actionName, _userIp, dateTime));
            }
        }

        protected void Application_EndRequest(Object sender, EventArgs e)
        {
            if (HttpContext.Current.Request.HttpMethod == "POST")
            {
                string controllerName = HttpContext.Current.Request.Url.ToString().Split('/')[3];
                string actionName = HttpContext.Current.Request.Url.ToString().Split('/')[4];
                string dateTime = DateTime.Now.ToString("dd-MMM-yyyy (hh:mm:ss tt)").Replace('.', ':');

                Logger.WriteLog2File(string.Format("End Request {0}/{1} from IP: {2} on {3}", controllerName, actionName, _userIp, dateTime));
                Logger.WriteLog2File("===========================================================================");
            }
        }

        /// <summary>
        /// WriteLog2File
        /// </summary>
        /// <param name="strMsg"></param>
        //public async Task WriteLog2File(string msg)
        //{
        //    string path = string.Format(@"{0}\{1}\{2}\Log-{3}.txt", _folderPath, DateTime.Now.ToString("yyyy"), DateTime.Now.ToString("MMMM"), DateTime.Now.ToString("yyyy-MM-dd"));
        //    FileInfo fileInfo = new FileInfo(path);
        //    fileInfo.Directory.Create();

        //    using (StreamWriter tw = new StreamWriter(path, true))
        //    {
        //        string user = GetVisitorIP();
        //        tw.WriteLine(msg);
        //    }
        //}
    }
}
