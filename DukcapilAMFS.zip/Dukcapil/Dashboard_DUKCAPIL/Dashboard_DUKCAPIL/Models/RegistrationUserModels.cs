﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dashboard_DUKCAPIL.Models
{
    public class RegistrationUserModels
    {
        public string Pass_App { get; set; }
        public string User_App { get; set; }
        public string FirstName { get; set;}
        public string LastName { get; set; }
        public string Disabled { get; set; }
        
        // Dukcapil

        public string USER_DUKCAPIL { get; set; }
        public string Pass_DUKCAPIL { get; set; }
        public string FirstName_DUKCAPIL { get; set; }
        public string LastName_DUKCAPIL { get; set; }
        public string NIP { get; set; }
        public IEnumerable<SelectListItem> UserFor { get; set; }
        public string UserForID { get; set; }
    }

    public class RegistrationUserApiModels
    {
        public string User_Apps { get; set; }
        public string Password_Apps { get; set; }
        public string Descriptions_Apps { get; set; }
        public bool Is_Active { get; set; }
        public string User { get; set; }

        public IEnumerable<SelectListItem> lst_Desc_Apps { get; set; }

        public List<ViewUserApiModels> lst_user_api { get; set; }

    }
    public class ViewUserApiModels
    {
        public string Id { get; set; }
        public string User_Apps { get; set; }
        public string Password_Apps { get; set; }
        public string Descriptions_Apps { get; set; }
        public string Is_Active { get; set; }
        public IEnumerable<SelectListItem> lst_Desc_Apps { get; set; }
    }
    public class DeptHeadModels
    {
        [Required(ErrorMessage = "Departement is required")]
        public string Departement { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [DataType(DataType.EmailAddress)]
        [EmailAddress]
        public string Email { get; set; }
        public int Is_Active { get; set; }

        public IEnumerable<SelectListItem> lst_isActive { get; set; }
        public IEnumerable<SelectListItem> lst_Dept { get; set; }
        public List<ViewDeptHeadModels> lst_view_Dept { get; set; }

    }
    public class ViewDeptHeadModels
    {
        public string Id { get; set; }
        public string Departement { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Is_Active { get; set; }
        public IEnumerable<SelectListItem> lst_isActive { get; set; }

    }
}