﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dashboard_DUKCAPIL.Models
{
    public class Dashboard
    {
        //public string EmployeeName { get; set; }
        //public string EmployeeID { get; set; }

        public Dashboard(int yx,string labelx,string LegendTextx)
        {
            this.y = yx;
            this.label = labelx;
            this.legendText = LegendTextx;
        }

        //Explicitly setting the name to be used while serializing to JSON.

        public Nullable<int> y = null;
        public string label = "";
        public string legendText = "";

        public int Count_HIT_DUKCAPIL { get; set; }
        public int Success_HIT_DUKCAPIL { get; set; }
        public int Failed_HIT_DUKCAPIL { get; set; }

        public int Count_HIT_MDM { get; set; }
        public int Success_HIT_MDM { get; set; }
        public int Failed_HIT_MDM { get; set; }
        //Explicitly setting the name to be used while serializing to JSON.

    }
}