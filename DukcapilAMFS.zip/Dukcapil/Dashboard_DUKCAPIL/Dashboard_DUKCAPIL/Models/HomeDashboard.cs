﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dashboard_DUKCAPIL.Models
{
    public class HomeDashboard
    {

        public int Count_HIT_DUKCAPIL { get; set; }
        public int Success_HIT_DUKCAPIL { get; set; }
        public int Failed_HIT_DUKCAPIL { get; set; }

        public int Count_HIT_MDM { get; set; }
        public int Success_HIT_MDM { get; set; }
        public int Failed_HIT_MDM { get; set; }

        public List<DashboardByDept> lstByDept { get; set; }
    }
    public class DashboardByDept
    {
        public int Count_HIT_DUKCAPIL { get; set; }
        public int Success_HIT_DUKCAPIL { get; set; }
        public int Failed_HIT_DUKCAPIL { get; set; }
        public string Departement { get; set; }

    }
}