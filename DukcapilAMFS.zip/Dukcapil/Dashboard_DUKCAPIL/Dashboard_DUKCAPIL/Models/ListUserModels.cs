﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dashboard_DUKCAPIL.Models
{
    public class ListUserModels
    {
        public string EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Role { get; set; }
        public string RoleID { get; set; }
        public IEnumerable<SelectListItem> Roles { get; set; }
        public string MenuName { get; set; }
    }
}