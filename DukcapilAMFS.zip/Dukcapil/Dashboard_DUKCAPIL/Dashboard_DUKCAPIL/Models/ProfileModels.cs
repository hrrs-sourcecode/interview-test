﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dashboard_DUKCAPIL.Models
{
    public class ProfileModels
    {
        [Required]
        [Display(Name = "Employee ID")]
        public string EmployeeID { get; set; }

        [Required]
        [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }

        [Required]
        public string Department { get; set; }
        public string CreatedBy { get; set; }

        [Required]
        [Display(Name = "User Apps")]
        public string UserApps { get; set; }
        public string FlagID { get; set; }

        [Required]
        [Display(Name = "Role")]
        public string RoleID { get; set; }
        public bool isDashboard { get; set; }
        public bool isVerification { get; set; }
        public bool isDatabalikan { get; set; }
        public bool isReport { get; set; }
        public bool isRptVerification { get; set; }
        public bool isRptDatabalikan { get; set; }
        public IEnumerable<SelectListItem> Flag { get; set; }
        public IEnumerable<SelectListItem> DeptLst { get; set; }
        public IEnumerable<SelectListItem> RoleLst { get; set; }

        //public ICollection<PrivilageModels> PrivLst { get; set; }
    }
    //public class PrivilageModels
    //{
    //    public bool isDashboard { get; set; }
    //    public bool isVerification { get; set; }
    //    public bool isDatabalikan { get; set; }
    //    public bool isReport { get; set; }
    //    public bool isRptVerification { get; set; }
    //    public bool isRptDatabalikan { get; set; }

    //}
}