﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dashboard_DUKCAPIL.Models
{
    public class PagedList_ListUserMatrix <T>
    {
        public IEnumerable<SelectListItem> Result { get; set; }
        public string EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string RoleID { get; set; }
        public IEnumerable<SelectListItem> Role { get; set; }
        public List<T> Content { get; set; }
    }
}
