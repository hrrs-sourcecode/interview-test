﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dashboard_DUKCAPIL.Models
{
    public class PagedList_Report_Databalikan<T>
    {
        public string NIK { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM-dd-yyyy}")]
        public DateTime Start_Date { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM-dd-yyyy}")]
        public DateTime End_Date { get; set; }
        public string Policy_No { get; set; }
        public string Aplication_Status { get; set; }
        public string USER_APPS { get; set; }
        public string Status { get; set; }
        public IEnumerable<SelectListItem> lst_USER_APPS { get; set; }
        public IEnumerable<SelectListItem> lst_Status { get; set; }
        public string MenuName { get; set; }
        public List<T> Content { get; set; }
    }
    public class ReportDatabalikanModels
    {
        public string NIK { get; set; }
        public string Policy_No { get; set; }
        public string MDM_ID { get; set; }
        public string App_Status { get; set; }
        public string Submit_Date { get; set; }
        public string USER_APPS { get; set; }
        public string Status { get; set; }
    }

    public class PagedList_Report_Verification<T>
    {
        public string NIK { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM-dd-yyyy}")]
        public DateTime Start_Date { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM-dd-yyyy}")]
        public DateTime End_Date { get; set; }
        public string Name { get; set; }
        public string Status_Data { get; set; }
        public string USER_APPS { get; set; }
        public IEnumerable<SelectListItem> lst_USER_APPS { get; set; }
        public IEnumerable<SelectListItem> lst_Status { get; set; }
        public string MenuName { get; set; }
        public List<T> Content { get; set; }
    }
    public class ReportVerificationModels
    {
        public string NIK { get; set; }
        public string NAMA_LGKP { get; set; }
        public string REQUEST_DATE { get; set; }
        public string USER_APPS { get; set; }
        public string STATUS_DATA { get; set; }
        public string MDM_ID { get; set; }
    }

    //for New Service 13/04/2021
    public class ReportVerificationNewModels
    {
        public string POLICY_NO  { get; set; }
        public string NIK { get; set; }
        public string STATUS_RESPONSE_NIK { get; set; }
        public string NAMA_LGKP { get; set; }
        public string STATUS_RESPONSE_NAMA_LGKP { get; set; }
        public string JENIS_KLMIN { get; set; }
        public string STATUS_RESPONSE_JENIS_KLMIN { get; set; }
        public string TMPT_LHR { get; set; }
        public string STATUS_RESPONSE_TMPT_LHR { get; set; }
        public string TGL_LHR { get; set; }
        public string STATUS_RESPONSE_TGL_LHR { get; set; }
        public string STATUS_KAWIN { get; set; }
        public string STATUS_RESPONSE_STATUS_KAWIN { get; set; }
        public string PDDK_AKH { get; set; }
        public string STATUS_RESPONSE_PDDK_AKH { get; set; }
        public string JENIS_PKRJN { get; set; }
        public string STATUS_RESPONSE_JENIS_PKRJN { get; set; }
        public string NAMA_LGKP_IBU { get; set; }
        public string STATUS_RESPONSE_NAMA_LGKP_IBU { get; set; }
        public string PROP_NAME { get; set; }
        public string STATUS_RESPONSE_PROP_NAME { get; set; }
        public string KAB_NAME { get; set; }
        public string STATUS_RESPONSE_KAB_NAME { get; set; }
        public string KEC_NAME { get; set; }
        public string STATUS_RESPONSE_KEC_NAME { get; set; }
        public string KEL_NAME { get; set; }
        public string STATUS_RESPONSE_KEL_NAME { get; set; }
        public string ALAMAT { get; set; }
        public string STATUS_RESPONSE_ALAMAT { get; set; }
        public string NO_RT { get; set; }
        public string STATUS_RESPONSE_NO_RT { get; set; }
        public string NO_RW { get; set; }
        public string STATUS_RESPONSE_NO_RW { get; set; }
        public string USER_APPS { get; set; }
        public string STATUS_REQUEST { get; set; }
        //public string MDM_ID { get; set; }
        public string REQUEST_DATE { get; set; }

    }


    public class PagedList_Report_Log<T>
    {
        public string NIK { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM-dd-yyyy}")]
        public DateTime Start_Date { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM-dd-yyyy}")]
        public DateTime End_Date { get; set; }
        public string Status_Data { get; set; }
        public string USER_APPS { get; set; }
        public string Departement { get; set; }
        public IEnumerable<SelectListItem> lst_USER_APPS { get; set; }
        public IEnumerable<SelectListItem> lst_Status { get; set; }
        public IEnumerable<SelectListItem> lst_Dept { get; set; }
        public string MenuName { get; set; }
        public List<T> Content { get; set; }
    }
    public class ReportLogModels
    {
        public string USER_APPS { get; set; }
        public string DEPARTEMENT { get; set; }
        public string NIK { get; set; }
        public string REQUEST_DATE { get; set; }
        public string STATUS_DATA { get; set; }
    }
}