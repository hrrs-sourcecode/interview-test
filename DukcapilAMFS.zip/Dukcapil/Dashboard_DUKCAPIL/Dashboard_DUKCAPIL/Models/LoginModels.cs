﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dashboard_DUKCAPIL.Models
{
    public class LoginModels
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string EmployeeID { get; set; }
        public string Entity { get; set; }
    }
}