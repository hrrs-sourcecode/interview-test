﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dashboard_DUKCAPIL.Models
{
    //for post submit
    public class DatabalikanModels
    {
        public string NIK { get; set; }
        public string PolicyNo { get; set; }
        public string ApplicationStatus { get; set; }

    }
    // for grid view
    public class FeedbackModels
    {
        public List<DataExcel> lstDataExcel { get; set; }
        public IEnumerable<SelectListItem> Result { get; set; }
        public string NIK { get; set; }
        public string PolicyNo { get; set; }
        public string ApplicationStatus { get; set; }
        public DateTime Submit_Date { get; set; }
        public string User_APPS { get; set; }
        public string STATUS_DATA { get; set; }

    }
    public class DataExcel
    {
        public string NIK { get; set; }
        public string Policy_No { get; set; }
        public string MDM_ID { get; set; }
    }

}