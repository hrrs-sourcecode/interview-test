﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Dashboard_DUKCAPIL.Startup))]
namespace Dashboard_DUKCAPIL
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
