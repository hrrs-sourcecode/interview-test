﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dashboard_DUKCAPIL.Models;
using System.Data.SqlClient;
using Dashboard_DUKCAPIL.Repository;
using System.Data;
using System.Configuration;
using ClosedXML.Excel;
using System.IO;
using static Dashboard_DUKCAPIL.Models.MenuViewModels;

namespace Dashboard_DUKCAPIL.Controllers
{
    public class ReportController : UserMatrixController
    {
        string PassApps = ConfigurationManager.AppSettings["PassWS"].ToString();
        
        // GET: Report
        public ActionResult Index()
        {
            return View();
        }
        public static List<SelectListItem> GET_STATUS_DATABALIKAN(string strSP_Name)
        {
            SqlConnection con = Common.GetConnection();
            List<SelectListItem> item = new List<SelectListItem>();

            item.Add(new SelectListItem
            {
                Text = "",
                Value = "",
                Selected = true
            });

            string query = "exec " + strSP_Name;
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        item.Add(new SelectListItem
                        {
                            Text = dr["Status"].ToString(),
                            Value = dr["Status"].ToString()
                        });
                    }
                }
                con.Close();
            }
            return item;
        }
        public static List<SelectListItem> GET_USER_APPS_DATABALIKAN(string strSP_Name)
        {
            SqlConnection con = Common.GetConnection();
            List<SelectListItem> item = new List<SelectListItem>();

            item.Add(new SelectListItem
            {
                Text = "",
                Value = "",
                Selected = true
            });

            string query = "exec " + strSP_Name;
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        item.Add(new SelectListItem
                        {
                            Text = dr["USER_APPS"].ToString(),
                            Value = dr["USER_APPS"].ToString()
                        });
                    }
                }
                con.Close();
            }
            return item;
        }
        public static List<SelectListItem> GET_DATA_LIST(string strSP_Name)
        {
            SqlConnection con = Common.GetConnection();
            List<SelectListItem> item = new List<SelectListItem>();

            item.Add(new SelectListItem
            {
                Text = "",
                Value = "",
                Selected = true
            });

            string query = "exec " + strSP_Name;
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        item.Add(new SelectListItem
                        {
                            Text = dr[1].ToString(),
                            Value = dr[1].ToString()
                        });
                    }
                }
                con.Close();
            }
            return item;
        }
        // GET: ReportDataFeedback
        [HttpGet]
        public ActionResult ReportDataFeedback()
        {
            PagedList_Report_Databalikan<ReportDatabalikanModels> model = new PagedList_Report_Databalikan<ReportDatabalikanModels>();

            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "ReportController";


                // populate list status
                var lst_Status = GET_STATUS_DATABALIKAN("sp_GET_STATUS_DATABALIKAN");
                List<SelectListItem> _lst_Status = new List<SelectListItem>();
                foreach (var item in lst_Status)
                {
                    _lst_Status.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                }
                model.lst_Status = new SelectList(_lst_Status, "Value", "Text");

                // populate list user apps
                var lst_USER_APPS = GET_USER_APPS_DATABALIKAN("sp_GET_USER_APPS_DATABALIKAN");
                List<SelectListItem> _lst_USER_APPS = new List<SelectListItem>();
                foreach (var item in lst_USER_APPS)
                {
                    _lst_USER_APPS.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                }
                model.lst_USER_APPS = new SelectList(_lst_USER_APPS, "Value", "Text");
                // populate list grid
                model.Content = ListReport_Databalikan("","","","","","","");

            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }
        // Post: ReportDataFeedback
        [HttpPost]
        public ActionResult ReportDataFeedback(PagedList_Report_Databalikan<ReportDatabalikanModels> model, string submit)
        {

            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "ReportController";
                if (submit == "Reset")
                {
                    // go to get this view
                    return RedirectToAction("ReportDataFeedback");
                }
                else
                {
                    // populate list status
                    var lst_Status = GET_STATUS_DATABALIKAN("sp_GET_STATUS_DATABALIKAN");
                    List<SelectListItem> _lst_Status = new List<SelectListItem>();
                    foreach (var item in lst_Status)
                    {
                        _lst_Status.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                    }
                    model.lst_Status = new SelectList(_lst_Status, "Value", "Text");

                    // populate list user apps
                    var lst_USER_APPS = GET_USER_APPS_DATABALIKAN("sp_GET_USER_APPS_DATABALIKAN");
                    List<SelectListItem> _lst_USER_APPS = new List<SelectListItem>();
                    foreach (var item in lst_USER_APPS)
                    {
                        _lst_USER_APPS.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                    }
                    model.lst_USER_APPS = new SelectList(_lst_USER_APPS, "Value", "Text");

                    if (submit == "Search")
                    {
                        DateTime date_empty = Convert.ToDateTime("1/1/0001 12:00:00 AM");
                        string strDate_Start = "";
                        if (model.Start_Date != date_empty) strDate_Start = model.Start_Date.ToString("MM-dd-yyyy");
                        string strDate_End = "";
                        if (model.End_Date != date_empty) strDate_End = model.End_Date.ToString("MM-dd-yyyy");
                        // populate list grid with filters             
                        model.Content = ListReport_Databalikan(model.NIK, model.Policy_No, model.Aplication_Status, model.Status, model.USER_APPS, strDate_Start, strDate_End);
                    }
                    if (submit == "Export")
                    {
                        DateTime date_empty = Convert.ToDateTime("1/1/0001 12:00:00 AM");
                        string strDate_Start = "";
                        if (model.Start_Date != date_empty) strDate_Start = model.Start_Date.ToString("MM-dd-yyyy");
                        string strDate_End = "";
                        if (model.End_Date != date_empty) strDate_End = model.End_Date.ToString("MM-dd-yyyy");
                        // populate list grid with filters             
                        model.Content = ListReport_Databalikan(model.NIK, model.Policy_No, model.Aplication_Status, model.Status, model.USER_APPS, strDate_Start, strDate_End);
                        // populate list for Export with filters              
                        DataTable dt = ExportReport_Databalikan(model.NIK, model.Policy_No, model.Aplication_Status, model.Status, model.USER_APPS, strDate_Start, strDate_End);
                        if (dt.Rows.Count > 0)
                        {
                            using (XLWorkbook wb = new XLWorkbook())
                            {
                                if (dt.Columns.Contains("APP_STATUS")) dt.Columns.Remove("APP_STATUS");
                                wb.Worksheets.Add(dt, "Report Databalikan");

                                Response.Clear();
                                Response.Buffer = true;
                                Response.Charset = "";
                                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                                Response.AddHeader("content-disposition", "attachment;filename=Dukcapil_Report_Databalikan_" + DateTime.Now.ToString("yyyyMMdd") + ".xlsx");
                                using (MemoryStream MyMemoryStream = new MemoryStream())
                                {
                                    wb.SaveAs(MyMemoryStream);
                                    MyMemoryStream.WriteTo(Response.OutputStream);
                                    Response.Flush();
                                    Response.End();
                                }
                            }
                        }
                        else TempData["messageRequest"] = "<script>alert('" + "No Data Found" + "');</script>";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }

        /// <summary>
        /// ListReport_Databalikan - all params is optional, can be string empty
        /// </summary>
        /// <param name="strNIK"></param>
        /// <param name="strPol_No"></param>
        /// <param name="strApp_Status"></param>
        /// <param name="strStatus"></param>
        /// <param name="strUSER_APPS"></param>
        /// <returns></returns>
        public static List<ReportDatabalikanModels> ListReport_Databalikan(string strNIK, string strPol_No, string strApp_Status, string strStatus, string strUSER_APPS, string strDate_Start, string strDate_End)
        {
            SqlConnection conn = Common.GetConnection();
            List<Dashboard_DUKCAPIL.Models.ReportDatabalikanModels> model = new List<ReportDatabalikanModels>();
            SqlCommand cmd = new SqlCommand("sp_GET_DATABALIKAN", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NIK", SqlDbType.VarChar).Value = strNIK;
            cmd.Parameters.Add("@Pol_No", SqlDbType.VarChar).Value = strPol_No;
            cmd.Parameters.Add("@App_Status", SqlDbType.VarChar).Value = strApp_Status;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = strStatus;
            cmd.Parameters.Add("@USER_APPS", SqlDbType.VarChar).Value = strUSER_APPS;
            cmd.Parameters.Add("@Date_Start", SqlDbType.VarChar).Value = strDate_Start;
            cmd.Parameters.Add("@Date_End", SqlDbType.VarChar).Value = strDate_End;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            conn.Open();
            da.Fill(dt);
            conn.Close();

            foreach (DataRow dr in dt.Rows)
            {
                model.Add(new ReportDatabalikanModels
                {
                    NIK = dr["NIK"].ToString(),
                    Policy_No = dr["Policy_No"].ToString(),
                    MDM_ID = dr["MDM_ID"].ToString(),
                    App_Status = dr["App_Status"].ToString(),
                    Submit_Date = dr["SUBMIT_DATE"].ToString(),
                    USER_APPS = dr["USER_APPS"].ToString(),
                    Status = dr["Status"].ToString()
                });
            }
            

            return model;
        }

        /// <summary>
        /// ExportReport_Databalikan - all params is optional, can be string empty
        /// </summary>
        /// <param name="strNIK"></param>
        /// <param name="strPol_No"></param>
        /// <param name="strApp_Status"></param>
        /// <param name="strStatus"></param>
        /// <param name="strUSER_APPS"></param>
        /// <returns></returns>
        public static DataTable ExportReport_Databalikan(string strNIK, string strPol_No, string strApp_Status, string strStatus, string strUSER_APPS, string strDate_Start, string strDate_End)
        {
            SqlConnection conn = Common.GetConnection();
            List<Dashboard_DUKCAPIL.Models.ReportDatabalikanModels> model = new List<ReportDatabalikanModels>();
            SqlCommand cmd = new SqlCommand("sp_GET_DATABALIKAN", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NIK", SqlDbType.VarChar).Value = strNIK;
            cmd.Parameters.Add("@Pol_No", SqlDbType.VarChar).Value = strPol_No;
            cmd.Parameters.Add("@App_Status", SqlDbType.VarChar).Value = strApp_Status;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = strStatus;
            cmd.Parameters.Add("@USER_APPS", SqlDbType.VarChar).Value = strUSER_APPS;
            cmd.Parameters.Add("@Date_Start", SqlDbType.VarChar).Value = strDate_Start;
            cmd.Parameters.Add("@Date_End", SqlDbType.VarChar).Value = strDate_End;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            conn.Open();
            da.Fill(dt);
            conn.Close();          

            return dt;
        }

        // GET: ReportDataVerification
        [HttpGet]
        public ActionResult ReportDataVerification()
        {
            PagedList_Report_Verification<ReportVerificationModels> model = new PagedList_Report_Verification<ReportVerificationModels>();

            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "ReportController";

                // populate list status
                var lst_Status = GET_STATUS_DATABALIKAN("sp_GET_STATUS_VERIFICATION");
                List<SelectListItem> _lst_Status = new List<SelectListItem>();
                foreach (var item in lst_Status)
                {
                    _lst_Status.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                }
                model.lst_Status = new SelectList(_lst_Status, "Value", "Text");

                // populate list user apps
                var lst_USER_APPS = GET_USER_APPS_DATABALIKAN("sp_GET_USER_APPS_VERIFICATION");
                List<SelectListItem> _lst_USER_APPS = new List<SelectListItem>();
                foreach (var item in lst_USER_APPS)
                {
                    _lst_USER_APPS.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                }
                model.lst_USER_APPS = new SelectList(_lst_USER_APPS, "Value", "Text");
                // populate list grid
                model.Content = ListReport_Verification("", "", "", "", "", "");

            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }
        // Post: ReportDataVerification
        [HttpPost]
        public ActionResult ReportDataVerification(PagedList_Report_Verification<ReportVerificationModels> model, string submit)
        {

            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "ReportController";

                if (submit == "Reset")
                {
                    // go to get this view
                    return RedirectToAction("ReportDataVerification");
                }
                else
                {
                    // populate list status
                    var lst_Status = GET_STATUS_DATABALIKAN("sp_GET_STATUS_VERIFICATION");
                    List<SelectListItem> _lst_Status = new List<SelectListItem>();
                    foreach (var item in lst_Status)
                    {
                        _lst_Status.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                    }
                    model.lst_Status = new SelectList(_lst_Status, "Value", "Text");

                    // populate list user apps
                    var lst_USER_APPS = GET_USER_APPS_DATABALIKAN("sp_GET_USER_APPS_VERIFICATION");
                    List<SelectListItem> _lst_USER_APPS = new List<SelectListItem>();
                    foreach (var item in lst_USER_APPS)
                    {
                        _lst_USER_APPS.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                    }
                    model.lst_USER_APPS = new SelectList(_lst_USER_APPS, "Value", "Text");

                    if (submit == "Search")
                    {
                        DateTime date_empty = Convert.ToDateTime("1/1/0001 12:00:00 AM");
                        string strDate_Start = "";
                        if (model.Start_Date != date_empty) strDate_Start = model.Start_Date.ToString("MM-dd-yyyy");
                        string strDate_End = "";
                        if (model.End_Date != date_empty) strDate_End = model.End_Date.ToString("MM-dd-yyyy");
                        // populate list grid with filters             
                        model.Content = ListReport_Verification(model.NIK, model.Name, model.Status_Data, model.USER_APPS, strDate_Start, strDate_End);
                    }
                    if (submit == "Export")
                    {
                        DateTime date_empty = Convert.ToDateTime("1/1/0001 12:00:00 AM");
                        string strDate_Start = "";
                        if (model.Start_Date != date_empty) strDate_Start = model.Start_Date.ToString("MM-dd-yyyy");
                        string strDate_End = "";
                        if (model.End_Date != date_empty) strDate_End = model.End_Date.ToString("MM-dd-yyyy");
                        // populate list grid with filters             
                        model.Content = ListReport_Verification(model.NIK, model.Name, model.Status_Data, model.USER_APPS, strDate_Start, strDate_End);
                        // populate list for Export with filters             
                        DataTable dt = ExportReport_Verification(model.NIK, model.Name, model.Status_Data, model.USER_APPS, strDate_Start, strDate_End);
                        if (dt.Rows.Count > 0)
                        {
                            using (XLWorkbook wb = new XLWorkbook())
                            {
                                if (dt.Columns.Contains("NO_KK")) dt.Columns.Remove("NO_KK");
                                if (dt.Columns.Contains("NAMA_LGKP")) dt.Columns.Remove("NAMA_LGKP");
                                wb.Worksheets.Add(dt, "Report Verification");

                                Response.Clear();
                                Response.Buffer = true;
                                Response.Charset = "";
                                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                                Response.AddHeader("content-disposition", "attachment;filename=Dukcapil_Report_Verification_" + DateTime.Now.ToString("yyyyMMdd") + ".xlsx");
                                using (MemoryStream MyMemoryStream = new MemoryStream())
                                {
                                    wb.SaveAs(MyMemoryStream);
                                    MyMemoryStream.WriteTo(Response.OutputStream);
                                    Response.Flush();
                                    Response.End();
                                };
                            }
                        }
                        else TempData["messageRequest"] = "<script>alert('" + "No Data Found" + "');</script>";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }
        /// <summary>
        /// ListReport_Verification - all params is optional, can be string empty
        /// </summary>
        /// <param name="strNIK"></param>
        /// <param name="strName"></param>
        /// <param name="strStatus"></param>
        /// <param name="strUSER_APPS"></param>
        /// <param name="strDate_Start"></param>
        /// <param name="strDate_End"></param>
        /// <returns></returns>
        public static List<ReportVerificationModels> ListReport_Verification(string strNIK, string strName, string strStatus, string strUSER_APPS, string strDate_Start, string strDate_End)
        {
            SqlConnection conn = Common.GetConnection();
            List<Dashboard_DUKCAPIL.Models.ReportVerificationModels> model = new List<ReportVerificationModels>();
            SqlCommand cmd = new SqlCommand("[sp_GET_DATA_VERIFICATION]", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NIK", SqlDbType.VarChar).Value = strNIK;
            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = strName;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = strStatus;
            cmd.Parameters.Add("@USER_APPS", SqlDbType.VarChar).Value = strUSER_APPS;
            cmd.Parameters.Add("@Date_Start", SqlDbType.VarChar).Value = strDate_Start;
            cmd.Parameters.Add("@Date_End", SqlDbType.VarChar).Value = strDate_End;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            conn.Open();
            da.Fill(dt);
            conn.Close();

            foreach (DataRow dr in dt.Rows)
            {
                model.Add(new ReportVerificationModels
                {
                    NIK = dr["NIK"].ToString(),
                    NAMA_LGKP = dr["NAMA_LGKP"].ToString(),
                    REQUEST_DATE = dr["REQUEST_DATE"].ToString(),
                    USER_APPS = dr["USER_APPS"].ToString(),
                    STATUS_DATA = dr["Status_Data"].ToString(),
                    MDM_ID = dr["MDM_ID"].ToString()
                });
            }


            return model;
        }

        /// <summary>
        /// ExportReport_Verification
        /// </summary>
        /// <param name="strNIK"></param>
        /// <param name="strName"></param>
        /// <param name="strStatus"></param>
        /// <param name="strUSER_APPS"></param>
        /// <param name="strDate_Start"></param>
        /// <param name="strDate_End"></param>
        /// <returns></returns>
        public static DataTable ExportReport_Verification(string strNIK, string strName, string strStatus, string strUSER_APPS, string strDate_Start, string strDate_End)
        {
            SqlConnection conn = Common.GetConnection();
            List<Dashboard_DUKCAPIL.Models.ReportDatabalikanModels> model = new List<ReportDatabalikanModels>();
            SqlCommand cmd = new SqlCommand("[sp_GET_DATA_VERIFICATION]", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NIK", SqlDbType.VarChar).Value = strNIK;
            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = strName;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = strStatus;
            cmd.Parameters.Add("@USER_APPS", SqlDbType.VarChar).Value = strUSER_APPS;
            cmd.Parameters.Add("@Date_Start", SqlDbType.VarChar).Value = strDate_Start;
            cmd.Parameters.Add("@Date_End", SqlDbType.VarChar).Value = strDate_End;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            conn.Open();
            da.Fill(dt);
            conn.Close();

            return dt;
        }

        public void get_Submenu(string catid)

        {

            DataSet ds = Get_SubMenu(catid);

            List<SubMenu> submenulist = new List<SubMenu>();

            foreach (DataRow dr in ds.Tables[0].Rows)

            {

                submenulist.Add(new SubMenu
                {

                    MenuID = dr["MenuID"].ToString(),

                    MenuName = dr["MenuName"].ToString(),

                    ActionName = dr["ActionName"].ToString(),

                    ControllerName = dr["ControllerName"].ToString()

                });

            }

            Session["submenu"] = submenulist;

        }

        // GET: ReportDataVerification
        [HttpGet]
        public ActionResult ReportDataLog()
        {
            PagedList_Report_Log<ReportLogModels> model = new PagedList_Report_Log<ReportLogModels>();

            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "ReportController";

                // populate list status
                var lst_Status = GET_STATUS_DATABALIKAN("sp_GET_STATUS_LOGGING");
                List<SelectListItem> _lst_Status = new List<SelectListItem>();
                foreach (var item in lst_Status)
                {
                    _lst_Status.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                }
                model.lst_Status = new SelectList(_lst_Status, "Value", "Text");

                // populate list user apps
                var lst_USER_APPS = GET_USER_APPS_DATABALIKAN("sp_GET_USER_APPS_LOGGING");
                List<SelectListItem> _lst_USER_APPS = new List<SelectListItem>();
                foreach (var item in lst_USER_APPS)
                {
                    _lst_USER_APPS.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                }
                model.lst_USER_APPS = new SelectList(_lst_USER_APPS, "Value", "Text");

                // populate list Departement
                var lst_Dept = GET_DATA_LIST("sp_GET_DEPARTEMENT_LIST");
                List<SelectListItem> _lst_Dept = new List<SelectListItem>();
                foreach (var item in lst_Dept)
                {
                    _lst_Dept.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                }
                model.lst_Dept = new SelectList(_lst_Dept, "Value", "Text");

                // populate list grid
                model.Content = ListReport_Log("", "", "", "", "", "");

            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }
        // Post: ReportDataVerification
        [HttpPost]
        public ActionResult ReportDataLog(PagedList_Report_Log<ReportLogModels> model, string submit)
        {

            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "ReportController";

                if (submit == "Reset")
                {
                    // go to get this view
                    return RedirectToAction("ReportDataVerification");
                }
                else
                {
                    // populate list status
                    var lst_Status = GET_STATUS_DATABALIKAN("sp_GET_STATUS_VERIFICATION");
                    List<SelectListItem> _lst_Status = new List<SelectListItem>();
                    foreach (var item in lst_Status)
                    {
                        _lst_Status.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                    }
                    model.lst_Status = new SelectList(_lst_Status, "Value", "Text");

                    // populate list user apps
                    var lst_USER_APPS = GET_USER_APPS_DATABALIKAN("sp_GET_USER_APPS_VERIFICATION");
                    List<SelectListItem> _lst_USER_APPS = new List<SelectListItem>();
                    foreach (var item in lst_USER_APPS)
                    {
                        _lst_USER_APPS.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                    }
                    model.lst_USER_APPS = new SelectList(_lst_USER_APPS, "Value", "Text");

                    // populate list Departement
                    var lst_Dept = GET_DATA_LIST("sp_GET_DEPARTEMENT_LIST");
                    List<SelectListItem> _lst_Dept = new List<SelectListItem>();
                    foreach (var item in lst_Dept)
                    {
                        _lst_Dept.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                    }
                    model.lst_Dept = new SelectList(_lst_Dept, "Value", "Text");

                    if (submit == "Search")
                    {
                        DateTime date_empty = Convert.ToDateTime("1/1/0001 12:00:00 AM");
                        string strDate_Start = "";
                        if (model.Start_Date != date_empty) strDate_Start = model.Start_Date.ToString("MM-dd-yyyy");
                        string strDate_End = "";
                        if (model.End_Date != date_empty) strDate_End = model.End_Date.ToString("MM-dd-yyyy");
                        // populate list grid with filters             
                        model.Content = ListReport_Log(model.NIK, model.Departement, model.Status_Data, model.USER_APPS, strDate_Start, strDate_End);
                    }
                    if (submit == "Export")
                    {
                        DateTime date_empty = Convert.ToDateTime("1/1/0001 12:00:00 AM");
                        string strDate_Start = "";
                        if (model.Start_Date != date_empty) strDate_Start = model.Start_Date.ToString("MM-dd-yyyy");
                        string strDate_End = "";
                        if (model.End_Date != date_empty) strDate_End = model.End_Date.ToString("MM-dd-yyyy");
                        // populate list grid with filters             
                        model.Content = ListReport_Log(model.NIK, model.Departement, model.Status_Data, model.USER_APPS, strDate_Start, strDate_End);
                        // populate list for Export with filters             
                        DataTable dt = ExportReport_Log(model.NIK, model.Departement, model.Status_Data, model.USER_APPS, strDate_Start, strDate_End);
                        if (dt.Rows.Count > 0)
                        {
                            using (XLWorkbook wb = new XLWorkbook())
                            {
                                var ws = wb.Worksheets.Add(dt, "Report Logging");
                                ws.Columns("A", "F").AdjustToContents();
                                //ws.Column("D").Style.NumberFormat.Format = "#,##0.";
                                ws.Column("D").Style.NumberFormat.SetNumberFormatId((int)XLPredefinedFormat.Number.Integer);
                                Response.Clear();
                                Response.Buffer = true;
                                Response.Charset = "";
                                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                                Response.AddHeader("content-disposition", "attachment;filename=Dukcapil_Report_Logging_" + DateTime.Now.ToString("yyyyMMdd") + ".xlsx");
                                using (MemoryStream MyMemoryStream = new MemoryStream())
                                {
                                    wb.SaveAs(MyMemoryStream);
                                    MyMemoryStream.WriteTo(Response.OutputStream);
                                    Response.Flush();
                                    Response.End();
                                };
                            }
                        }
                        else TempData["messageRequest"] = "<script>alert('" + "No Data Found" + "');</script>";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }

        /// <summary>
        /// ListReport_Log
        /// </summary>
        /// <param name="strNIK"></param>
        /// <param name="strDept"></param>
        /// <param name="strStatus"></param>
        /// <param name="strUSER_APPS"></param>
        /// <param name="strDate_Start"></param>
        /// <param name="strDate_End"></param>
        /// <returns></returns>
        public static List<ReportLogModels> ListReport_Log(string strNIK, string strDept, string strStatus, string strUSER_APPS, string strDate_Start, string strDate_End)
        {
            SqlConnection conn = Common.GetConnection();
            List<Dashboard_DUKCAPIL.Models.ReportLogModels> model = new List<ReportLogModels>();
            SqlCommand cmd = new SqlCommand("[sp_GET_DATA_LOGGING]", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NIK", SqlDbType.VarChar).Value = strNIK;
            cmd.Parameters.Add("@Dept", SqlDbType.VarChar).Value = strDept;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = strStatus;
            cmd.Parameters.Add("@USER_APPS", SqlDbType.VarChar).Value = strUSER_APPS;
            cmd.Parameters.Add("@Date_Start", SqlDbType.VarChar).Value = strDate_Start;
            cmd.Parameters.Add("@Date_End", SqlDbType.VarChar).Value = strDate_End;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            conn.Open();
            da.Fill(dt);
            conn.Close();

            foreach (DataRow dr in dt.Rows)
            {
                model.Add(new ReportLogModels
                {
                    USER_APPS = dr["USER_APPS"].ToString(),
                    DEPARTEMENT = dr["DEPARTEMENT"].ToString(),
                    NIK = dr["NIK"].ToString(),                    
                    REQUEST_DATE = dr["REQUEST_DATE"].ToString(),
                    STATUS_DATA = dr["Status_Data"].ToString()

                });
            }


            return model;
        }
        /// <summary>
        /// ExportReport_Log
        /// </summary>
        /// <param name="strNIK"></param>
        /// <param name="strDept"></param>
        /// <param name="strStatus"></param>
        /// <param name="strUSER_APPS"></param>
        /// <param name="strDate_Start"></param>
        /// <param name="strDate_End"></param>
        /// <returns></returns>
        public static DataTable ExportReport_Log(string strNIK, string strDept, string strStatus, string strUSER_APPS, string strDate_Start, string strDate_End)
        {
            SqlConnection conn = Common.GetConnection();
            List<Dashboard_DUKCAPIL.Models.ReportLogModels> model = new List<ReportLogModels>();
            SqlCommand cmd = new SqlCommand("[sp_GET_DATA_LOGGING]", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NIK", SqlDbType.VarChar).Value = strNIK;
            cmd.Parameters.Add("@Dept", SqlDbType.VarChar).Value = strDept;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = strStatus;
            cmd.Parameters.Add("@USER_APPS", SqlDbType.VarChar).Value = strUSER_APPS;
            cmd.Parameters.Add("@Date_Start", SqlDbType.VarChar).Value = strDate_Start;
            cmd.Parameters.Add("@Date_End", SqlDbType.VarChar).Value = strDate_End;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            conn.Open();
            da.Fill(dt);
            conn.Close();

            return dt;
        }

        [HttpPost]
        public ActionResult LoadData_Log(FormCollection form)
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

               // var searchDate = Request.Form.GetValues("columns[3][search][value]").FirstOrDefault();

                //Paging Size (10,20,50,100)    
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;

                // Getting all Customer data with filters   

                List<ReportLogModels> lstReport = new List<ReportLogModels>();
                if (!string.IsNullOrEmpty(searchValue))
                {

                    string[] strLst = searchValue.Split(';');
                    if (strLst.Count() > 1) lstReport = ListReport_Log(strLst[0], strLst[1], strLst[2], strLst[3], strLst[4], strLst[5]);
                    else {
                        lstReport = ListReport_Log("", "", "", "", "", "");
                        lstReport = lstReport.Where(m => m.NIK == searchValue
                        || m.DEPARTEMENT.ToLower() == searchValue.ToLower()
                        || m.USER_APPS.ToLower() == searchValue.ToLower()
                        ).ToList();
                    };

                }
                else lstReport = ListReport_Log("", "", "", "", "", "");



                //Sorting    
                //if (!(string.IsNullOrEmpty(sortColumn) && string.IsNullOrEmpty(sortColumnDir)))
                //{
                //    lstRepot = lstRepot.OrderBy(sortColumn);
                //}
                //Search    
                //if (!string.IsNullOrEmpty(searchValue))
                //{
                //    lstReport = lstReport.Where(m => m.NIK == searchValue 
                //    || m.DEPARTEMENT.ToLower() == searchValue.ToLower() 
                //    || m.USER_APPS.ToLower() == searchValue.ToLower()
                //    ).ToList();
                //}


                //total number of rows count     
                recordsTotal = lstReport.Count();
                //Paging     
                var data = lstReport.Skip(skip).Take(pageSize).ToList();
                //Returning Json Data    
                return Json(new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = data });

            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        public ActionResult LoadData_Databalikan(FormCollection form)
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                // var searchDate = Request.Form.GetValues("columns[3][search][value]").FirstOrDefault();

                //Paging Size (10,20,50,100)    
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;

                // Getting all Customer data with filters   

                List<ReportDatabalikanModels> lstReport = new List<ReportDatabalikanModels>();
                if (!string.IsNullOrEmpty(searchValue))
                {

                    string[] strLst = searchValue.Split(';');
                    if (strLst.Count() > 1) lstReport = ListReport_Databalikan(strLst[0], strLst[1], strLst[2], strLst[3], strLst[4], strLst[5], strLst[6]);
                    else
                    {
                        lstReport = ListReport_Databalikan("", "", "", "", "", "", "");
                        lstReport = lstReport.Where(m => m.NIK == searchValue
                        || m.Policy_No.ToLower() == searchValue.ToLower()
                        || m.USER_APPS.ToLower() == searchValue.ToLower()
                        || m.MDM_ID.ToLower() == searchValue.ToLower()
                        || m.Status.ToLower() == searchValue.ToLower()
                        ).ToList();
                    };

                }
                else lstReport = ListReport_Databalikan("", "", "", "", "", "", "");



                //Sorting    
                //if (!(string.IsNullOrEmpty(sortColumn) && string.IsNullOrEmpty(sortColumnDir)))
                //{
                //    lstRepot = lstRepot.OrderBy(sortColumn);
                //}
                //Search    
                //if (!string.IsNullOrEmpty(searchValue))
                //{
                //    lstReport = lstReport.Where(m => m.NIK == searchValue 
                //    || m.DEPARTEMENT.ToLower() == searchValue.ToLower() 
                //    || m.USER_APPS.ToLower() == searchValue.ToLower()
                //    ).ToList();
                //}


                //total number of rows count     
                recordsTotal = lstReport.Count();
                //Paging     
                var data = lstReport.Skip(skip).Take(pageSize).ToList();
                //Returning Json Data    
                return Json(new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = data });

            }
            catch (Exception ex)
            {
                throw;
            }

        }

        [HttpPost]
        public ActionResult LoadData_Verification(FormCollection form)
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                // var searchDate = Request.Form.GetValues("columns[3][search][value]").FirstOrDefault();

                //Paging Size (10,20,50,100)    
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;

                // Getting all Customer data with filters   

                List<ReportVerificationModels> lstReport = new List<ReportVerificationModels>();
                if (!string.IsNullOrEmpty(searchValue))
                {
                    //nik + ';' + status + ';' + user + ';' + search_date
                    string[] strLst = searchValue.Split(';');
                    if (strLst.Count() > 1) lstReport = ListReport_Verification(strLst[0],"", strLst[1], strLst[2], strLst[3], strLst[4]);
                    else
                    {
                        lstReport = ListReport_Verification("", "", "", "", "", "");
                        lstReport = lstReport.Where(m => m.NIK == searchValue                        
                        || m.USER_APPS.ToLower() == searchValue.ToLower()
                        || m.MDM_ID.ToLower() == searchValue.ToLower()
                        || m.STATUS_DATA.ToLower() == searchValue.ToLower()
                        ).ToList();
                    };

                }
                else lstReport = ListReport_Verification("", "", "", "", "", "");



                //Sorting    
                //if (!(string.IsNullOrEmpty(sortColumn) && string.IsNullOrEmpty(sortColumnDir)))
                //{
                //    lstRepot = lstRepot.OrderBy(sortColumn);
                //}
                //Search    
                //if (!string.IsNullOrEmpty(searchValue))
                //{
                //    lstReport = lstReport.Where(m => m.NIK == searchValue 
                //    || m.DEPARTEMENT.ToLower() == searchValue.ToLower() 
                //    || m.USER_APPS.ToLower() == searchValue.ToLower()
                //    ).ToList();
                //}


                //total number of rows count     
                recordsTotal = lstReport.Count();
                //Paging     
                var data = lstReport.Skip(skip).Take(pageSize).ToList();
                //Returning Json Data    
                return Json(new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = data });

            }
            catch (Exception ex)
            {
                throw;
            }

        }


        // GET: ReportDataVerificationNew
        [HttpGet]
        public ActionResult ReportDataVerificationNew()
        {
            PagedList_Report_Verification<ReportVerificationNewModels> model = new PagedList_Report_Verification<ReportVerificationNewModels>();

            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "ReportController";

                // populate list status
                var lst_Status = GET_STATUS_DATABALIKAN("sp_GET_STATUS_REQUEST_VERIFICATION");
                List<SelectListItem> _lst_Status = new List<SelectListItem>();
                foreach (var item in lst_Status)
                {
                    _lst_Status.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                }
                model.lst_Status = new SelectList(_lst_Status, "Value", "Text");

                // populate list user apps
                var lst_USER_APPS = GET_USER_APPS_DATABALIKAN("sp_GET_USER_APPS_VERIFICATION_NEW");
                List<SelectListItem> _lst_USER_APPS = new List<SelectListItem>();
                foreach (var item in lst_USER_APPS)
                {
                    _lst_USER_APPS.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                }
                model.lst_USER_APPS = new SelectList(_lst_USER_APPS, "Value", "Text");
                // populate list grid
                model.Content = ListReport_Verification_New("", "", "", "", "", "");

            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }

        // Post: ReportDataVerificationNew
        [HttpPost]
        public ActionResult ReportDataVerificationNew(PagedList_Report_Verification<ReportVerificationNewModels> model, string submit)
        {

            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "ReportController";

                if (submit == "Reset")
                {
                    // go to get this view
                    return RedirectToAction("ReportDataVerification");
                }
                else
                {
                    // populate list status
                    var lst_Status = GET_STATUS_DATABALIKAN("sp_GET_STATUS_REQUEST_VERIFICATION");
                    List<SelectListItem> _lst_Status = new List<SelectListItem>();
                    foreach (var item in lst_Status)
                    {
                        _lst_Status.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                    }
                    model.lst_Status = new SelectList(_lst_Status, "Value", "Text");

                    // populate list user apps
                    var lst_USER_APPS = GET_USER_APPS_DATABALIKAN("sp_GET_USER_APPS_VERIFICATION_NEW");
                    List<SelectListItem> _lst_USER_APPS = new List<SelectListItem>();
                    foreach (var item in lst_USER_APPS)
                    {
                        _lst_USER_APPS.Add(new SelectListItem { Text = item.Text, Value = item.Value.ToString() });
                    }
                    model.lst_USER_APPS = new SelectList(_lst_USER_APPS, "Value", "Text");

                    if (submit == "Search")
                    {
                        DateTime date_empty = Convert.ToDateTime("1/1/0001 12:00:00 AM");
                        string strDate_Start = "";
                        if (model.Start_Date != date_empty) strDate_Start = model.Start_Date.ToString("MM-dd-yyyy");
                        string strDate_End = "";
                        if (model.End_Date != date_empty) strDate_End = model.End_Date.ToString("MM-dd-yyyy");
                        // populate list grid with filters             
                        model.Content = ListReport_Verification_New(model.NIK, model.Name, model.Status_Data, model.USER_APPS, strDate_Start, strDate_End);
                    }
                    if (submit == "Export")
                    {
                        DateTime date_empty = Convert.ToDateTime("1/1/0001 12:00:00 AM");
                        string strDate_Start = "";
                        if (model.Start_Date != date_empty) strDate_Start = model.Start_Date.ToString("MM-dd-yyyy");
                        string strDate_End = "";
                        if (model.End_Date != date_empty) strDate_End = model.End_Date.ToString("MM-dd-yyyy");
                        // populate list grid with filters             
                        model.Content = ListReport_Verification_New(model.NIK, model.Name, model.Status_Data, model.USER_APPS, strDate_Start, strDate_End);
                        // populate list for Export with filters             
                        DataTable dt = ExportReport_Verification_New(model.NIK, model.Name, model.Status_Data, model.USER_APPS, strDate_Start, strDate_End);
                        if (dt.Rows.Count > 0)
                        {
                            using (XLWorkbook wb = new XLWorkbook())
                            {
                                //if (dt.Columns.Contains("NO_KK")) dt.Columns.Remove("NO_KK");
                                //if (dt.Columns.Contains("NAMA_LGKP")) dt.Columns.Remove("NAMA_LGKP");
                                wb.Worksheets.Add(dt, "Report Validation");

                                Response.Clear();
                                Response.Buffer = true;
                                Response.Charset = "";
                                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                                Response.AddHeader("content-disposition", "attachment;filename=Dukcapil_Report_Validation" + DateTime.Now.ToString("yyyyMMdd") + ".xlsx");
                                using (MemoryStream MyMemoryStream = new MemoryStream())
                                {
                                    wb.SaveAs(MyMemoryStream);
                                    MyMemoryStream.WriteTo(Response.OutputStream);
                                    Response.Flush();
                                    Response.End();
                                };
                            }
                        }
                        else TempData["messageRequest"] = "<script>alert('" + "No Data Found" + "');</script>";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }

        [HttpPost]
        public ActionResult LoadData_Verification_New(FormCollection form)
        {
            try
            {
                var draw = Request.Form.GetValues("draw").FirstOrDefault();
                var start = Request.Form.GetValues("start").FirstOrDefault();
                var length = Request.Form.GetValues("length").FirstOrDefault();
                var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
                var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();
                var searchValue = Request.Form.GetValues("search[value]").FirstOrDefault();

                // var searchDate = Request.Form.GetValues("columns[3][search][value]").FirstOrDefault();

                //Paging Size (10,20,50,100)    
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;

                // Getting all Customer data with filters   

                List<ReportVerificationNewModels> lstReport = new List<ReportVerificationNewModels>();
                if (!string.IsNullOrEmpty(searchValue))
                {
                    //nik + ';' + status + ';' + user + ';' + search_date
                    string[] strLst = searchValue.Split(';');
                    if (strLst.Count() > 1) lstReport = ListReport_Verification_New(strLst[0], "", strLst[1], strLst[2], strLst[3], strLst[4]);
                    else
                    {
                        lstReport = ListReport_Verification_New("", "", "", "", "", "");
                        lstReport = lstReport.Where(m => m.NIK == searchValue
                        || m.USER_APPS.ToLower() == searchValue.ToLower()
                        || m.STATUS_REQUEST.ToLower() == searchValue.ToLower()
                        ).ToList();
                    };

                }
                else lstReport = ListReport_Verification_New("", "", "", "", "", "");
                //total number of rows count     
                recordsTotal = lstReport.Count();
                //Paging     
                var data = lstReport.Skip(skip).Take(pageSize).ToList();
                //Returning Json Data    
                return Json(new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = data });

            }
            catch (Exception ex)
            {
                DebugLogger.WriteLog("error" + ex.Message);
                return Json(ex);
            }

        }

        public static List<ReportVerificationNewModels> ListReport_Verification_New(string strNIK, string strName, string strStatus, string strUSER_APPS, string strDate_Start, string strDate_End)
        {
            SqlConnection conn = Common.GetConnection();
            List<Dashboard_DUKCAPIL.Models.ReportVerificationNewModels> model = new List<ReportVerificationNewModels>();
            SqlCommand cmd = new SqlCommand("[sp_GET_DATA_VERIFICATION_NEW]", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NIK", SqlDbType.VarChar).Value = strNIK;
            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = strName;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = strStatus;
            cmd.Parameters.Add("@USER_APPS", SqlDbType.VarChar).Value = strUSER_APPS;
            cmd.Parameters.Add("@Date_Start", SqlDbType.VarChar).Value = strDate_Start;
            cmd.Parameters.Add("@Date_End", SqlDbType.VarChar).Value = strDate_End;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            conn.Open();
            da.Fill(dt);
            conn.Close();

            foreach (DataRow dr in dt.Rows)
            {
                model.Add(new ReportVerificationNewModels
                {
                    POLICY_NO = dr["POLICY_NO"].ToString(),
                    NIK = dr["NIK"].ToString(),
                    STATUS_RESPONSE_NIK = dr["STATUS_RESPONSE_NIK"].ToString(),
                    NAMA_LGKP = dr["NAMA_LGKP"].ToString(),
                    STATUS_RESPONSE_NAMA_LGKP = dr["STATUS_RESPONSE_NAMA_LGKP"].ToString(),
                    JENIS_KLMIN = dr["JENIS_KLMIN"].ToString(),
                    STATUS_RESPONSE_JENIS_KLMIN = dr["STATUS_RESPONSE_JENIS_KLMIN"].ToString(),
                    TMPT_LHR = dr["TMPT_LHR"].ToString(),
                    STATUS_RESPONSE_TMPT_LHR = dr["STATUS_RESPONSE_TMPT_LHR"].ToString(),
                    TGL_LHR = dr["TGL_LHR"].ToString(),
                    STATUS_RESPONSE_TGL_LHR = dr["STATUS_RESPONSE_TGL_LHR"].ToString(),
                    STATUS_KAWIN = dr["STATUS_KAWIN"].ToString(),
                    STATUS_RESPONSE_STATUS_KAWIN = dr["STATUS_RESPONSE_STATUS_KAWIN"].ToString(),
                    PDDK_AKH = dr["PDDK_AKH"].ToString(),
                    STATUS_RESPONSE_PDDK_AKH = dr["STATUS_RESPONSE_PDDK_AKH"].ToString(),
                    JENIS_PKRJN = dr["JENIS_PKRJN"].ToString(),
                    STATUS_RESPONSE_JENIS_PKRJN = dr["STATUS_RESPONSE_JENIS_PKRJN"].ToString(),
                    NAMA_LGKP_IBU = dr["NAMA_LGKP_IBU"].ToString(),
                    STATUS_RESPONSE_NAMA_LGKP_IBU = dr["STATUS_RESPONSE_NAMA_LGKP_IBU"].ToString(),
                    PROP_NAME = dr["PROP_NAME"].ToString(),
                    STATUS_RESPONSE_PROP_NAME = dr["STATUS_RESPONSE_PROP_NAME"].ToString(),
                    KAB_NAME = dr["KAB_NAME"].ToString(),
                    STATUS_RESPONSE_KAB_NAME = dr["STATUS_RESPONSE_KAB_NAME"].ToString(),
                    KEC_NAME = dr["KEC_NAME"].ToString(),
                    STATUS_RESPONSE_KEC_NAME = dr["STATUS_RESPONSE_KEC_NAME"].ToString(),
                    KEL_NAME = dr["KEL_NAME"].ToString(),
                    STATUS_RESPONSE_KEL_NAME = dr["STATUS_RESPONSE_KEL_NAME"].ToString(),
                    ALAMAT = dr["ALAMAT"].ToString(),
                    STATUS_RESPONSE_ALAMAT = dr["STATUS_RESPONSE_ALAMAT"].ToString(),
                    NO_RT = dr["NO_RT"].ToString(),
                    STATUS_RESPONSE_NO_RT = dr["STATUS_RESPONSE_NO_RT"].ToString(),
                    NO_RW = dr["NO_RW"].ToString(),
                    STATUS_RESPONSE_NO_RW = dr["STATUS_RESPONSE_NO_RW"].ToString(),
                    USER_APPS = dr["USER_APPS"].ToString(),
                    STATUS_REQUEST = dr["STATUS_REQUEST"].ToString(),
                    REQUEST_DATE = dr["REQUEST_DATE"].ToString()

                });
            }

            return model;
        }
        public static DataTable ExportReport_Verification_New(string strNIK, string strName, string strStatus, string strUSER_APPS, string strDate_Start, string strDate_End)
        {
            SqlConnection conn = Common.GetConnection();
            List<Dashboard_DUKCAPIL.Models.ReportDatabalikanModels> model = new List<ReportDatabalikanModels>();
            SqlCommand cmd = new SqlCommand("[sp_GET_DATA_VERIFICATION_NEW]", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NIK", SqlDbType.VarChar).Value = strNIK;
            cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = strName;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = strStatus;
            cmd.Parameters.Add("@USER_APPS", SqlDbType.VarChar).Value = strUSER_APPS;
            cmd.Parameters.Add("@Date_Start", SqlDbType.VarChar).Value = strDate_Start;
            cmd.Parameters.Add("@Date_End", SqlDbType.VarChar).Value = strDate_End;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            conn.Open();
            da.Fill(dt);
            conn.Close();

            return dt;
        }
    }
}