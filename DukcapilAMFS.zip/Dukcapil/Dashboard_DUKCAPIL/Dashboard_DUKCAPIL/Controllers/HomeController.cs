﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dashboard_DUKCAPIL.Models;
using Dashboard_DUKCAPIL.Repository;
using System.Web.Security;
using static Dashboard_DUKCAPIL.Models.MenuViewModels;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Configuration;
using System.IO;
using ClosedXML.Excel;
using System.Web.Script.Serialization;
using System.Web.Configuration;
using System.Xml;
using System.Text;
using System.Net;
using System.Net.Http;
using HastyAPI;
using System.Globalization;

namespace Dashboard_DUKCAPIL.Controllers
{
    public class HomeController : Controller
    {
        string UserApps = ConfigurationManager.AppSettings["UserWS"].ToString();
        string PassApps = ConfigurationManager.AppSettings["PassWS"].ToString();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Dashboard()
        {
            HomeDashboard model = new HomeDashboard();
            Session["controller"] = "HomeController";

            ViewBag.menu = Session["menu"];
            DataTable dt = Common.ExecuteQuery("dbo.[DASHBOARD_DUKCAPIL]");
            if (dt.Rows.Count > 0)
            {
                model.Count_HIT_DUKCAPIL = string.IsNullOrEmpty(dt.Rows[0]["COUNT_HIT"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[0]["COUNT_HIT"].ToString());
                model.Success_HIT_DUKCAPIL = string.IsNullOrEmpty(dt.Rows[0]["SUCCESS_HIT"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[0]["SUCCESS_HIT"].ToString());
                model.Failed_HIT_DUKCAPIL = string.IsNullOrEmpty(dt.Rows[0]["FAILED_HIT"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[0]["FAILED_HIT"].ToString());

            }
            //DataTable MDM = Common.ExecuteQuery("dbo.[DASHBOARD_MDM]");
            //if (MDM.Rows.Count > 0)
            //{
            //    //MDM
            //    model.Count_HIT_MDM = Convert.ToInt32(MDM.Rows[0]["COUNT_HIT"].ToString());
            //    model.Success_HIT_MDM = Convert.ToInt32(MDM.Rows[0]["SUCCESS_HIT"].ToString());
            //    model.Failed_HIT_MDM = Convert.ToInt32(MDM.Rows[0]["FAILED_HIT"].ToString());
            //}

            //2020/10/20 - by dept
            model.lstByDept = new List<DashboardByDept>();
            DataTable dt_by_dept = Common.ExecuteQuery("dbo.[DASHBOARD_DUKCAPIL_Departement]");
            if (dt_by_dept.Rows.Count > 0)
            {
                foreach (DataRow item in dt_by_dept.AsEnumerable())
                {
                    DashboardByDept data = new DashboardByDept();
                    data.Count_HIT_DUKCAPIL = string.IsNullOrEmpty(dt.Rows[0]["COUNT_HIT"].ToString()) ? 0 : Convert.ToInt32(item["COUNT_HIT"].ToString());
                    data.Success_HIT_DUKCAPIL = string.IsNullOrEmpty(dt.Rows[0]["SUCCESS_HIT"].ToString()) ? 0 : Convert.ToInt32(item["SUCCESS_HIT"].ToString());
                    data.Failed_HIT_DUKCAPIL = string.IsNullOrEmpty(dt.Rows[0]["FAILED_HIT"].ToString()) ? 0 : Convert.ToInt32(item["FAILED_HIT"].ToString());
                    data.Departement = item["Departement"].ToString();
                    model.lstByDept.Add(data);
                }
            }


            //List<Dashboard> dataPoints = new List<Dashboard>();

            //dataPoints.Add(new Dashboard(25,"Samsung", "Samsung"));
            //dataPoints.Add(new Dashboard(13,"Micromax", "Micromax"));
            //dataPoints.Add(new Dashboard(8,"Lenovo","Lenovo"));
            //dataPoints.Add(new Dashboard(7,"Intex","Intex"));
            //dataPoints.Add(new Dashboard(6.8,"Reliance", "Reliance"));
            //dataPoints.Add(new Dashboard(40.2,"Others", "Others"));

            //List<Dashboard> dataPoints2 = new List<Dashboard>();

            //dataPoints2.Add(new Dashboard(13, "HP", "HP"));
            //dataPoints2.Add(new Dashboard(19, "Dell", "Dell"));
            //dataPoints2.Add(new Dashboard(80, "Telnet", "Telnet"));
            //dataPoints2.Add(new Dashboard(71, "Intel", "Intel"));
            //dataPoints2.Add(new Dashboard(1.8, "Rally", "Rally"));
            //dataPoints2.Add(new Dashboard(10.3, "Masuk", "Masuk"));

            //ViewBag.DataPoints = JsonConvert.SerializeObject(dataPoints);
            //ViewBag.DataPoints2 = JsonConvert.SerializeObject(dataPoints2);

            return View(model);
        }
        public ActionResult Dashboard_DUKCAPIL()
        {
            Session["controller"] = "HomeController";

            ViewBag.menu = Session["menu"];
            List<Dashboard> dataPoints = new List<Dashboard>();

            SqlConnection con = Common.GetConnection();
            List<SelectListItem> item = new List<SelectListItem>();
            string query = "exec DASHBOARD_DUKCAPIL_DETAIL";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        dataPoints.Add(new Dashboard(string.IsNullOrEmpty(dr["COUNT_HIT"].ToString()) ? 0 : Convert.ToInt32(dr["COUNT_HIT"].ToString())
                            , string.IsNullOrEmpty(dr["JUMLAHHIT"].ToString()) ? "0" : dr["JUMLAHHIT"].ToString()
                            , string.IsNullOrEmpty(dr["JUMLAHHIT"].ToString()) ? "0" : dr["JUMLAHHIT"].ToString()));
                    }
                }
                con.Close();
            }

            //dataPoints.Add(new Dashboard(25, "Samsung", "Samsung"));
            //dataPoints.Add(new Dashboard(13, "Micromax", "Micromax"));
            //dataPoints.Add(new Dashboard(8, "Lenovo", "Lenovo"));
            //dataPoints.Add(new Dashboard(7, "Intex", "Intex"));
            //dataPoints.Add(new Dashboard(6.8, "Reliance", "Reliance"));
            //dataPoints.Add(new Dashboard(40.2, "Others", "Others"));
            ViewBag.DataPoints = JsonConvert.SerializeObject(dataPoints);

            return View();
        }
        public ActionResult Dashboard_MDM()
        {
            ViewBag.menu = Session["menu"];
            Session["controller"] = "HomeController";
            List<Dashboard> dataPoints = new List<Dashboard>();

            SqlConnection con = Common.GetConnection();
            List<SelectListItem> item = new List<SelectListItem>();
            string query = "exec DASHBOARD_MDM_DETAIL";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        dataPoints.Add(new Dashboard(string.IsNullOrEmpty(dr["COUNT_HIT"].ToString()) ? 0 : Convert.ToInt32(dr["COUNT_HIT"].ToString())
                             , string.IsNullOrEmpty(dr["JUMLAHHIT"].ToString()) ? "0" : dr["JUMLAHHIT"].ToString()
                             , string.IsNullOrEmpty(dr["JUMLAHHIT"].ToString()) ? "0" : dr["JUMLAHHIT"].ToString()));
                    }
                }
                con.Close();
            }

            //dataPoints.Add(new Dashboard(25, "Samsung", "Samsung"));
            //dataPoints.Add(new Dashboard(13, "Micromax", "Micromax"));
            //dataPoints.Add(new Dashboard(8, "Lenovo", "Lenovo"));
            //dataPoints.Add(new Dashboard(7, "Intex", "Intex"));
            //dataPoints.Add(new Dashboard(6.8, "Reliance", "Reliance"));
            //dataPoints.Add(new Dashboard(40.2, "Others", "Others"));
            ViewBag.DataPoints = JsonConvert.SerializeObject(dataPoints);

            return View();
        }
        public ActionResult _Dashboard()
        {
            Session["controller"] = "HomeController";
            return PartialView();
        }
        public ActionResult HIT_WS(PagedList<HITWSModels> model)
        {
            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "HomeController";
                model.Content = ListEmployee(null);

                model.Disabled = false;
                model.User_APPS = Session["UserID"].ToString();

                //DataTable dt01 = Common.ExecuteQuery("dbo.[so_GET_USERNAME_APPS] '" + Session["UserID"].ToString() + "','" + Session["EmployeeNumber"].ToString() + "'");
                //if (dt01.Rows.Count > 0)
                //{
                //   model.User_APPS = dt01.Rows[0]["UserApps"].ToString();
                //}

                if (string.IsNullOrEmpty(model.User_APPS) == true)
                {
                    model.Disabled = true;
                    TempData["messageRequest"] = "<script>alert('Please Fill User Apps in Profile Page');</script>";
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }
        [HttpPost]
        public ActionResult HIT_WS(PagedList<HITWSModels> model = null, string Submit = "")
        {
            ViewBag.menu = Session["menu"];
            Session["controller"] = "HomeController";
            DataSet result = new DataSet();

            model.Content = ListEmployee(null);
            model.User_APPS = Session["UserID"].ToString();

            try
            {
                if (string.IsNullOrEmpty(model.NIK) == true)
                {
                    TempData["messageRequest"] = "<script>alert('Please Fill Data NIK');</script>";
                    return View(model);
                };
                if (string.IsNullOrEmpty(model.POLICY_NO) == true)
                {
                    TempData["messageRequest"] = "<script>alert('Please Fill Data POLICY_NO');</script>";
                    return View(model);
                };
                if (string.IsNullOrEmpty(model.User_APPS) == true)
                {
                    model.Disabled = true;
                    TempData["messageRequest"] = "<script>alert('Please Fill User Apps in Profile Page');</script>";
                    return View(model);
                };
                // get password apps etc
                string strDesc = WebConfigurationManager.AppSettings["ws_desc"].ToString();
                ViewUserApiModels vUserApi = new ViewUserApiModels();
                List<ViewUserApiModels> lst_user_api = GetDataUserAPI("", model.User_APPS, "", strDesc, "1");
                if (lst_user_api != null)
                {
                    if (lst_user_api.Count > 0)
                    {
                        vUserApi = lst_user_api.FirstOrDefault();
                        WS_DUKCAPIL.Service1Client DukcapilWS = new WS_DUKCAPIL.Service1Client();
                        //ignore untrusted certificate remove when https is trusted
                        System.Net.ServicePointManager.ServerCertificateValidationCallback +=
                        (se, cert, chain, sslerror) =>
                        {
                            return true;
                        };
                        DukcapilWS.Open();
                        result = DukcapilWS.GetData(model.NIK, vUserApi.User_Apps, vUserApi.Password_Apps, vUserApi.Descriptions_Apps, model.POLICY_NO);
                        DukcapilWS.Close();

                        model.Content = ListEmployee(result);
                    }
                    else
                    {
                        model.Disabled = true;
                        TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                        return View(model);
                    }
                }
                else
                {
                    model.Disabled = true;
                    TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                    return View(model);
                }

            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            return View(model);
        }
        //tambahan form data balikan
        [HttpGet]
        public ActionResult Feedback_Data()
        {
            FeedbackModels model = new FeedbackModels();
            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "HomeController";
                TempData["TblExcel_Tot_Rows"] = (int)0;
                TempData["TblExcel_Tot_MDM_ID"] = (int)0;
                // model.Content = ListEmployee(null);

                if (Session["UserID"] == null)
                {
                    Response.Redirect("~/Login/Index");
                }
                else
                {
                    model.User_APPS = Session["UserID"].ToString();
                    ViewBag.AppStatus = new MultiSelectList(new List<string>() { "Nasabah", "Bukan Nasabah" });
                }
                return View(model);
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
            // return View(model);
        }
        [HttpPost]
        public ActionResult Feedback_Data(HttpPostedFileBase file, FeedbackModels _data, string submit, FormCollection form)
        {
            ViewBag.menu = Session["menu"];
            ViewBag.AppStatus = new MultiSelectList(new List<string>() { "Nasabah", "Bukan Nasabah" });
            Session["controller"] = "HomeController";
            TempData["TblExcel_Tot_Rows"] = (int)0;
            TempData["TblExcel_Tot_MDM_ID"] = (int)0;
            FeedbackModels model = new FeedbackModels();
            model = _data;
            if (Session["UserID"] == null)
            {
                Response.Redirect("~/Login/Index");
            }
            else
            {
                model.User_APPS = Session["UserID"].ToString();
                string strUserId = Session["EmployeeNumber"].ToString();
                string strResult = "";
                //model.ApplicationStatus = form["AppStatus"].ToString();
                model.ApplicationStatus = "";
                model.lstDataExcel = new List<DataExcel>();
                if (submit == "Submit")
                {
                    try
                    {
                        if (string.IsNullOrEmpty(model.PolicyNo) == true) model.PolicyNo = "";
                        if (string.IsNullOrEmpty(model.ApplicationStatus) == true) model.ApplicationStatus = "";

                        if (string.IsNullOrEmpty(model.NIK) == true)
                        {
                            TempData["messageRequest"] = "<script>alert('Please Fill NIK Data');</script>";
                            TempData["ErrorRequest"] = "Please Fill NIK Data";
                            return View(model);
                        }

                        if (string.IsNullOrEmpty(model.User_APPS) == true)
                        {
                            TempData["messageRequest"] = "<script>alert('Please Fill User Apps in Profile Page');</script>";
                            TempData["ErrorRequest"] = "Please Fill User Apps in Profile Page";
                            return View(model);
                        }

                        // Bagian Send ke service to submit
                        //WS_DUKCAPIL.Service1Client DukcapilWS = new WS_DUKCAPIL.Service1Client();
                        //string strGUID = WebConfigurationManager.AppSettings["WS_GUID"].ToString();
                        // perubahan pada service dukcapil:
                        // string SubmitData(string strNIK, string strPolicyNo, string strApplicationStatus, string USER_APPS, string PASS_APPS, string strDescriptions);
                        // get password apps etc
                        string strDesc = WebConfigurationManager.AppSettings["ws_desc"].ToString();
                        ViewUserApiModels vUserApi = new ViewUserApiModels();
                        List<ViewUserApiModels> lst_user_api = GetDataUserAPI("", model.User_APPS, "", strDesc, "1");
                        if (lst_user_api != null)
                        {
                            if (lst_user_api.Count > 0)
                            {
                                vUserApi = lst_user_api.FirstOrDefault();
                                WS_DUKCAPIL.Service1Client DukcapilWS = new WS_DUKCAPIL.Service1Client();
                                //ignore untrusted certificate remove when https is trusted
                                System.Net.ServicePointManager.ServerCertificateValidationCallback +=
                                (se, cert, chain, sslerror) =>
                                {
                                    return true;
                                };
                                DukcapilWS.Open();
                                strResult = DukcapilWS.SubmitData(model.NIK, model.PolicyNo, null, model.ApplicationStatus, vUserApi.User_Apps, vUserApi.Password_Apps, vUserApi.Descriptions_Apps);
                                DukcapilWS.Close();

                                TempData["messageRequest"] = "<script>alert('" + strResult + "');</script>";
                            }
                            else
                            {
                                TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                                return View(model);
                            }
                        }
                        else
                        {
                            TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                            return View(model);
                        }

                    }
                    catch (Exception ex)
                    {
                        TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                        return View(model);
                    }
                }
                if (submit == "Upload")
                {
                    // Section of Upload File
                    DataTable dt_File = new DataTable();
                    bool bStatus = true;
                    //Checking file content length and Extension must be .xlsx  
                    if (file != null && file.ContentLength > 0 && System.IO.Path.GetExtension(file.FileName).ToLower() == ".xlsx")
                    {
                        try
                        {
                            string strFileName = WebConfigurationManager.AppSettings["name_file_upload_excel_databalikan"].ToString();
                            strFileName = System.IO.Path.GetFileNameWithoutExtension(file.FileName) + "_" + strFileName + "_" + DateTime.Now.ToString("HHmmss_ddMMyyyy") + ".xlsx";
                            string path = Path.Combine(Server.MapPath("~/Uploads"), strFileName);
                            //Saving the file  
                            file.SaveAs(path);

                            using (FileStream fs = System.IO.File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                            {
                                //Started reading the Excel file.  
                                using (XLWorkbook workbook = new XLWorkbook(fs))
                                {
                                    IXLWorksheet worksheet = workbook.Worksheet(1);
                                    bool FirstRow = true;
                                    //Range for reading the cells based on the last cell used.  
                                    string readRange = "1:1";
                                    //before that check column is right or not
                                    int iColumnCount = worksheet.Columns().Count();
                                    string strColumn1 = worksheet.Cell(1, 1).Value.ToString();
                                    string strColumn2 = worksheet.Cell(1, 2).Value.ToString();
                                    //string strColumn3 = worksheet.Cell(1, 3).Value.ToString();

                                    //get data xml column
                                    DataTable dtFormat = getFormatExcelDatabalikanXML();
                                    DataColumnCollection dtColumns = dtFormat.Columns;

                                    //if (strColumn1 == "NIK" && strColumn2 == "Policy No" && strColumn3 == "Application Status")
                                    if (dtColumns.Contains(strColumn1) && dtColumns.Contains(strColumn2))
                                    {
                                        foreach (IXLRow row in worksheet.RowsUsed())
                                        {
                                            //If Reading the First Row (used) then add them as column name  
                                            if (FirstRow)
                                            {
                                                //Checking the Last cellused for column generation in datatable  
                                                readRange = string.Format("{0}:{1}", 1, row.LastCellUsed().Address.ColumnNumber);
                                                foreach (IXLCell cell in row.Cells(readRange))
                                                {
                                                    dt_File.Columns.Add(cell.Value.ToString());
                                                }
                                                FirstRow = false;
                                            }
                                            else
                                            {
                                                //Adding a Row in datatable  
                                                dt_File.Rows.Add();
                                                int cellIndex = 0;
                                                //Updating the values of datatable  
                                                foreach (IXLCell cell in row.Cells(readRange))
                                                {
                                                    dt_File.Rows[dt_File.Rows.Count - 1][cellIndex] = cell.Value.ToString();
                                                    cellIndex++;
                                                }
                                            }
                                        }
                                        //If no data in Excel file  
                                        if (FirstRow)
                                        {
                                            TempData["ErrorRequest"] = "Empty Excel File!";
                                            bStatus = false;
                                        }
                                        else
                                        {
                                            // get data mdm_id from list
                                            int iRows_w_MDM_ID = 0;
                                            foreach (DataRow dr in dt_File.AsEnumerable())
                                            {
                                                DataExcel dtEx = new DataExcel();
                                                dtEx.NIK = dr["NIK"].ToString() != "" ? dr["NIK"].ToString() : "";
                                                dtEx.Policy_No = dr["Policy No"].ToString() != "" ? dr["Policy No"].ToString() : "";
                                                dtEx.MDM_ID = "";
                                                if (dtEx.Policy_No.Trim().Length > 0)
                                                {
                                                    dtEx.MDM_ID = Get_Data_MDM_ID_BY_POLICY_NO(dtEx.Policy_No.Trim());
                                                    if (dtEx.MDM_ID.Length > 0) iRows_w_MDM_ID++;
                                                }
                                                model.lstDataExcel.Add(dtEx);
                                            };
                                            TempData["TblExcel_Tot_Rows"] = (int)model.lstDataExcel.Count;
                                            TempData["TblExcel_Tot_MDM_ID"] = (int)iRows_w_MDM_ID;
                                            Session["tblExcel"] = model.lstDataExcel;
                                        }
                                    }
                                    else
                                    {
                                        TempData["ErrorRequest"] = "Column in File Excel not match.";
                                        bStatus = false;
                                    }
                                }

                            }
                        }
                        catch (Exception ex)
                        {
                            TempData["ErrorRequest"] = ex.Message.ToString();
                        }

                    }
                    else
                    {
                        //If file extension of the uploaded file is different then .xlsx  
                        //ViewBag.Message = "Please select file with .xlsx extension!";
                        TempData["ErrorRequest"] = "Please select file with .xlsx extension!";
                        //TempData["messageRequest"] = "<script>alert('" + strResult + "');</script>";
                        bStatus = false;
                    };
                    if (bStatus == false)
                    {
                        TempData["ErrorRequest"] = "No Data Found in Excel File!";
                    };
                    //if (bStatus != false)
                    //{
                    //    if (dt_File.Rows.Count > 0)
                    //    {
                    //        //Section Submit Databalikan
                    //        //model = new FeedbackModels();
                    //        //model = _data;
                    //        //model.User_APPS = Session["UserID"].ToString();
                    //        //string strEmpNo = Session["EmployeeNumber"].ToString();
                    //        //strResult = "";
                    //        //string strListResult = "";
                    //        //foreach (DataRow dr in dt_File.Rows)
                    //        //{
                    //        //    string strGUID = WebConfigurationManager.AppSettings["WS_GUID"].ToString();
                    //        //    WS_DUKCAPIL_DATABALIKAN.Service1Client DukcapilWS = new WS_DUKCAPIL_DATABALIKAN.Service1Client();
                    //        //    DukcapilWS.Open();
                    //        //    strResult = DukcapilWS.SubmitData(dr["NIK"].ToString(), dr["Policy No"].ToString(), dr["Application Status"].ToString(), model.User_APPS, strEmpNo, strGUID);
                    //        //    DukcapilWS.Close();
                    //        //    strListResult += dr["NIK"].ToString() + " [" + (strResult.Length == 0 ? "No Response" : strResult) + "] " + System.Environment.NewLine;
                    //        //};
                    //        //TempData["ErrorRequest"] = strListResult;

                    //        // get password apps etc
                    //        string strDesc = WebConfigurationManager.AppSettings["ws_desc"].ToString();
                    //        ViewUserApiModels vUserApi = new ViewUserApiModels();
                    //        List<ViewUserApiModels> lst_user_api = GetDataUserAPI("", model.User_APPS, "", strDesc, "1");
                    //        if (lst_user_api != null)
                    //        {
                    //            if (lst_user_api.Count > 0)
                    //            {
                    //                vUserApi = lst_user_api.FirstOrDefault();
                    //                strResult = "";
                    //                string strListResult = "";
                    //                int iData = 1;
                    //                foreach (DataRow dr in dt_File.Rows)
                    //                {
                    //                    // string strGUID = WebConfigurationManager.AppSettings["WS_GUID"].ToString();
                    //                    string strNIK = (dr["NIK"] != null ? (dr["NIK"].ToString() != "" ? dr["NIK"].ToString() : "") : "").Trim();
                    //                    string strPolNo = (dr["Policy No"] != null ? (dr["Policy No"].ToString() != "" ? dr["Policy No"].ToString() : "") : "").Trim();
                    //                    string strAppStatus = (dr["Application Status"] != null ? (dr["Application Status"].ToString() != "" ? dr["Application Status"].ToString() : "") : "").Trim();
                    //                    if (strNIK != "")
                    //                    {
                    //                        WS_DUKCAPIL.Service1Client DukcapilWS = new WS_DUKCAPIL.Service1Client();
                    //                        //ignore untrusted certificate remove when https is trusted
                    //                        System.Net.ServicePointManager.ServerCertificateValidationCallback +=
                    //                        (se, cert, chain, sslerror) =>
                    //                        {
                    //                            return true;
                    //                        };
                    //                        DukcapilWS.Open();
                    //                        strResult = DukcapilWS.SubmitData(strNIK, strPolNo, null, strAppStatus, vUserApi.User_Apps, vUserApi.Password_Apps, vUserApi.Descriptions_Apps);
                    //                        DukcapilWS.Close();
                    //                        strListResult += dr["NIK"].ToString() + " [" + (strResult.Length == 0 ? "No Response" : strResult) + "] " + System.Environment.NewLine;
                    //                    }
                    //                    else strListResult += "[ Line : " + iData + " NIK Empty ] " + System.Environment.NewLine;

                    //                    iData++;
                    //                };
                    //                TempData["ErrorRequest"] = strListResult;
                    //                //TempData["messageRequest"] = "<script>alert('" + strResult + "');</script>";
                    //            }
                    //            else
                    //            {
                    //                TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                    //                return View(model);
                    //            }
                    //        }
                    //        else
                    //        {
                    //            TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                    //            return View(model);
                    //        }
                    //    }
                    //    else
                    //    {
                    //        TempData["ErrorRequest"] = "No Data Found in Excel File!";
                    //    }
                    //}
                }
                if (submit == "Download") return RedirectToAction("WriteFormatDatabalikanExcel", "Home");
                if (submit == "No") return RedirectToAction("Feedback_Data", "Home");
                if (submit == "Yes")
                {
                    var lstExcel = (List<DataExcel>)Session["tblExcel"];
                    model.lstDataExcel = lstExcel;
                    if (model.lstDataExcel.Count > 0)
                    {
                        //Section Submit Databalikan

                        // get password apps etc
                        string strDesc = WebConfigurationManager.AppSettings["ws_desc"].ToString();
                        ViewUserApiModels vUserApi = new ViewUserApiModels();
                        List<ViewUserApiModels> lst_user_api = GetDataUserAPI("", model.User_APPS, "", strDesc, "1");
                        if (lst_user_api != null)
                        {
                            if (lst_user_api.Count > 0)
                            {
                                vUserApi = lst_user_api.FirstOrDefault();
                                strResult = "";
                                string strListResult = "";
                                int iData = 1;
                                foreach (DataExcel dr in model.lstDataExcel)
                                {
                                    // string strGUID = WebConfigurationManager.AppSettings["WS_GUID"].ToString();
                                    string strNIK = dr.NIK;
                                    string strPolNo = dr.Policy_No;
                                    string strMDM_ID = dr.MDM_ID;
                                    if (strNIK != "")
                                    {
                                        WS_DUKCAPIL.Service1Client DukcapilWS = new WS_DUKCAPIL.Service1Client();
                                        //ignore untrusted certificate remove when https is trusted
                                        System.Net.ServicePointManager.ServerCertificateValidationCallback +=
                                        (se, cert, chain, sslerror) =>
                                        {
                                            return true;
                                        };
                                        DukcapilWS.Open();
                                        strResult = DukcapilWS.SubmitData(strNIK, strPolNo, strMDM_ID, "", vUserApi.User_Apps, vUserApi.Password_Apps, vUserApi.Descriptions_Apps);
                                        DukcapilWS.Close();
                                        strListResult += "<p>" + strNIK + " [" + (strResult.Length == 0 ? "No Response" : strResult) + "] </p>" + System.Environment.NewLine;
                                    }
                                    else strListResult += "<p>" + "[ Line : " + iData + " NIK Empty ] </p>" + System.Environment.NewLine;

                                    iData++;
                                };
                                TempData["ErrorRequest"] = strListResult;
                            }
                            else
                            {
                                TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                                return View(model);
                            };
                        }
                        else
                        {
                            TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                            return View(model);
                        };
                    };
                };//if (submit == "Yes")
            }

            //ViewBag.menu = Session["menu"];
            return View(model);
        }

        /// <summary>
        /// View and Edit Profile User Login
        /// </summary>
        /// <returns></returns>
        public ActionResult Profiles()
        {
            ProfileModels model = new ProfileModels();

            model.EmployeeID = Session["EmployeeNumber"].ToString();
            model.EmployeeName = Session["UserID"].ToString();
            model.Flag = DDLFlag();

            ViewBag.menu = Session["menu"];
            Session["controller"] = "HomeController";

            model.EmployeeID = string.IsNullOrEmpty(model.EmployeeID) == true ? "" : model.EmployeeID;
            DataTable dtProf = Common.ExecuteQuery("sp_GET_PROFILE'" + model.EmployeeID + "'");
            if (dtProf.Rows.Count > 0)
            {
                model.Department = dtProf.Rows[0]["Departement"].ToString();
                model.UserApps = dtProf.Rows[0]["UserApps"].ToString();
                model.FlagID = dtProf.Rows[0]["Flag"].ToString();
            }


            return View(model);
        }
        [HttpPost]
        public ActionResult Profiles(ProfileModels model, string Submit)
        {
            model.EmployeeID = Session["EmployeeNumber"].ToString();
            model.EmployeeName = Session["UserID"].ToString();
            model.Flag = DDLFlag();

            ViewBag.menu = Session["menu"];
            Session["controller"] = "HomeController";
            model.EmployeeID = string.IsNullOrEmpty(model.EmployeeID) == true ? "" : model.EmployeeID;


            if (ModelState.IsValid == true)
            {
                if (Submit == "Submit")
                {
                    using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSql"].ConnectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("sp_INSERT_MST_PROFILE", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@EmployeeID", string.IsNullOrEmpty(model.EmployeeID) == true ? "" : model.EmployeeID);
                            cmd.Parameters.AddWithValue("@EmployeeName", string.IsNullOrEmpty(model.EmployeeName) == true ? "" : model.EmployeeName);
                            cmd.Parameters.AddWithValue("@Departement", string.IsNullOrEmpty(model.Department) == true ? "" : model.Department);
                            cmd.Parameters.AddWithValue("@UserApps", string.IsNullOrEmpty(model.UserApps) == true ? "" : model.UserApps);
                            cmd.Parameters.AddWithValue("@CreatedBy", string.IsNullOrEmpty(Session["UserID"].ToString()) == true ? "" : Session["UserID"].ToString());
                            cmd.Parameters.AddWithValue("@Flag", string.IsNullOrEmpty(model.FlagID) == true ? "0" : model.FlagID);
                            conn.Open();
                            cmd.ExecuteNonQuery();
                            conn.Close();
                        }
                    }

                    TempData["messageRequest"] = "<script>alert('Submit Data Success');</script>";
                    return RedirectToAction("Profiles", "Home");

                }
            }
            return View(model);
        }

        public static List<HITWSModels> ListEmployee(DataSet ds)
        {
            SqlConnection conn = Common.GetConnection();
            List<HITWSModels> model = new List<HITWSModels>();
            if (ds == null)
            {
                model.Add(new HITWSModels
                {
                    NO_KK = "",
                    NIK = "",
                    NAMA_LGKP = "",
                    KAB_NAME = "",
                    AGAMA = "",
                    NO_RW = "",
                    KEC_NAME = "",
                    JENIS_PKRJN = "",
                    NO_RT = "",
                    NO_KEL = "",
                    ALAMAT = "",
                    NO_KEC = "",
                    TMPT_LHR = "",
                    PDDK_AKH = "",
                    STATUS_KAWIN = "",
                    STAT_HBKEL = "",
                    NO_PROP = "",
                    NAMA_LGKP_IBU = "",
                    PROP_NAME = "",
                    NO_KAB = "",
                    KEL_NAME = "",
                    JENIS_KLMIN = "",
                    TGL_LHR = "",
                    STATUS_DATA = ""
                });
            }
            else
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    model.Add(new HITWSModels
                    {
                        NO_KK = dr["NO_KK"].ToString(),
                        NIK = dr["NIK"].ToString(),
                        NAMA_LGKP = dr["NAMA_LGKP"].ToString(),
                        KAB_NAME = dr["KAB_NAME"].ToString(),
                        AGAMA = "",
                        NO_RW = dr["NO_RW"].ToString(),
                        KEC_NAME = dr["KEC_NAME"].ToString(),
                        JENIS_PKRJN = dr["JENIS_PKRJN"].ToString(),
                        NO_RT = dr["NO_RT"].ToString(),
                        NO_KEL = dr["NO_KEL"].ToString(),
                        ALAMAT = dr["ALAMAT"].ToString(),
                        NO_KEC = dr["NO_KEC"].ToString(),
                        TMPT_LHR = dr["TMPT_LHR"].ToString(),
                        PDDK_AKH = "",
                        STATUS_KAWIN = dr["STATUS_KAWIN"].ToString(),
                        STAT_HBKEL = "",
                        NO_PROP = dr["NO_PROP"].ToString(),
                        NAMA_LGKP_IBU = dr["NAMA_LGKP_IBU"].ToString(),
                        PROP_NAME = dr["PROP_NAME"].ToString(),
                        NO_KAB = dr["NO_KAB"].ToString(),
                        KEL_NAME = dr["KEL_NAME"].ToString(),
                        JENIS_KLMIN = dr["JENIS_KLMIN"].ToString(),
                        TGL_LHR = dr["TGL_LHR"].ToString(),
                        STATUS_DATA = dr["COUNT_DATA"].ToString()
                    });
                }
            }
            return model;
        }
        public DataSet Get_Menu()

        {

            SqlCommand com = new SqlCommand("exec [sp_Get_Menu_Parent] '" + Session["EmployeeNumber"] + "'", Common.GetConnection());

            SqlDataAdapter da = new SqlDataAdapter(com);

            DataSet ds = new DataSet();

            da.Fill(ds);


            return ds;

        }

        public DataSet Get_SubMenu(string ParentID)

        {

            SqlCommand com = new SqlCommand("exec [sp_Get_SubMenu] '" + Session["EmployeeNumber"] + "',@ParentID", Common.GetConnection());

            com.Parameters.AddWithValue("@ParentID", ParentID);

            SqlDataAdapter da = new SqlDataAdapter(com);

            DataSet ds = new DataSet();

            da.Fill(ds);

            return ds;

        }

        public void get_Submenu(string catid)

        {

            DataSet ds = Get_SubMenu(catid);

            List<SubMenu> submenulist = new List<SubMenu>();

            foreach (DataRow dr in ds.Tables[0].Rows)

            {

                submenulist.Add(new SubMenu
                {

                    MenuID = dr["MenuID"].ToString(),

                    MenuName = dr["MenuName"].ToString(),

                    ActionName = dr["ActionName"].ToString(),

                    ControllerName = dr["ControllerName"].ToString()

                });

            }

            Session["submenu"] = submenulist;

        }
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            //AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
            return RedirectToAction("Index", "Login");
        }
        private static List<SelectListItem> DDLFlag()
        {
            SqlConnection con = Common.GetConnection();
            List<SelectListItem> item = new List<SelectListItem>();
            string query = "EXEC [dbo].[sp_GET_FLAG] ";

            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Connection = con;
                con.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        item.Add(new SelectListItem
                        {
                            Text = dr["FLAG"].ToString(),
                            Value = dr["FLAGID"].ToString()
                        });
                    }
                }


                con.Close();
            }
            return item;
        }
        public string DataTableToJSON(DataTable table)
        {
            JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
            List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            foreach (DataRow row in table.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    childRow.Add(col.ColumnName, row[col]);
                }
                parentRow.Add(childRow);
            }
            return jsSerializer.Serialize(parentRow);
        }
        public DataTable getFormatExcelDatabalikan()
        {

            //Creating DataTable  
            DataTable dt = new DataTable();
            //Setting Table Name  
            dt.TableName = "DataBalikan";
            //Add Columns  
            dt.Columns.Add("NIK", typeof(string));
            dt.Columns.Add("Policy No", typeof(string));
            dt.Columns.Add("Application Status", typeof(string));
            //Add Rows in DataTable  
            dt.Rows.Add("1218020405970007", "test Polis", "test Status");
            dt.AcceptChanges();
            return dt;
        }
        private DataTable getFormatExcelDatabalikanXML()
        {
            //Creating DataTable  
            DataTable dt = new DataTable();

            //string xmlFile = @"c:\users\ari subekti\source\repos\ConsoleApp_XML\ConsoleApp_XML\XMLFile2.xml";
            string strXmlFile = Server.MapPath("~/format_excel_databalikan.xml");
            if (System.IO.File.Exists(strXmlFile))
            {
                //Setting Table Name  
                dt.TableName = "DataBalikan";
                using (FileStream fs = System.IO.File.Open(strXmlFile, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(fs);
                    XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("/Columns/Column");
                    string strID = "", strName = "", strType = "";
                    foreach (XmlNode node in nodeList)
                    {
                        strID = node.SelectSingleNode("ID").InnerText;
                        strName = node.SelectSingleNode("Name").InnerText;
                        strType = node.SelectSingleNode("Type").InnerText;
                        Type type = Type.GetType("System." + strType);
                        dt.Columns.Add(strName, type);
                    }
                    //Add Rows in DataTable  
                    //dt.Rows.Add("1218020405970007", "test Polis", "test Status");
                    dt.Rows.Add("1218020405970007", "test Polis");
                    dt.AcceptChanges();
                }
            }
            return dt;
        }

        // GET: Upload Databalikan Excel
        public ActionResult UploadDatabalikanExcel()
        {
            //DataTable dt = getFormatExcelDatabalikan();
            DataTable dt = getFormatExcelDatabalikanXML();
            //Name of File  

            string fileName = WebConfigurationManager.AppSettings["name_file_download_excel_databalikan"].ToString() + ".xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                //Add DataTable in worksheet  
                IXLWorksheet iWs = wb.Worksheets.Add(dt);

                //IXLWorksheet iWs = wb.Worksheets.Add("DataBalikan");
                //iWs.Cell(1, 1).SetValue("NIK");
                iWs.Cell(1, 1).Style.Font.SetBold();
                iWs.Cell(1, 1).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
                iWs.Cell(1, 1).Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
                iWs.Cell(1, 1).Style.Border.SetBottomBorder(XLBorderStyleValues.Medium);

                //iWs.Cell(1, 2).SetValue("Policy No");
                iWs.Cell(1, 2).Style.Font.SetBold();
                iWs.Cell(1, 2).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
                iWs.Cell(1, 2).Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
                iWs.Cell(1, 2).Style.Border.SetBottomBorder(XLBorderStyleValues.Medium);
                ////iWs.Cell(1, 3).SetValue("Application Status");
                //iWs.Cell(1, 3).Style.Font.SetBold();
                //iWs.Cell(1, 3).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
                //iWs.Cell(1, 3).Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
                //iWs.Cell(1, 3).Style.Border.SetBottomBorder(XLBorderStyleValues.Medium);

                //style
                iWs.Column(1).Width = 25;
                //set data type of column
                iWs.Column(1).CellsUsed().SetDataType(XLDataType.Text);
                iWs.Column(2).Width = 25;
                //set data type of column
                iWs.Column(2).CellsUsed().SetDataType(XLDataType.Text);
                //iWs.Column(3).Width = 25;
                ////set data type of column
                //iWs.Column(3).CellsUsed().SetDataType(XLDataType.Text);

                //add comment in cell
                //iWs.Cell("A1").Comment.Style.Alignment.SetAutomaticSize();
                iWs.Cell("A1").Comment.AddText("Masukan data NIK hanya sebagai Text.");


                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    //Return xlsx Excel File  
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
                }

            }
        }
        // GET: WriteDataToExcel  
        public ActionResult WriteFormatDatabalikanExcel()
        {
            //DataTable dt = getFormatExcelDatabalikan();
            DataTable dt = getFormatExcelDatabalikanXML();
            //Name of File  

            string fileName = WebConfigurationManager.AppSettings["name_file_download_excel_databalikan"].ToString() + ".xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                //Add DataTable in worksheet  
                IXLWorksheet iWs = wb.Worksheets.Add(dt);

                //IXLWorksheet iWs = wb.Worksheets.Add("DataBalikan");
                //iWs.Cell(1, 1).SetValue("NIK");
                iWs.Cell(1, 1).Style.Font.SetBold();
                iWs.Cell(1, 1).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
                iWs.Cell(1, 1).Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
                iWs.Cell(1, 1).Style.Border.SetBottomBorder(XLBorderStyleValues.Medium);

                //iWs.Cell(1, 2).SetValue("Policy No");
                iWs.Cell(1, 2).Style.Font.SetBold();
                iWs.Cell(1, 2).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
                iWs.Cell(1, 2).Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
                iWs.Cell(1, 2).Style.Border.SetBottomBorder(XLBorderStyleValues.Medium);
                ////iWs.Cell(1, 3).SetValue("Application Status");
                //iWs.Cell(1, 3).Style.Font.SetBold();
                //iWs.Cell(1, 3).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
                //iWs.Cell(1, 3).Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
                //iWs.Cell(1, 3).Style.Border.SetBottomBorder(XLBorderStyleValues.Medium);

                //style
                iWs.Column(1).Width = 25;
                //set data type of column
                iWs.Column(1).CellsUsed().SetDataType(XLDataType.Text);
                iWs.Column(2).Width = 25;
                //set data type of column
                iWs.Column(2).CellsUsed().SetDataType(XLDataType.Text);
                //iWs.Column(3).Width = 25;
                ////set data type of column
                //iWs.Column(3).CellsUsed().SetDataType(XLDataType.Text);

                //add comment in cell
                //iWs.Cell("A1").Comment.Style.Alignment.SetAutomaticSize();
                iWs.Cell("A1").Comment.AddText("Masukan data NIK hanya sebagai Text.");


                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    //Return xlsx Excel File  
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
                }

            }
        }
        private static List<ViewUserApiModels> GetDataUserAPI(string strID, string strUser_Apps, string strPass_Apps,
        string strDesc_Apps, string strIs_Active)
        {
            List<ViewUserApiModels> items = new List<ViewUserApiModels>();
            DataTable dtRet = new DataTable();
            using (SqlConnection sqlconnection = Common.GetConnection())
            {
                SqlCommand command = new SqlCommand("sp_GET_DATA_USER_API", sqlconnection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ID", string.IsNullOrEmpty(strID) == true ? "" : strID);
                command.Parameters.AddWithValue("@User_Apps", string.IsNullOrEmpty(strUser_Apps) == true ? "" : strUser_Apps);
                command.Parameters.AddWithValue("@Password_Apps", string.IsNullOrEmpty(strPass_Apps) == true ? "" : strPass_Apps);
                command.Parameters.AddWithValue("@Descriptions_Apps", string.IsNullOrEmpty(strDesc_Apps) == true ? "" : strDesc_Apps);
                command.Parameters.AddWithValue("@Is_Active", string.IsNullOrEmpty(strIs_Active) == true ? "" : strIs_Active);

                command.Connection.Open();
                SqlDataAdapter adp = new SqlDataAdapter(command);
                //DataSet ds = new DataSet();
                adp.Fill(dtRet);
                adp.Dispose();
                command.Connection.Close();
            }
            if (dtRet != null)
            {
                if (dtRet.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtRet.AsEnumerable())
                    {
                        ViewUserApiModels dataUserApi = new ViewUserApiModels();
                        dataUserApi.Id = dr["ID"].ToString();
                        dataUserApi.User_Apps = dr["User_Apps"].ToString();
                        dataUserApi.Password_Apps = dr["Password_Apps"].ToString();
                        dataUserApi.Descriptions_Apps = dr["Descriptions_Apps"].ToString();
                        dataUserApi.Is_Active = dr["Is_Active"].ToString();
                        items.Add(dataUserApi);
                    }
                }
            }
            return items;
        }
        public string Get_Data_MDM_ID_BY_POLICY_NO(string strPolicy_No)

        {
            string strRet = "";
            DataTable dt = new DataTable();
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSql_MDM"].ConnectionString))
            {
                sqlConn.Open();
                SqlCommand com = new SqlCommand("exec [sp_GET_DATA_MDM_ID_by_policy_no] @POLICY_NO = N'" + strPolicy_No + "';", sqlConn);
                SqlDataAdapter da = new SqlDataAdapter(com);

                da.Fill(dt);
                da.Dispose();
                com.Dispose();
                sqlConn.Close();
            }

            if (dt.Rows.Count > 0)
            {
                strRet = dt.Rows[0]["MDM_ID"].ToString();
            }
            return strRet;

        }

        //tambahan form new verification
        [HttpGet]
        public ActionResult Verification_Data()
        {
            VerificationModels model = new VerificationModels();
            try
            {
                ViewBag.menu = Session["menu"];
                Session["controller"] = "HomeController";
                //TempData["TblExcel_Tot_Rows"] = (int)0;
                //TempData["TblExcel_Tot_MDM_ID"] = (int)0;
                // model.Content = ListEmployee(null);


                if (Session["UserID"] == null)
                {
                    Response.Redirect("~/Login/Index");
                }
                else
                {

                    model.User_APPS = Session["UserID"].ToString();
                    //model.NIK = "3173044607870002";
                    //model.Nama_lgkp = "YULIA";
                    //model.Tmpt_lhr = "JAKARTA";

                    ViewBag.AppStatus = new MultiSelectList(new List<string>() { "Nasabah", "Bukan Nasabah" });
                }
                return View(model);
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
        }
        [HttpPost]
        public ActionResult Verification_Data(VerificationModels _data, string submit, FormCollection form)
        {

            VerificationModels model = new VerificationModels();
            model = _data;

            if (Session["UserID"] == null)
            {
                Response.Redirect("~/Login/Index");
            }
            else
            {
                Session["controller"] = "HomeController";
                ViewBag.AppStatus = new MultiSelectList(new List<string>() { "Nasabah", "Bukan Nasabah" });
                ViewBag.menu = Session["menu"];
                model.User_APPS = Session["UserID"].ToString();
                string strUserId = Session["EmployeeNumber"].ToString();
               
                //model.ApplicationStatus = form["AppStatus"].ToString();

                if (submit == "Submit")
                {
                    try
                    {
                        string strErrorEmpty = "Data tidak boleh kosong.";
                        string strDataFound = "Data Ditemukan.";
                        Boolean bError = false;
                        if (string.IsNullOrEmpty(model.NIK) == true)
                        {
                            _data.Respon_NIK = strErrorEmpty;
                            bError = true;
                        };
                        if (string.IsNullOrEmpty(model.POLICY_NO) == true)
                        {
                            _data.Respon_POLICY_NO = strErrorEmpty;
                            bError = true;
                        };
                        if ((string.IsNullOrEmpty(model.Nama_lgkp) == true) && (string.IsNullOrEmpty(model.JENIS_KLMIN) == true) && (string.IsNullOrEmpty(model.Tmpt_lhr) == true)
                            && (string.IsNullOrEmpty(model.Tgl_lhr) == true) && (string.IsNullOrEmpty(model.STATUS_KAWIN) == true) && (string.IsNullOrEmpty(model.PDDK_AKH) == true)
                            && (string.IsNullOrEmpty(model.JENIS_PKRJN) == true) && (string.IsNullOrEmpty(model.Nama_lGKP_Ibu) == true) && (string.IsNullOrEmpty(model.PROP_NAME) == true)
                            && (string.IsNullOrEmpty(model.KAB_NAME) == true) && (string.IsNullOrEmpty(model.KEC_NAME) == true) && (string.IsNullOrEmpty(model.KEL_NAME) == true)
                            && (string.IsNullOrEmpty(model.ALAMAT) == true) && (string.IsNullOrEmpty(model.NO_RT) == true) && (string.IsNullOrEmpty(model.NO_RW) == true))
                        {
                            TempData["messageRequest"] = "<script>alert('Diharap untuk isi data lainnya. Min. 1 data.');</script>";
                            TempData["ErrorRequest"] = "Diharap untuk isi data lainnya. Min. 1 data.";
                            bError = true;
                        };


                        //if (string.IsNullOrEmpty(model.Nama_lgkp) == true)
                        //{
                        //    _data.Respon_Nama_lgkp = strErrorEmpty;
                        //    bError = true;
                        //};
                        //if (string.IsNullOrEmpty(model.JENIS_KLMIN) == true)
                        //{
                        //    _data.Respon_JENIS_KLMIN = strErrorEmpty;
                        //    bError = true;
                        //};
                        //if (string.IsNullOrEmpty(model.Tgl_lhr) == true)
                        //{
                        //    _data.Respon_Tgl_lhr = strErrorEmpty;
                        //    bError = true;
                        //};


                        if (string.IsNullOrEmpty(model.User_APPS) == true)
                        {
                            TempData["messageRequest"] = "<script>alert('Please Fill User Apps in Profile Page');</script>";
                            TempData["ErrorRequest"] = "Please Fill User Apps in Profile Page";
                            bError = true;
                        };

                        if(bError) return View(model);

                        // Bagian Send ke service to submit
                        //WS_DUKCAPIL.Service1Client DukcapilWS = new WS_DUKCAPIL.Service1Client();
                        //string strGUID = WebConfigurationManager.AppSettings["WS_GUID"].ToString();
                        // perubahan pada service dukcapil:
                        // string SubmitData(string strNIK, string strPolicyNo, string strApplicationStatus, string USER_APPS, string PASS_APPS, string strDescriptions);
                        // get password apps etc
                        string strDesc = WebConfigurationManager.AppSettings["ws_desc"].ToString();
                        ViewUserApiModels vUserApi = new ViewUserApiModels();
                        List<ViewUserApiModels> lst_user_api = GetDataUserAPI("", model.User_APPS, "", strDesc, "1");
                        if (lst_user_api != null)
                        {
                            if (lst_user_api.Count > 0)
                            {
                                vUserApi = lst_user_api.FirstOrDefault();
                                // Post DirectVerificationNEW  API
                                // input parameter
                                ParamRequest paramReq = new ParamRequest();
                                paramReq.NIK = _data.NIK;
                                paramReq.Nama_lgkp = _data.Nama_lgkp;
                                paramReq.JENIS_KLMIN = _data.JENIS_KLMIN == null ? "" : _data.JENIS_KLMIN;
                                paramReq.Tmpt_lhr = _data.Tmpt_lhr == null ? "" : _data.Tmpt_lhr;
                                if (!string.IsNullOrEmpty(_data.Tgl_lhr))
                                {
                                    DateTime dtTglLahir;
                                    DateTime.TryParseExact(_data.Tgl_lhr,
                                                        "yyyy-MM-dd",
                                                        CultureInfo.InvariantCulture,
                                                        DateTimeStyles.None,
                                                        out dtTglLahir);
                                    paramReq.Tgl_lhr = dtTglLahir.ToString("dd-MM-yyyy").ToString();
                                }
                                else paramReq.Tgl_lhr = "";
                                //paramReq.Tgl_lhr = "06-07-1987";

                                paramReq.STATUS_KAWIN = _data.STATUS_KAWIN == null ? "" : _data.STATUS_KAWIN;
                                paramReq.PDDK_AKH = _data.PDDK_AKH == null ? "" : _data.PDDK_AKH;
                                paramReq.JENIS_PKRJN = _data.JENIS_PKRJN == null ? "" : _data.JENIS_PKRJN;
                                paramReq.Nama_lGKP_Ibu = _data.Nama_lGKP_Ibu == null ? "" : _data.Nama_lGKP_Ibu;
                                paramReq.PROP_NAME = _data.PROP_NAME == null ? "" : _data.PROP_NAME;
                                paramReq.KAB_NAME = _data.KAB_NAME == null ? "" : _data.KAB_NAME;
                                paramReq.KEC_NAME = _data.KEC_NAME == null ? "" : _data.KEC_NAME;
                                paramReq.KEL_NAME = _data.KEL_NAME == null ? "" : _data.KEL_NAME;
                                paramReq.ALAMAT = _data.ALAMAT == null ? "" : _data.ALAMAT;
                                if (string.IsNullOrEmpty(_data.NO_RT) == false) paramReq.NO_RT = Convert.ToInt32(_data.NO_RT);
                                if (string.IsNullOrEmpty(_data.NO_RW) == false) paramReq.NO_RW = Convert.ToInt32(_data.NO_RW);
                                paramReq.treshold = 90;
                                //paramReq.user_id = "9393174202102101axamandiri";
                                //paramReq.password = "123";
                                //paramReq.ip_user = "10.162.110.1";
                                paramReq.POLICY_NO = _data.POLICY_NO == null ? "" : _data.POLICY_NO;
                                // this user api from session
                                paramReq.UserApps = vUserApi.User_Apps;
                                paramReq.PassApps = vUserApi.Password_Apps;
                                paramReq.Descriptions = vUserApi.Descriptions_Apps;

                                // Proses Post
                                //bool bRespon = RequestDirectVerificationAsync(paramReq).Result;
                                string strResponse = "";
                                bool bRespon = Request_POST_DirectVerification_New(paramReq, ref strResponse);
                                if (bRespon)
                                {
                                    //string strTest = "{\"content\":[{\"NAMA_LGKP\":\"Sesuai (92)\",\"KAB_NAME\":\"Tidak Sesuai\",\"NO_RW\":\"Tidak Sesuai\",\"JENIS_PKRJN\":\"Tidak Sesuai\",\"KEC_NAME\":\"Tidak Sesuai\",\"NO_RT\":\"Tidak Sesuai\",\"ALAMAT\":\"Tidak Sesuai (0)\",\"TMPT_LHR\":\"Sesuai (100)\",\"PDDK_AKH\":\"Tidak Sesuai\",\"STATUS_KAWIN\":\"Sesuai\",\"NAMA_LGKP_IBU\":\"Tidak Sesuai (0)\",\"PROP_NAME\":\"Tidak Sesuai\",\"JENIS_KLMIN\":\"Sesuai\",\"TGL_LHR\":\"Sesuai\",\"KEL_NAME\":\"Tidak Sesuai\"}],\"lastPage\":true,\"numberOfElements\":1,\"sort\":null,\"totalElements\":1,\"firstPage\":true,\"number\":0,\"size\":1}";
                                    string strJson = strResponse.TrimStart('"').TrimEnd('"');
                                    strJson = strJson.Replace("\\", string.Empty);
                                    var JSONsettings = new JsonSerializerSettings()
                                    {
                                        NullValueHandling = NullValueHandling.Ignore
                                    };
                                    
                                    ResponseVerificationModels objResponse = JsonConvert.DeserializeObject<ResponseVerificationModels>(strJson, JSONsettings);
                                    ContentResponseVerificationModels contentRes = new ContentResponseVerificationModels();
                                    contentRes = objResponse.content[0];

                                    if (contentRes.RESPON == null)
                                    {
                                        // jika respon == null maka ada data
                                        model.Respon_POLICY_NO = strDataFound;
                                        model.Respon_NIK = strDataFound;
                                        model.Respon_Nama_lgkp = contentRes.NAMA_LGKP;
                                        model.Respon_JENIS_KLMIN = contentRes.JENIS_KLMIN;
                                        model.Respon_Tmpt_lhr = contentRes.TMPT_LHR;
                                        model.Respon_Tgl_lhr = contentRes.TGL_LHR;
                                        model.Respon_STATUS_KAWIN = contentRes.STATUS_KAWIN;
                                        model.Respon_PDDK_AKH = contentRes.PDDK_AKH;
                                        model.Respon_JENIS_PKRJN = contentRes.JENIS_PKRJN;
                                        model.Respon_Nama_lGKP_Ibu = contentRes.NAMA_LGKP_IBU;
                                        model.Respon_PROP_NAME = contentRes.PROP_NAME;
                                        model.Respon_KAB_NAME = contentRes.KAB_NAME;
                                        model.Respon_KEC_NAME = contentRes.KEC_NAME;
                                        model.Respon_KEL_NAME = contentRes.KEL_NAME;
                                        model.Respon_ALAMAT = contentRes.ALAMAT;
                                        model.Respon_NO_RT = contentRes.NO_RT;
                                        model.Respon_NO_RW = contentRes.NO_RW;
                                    }
                                    else {
                                        // ini respon tanpa data 
                                        model.Respon_POLICY_NO = "";
                                        model.Respon_NIK = contentRes.RESPON;
                                        model.Respon_Nama_lgkp = contentRes.NAMA_LGKP;
                                        model.Respon_JENIS_KLMIN = contentRes.JENIS_KLMIN;
                                        model.Respon_Tmpt_lhr = contentRes.TMPT_LHR;
                                        model.Respon_Tgl_lhr = contentRes.TGL_LHR;
                                        model.Respon_STATUS_KAWIN = contentRes.STATUS_KAWIN;
                                        model.Respon_PDDK_AKH = contentRes.PDDK_AKH;
                                        model.Respon_JENIS_PKRJN = contentRes.JENIS_PKRJN;
                                        model.Respon_Nama_lGKP_Ibu = contentRes.NAMA_LGKP_IBU;
                                        model.Respon_PROP_NAME = contentRes.PROP_NAME;
                                        model.Respon_KAB_NAME = contentRes.KAB_NAME;
                                        model.Respon_KEC_NAME = contentRes.KEC_NAME;
                                        model.Respon_KEL_NAME = contentRes.KEL_NAME;
                                        model.Respon_ALAMAT = contentRes.ALAMAT;
                                        model.Respon_NO_RT = contentRes.NO_RT;
                                        model.Respon_NO_RW = contentRes.NO_RW;
                                    };
                                }
                                else
                                {

                                };

                                //TempData["messageRequest"] = "<script>alert('" + strResponse + "');</script>";
                            }
                            else
                            {
                                TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                                return View(model);
                            }
                        }
                        else
                        {
                            TempData["messageRequest"] = "<script>alert('User Apps is not active or not been registered.');</script>";
                            return View(model);
                        }

                    }
                    catch (Exception ex)
                    {
                        TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                        return View(model);
                    }
                }

            }
            return View(model);
        }

        private static ResponseVerificationModels ViewResponseVerification(VerificationModels verModels)
        {
            ResponseVerificationModels resResult = new ResponseVerificationModels();

            return resResult;
        }

        /// <summary>
        /// GET New Web Service Dukcapil
        /// </summary>
        /// <param name="_model">strJSON</param>
        /// <returns></returns>
        public bool Request_POST_DirectVerification_New(ParamRequest paramReq, ref string strReturn)
        {
            bool bRet = false;
            HttpResponseMessage responseMsg = new HttpResponseMessage();
            strReturn = "";
            // check req.data
            try
            {
                // proses submit  
                // get url = end point + resource
                string strUrlAPI = ConfigurationManager.AppSettings.Get("url_service_api");
                var result = new APIRequest(strUrlAPI)
                .WithData(JsonConvert.SerializeObject(paramReq), "application/json")
                .Post()
                .Text;

                if (result.Length > 0)
                {
                    bRet = true;
                    strReturn = result;
                }
                else
                {
                    bRet = false;
                    strReturn = "failed";
                };


            }
            catch (Exception ex)
            {
                strReturn = ex.Message.ToString();
                bRet = false;
            }

            return bRet;
        }
    }
}