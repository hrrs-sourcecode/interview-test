﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dashboard_DUKCAPIL.Models;
using System.Data.SqlClient;
using Dashboard_DUKCAPIL.Repository;
using System.Configuration;
using System.Data;
using System.Web.Configuration;
using System.IO;
using ClosedXML.Excel;
using System.Threading.Tasks;

namespace Dashboard_DUKCAPIL.Controllers
{
    public class RegistrationUserController : Controller
    {
        // GET: RegistrationUser
        public ActionResult AddUser()
        {

            Session["controller"] = "RegistrationController";

            ViewBag.menu = Session["menu"];

            RegistrationUserApiModels model = new RegistrationUserApiModels();
            model.lst_Desc_Apps = DDLApplication();
            model.lst_user_api = GetDataUserAPI("","","","","");

            return View(model);
        }

        [HttpPost]
        public ActionResult AddUser(RegistrationUserApiModels model = null,string Submit="")
        {
            try
            {

                Session["controller"] = "RegistrationController";
                ViewBag.menu = Session["menu"];
                string strUser = (string)Session["UserID"];
                model.lst_Desc_Apps = DDLApplication();
                if (Submit == "Submit")
                {
                    if (model.Descriptions_Apps.ToString() == "--Choose--")
                    {
                        TempData["messageRequest"] = "<script>alert('Please Choose a Application');</script>";
                        return View(model);
                    }
                    else
                    {
                        bool bCheck = true;
                        bCheck = model.User_Apps == null ? false : true;
                        bCheck = model.Password_Apps == null ? false : true;
                        if (bCheck)
                        {
                            bCheck = model.User_Apps == "" ? false : true;
                            bCheck = model.Password_Apps == "" ? false : true;
                            if (bCheck)
                            {
                                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSql"].ConnectionString))
                                {
                                    using (SqlCommand cmd = new SqlCommand("sp_INSERT_DATA_USER_API", conn))
                                    {
                                        cmd.CommandType = CommandType.StoredProcedure;
                                        cmd.Parameters.AddWithValue("@ID", "");
                                        cmd.Parameters.AddWithValue("@User_Apps", string.IsNullOrEmpty(model.User_Apps) == true ? "" : model.User_Apps.ToString().TrimEnd());
                                        cmd.Parameters.AddWithValue("@Password_Apps", string.IsNullOrEmpty(model.Password_Apps) == true ? "" : model.Password_Apps.ToString().TrimEnd());
                                        cmd.Parameters.AddWithValue("@Descriptions_Apps", string.IsNullOrEmpty(model.Descriptions_Apps) == true ? "" : model.Descriptions_Apps.ToString());
                                        cmd.Parameters.AddWithValue("@Is_Active", string.IsNullOrEmpty("1") == true ? "" : "1");
                                        cmd.Parameters.AddWithValue("@User", string.IsNullOrEmpty(strUser) == true ? "" : strUser.ToString());
                                        cmd.Parameters.AddWithValue("@StatementType", "insert");


                                        conn.Open();
                                        cmd.ExecuteNonQuery();
                                    }
                                }
                                TempData["messageRequest"] = "<script>alert('Save Data Success.');</script>";
                                //return Content("jAlert('Wow !My alert message with custom titile','My custom title bar here...');");
                                //return Content("<script language='javascript' type='text/javascript'>jAlert('Wow !My alert message with custom titile','My custom title bar here...');</script>");
                                return RedirectToAction("AddUser", "RegistrationUser");
                            }
                            else
                            {
                                TempData["messageRequest"] = "<script>alert('User Apps and Password is cannot be empty string.');</script>";
                                return View(model);
                            }
                        }
                        else
                        {
                            TempData["messageRequest"] = "<script>alert('User Apps and Password is cannot be null.');</script>";
                            return View(model);
                        }
                    }
                }
                else return RedirectToAction("AddUser", "RegistrationUser");
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                //return Content("jAlert('Wow !My alert message with custom titile','My custom title bar here...');");
                //return Content("<script language='javascript' type='text/javascript'>jAlert('Wow !My alert message with custom titile','My custom title bar here...');</script>");
                return RedirectToAction("AddUser", "RegistrationUser");
            }            
        }

        // GET: Edit RegistrationUser
        public ActionResult EditUser(string ID)
        {

            Session["controller"] = "RegistrationController";

            ViewBag.menu = Session["menu"];

            ViewUserApiModels model = new ViewUserApiModels();
            List<ViewUserApiModels> lstData = GetDataUserAPI(ID, "", "", "", "");
            if (lstData != null)
            {
                if (lstData.Count > 0) model = lstData.FirstOrDefault();
            }
            if (model.Is_Active == "True") model.Is_Active = "1";
            if (model.Is_Active == "False") model.Is_Active = "0";
            model.lst_Desc_Apps = DDLApplication();

            return View(model);
        }

        [HttpPost]
        public ActionResult EditUser(ViewUserApiModels model = null, string Submit = "")
        {
            try
            {

                Session["controller"] = "RegistrationController";
                ViewBag.menu = Session["menu"];
                string strUser = (string)Session["UserID"];
                model.lst_Desc_Apps = DDLApplication();
                if (Submit == "Submit")
                {
                    if (model.Descriptions_Apps.ToString() == "--Choose--")
                    {
                        TempData["messageRequest"] = "<script>alert('Please Choose a Application');</script>";
                        return View(model);
                    }
                    else
                    {
                        bool bCheck = true;
                        bCheck = model.User_Apps == null ? false : true;
                        bCheck = model.Password_Apps == null ? false : true;
                        if (bCheck)
                        {
                            bCheck = model.User_Apps == "" ? false : true;
                            bCheck = model.Password_Apps == "" ? false : true;
                            if (bCheck)
                            {
                                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSql"].ConnectionString))
                                {
                                    using (SqlCommand cmd = new SqlCommand("sp_INSERT_DATA_USER_API", conn))
                                    {
                                        cmd.CommandType = CommandType.StoredProcedure;
                                        cmd.Parameters.AddWithValue("@ID", string.IsNullOrEmpty(model.Id) == true ? "" : model.Id.ToString().TrimEnd());
                                        cmd.Parameters.AddWithValue("@User_Apps", string.IsNullOrEmpty(model.User_Apps) == true ? "" : model.User_Apps.ToString().TrimEnd());
                                        cmd.Parameters.AddWithValue("@Password_Apps", string.IsNullOrEmpty(model.Password_Apps) == true ? "" : model.Password_Apps.ToString().TrimEnd());
                                        cmd.Parameters.AddWithValue("@Descriptions_Apps", string.IsNullOrEmpty(model.Descriptions_Apps) == true ? "" : model.Descriptions_Apps.ToString());
                                        cmd.Parameters.AddWithValue("@Is_Active", string.IsNullOrEmpty(model.Is_Active) == true ? "0" : model.Is_Active);
                                        cmd.Parameters.AddWithValue("@User", string.IsNullOrEmpty(strUser) == true ? "" : strUser.ToString());
                                        cmd.Parameters.AddWithValue("@StatementType", "update");


                                        conn.Open();
                                        cmd.ExecuteNonQuery();
                                    }
                                }
                                TempData["messageRequest"] = "<script>alert('Save Data Success.');</script>";
                                //return Content("jAlert('Wow !My alert message with custom titile','My custom title bar here...');");
                                //return Content("<script language='javascript' type='text/javascript'>jAlert('Wow !My alert message with custom titile','My custom title bar here...');</script>");
                                return RedirectToAction("AddUser", "RegistrationUser");
                            }
                            else
                            {
                                TempData["messageRequest"] = "<script>alert('User Apps and Password is cannot be empty string.');</script>";
                                return View(model);
                            }
                        }
                        else
                        {
                            TempData["messageRequest"] = "<script>alert('User Apps and Password is cannot be null.');</script>";
                            return View(model);
                        }
                    }
                }
                else return RedirectToAction("AddUser", "RegistrationUser");
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                //return Content("jAlert('Wow !My alert message with custom titile','My custom title bar here...');");
                //return Content("<script language='javascript' type='text/javascript'>jAlert('Wow !My alert message with custom titile','My custom title bar here...');</script>");
                return RedirectToAction("AddUser", "RegistrationUser");
            }

        }

        /// <summary>
        /// Add User in Profiles (admin only)
        /// </summary>
        /// <returns></returns>
        public ActionResult AddUserProfiles()
        {
            ProfileModels model = new ProfileModels();
            model.Flag = DDLFlag();
            model.DeptLst = DDLDept();
            model.RoleLst = RoleLst();

            ViewBag.menu = Session["menu"];
            Session["controller"] = "RegistrationController";
            return View(model);
        }

        [HttpPost]
        public ActionResult AddUserProfiles(HttpPostedFileBase file, ProfileModels model, string Submit)
        {
            model.Flag = DDLFlag();
            model.DeptLst = DDLDept();
            model.RoleLst = RoleLst();
            ViewBag.menu = Session["menu"];
            Session["controller"] = "RegistrationController";

            KeyValuePair<string, string> statusInsert = new KeyValuePair<string, string>();

            if (Submit == "Download")
            {
                Response.ContentType = "application/vnd.ms-excel";
                Response.AppendHeader("Content-Disposition", "attachment; filename=format_profile.xlsx");
                Response.TransmitFile(Server.MapPath("~/Uploads/Profile/format_profile.xlsx"));
                Response.End();
            };
            if (Submit == "Submit")
            {
                if (ModelState.IsValid)
                {
                    if (model.EmployeeID != "")
                    {
                        //1.MST_PROFILE
                        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSql"].ConnectionString))
                        {
                            conn.Open();
                            statusInsert = ProcessUserProfile(model, conn);
                            conn.Close();
                        };

                        TempData["messageRequest"] = string.Format("<script>alert('{0}');</script>", $"Employee ID : {statusInsert.Key}, {statusInsert.Value}");
                        TempData["messageRequest"] = "<script>alert('Submit Data Success');</script>";
                        return RedirectToAction("AddUserProfiles", "RegistrationUser");
                    }
                }

                else
                {
                    return View(model);
                }
            };
            if (Submit == "Upload")
            {
                // Section of Upload File
                DataTable dt_File = new DataTable();
                bool bStatus = true;
                //Checking file content length and Extension must be .xlsx  
                if (file != null && file.ContentLength > 0 && System.IO.Path.GetExtension(file.FileName).ToLower() == ".xlsx")
                {
                    try
                    {
                        string strFileName = WebConfigurationManager.AppSettings["name_file_upload_excel_add_user_profile"].ToString();
                        strFileName = System.IO.Path.GetFileNameWithoutExtension(file.FileName) + "_" + strFileName + "_" + DateTime.Now.ToString("HHmmss_ddMMyyyy") + ".xlsx";
                        string path = Path.Combine(Server.MapPath("~/Uploads/Profile"), strFileName);
                        //Saving the file  
                        file.SaveAs(path);

                        using (FileStream fs = System.IO.File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                        {
                            // get data from excel using loop process
                            dt_File = GetDataFromExcel(fs, "Insert");
                            // default column of excel
                            List<string> lstColums = new List<string>() {
                                    "No"//0
                                    ,"Employee ID"
                                    ,"User Apps"
                                    ,"Employee Name"
                                    ,"Departement"                                   
                                    ,"Role"
                                    ,"Dashboard"//6
                                    ,"Validation Dukcapil"
                                    ,"Databalikan Dukcapil"
                                    ,"Report"
                                    ,"Report Data Validation"
                                    ,"Report Data Balikan"//11
                                };

                            // check column of default and datatable is equal
                            //bool bCheckColumns = false;
                            DataTable dtFormat = new DataTable();
                            DataTable dtPriv = new DataTable();
                            dtPriv.Columns.Add("Name", typeof(string));
                            dtPriv.Columns.Add("MenuID", typeof(string));

                            int iCol = 0;
                            foreach (string item in lstColums)
                            {
                                string xlColumn = dt_File.Columns[iCol].ToString();
                                if (xlColumn.Equals(item))
                                {
                                    dtFormat.Columns.Add(item, typeof(string));
                                    if (item.Equals("Dashboard")) dtPriv.Rows.Add(item, "2");
                                    if (item.Equals("Validation Dukcapil")) dtPriv.Rows.Add(item, "18");
                                    if (item.Equals("Databalikan Dukcapil")) dtPriv.Rows.Add(item, "14");
                                    if (item.Equals("Report")) dtPriv.Rows.Add(item, "11");
                                    if (item.Equals("Report Data Validation")) dtPriv.Rows.Add(item, "19");
                                    if (item.Equals("Report Data Balikan")) dtPriv.Rows.Add(item, "13");
                                }
                                iCol++;
                            };
                            //if (dtFormat.Columns.Count == lstColums.Count) bCheckColumns = true;

                            if (dtFormat.Columns.Count == lstColums.Count)
                            {
                                //process here
                                //1.MST_PROFILES
                                //"EXEC [dbo].[sp_INSERT_MST_PROFILE] @EmployeeID = N'{0}', @EmployeeName = N'{1}', @Departement = N'{2}', @UserApps = N'{3}', @CreatedBy = N'{4}', @Flag = 1;";
                                List<string> lstQueryProfile = new List<string>();
                                //2.MST_USER_API
                                //"EXEC [dbo].[sp_INSERT_DATA_USER_API] @ID='', @User_Apps= N'{0}', @Password_Apps= N'{1}', @Descriptions_Apps= N'{2}', @Is_Active= 1, @User= N'{3}', @StatementType = N'insert';";
                                List<string> lstQueryUserApi = new List<string>();
                                //3.MST_PRIVILEGE
                                //"EXEC [dbo].[sp_INSERT_DATA_USER_API] @ID='', @User_Apps= N'{0}', @Password_Apps= N'{1}', @Descriptions_Apps= N'{2}', @Is_Active= 1, @User= N'{3}', @StatementType = N'insert'";
                                List<string> lstQueryPriv = new List<string>();

                                IList<ProfileModels> profileList = new List<ProfileModels>();

                                foreach (DataRow dr in dt_File.Rows)
                                {
                                    string empID = dr["Employee ID"].ToString();
                                    string userApps = dr["User Apps"].ToString();
                                    string roleID = dr["Role"].ToString() == "Super Admin" ? "1" : dr["Role"].ToString() == "Admin" ? "2" : "3";
                                    if (!string.IsNullOrEmpty(empID) && !string.IsNullOrEmpty(userApps))
                                    {
                                        profileList.Add(new ProfileModels
                                        {
                                            EmployeeID = empID,
                                            UserApps = userApps,
                                            EmployeeName = dr["Employee Name"].ToString(),
                                            Department = dr["Departement"].ToString(),                                           
                                            RoleID = roleID,
                                            isDashboard = dr["Dashboard"].ToString() == "1",
                                            isVerification = dr["Validation Dukcapil"].ToString() == "1",
                                            isDatabalikan = dr["Databalikan Dukcapil"].ToString() == "1",
                                            isReport = dr["Report"].ToString() == "1",
                                            isRptVerification = dr["Report Data Validation"].ToString() == "1",
                                            isRptDatabalikan = dr["Report Data Balikan"].ToString() == "1",
                                            FlagID = "1",
                                            CreatedBy = Session["UserID"].ToString()
                                        });
                                    }                                    
                                };

                                IList<KeyValuePair<string, string>> employeeInsertStatusList = new List<KeyValuePair<string, string>>();

                                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSql"].ConnectionString))
                                {
                                    foreach (ProfileModels profile in profileList)
                                    {
                                        conn.Open();
                                        employeeInsertStatusList.Add(ProcessUserProfile(profile, conn));
                                        conn.Close();
                                    }
                                }

                                string msg = "";
                                if (employeeInsertStatusList.Any())
                                {
                                    employeeInsertStatusList.ToList().
                                        ForEach(x =>
                                       {
                                           msg += $"Employee ID : {x.Key}, {x.Value} \\n";
                                       });
                                }
                                else
                                {
                                    msg = $"No valid data has been found in excel file";
                                }

                                 TempData["messageRequest"] = string.Format("<script>alert('{0}');</script>", msg);
                            }
                            else
                            {
                                TempData["ErrorRequest"] = "Column in File Excel not match.";
                                bStatus = false;
                            };

                        };
                    }
                    catch (Exception ex)
                    {
                        TempData["ErrorRequest"] = ex.Message.ToString();
                    }

                }
                else
                {
                    //If file extension of the uploaded file is different then .xlsx  
                    //ViewBag.Message = "Please select file with .xlsx extension!";
                    TempData["ErrorRequest"] = "Upload failed, the file should be .xlsx extension!";
                    //TempData["messageRequest"] = "<script>alert('" + strResult + "');</script>";
                    bStatus = false;
                }
                return RedirectToAction("AddUserProfiles");
            }

            return View(model);
        }

        private void AddUserPrf(ProfileModels model, SqlConnection conn)
        {
            using (SqlCommand cmd = new SqlCommand("sp_INSERT_MST_PROFILE", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmployeeID", string.IsNullOrEmpty(model.EmployeeID) ? "" : model.EmployeeID);
                cmd.Parameters.AddWithValue("@EmployeeName", string.IsNullOrEmpty(model.EmployeeName) ? "" : model.EmployeeName);
                cmd.Parameters.AddWithValue("@Departement", string.IsNullOrEmpty(model.Department) ? "" : model.Department);
                cmd.Parameters.AddWithValue("@UserApps", string.IsNullOrEmpty(model.UserApps) ? "" : model.UserApps);
                cmd.Parameters.AddWithValue("@CreatedBy", string.IsNullOrEmpty(Session["UserID"].ToString()) ? "" : Session["UserID"].ToString());
                cmd.Parameters.AddWithValue("@Flag", string.IsNullOrEmpty(model.FlagID) ? "0" : model.FlagID);

                cmd.ExecuteNonQuery();

            }
            // 2. MST_USER_API
            using (SqlCommand cmd = new SqlCommand("sp_INSERT_DATA_USER_API", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", "");
                cmd.Parameters.AddWithValue("@User_Apps", string.IsNullOrEmpty(model.UserApps) ? "" : model.UserApps);
                cmd.Parameters.AddWithValue("@Password_Apps", "AMFS-User");
                cmd.Parameters.AddWithValue("@Descriptions_Apps", "DASHBOARD");
                cmd.Parameters.AddWithValue("@Is_Active", string.IsNullOrEmpty(model.FlagID) ? "0" : model.FlagID);
                cmd.Parameters.AddWithValue("@User", string.IsNullOrEmpty(Session["UserID"].ToString()) ? "" : Session["UserID"].ToString());
                cmd.Parameters.AddWithValue("@StatementType", "insert");

                cmd.ExecuteNonQuery();

            };
            // 3. MST_PRIVILEGE
            // before we insert please to make sure delete data by EmpId...
            using (SqlCommand cmd = new SqlCommand("sp_Delete_Privilege", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", string.IsNullOrEmpty(model.EmployeeID) ? "" : model.EmployeeID);

                cmd.ExecuteNonQuery();
            }
            // than we insert...
            using (SqlCommand cmd = new SqlCommand("sp_Insert_Previlege", conn))
            {
                SqlTransaction transaction = conn.BeginTransaction("trPriv");
                cmd.Transaction = transaction;
                cmd.CommandType = CommandType.StoredProcedure;
                if (model.isDashboard)
                {
                    cmd.Parameters.AddWithValue("@RoleID", model.RoleID);
                    cmd.Parameters.AddWithValue("@MenuID", "2");
                    cmd.Parameters.AddWithValue("@NIK", model.EmployeeID);
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                };
                if (model.isVerification)
                {
                    cmd.Parameters.AddWithValue("@RoleID", model.RoleID);
                    cmd.Parameters.AddWithValue("@MenuID", "18");
                    cmd.Parameters.AddWithValue("@NIK", model.EmployeeID);
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                };
                if (model.isDatabalikan)
                {
                    cmd.Parameters.AddWithValue("@RoleID", model.RoleID);
                    cmd.Parameters.AddWithValue("@MenuID", "14");
                    cmd.Parameters.AddWithValue("@NIK", model.EmployeeID);
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                };
                if (model.isReport)
                {
                    cmd.Parameters.AddWithValue("@RoleID", model.RoleID);
                    cmd.Parameters.AddWithValue("@MenuID", "11");
                    cmd.Parameters.AddWithValue("@NIK", model.EmployeeID);
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                };
                if (model.isRptVerification)
                {
                    cmd.Parameters.AddWithValue("@RoleID", model.RoleID);
                    cmd.Parameters.AddWithValue("@MenuID", "19");
                    cmd.Parameters.AddWithValue("@NIK", model.EmployeeID);
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                };
                if (model.isRptDatabalikan)
                {
                    cmd.Parameters.AddWithValue("@RoleID", model.RoleID);
                    cmd.Parameters.AddWithValue("@MenuID", "13");
                    cmd.Parameters.AddWithValue("@NIK", model.EmployeeID);
                    cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                };
                transaction.Commit();
            };
        }

        public ActionResult AddDeptHead()
        {

            Session["controller"] = "RegistrationController";
            ViewBag.menu = Session["menu"];
            DeptHeadModels model = new DeptHeadModels();
            model.lst_isActive = DDLFlag();
            //model.lst_Dept = DDLDept();

            // Get data for Table
            model.lst_view_Dept = GetDataDepartement(null,"", null);
            return View(model);
        }

        [HttpPost]
        public ActionResult AddDeptHead(DeptHeadModels model, string Submit)
        {

            Session["controller"] = "RegistrationController";
            ViewBag.menu = Session["menu"];
            model.lst_isActive = DDLFlag();
            //model.lst_Dept = DDLDept();

            if (Submit == "Submit")
            {
                if (ModelState.IsValid == true)
                {
                    if (model.Departement.Trim() != "" && model.Name.Trim() != "" && model.Email.Trim() != "")
                    {
                        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSql"].ConnectionString))
                        {
                            conn.Open();
                            // 1. MST_DEPT_HEAD
                            using (SqlCommand cmd = new SqlCommand("sp_INSERT_MST_DEPT_HEAD", conn))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@Departement", model.Departement.Trim());
                                cmd.Parameters.AddWithValue("@Name", model.Name);
                                cmd.Parameters.AddWithValue("@Email", model.Email);
                                cmd.Parameters.AddWithValue("@Is_Active", model.Is_Active );
                                cmd.Parameters.AddWithValue("@User", string.IsNullOrEmpty(Session["UserID"].ToString()) == true ? "" : Session["UserID"].ToString());
                                cmd.Parameters.AddWithValue("@ID", "0");

                                cmd.ExecuteNonQuery();
                            };                         
                            conn.Close();
                        };

                        TempData["messageRequest"] = "<script>alert('Submit Data Success');</script>";
                        return RedirectToAction("AddDeptHead", "RegistrationUser");
                    };
                };
            };

            // Get data for Table
            model.lst_view_Dept = GetDataDepartement(null,"", null);
            return View(model);
        }

        public ActionResult EditDeptHead(string ID)
        {

            Session["controller"] = "RegistrationController";
            ViewBag.menu = Session["menu"];
            // Get data for Table
            List<ViewDeptHeadModels> lstModel = GetDataDepartement(ID, "", null);
            ViewDeptHeadModels model = new ViewDeptHeadModels();
            model.Id = ID;
            model.Departement = lstModel[0].Departement;
            model.Name = lstModel[0].Name;
            model.Email = lstModel[0].Email;
            model.Is_Active = lstModel[0].Is_Active;
            model.lst_isActive = DDLFlag();
            return View(model);
        }

        [HttpPost]
        public ActionResult EditDeptHead(ViewDeptHeadModels model, string Submit)
        {
            try
            {

                Session["controller"] = "RegistrationController";
                ViewBag.menu = Session["menu"];
                string strUser = (string)Session["UserID"];
                model.lst_isActive = DDLFlag();
                if (Submit == "Submit")
                {
                    if (ModelState.IsValid == true)
                    {
                        if (model.Departement.Trim() != "" && model.Name.Trim() != "" && model.Email.Trim() != "")
                        {
                            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSql"].ConnectionString))
                            {
                                conn.Open();
                                // 1. MST_DEPT_HEAD
                                using (SqlCommand cmd = new SqlCommand("sp_INSERT_MST_DEPT_HEAD", conn))
                                {
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.Parameters.AddWithValue("@Departement", model.Departement.Trim());
                                    cmd.Parameters.AddWithValue("@Name", model.Name);
                                    cmd.Parameters.AddWithValue("@Email", model.Email);
                                    cmd.Parameters.AddWithValue("@Is_Active", model.Is_Active);
                                    cmd.Parameters.AddWithValue("@User", string.IsNullOrEmpty(Session["UserID"].ToString()) == true ? "" : Session["UserID"].ToString());
                                    cmd.Parameters.AddWithValue("@ID", model.Id);

                                    cmd.ExecuteNonQuery();
                                };
                                conn.Close();
                            };

                            TempData["messageRequest"] = "<script>alert('Submit Data Success');</script>";
                            return RedirectToAction("AddDeptHead", "RegistrationUser");
                        }
                        else
                        {
                            TempData["messageRequest"] = "<script>alert('Departement,Name and Email cannot be null.');</script>";
                            return View(model);
                        }
                    }
                    else
                    {
                        TempData["messageRequest"] = "<script>alert('ModelState is not valid');</script>";
                        return View(model);
                    }
                }
                else return RedirectToAction("AddDeptHead", "RegistrationUser");
            }
            catch (Exception ex)
            {
                TempData["messageRequest"] = "<script>alert('" + ex.Message.ToString() + "');</script>";
                return View(model);
            }
        }
        private static List<SelectListItem> DDLApplication()
        {
            SqlConnection con = Common.GetConnection();
            List<SelectListItem> item = new List<SelectListItem>();
            string query = "EXEC [dbo].[sp_GET_APPLICATION] ";

            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Connection = con;
                con.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        item.Add(new SelectListItem
                        {
                            Text = dr["ApplicationName"].ToString(),
                            Value = dr["ApplicationName"].ToString()
                        });
                    }
                }


                con.Close();
            }
            return item;
        }

        public DataSet Get_Menu()

        {

            SqlCommand com = new SqlCommand("exec [sp_Get_Menu_Parent] '" + Session["EmployeeNumber"] + "'", Common.GetConnection());

            SqlDataAdapter da = new SqlDataAdapter(com);

            DataSet ds = new DataSet();

            da.Fill(ds);


            return ds;

        }

        public DataSet Get_SubMenu(string ParentID)

        {

            SqlCommand com = new SqlCommand("exec [sp_Get_SubMenu] '" + Session["EmployeeNumber"] + "',@ParentID", Common.GetConnection());

            com.Parameters.AddWithValue("@ParentID", ParentID);

            SqlDataAdapter da = new SqlDataAdapter(com);

            DataSet ds = new DataSet();

            da.Fill(ds);

            return ds;

        }

        public void get_Submenu(string catid)

        {

            DataSet ds = Get_SubMenu(catid);

            List<MenuViewModels.SubMenu> submenulist = new List<MenuViewModels.SubMenu>();

            foreach (DataRow dr in ds.Tables[0].Rows)

            {

                submenulist.Add(new MenuViewModels.SubMenu
                {

                    MenuID = dr["MenuID"].ToString(),

                    MenuName = dr["MenuName"].ToString(),

                    ActionName = dr["ActionName"].ToString(),

                    ControllerName = dr["ControllerName"].ToString()

                });

            }

            Session["submenu"] = submenulist;

        }

        private static List<ViewUserApiModels> GetDataUserAPI(string strID, string strUser_Apps, string strPass_Apps, 
            string strDesc_Apps,string strIs_Active)
        {
            List<ViewUserApiModels> items = new List<ViewUserApiModels>();
            DataTable dtRet = new DataTable();
            using (SqlConnection sqlconnection = Common.GetConnection())
            {                
                SqlCommand command = new SqlCommand("sp_GET_DATA_USER_API", sqlconnection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ID", string.IsNullOrEmpty(strID) == true ? "" : strID);
                command.Parameters.AddWithValue("@User_Apps", string.IsNullOrEmpty(strUser_Apps) == true ? "" : strUser_Apps);
                command.Parameters.AddWithValue("@Password_Apps", string.IsNullOrEmpty(strPass_Apps) == true ? "" : strPass_Apps);
                command.Parameters.AddWithValue("@Descriptions_Apps", string.IsNullOrEmpty(strDesc_Apps) == true ? "" : strDesc_Apps);
                command.Parameters.AddWithValue("@Is_Active", string.IsNullOrEmpty(strIs_Active) == true ? "" : strIs_Active);

                command.Connection.Open();
                SqlDataAdapter adp = new SqlDataAdapter(command);
                //DataSet ds = new DataSet();
                adp.Fill(dtRet);
                adp.Dispose();
                command.Connection.Close();
            }
            if (dtRet != null)
            {
                if (dtRet.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtRet.AsEnumerable())
                    {
                        ViewUserApiModels dataUserApi = new ViewUserApiModels();
                        dataUserApi.Id = dr["ID"].ToString();
                        dataUserApi.User_Apps = dr["User_Apps"].ToString();
                        dataUserApi.Password_Apps = dr["Password_Apps"].ToString();
                        dataUserApi.Descriptions_Apps = dr["Descriptions_Apps"].ToString();
                        dataUserApi.Is_Active = dr["Is_Active"].ToString();
                        items.Add(dataUserApi);
                    }
                }
            }
            return items;
        }

        private static List<ViewDeptHeadModels> GetDataDepartement(string strID,string strDept, string is_active)
        {
            List<ViewDeptHeadModels> items = new List<ViewDeptHeadModels>();
            DataTable dtRet = new DataTable();
            using (SqlConnection sqlconnection = Common.GetConnection())
            {
                SqlCommand command = new SqlCommand("sp_GET_DATA_MST_DEPT_HEAD", sqlconnection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ID", string.IsNullOrEmpty(strID) == true ? null: strID);
                command.Parameters.AddWithValue("@Departement", string.IsNullOrEmpty(strDept) == true ? "" : strDept);
                command.Parameters.AddWithValue("@Is_Active", string.IsNullOrEmpty(is_active) == true ? null : is_active);              
                command.Connection.Open();
                SqlDataAdapter adp = new SqlDataAdapter(command);
                //DataSet ds = new DataSet();
                adp.Fill(dtRet);
                adp.Dispose();
                command.Connection.Close();
            }
            if (dtRet != null)
            {
                if (dtRet.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtRet.AsEnumerable())
                    {
                        ViewDeptHeadModels dataDept = new ViewDeptHeadModels();
                        dataDept.Id = dr["ID"].ToString();
                        dataDept.Departement = dr["Departement"].ToString();
                        dataDept.Name = dr["Name"].ToString();
                        dataDept.Email = dr["Email"].ToString();
                        dataDept.Is_Active = dr["Is_Active"].ToString().ToLower() == "true" ? 1:0;
                        items.Add(dataDept);
                    }
                }
            }
            return items;
        }
        private static List<SelectListItem> DDLFlag()
        {
            SqlConnection con = Common.GetConnection();
            List<SelectListItem> item = new List<SelectListItem>();
            string query = "EXEC [dbo].[sp_GET_FLAG] ";

            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Connection = con;
                con.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        item.Add(new SelectListItem
                        {
                            Text = dr["FLAG"].ToString(),
                            Value = dr["FLAGID"].ToString()
                        });
                    }
                }


                con.Close();
            }
            return item;
        }
        private static List<SelectListItem> DDLDept()
        {
            SqlConnection con = Common.GetConnection();
            List<SelectListItem> item = new List<SelectListItem>();
            string query = "select distinct Departement from MST_DEPT_HEAD";

            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Connection = con;
                con.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        item.Add(new SelectListItem
                        {
                            Text = dr["Departement"].ToString(),
                            Value = dr["Departement"].ToString()
                        });
                    }
                }
                con.Close();
            }
            return item;
        }
        private static List<SelectListItem> RoleLst()
        {
            //Role          id
            //SuperAdmin    1
            //Admin         2
            //NonAdmin      3
            List<SelectListItem> item = new List<SelectListItem>();
            //item.Add(new SelectListItem
            //{
            //    Text = "SuperAdmin",
            //    Value = "1"
            //});
            item.Add(new SelectListItem
            {
                Text = "Admin",
                Value = "2"
            });
            item.Add(new SelectListItem
            {
                Text = "User",
                Value = "3"
            });
            return item;
        }
        public static DataTable GetDataFromExcel(FileStream fsPath, dynamic worksheet)
        {
            DataTable dt = new DataTable();
            //Open the Excel file using ClosedXML.
            using (XLWorkbook workBook = new XLWorkbook(fsPath))
            {
                //Read the first Sheet from Excel file.
                IXLWorksheet workSheet = workBook.Worksheet(worksheet);

                //Create a new DataTable.

                //Loop through the Worksheet rows.
                bool firstRow = true;
                foreach (IXLRow row in workSheet.RowsUsed())
                {
                    //Use the first row to add columns to DataTable.
                    if (firstRow)
                    {
                        foreach (IXLCell cell in row.Cells())
                        {
                            if (!string.IsNullOrEmpty(cell.Value.ToString()))
                            {
                                dt.Columns.Add(cell.Value.ToString());
                            }
                            else
                            {
                                break;
                            }
                        }
                        firstRow = false;
                    }
                    else
                    {
                        int i = 0;
                        DataRow toInsert = dt.NewRow();
                        foreach (IXLCell cell in row.Cells(1, dt.Columns.Count))
                        {
                            try
                            {
                                toInsert[i] = cell.Value.ToString();
                            }
                            catch (Exception ex)
                            {

                            }
                            i++;
                        }
                        dt.Rows.Add(toInsert);
                    }
                }
                return dt;
            }
        }

        public JsonResult GetDataEmpId(string strEmpId)
        {
            List<string> lstEmpId = new List<string>();
            DataTable dtRet = new DataTable();
            using (SqlConnection sqlconnection = Common.GetConnection())
            {
                SqlCommand command = new SqlCommand("sp_GET_DATA_EMPLOYEE_ID", sqlconnection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@EMP_ID", string.IsNullOrEmpty(strEmpId) == true ? "" : strEmpId);

                command.Connection.Open();
                SqlDataAdapter adp = new SqlDataAdapter(command);
                //DataSet ds = new DataSet();
                adp.Fill(dtRet);
                adp.Dispose();
                command.Connection.Close();
            }
            if (dtRet != null)
            {
                if (dtRet.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtRet.AsEnumerable())
                    {
                        string strData_EmpId = dr["EmployeeID"].ToString();
                        lstEmpId.Add(strData_EmpId);
                    }
                }
            }
            return Json(lstEmpId, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetDataEmpName(string strEmpId)
        {
            List<string> lstEmpId = new List<string>();
            DataTable dtRet = new DataTable();
            using (SqlConnection sqlconnection = Common.GetConnection())
            {
                SqlCommand command = new SqlCommand("sp_GET_DATA_EMPLOYEE_ID", sqlconnection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@EMP_ID", string.IsNullOrEmpty(strEmpId) == true ? "" : strEmpId);

                command.Connection.Open();
                SqlDataAdapter adp = new SqlDataAdapter(command);
                //DataSet ds = new DataSet();
                adp.Fill(dtRet);
                adp.Dispose();
                command.Connection.Close();
            }
            if (dtRet != null)
            {
                if (dtRet.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtRet.AsEnumerable())
                    {
                        string strData_EmpId = dr["EmployeeName"].ToString();
                        lstEmpId.Add(strData_EmpId);
                    }
                }
            }
            return Json(lstEmpId[0], JsonRequestBehavior.AllowGet);
        }

        [AcceptVerbs("Get","Post")]
        public JsonResult GetUser(string param)
        {
            UserViewModel user = new UserViewModel();

            using (SqlConnection sqlConnection = Common.GetConnection())
            {
                sqlConnection.Open();
                user = GetUserProfileByEmployeeID(param,sqlConnection);
                sqlConnection.Close();
            }
            
            return Json(user);
        }


        private UserViewModel GetUserProfileByEmployeeID(string empID, SqlConnection sqlConnection)
        {
            UserViewModel user = new UserViewModel();

            string query = "sp_GetUserProfileByEmployeeID";
            using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
            {
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@EmployeeID", empID);
                using (SqlDataReader dataReader = sqlCommand.ExecuteReader())
                {
                    user.IsEmployeeExist = dataReader.HasRows;
                    while (dataReader.Read())
                    {
                        user.EmployeeID = dataReader["EmployeeID"].ToString();
                        user.EmployeeName = dataReader["EmployeeName"].ToString();
                        user.Departement = (dataReader["Departement"] ?? "").ToString();
                        user.Role = (dataReader["RoleID"] ?? "").ToString();
                        user.UserApps = (dataReader["UserApps"] ?? "").ToString();
                        user.Flag = dataReader["Flag"].ToString();
                        user.IsProfileExist = (dataReader["UserApps"] ?? "").ToString() != "";
                        user.AuthorizeDashboard = dataReader["AuthorizeDashboard"].ToString() == "1";
                        user.AuthorizeValidation = dataReader["AuthorizeValidation"].ToString() == "1";
                        user.AuthorizeDataBalikan = dataReader["AuthorizeDataBalikan"].ToString() == "1";
                        user.AuthorizeReport = dataReader["AuthorizeReport"].ToString() == "1";
                        user.AuthorizeReportValidation = dataReader["AuthorizeReportValidation"].ToString() == "1";
                        user.AuthorizeReportDataBalikan = dataReader["AuthorizeReportDataBalikan"].ToString() == "1";
                    }
                }
            }

            return user;
        }

        private KeyValuePair<string,string> ProcessUserProfile (ProfileModels profile, SqlConnection conn)
        {
            UserViewModel user = GetUserProfileByEmployeeID(profile.EmployeeID, conn);
            KeyValuePair<string, string> statusProfile = new KeyValuePair<string, string>();
            if (user.IsEmployeeExist)
            {
                if (user.IsProfileExist && user.Role == "1")
                {
                    statusProfile = new KeyValuePair<string, string>(profile.EmployeeID, "have role Super Admin, cannot be updated !");
                }
                else if (user.IsProfileExist)
                {
                    profile.UserApps = user.UserApps;
                    profile.EmployeeName = user.EmployeeName;
                    AddUserPrf(profile, conn);
                    statusProfile = new KeyValuePair<string, string>(profile.EmployeeID, "succesfully updated !");
                }
                else
                {
                    AddUserPrf(profile, conn);
                    statusProfile = new KeyValuePair<string, string>(profile.EmployeeID, "succesfully added !");
                }
            }
            else
            {
                statusProfile = new KeyValuePair<string, string>(profile.EmployeeID, "is not exist !");
            }

            return statusProfile;
        }

    }
}