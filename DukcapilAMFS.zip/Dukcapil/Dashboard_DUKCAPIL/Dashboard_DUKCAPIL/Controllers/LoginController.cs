﻿using Dashboard_DUKCAPIL.Models;
using Dashboard_DUKCAPIL.Repository;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dashboard_DUKCAPIL.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            LoginModels model = new LoginModels();
            return View(model);
        }
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Index(string returnUrl, LoginModels model)
        {
            try
            {
                string EmplNumber = "";
                
                ViewBag.ReturnUrl = returnUrl;
                String adPath = ConfigurationManager.AppSettings["LDAPPath"].ToString();
                String domain = ConfigurationManager.AppSettings["LDAPDomain"].ToString();
                LdapAuthentication adAuth = new LdapAuthentication(adPath);
                String LocalHostaddress = HttpContext.Request.UserHostAddress;
                String Ip_Local = LocalHostaddress.Replace(".", "").Replace("::", "").Trim();
                Boolean bCheckEmp = adAuth.IsAuthenticated(domain, model.UserName, model.Password);
                if (bCheckEmp)
                {
                    string strGroup = adAuth.GetGroups();
                    EmplNumber = adAuth.GetPropertyUser(domain, model.UserName, model.Password);
                    Session["EmployeeNumber"] = EmplNumber;
                    Session["UserID"] = model.UserName;
                    if (EmplNumber != null)
                    {                       
                        if (EmplNumber != "")
                        {
                            bool bIsNumber = EmplNumber.All(char.IsDigit);
                            if (bIsNumber)
                            {
                                DataTable dtlogin = Common.ExecuteQuery("sp_CHECK_ROLE'" + model.UserName + "','" + EmplNumber + "'");
                                if (dtlogin.Rows.Count > 0)
                                {
                                    Session["Role"] = dtlogin.Rows[0]["Role"].ToString();
                                }

                                DataSet ds = Get_Menu();
                                Session["menu"] = ds.Tables[0];

                                return RedirectToAction("Dashboard", "Home");

                            }
                            else
                            {
                                ViewBag.Message = "Employee is Not User.";
                            };

                        };
                    };
                }

                // for dev only
                //model.UserName = "HERMAN";
                //model.EmployeeID = "136363";
                //Session["EmployeeNumber"] = model;

                //Session["UserID"] = "alia andarina";
                //EmplNumber = "107516";
                //Session["EmployeeNumber"] = EmplNumber;
                //if (EmplNumber != "")
                //{
                //    DataTable dtlogin = Common.ExecuteQuery("sp_CHECK_ROLE'" + model.UserName + "','" + EmplNumber + "'");
                //    if (dtlogin.Rows.Count > 0)
                //    {
                //        Session["Role"] = dtlogin.Rows[0]["Role"].ToString();
                //    }


                //    DataSet ds = Get_Menu();
                //    Session["menu"] = ds.Tables[0];

                //    return RedirectToAction("Dashboard", "Home");
                //}

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                //ShowMessage("", model.Message);
                return View(model);
            }

            return View(model);
        }

        // Menu
        public DataSet Get_Menu()

        {

            SqlCommand com = new SqlCommand("exec [sp_Get_Menu_Parent] '" + Session["EmployeeNumber"] + "'", Common.GetConnection());

            SqlDataAdapter da = new SqlDataAdapter(com);

            DataSet ds = new DataSet();

            da.Fill(ds);


            return ds;

        }

        public DataSet Get_SubMenu(string ParentID)

        {

            SqlCommand com = new SqlCommand("exec [sp_Get_SubMenu] '" + Session["EmployeeNumber"] + "',@ParentID", Common.GetConnection());

            com.Parameters.AddWithValue("@ParentID", ParentID);

            SqlDataAdapter da = new SqlDataAdapter(com);

            DataSet ds = new DataSet();

            da.Fill(ds);

            return ds;

        }

        public void get_Submenu(string catid)

        {

            DataSet ds = Get_SubMenu(catid);

            List<MenuViewModels.SubMenu> submenulist = new List<MenuViewModels.SubMenu>();

            foreach (DataRow dr in ds.Tables[0].Rows)

            {

                submenulist.Add(new MenuViewModels.SubMenu
                {

                    MenuID = dr["MenuID"].ToString(),

                    MenuName = dr["MenuName"].ToString(),

                    ActionName = dr["ActionName"].ToString(),

                    ControllerName = dr["ControllerName"].ToString()

                });

            }

            Session["submenu"] = submenulist;

        }
        // End Menu
    }
}