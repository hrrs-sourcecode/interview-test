﻿using EstatementLib.Object;
using GenerateLetterNCBReminder.Shared;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace GenerateLetterNCBReminder
{
    public enum WebMethod
    {
        None,
        Post,
        Get
    }
    public class SMSAPI
    {
        public string URL { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string ContentType { get; set; }

        public ResultStatus Send(WebMethod Method, string SendData, string PhoneNumber)
        {
            ResultStatus Result = new ResultStatus();

            if (string.IsNullOrEmpty(this.URL))
            {
                Console.WriteLine("URL NOT FOUND");
                Result.Status = false;
                Result.Message = "URL not found !";
                goto Exit;
            }

            try
            {
                if (Method == WebMethod.Post)
                {
                    #region Post Method
                    dynamic request = (HttpWebRequest)WebRequest.Create(this.URL);

                    //IWebProxy proxy = request.Proxy;

                    //if (proxy != null)
                    //{
                    //    //// Create a NetworkCredential object and associate it with the  
                    //    //// Proxy property of request object.
                    //    ////proxy.Credentials = new NetworkCredential(username, password);
                    //    proxy.Credentials = new NetworkCredential(UserName, "");
                    //    //// or 
                    //    //proxy.UseDefaultCredentials = true;

                    //    //// try forcing the proxy to use http (just to the proxy not from proxy to server)
                    //    //UriBuilder proxyAddress = new UriBuilder(proxy.Address);
                    //    //proxyAddress.Scheme = "http";

                    //    request.Proxy = proxy;
                    //}

                    Console.WriteLine("1");
                    string SecurityContext = "userid=" + this.UserName + "&password=" + this.Password + "&";
                    string Target = "msisdn=" + PhoneNumber + "&";
                    string Message = "message=" + SendData;
                    string Parameter = SecurityContext + Target + Message;
                    //Parameter = "userid=AXAFTEST&password=AXAFTEST789&msisdn=6285852894643&message=Yth Bpk/Ibu AMIELLA UDJI HANDAYANI, jmlh investasi Anda no polis 510-3943287 bln September dpt dilihat pd link https://t2m.io/e-statementIndividualAMFS. Password:tgl lahir (ddmmyyyy). Link berlaku 30 hari. Info hub. 021-30058788&sender=INFO&division=AT1&batchname=Test_Ekreasi&uploadby=Ekreasi_Test&channel=1";

                    var data = Encoding.ASCII.GetBytes(Parameter);

                    request.Method = "POST";
                    request.ContentType = this.ContentType;
                    request.ContentLength = data.Length;

                    Console.WriteLine("2");
                    using (var stream = request.GetRequestStream())
                    {
                        stream.Write(data, 0, data.Length);
                    }

                    var response = (HttpWebResponse)request.GetResponse();
                    Console.WriteLine("3");
                    var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                    if (responseString.Substring(7, 1) != "1")
                    {
                        Result.Status = false;
                        Result.Message = "Send SMS Failed Response : " + responseString;
                    }
                    else
                    {
                        Result.Status = true;
                        Result.Message = "Send SMS Success Response : " + responseString;
                    }
                    #endregion
                    Console.WriteLine("4");
                }
            }
            catch (Exception ex)
            {
                Result.Status = false;
                Result.Message = ex.Message;
            }

            Exit:
            return Result;
        }
    }

    public class SMSEIP
    {
        public string URL { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string ContentType { get; set; }
        public string transactionId { get; set; }
        public string appID { get; set; }
        public string entity { get; set; }
        public string service { get; set; }
        public string operation { get; set; }
        public string sender { get; set; }
        public string target { get; set; }
        public string message { get; set; }
        public string bizDivision { get; set; }
        public string batchName { get; set; }
        public string triggeredBy { get; set; }
        public int channelID { get; set; }
        public string deliveryStatusCD { get; set; }
        public string deliveryStatusDesc { get; set; }
        public string messageID { get; set; }

        public ResultStatus Send()
        {
            //Log log = new Log();
            ResultStatus Result = new ResultStatus();
            try
            {
                //Must be valid json
                string requestHeader =
                "{" +
                    "\"Header\":{" +
                    "\"SecurityContext\":{" +
                        "\"username\":\"" + this.UserName + "\"," +
                        "\"password\":\"" + this.Password + "\"}}," +
                    "\"Body\":{" +
                    "\"transactionId\":\"" + this.transactionId + "\"," +
                    "\"appID\":\"" + this.appID + "\"," +
                    "\"entity\":\"" + this.entity + "\"," +
                    "\"service\":\"" + this.service + "\"," +
                    "\"operation\":\"" + this.operation + "\"," +
                    "\"Customer\":{" +
                        "\"haveCommunicatedMessage\":[" +
                        "{" +
                            "\"sender\":\"" + this.sender + "\"," +
                            "\"target\":\"" + this.target + "\"," +
                            "\"message\":\"" + this.message + "\"," +
                            "\"bizDivision\":\"" + this.bizDivision + "\"," +
                            "\"batchName\":\"" + this.batchName + "\"," +
                            "\"triggeredBy\":\"" + this.triggeredBy + "\"," +
                            "\"channelID\":\"" + this.channelID + "\"" +
                        "}" +
                        "]" +
                    "}" +
                    "}" +
                "}";

                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls;
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => { return true; };
                //Console.WriteLine("WebRequest");
                dynamic request = (HttpWebRequest)WebRequest.Create(URL);
                request.ContentType = this.ContentType;
                request.Method = "POST";
                request.Timeout = 150000000;
                ServicePointManager.DefaultConnectionLimit = 32;

                Stopwatch st = new Stopwatch();
                st.Start();
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(requestHeader);
                    streamWriter.Flush();
                    //streamWriter.Close();
                }

                st.Stop();
                Console.WriteLine("SMS executed time: " + st.Elapsed);

                HttpWebResponse response = request.GetResponse() as HttpWebResponse;

                dynamic result = null;
                using (var streamReader = new StreamReader(response.GetResponseStream()))
                {
                    result = streamReader.ReadToEnd();
                }

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                var dict = serializer.Deserialize<Dictionary<string, dynamic>>(result);
                dynamic _body = (dict["Body"]);
                dynamic _customer = (_body["Customer"]);
                dynamic _haveCommunicatedMessage = (_customer["haveCommunicatedMessage"]);
                dynamic _result = (_haveCommunicatedMessage[0]);
                this.deliveryStatusCD = (_result["deliveryStatusCD"]);
                this.deliveryStatusDesc = (_result["deliveryStatusDesc"]);

                DebugLogger.WriteLog("del status CD : " + _result["deliveryStatusCD"]);
                DebugLogger.WriteLog("del status Desc : " + _result["deliveryStatusDesc"]);

                if (deliveryStatusCD == "1")
                    this.messageID = (_result["messageID"]);

                else
                    throw new Exception(_result["deliveryStatusDesc"]);

                Result.Status = true;
                Result.Message = deliveryStatusDesc;
                Result.Result = deliveryStatusCD;
            }
            //catch (WebException ex)
            //{
               
            //    //log.CreateLogError(ex, "");
            //    //using (var stream = ex.Response.GetResponseStream())
            //    //using (var reader = new StreamReader(stream))
            //    //{
            //    //    Console.WriteLine(reader.ReadToEnd());
            //    //}
            //}
            catch (Exception ex)
            {
                DebugLogger.WriteLog(ex.Message);
                Console.WriteLine(ex.Message);
                //this.deliveryStatusCD = "0";
                //this.deliveryStatusDesc = ex.Message;
                //this.messageID = "";

                //Console.WriteLine(ex.StackTrace);
                //Result.Status = false;
                //Result.Message = ex.Message;
                //Result.Result = "";

                //log.CreateLogError(ex, "");
                //CreateLogError(ex, _smsDetailDomain.transactionId + "==>" + _smsDetailDomain.policyNo, "Sending SMS");
            }

            return Result;
        }
    }

    //public class ShortMessageService
    //{

    //    public class SMSAPI
    //    {
    //        public string URL { get; set; }
    //        public string UserName { get; set; }
    //        public string Password { get; set; }
    //        public string ContentType { get; set; }

    //        public ResultStatus Send(WebMethod Method, string SendData, string PhoneNumber)
    //        {
    //            ResultStatus Result = new ResultStatus();

    //            if (string.IsNullOrEmpty(this.URL))
    //            {
    //                Console.WriteLine("URL NOT FOUND");
    //                Result.Status = false;
    //                Result.Message = "URL not found !";
    //                goto Exit;
    //            }

    //            try
    //            {
    //                if (Method == WebMethod.Post)
    //                {
    //                    #region Post Method
    //                    dynamic request = (HttpWebRequest)WebRequest.Create(this.URL);

    //                    //IWebProxy proxy = request.Proxy;

    //                    //if (proxy != null)
    //                    //{
    //                    //    //// Create a NetworkCredential object and associate it with the  
    //                    //    //// Proxy property of request object.
    //                    //    ////proxy.Credentials = new NetworkCredential(username, password);
    //                    //    proxy.Credentials = new NetworkCredential(UserName, "");
    //                    //    //// or 
    //                    //    //proxy.UseDefaultCredentials = true;

    //                    //    //// try forcing the proxy to use http (just to the proxy not from proxy to server)
    //                    //    //UriBuilder proxyAddress = new UriBuilder(proxy.Address);
    //                    //    //proxyAddress.Scheme = "http";

    //                    //    request.Proxy = proxy;
    //                    //}

    //                    Console.WriteLine("1");
    //                    string SecurityContext = "userid=" + this.UserName + "&password=" + this.Password + "&";
    //                    string Target = "msisdn=" + PhoneNumber + "&";
    //                    string Message = "message=" + SendData;
    //                    string Parameter = SecurityContext + Target + Message;
    //                    //Parameter = "userid=AXAFTEST&password=AXAFTEST789&msisdn=6285852894643&message=Yth Bpk/Ibu AMIELLA UDJI HANDAYANI, jmlh investasi Anda no polis 510-3943287 bln September dpt dilihat pd link https://t2m.io/e-statementIndividualAMFS. Password:tgl lahir (ddmmyyyy). Link berlaku 30 hari. Info hub. 021-30058788&sender=INFO&division=AT1&batchname=Test_Ekreasi&uploadby=Ekreasi_Test&channel=1";

    //                    var data = Encoding.ASCII.GetBytes(Parameter);

    //                    request.Method = "POST";
    //                    request.ContentType = this.ContentType;
    //                    request.ContentLength = data.Length;

    //                    Console.WriteLine("2");
    //                    using (var stream = request.GetRequestStream())
    //                    {
    //                        stream.Write(data, 0, data.Length);
    //                    }

    //                    var response = (HttpWebResponse)request.GetResponse();
    //                    Console.WriteLine("3");
    //                    var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
    //                    if (responseString.Substring(7, 1) != "1")
    //                    {
    //                        Result.Status = false;
    //                        Result.Message = "Send SMS Failed Response : " + responseString;
    //                    }
    //                    else
    //                    {
    //                        Result.Status = true;
    //                        Result.Message = "Send SMS Success Response : " + responseString;
    //                    }
    //                    #endregion
    //                    Console.WriteLine("4");
    //                }
    //            }
    //            catch (Exception ex)
    //            {
    //                Result.Status = false;
    //                Result.Message = ex.Message;
    //            }

    //            Exit:
    //            return Result;
    //        }
    //    }
    //    public class SMSEIP
    //    {
    //        public string URL { get; set; }
    //        public string UserName { get; set; }
    //        public string Password { get; set; }
    //        public string ContentType { get; set; }
    //        public string transactionId { get; set; }
    //        public string appID { get; set; }
    //        public string entity { get; set; }
    //        public string service { get; set; }
    //        public string operation { get; set; }
    //        public string sender { get; set; }
    //        public string target { get; set; }
    //        public string message { get; set; }
    //        public string bizDivision { get; set; }
    //        public string batchName { get; set; }
    //        public string triggeredBy { get; set; }
    //        public int channelID { get; set; }
    //        public string deliveryStatusCD { get; set; }
    //        public string deliveryStatusDesc { get; set; }
    //        public string messageID { get; set; }

    //        public ResultStatus Send()
    //        {
    //            //Log log = new Log();
    //            ResultStatus Result = new ResultStatus();
    //            try
    //            {
    //                //Must be valid json
    //                string requestHeader =
    //                                        "{" +
    //                                            "\"Header\":{" +
    //                                            "\"SecurityContext\":{" +
    //                                                "\"username\":\"" + this.UserName + "\"," +
    //                                                "\"password\":\"" + this.Password + "\"}}," +
    //                                            "\"Body\":{" +
    //                                            "\"transactionId\":\"" + this.transactionId + "\"," +
    //                                            "\"appID\":\"" + this.appID + "\"," +
    //                                            "\"entity\":\"" + this.entity + "\"," +
    //                                            "\"service\":\"" + this.service + "\"," +
    //                                            "\"operation\":\"" + this.operation + "\"," +
    //                                            "\"Customer\":{" +
    //                                                "\"haveCommunicatedMessage\":[" +
    //                                                "{" +
    //                                                    "\"sender\":\"" + this.sender + "\"," +
    //                                                    "\"target\":\"" + this.target + "\"," +
    //                                                    "\"message\":\"" + this.message + "\"," +
    //                                                    "\"bizDivision\":\"" + this.bizDivision + "\"," +
    //                                                    "\"batchName\":\"" + this.batchName + "\"," +
    //                                                    "\"triggeredBy\":\"" + this.triggeredBy + "\"," +
    //                                                    "\"channelID\":\"" + this.channelID + "\"" +
    //                                                "}" +
    //                                                "]" +
    //                                            "}" +
    //                                            "}" +
    //                                        "}";

    //                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls;
    //                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => { return true; };
    //                Console.WriteLine("WebRequest");
    //                dynamic request = (HttpWebRequest)WebRequest.Create(URL);
    //                request.ContentType = this.ContentType;
    //                request.Method = "POST";
    //                request.Timeout = 150000000;
    //                ServicePointManager.DefaultConnectionLimit = 32;

    //                Stopwatch st = new Stopwatch();
    //                st.Start();
    //                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
    //                {
    //                    streamWriter.Write(requestHeader);
    //                    streamWriter.Flush();
    //                    //streamWriter.Close();
    //                }

    //                st.Stop();
    //                Console.WriteLine("SMS executed time: " + st.Elapsed);

    //                HttpWebResponse response = request.GetResponse() as HttpWebResponse;

    //                dynamic result = null;
    //                using (var streamReader = new StreamReader(response.GetResponseStream()))
    //                {
    //                    result = streamReader.ReadToEnd();
    //                }

    //                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
    //                var dict = serializer.Deserialize<Dictionary<string, dynamic>>(result);
    //                dynamic _body = (dict["Body"]);
    //                dynamic _customer = (_body["Customer"]);
    //                dynamic _haveCommunicatedMessage = (_customer["haveCommunicatedMessage"]);
    //                dynamic _result = (_haveCommunicatedMessage[0]);
    //                this.deliveryStatusCD = (_result["deliveryStatusCD"]);
    //                this.deliveryStatusDesc = (_result["deliveryStatusDesc"]);

    //                if (deliveryStatusCD == "1")
    //                    this.messageID = (_result["messageID"]);

    //                Result.Status = true;
    //                Result.Message = deliveryStatusDesc;
    //                Result.Result = deliveryStatusCD;
    //            }
    //            catch (WebException ex)
    //            {
    //                //log.CreateLogError(ex, "");
    //                using (var stream = ex.Response.GetResponseStream())
    //                using (var reader = new StreamReader(stream))
    //                {
    //                    Console.WriteLine(reader.ReadToEnd());
    //                }
    //            }
    //            catch (Exception ex)
    //            {
    //                //log.CreateLogError(ex, "");
    //                this.deliveryStatusCD = "0";
    //                this.deliveryStatusDesc = ex.Message;
    //                this.messageID = "";

    //                Console.WriteLine(ex.StackTrace);
    //                Result.Status = false;
    //                Result.Message = ex.Message;
    //                Result.Result = "";
    //                //CreateLogError(ex, _smsDetailDomain.transactionId + "==>" + _smsDetailDomain.policyNo, "Sending SMS");
    //            }

    //            return Result;
    //        }
    //    }
    //}

    //public class ResultStatus
    //{
    //    public bool Status { get; set; }
    //    public string Message { get; set; }
    //    public object Result { get; set; }
    //}

    public class TransmittalStatusModel
    {
        public long ConsoleScheduleId { get; set; }
        public string PolicyNo { get; set; }
        public string Periode { get; set; }
        public string FileGenerateStatus { get; set; }
        public string FilePathFolder { get; set; }
        public string FileGenerateMsg { get; set; }
        public string DownloadLink { get; set; }
        public string SendStatus { get; set; }
        public string Message { get; set; }
        public string LetterNo { get; set; }
        public string DocCode { get; set; }


        #region Email
        public string MailAddress { get; set; }
        public string MailMessageStatus { get; set; }
        public string Subject { get; set; }
        public string Customer { get; set; }
        public string Gender { get; set; }
        public string Content { get; set; }
        #endregion

        #region SMS
        public string Url { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string ContentType { get; set; }
        public string Sender { get; set; }
        public string BizDivision { get; set; }
        public string BatchName { get; set; }
        public string TriggeredBy { get; set; }
        public int ChannelId { get; set; }
        public string TransactionId { get; set; }
        public string AppId { get; set; }
        public string Entity { get; set; }
        public string Service { get; set; }
        public string Operation { get; set; }
        public string Target { get; set; }
        public string SmsSendMsgStatus { get; set; }
        public string SmsBody { get; set; }
        public string SmsNumber { get; set; }
        #endregion

        #region Request SMS
        public string DeliveryStatusCD { get; set; }
        public string DeliveryStatusDesc { get; set; }
        public string MessageId { get; set; }
        #endregion
    }
}
