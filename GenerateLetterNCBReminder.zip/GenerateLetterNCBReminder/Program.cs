﻿using ClosedXML.Excel;
using EncryptDecrypt;
using EstatementLib.Object;
using EstatementLib.Services;
using EStatementLib.Model.ELetter.POS;
using EstatementLib.Helpers;
using static EstatementLib.Helpers.UniformResourceLocator;
using GenerateLetterNCBReminder.Shared;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PdfSharp.Pdf.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Web.Script.Serialization;
using EStatementLib.Helpers;
using ErrorLog;
using Microsoft.Office.Core;

namespace GenerateLetterNCBReminder
{
    public class StoreProcedure
    {
        public bool ResultStatus { get; set; }
        public string ResultMessage { get; set; }
        public Int64 sp_insert_console_scheduler(SqlConnection Connection, int TotalData, DateTime Date)
        {
            string StoreProcedure = "[e_statement].[sp_insert_console_scheduler]";

            Int64? GetID = null;
            Int64 Result = 0;

            SqlCommand cmd = new SqlCommand(StoreProcedure, Connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@TotalData", SqlDbType.Int).Value = TotalData;
            cmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = Date;

            try
            {
                if (Connection.State == ConnectionState.Closed)
                    Connection.Open();

                string scalarResult = cmd.ExecuteScalar().ToString();
                if (string.IsNullOrWhiteSpace(scalarResult))
                    GetID = null;
                else
                    GetID = Convert.ToInt64(scalarResult);

                if (GetID != null)
                {
                    this.ResultStatus = true;
                    this.ResultMessage = "Success";
                    Result = (Int64)GetID;
                }
                else
                {
                    this.ResultStatus = false;
                    this.ResultMessage = "Can not get ID from sp_insert_console_scheduler.";
                }

            }
            catch (Exception ex)
            {
                this.ResultStatus = false;
                this.ResultMessage = ex.Message;
            }

            return Result;
        }
    }

    class Program
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["ConSql"].ConnectionString;
        private static string linkDownload = ConfigurationManager.AppSettings["linkDownload"];
        private static string keyEncrypt = ConfigurationManager.AppSettings["KeyEncryption"];

        static void Main(string[] args)
        {
            PrintLog("Application Start..." + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
            //DeleteFileByPath(@"\\WRFRDS01\AMFS_EDocs\NCB\PDFTest\NCB_Reminder_13012022.xls");
            try
            {
                ProcessScheduler();
            }

            catch (Exception ex)
            {
                PrintLog(ex.Message);
                DebugLogger.WriteLog(ex.StackTrace);
            }
                                   
            PrintLog(string.Format("Application Finish...{0}{1}", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), Environment.NewLine));
            Console.ReadLine();
        }

        private static void ProcessScheduler()
        {
            string targetFolderPathExcel = ConfigurationManager.AppSettings["TargetFolderPathExcel"];
            string targetFolderPathPDF = ConfigurationManager.AppSettings["TargetFolderPathPDF"];

            string targetFolderPath = ConfigurationManager.AppSettings["TargetFolderPath"];
            //string compleoPath = ConfigurationManager.AppSettings["CompleoPath"];
            //string compleoWorksheet = ConfigurationManager.AppSettings["CompleoWorksheet"];

            ResultStatus rs = new ResultStatus();

            // Get the file name PDF from selected folder
            IList<KeyValuePair<string, string>> valuePairNamePathPDF = GetFileNameFromFolder(targetFolderPath, "*.pdf");

            // Get the file name compleo from the source folder 
            IList<KeyValuePair<string, string>> valuePairNamePathExcel = GetFileNameFromFolder(targetFolderPath, "*.xls");

            //  Read file Compleo
            DataTable dt_File = new DataTable();

            foreach (KeyValuePair<string, string> item in valuePairNamePathExcel)
            {
                // Change format xls to xlsx
                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                xlApp.FileValidation = MsoFileValidationMode.msoFileValidationSkip;

                Microsoft.Office.Interop.Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(item.Value);
                xlWorkbook.SaveAs(item.Value + "x", FileFormat: Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook);
                xlWorkbook.Close();
                xlApp.Quit();

                using (FileStream fs = System.IO.File.Open(item.Value + "x", FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                {               
                    dt_File = dt_File.AsEnumerable().Union(GetDataFromExcel(fs).AsEnumerable()).CopyToDataTable();
                }
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Store compleo to the DB and submit the log
                rs = SaveCompleoToDB(conn, dt_File);

                if (!rs.Status) throw new Exception(rs.Message);

                foreach (KeyValuePair<string, string> item in valuePairNamePathExcel)
                {
                    // Delete xls file
                    DeleteFileByPath(item.Value);

                    // Delete xlxs file
                    DeleteFileByPath(item.Value + "x");
                }

                StoreProcedure _sp = new StoreProcedure();

                // Register the scheduler 
                long scheduleID = InsertConsoleSchedule(_sp, valuePairNamePathPDF.Count, DateTime.Now);

                int emailSentSuccess = 0;
                int emailSentFailed = 0;
                int smsSentSuccess = 0;
                int smsSentFailed = 0;

                // Generate the letter no to be used when calling POS
                //  string letterNo = GenerateLetterNo(conn);

                string seqNum = scheduleID.ToString();
                
                string printDate = DateTime.Now.ToString("ddMMyyyy");
                string tsNum = printDate + "-" + seqNum.PadLeft(6, '0');

                string docCode = "NCBR";

                IList<POSModel> postModelList = GetPOSModelAndUpdateValuePath(valuePairNamePathPDF, printDate, tsNum, docCode, scheduleID, dt_File);

                //UpdateValueNamePathWithTheFileCopy(valuePairNamePath);

                foreach (KeyValuePair<string, string> item in valuePairNamePathPDF)
                {
                    DataRow dtRow = dt_File.AsEnumerable().Where(x => (string)x["S23PNO"] == item.Key).FirstOrDefault();

                    string cusName = dtRow["S23OWNER"].ToString();
                    string gender = dtRow["GENDER"].ToString();
                    string emailTo = dtRow["S23EMAIL"].ToString();
                    string phoneNumber = dtRow["S23MOB"].ToString();
                    string passEmail = DateTime.ParseExact(dtRow["TGL_LAHIR"].ToString(), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("ddMMyyyy");
                    string polNum = item.Key;
                    // Compose email template
                    string emailBody = GenerateBodyEmail(cusName, gender);
                    string smsMsgBody = "";

                    RFISATClass rfisatClass = new RFISATClass();

                    PrintLog(string.Format("Processing Policy No {0} .....", polNum));

                    // Generate POS Model

                    // Save the file to the destination 
                    //POSModel posModel = CreatePOSModelDeleteOriginalFileAndSaveTheCopy(emailTo, printDate, docCode, item, cusName, gender, scheduleID, phoneNumber, tsNum, item.Key, passEmail);

                    // Get POS Model
                    POSModel posModel = postModelList.FirstOrDefault(x => x.PolicyNo == item.Key);

                    //POSModel posModel = GeneratePosModel(emailTo, printDate, docCode, item, cusName, gender, scheduleID, phoneNumber, tsNum, item.Key);

                    // Generate Data POS
                    //DataTable dtPos = GenerateDataPOS(conn, polNum, letterNo);

                    JavaScriptSerializer serializer = new JavaScriptSerializer();

                    if (IsEmailSent(emailTo, emailBody, posModel.FilePathFolder, posModel.PolicyNo, conn))
                    {
                        emailSentSuccess++;
                        PrintLog(string.Format("Policy No : {0}, success sent email to : {1}", polNum, emailTo));

                        string data = serializer.Serialize(posModel);

                        ResultStatus res = rfisatClass.InsertTransmittalStatus(connectionString,
                                scheduleID, polNum, 0, posModel.Periode, "Auto Send",
                                "Email", DateTime.Now, posModel.FileGenerateStatus, posModel.FilePathFolder,
                                posModel.FileGenerateMsg, posModel.DownloadLink,
                                DateTime.Now, "Success", posModel.MailAddress, posModel.MailMessageStatus,
                                0, string.Empty, string.Empty, null,
                                string.Empty, null, "Non SMS", phoneNumber, string.Empty,
                                string.Empty, string.Empty, string.Empty, string.Empty, string.Empty,
                                string.Empty, string.Empty, string.Empty, null, null,
                                posModel.Message, "System", posModel.LetterNo, docCode, false);

                        PrintLog(string.Format("Inserting data to Transmittal status table : {0}", res.Message));

                        ResultStatus resJobStatus = rfisatClass.InsertJobStatusWithoutCloseConn(conn,
                                polNum, polNum + "-" + tsNum, Int32.Parse(printDate), data, "Email", docCode, 1, "",
                                scheduleID, DateTime.Now, "Console App NCB Reminder");
                        
                       PrintLog(string.Format("Inserting data to JobStatus table : {0}", res.Message));
                    }

                    
                    else if (IsSmsSent(phoneNumber, posModel.PolicyNo, posModel.DownloadLink , posModel.ConsoleScheduleId.ToString(), out smsMsgBody, posModel))
                    {
                        emailSentFailed++;
                        smsSentSuccess++;

                        PrintLog(string.Format("Policy No : {0}, success sent SMS to : {1} ", polNum, phoneNumber));

                        ResultStatus res = rfisatClass.InsertTransmittalStatus(connectionString,
                                posModel.ConsoleScheduleId, posModel.PolicyNo, 0, posModel.Periode, "Auto Send",
                                "SMS", DateTime.Now, posModel.FileGenerateStatus,
                                posModel.FilePathFolder, posModel.FileGenerateMsg, posModel.DownloadLink,
                                null, "Non Email", posModel.MailAddress, posModel.MailMessageStatus,
                                0, string.Empty,
                                string.Empty,null,
                                posModel.MessageId, DateTime.Now, posModel.SendStatus, posModel.SmsNumber,
                                posModel.SmsSendMsgStatus,
                                posModel.Sender, posModel.Message, posModel.BizDivision,
                                posModel.BatchName,
                                posModel.TriggeredBy, Convert.ToString(posModel.ChannelId),
                                posModel.DeliveryStatusCD, posModel.DeliveryStatusCD, null, null, posModel.Message, "System", posModel.LetterNo,
                                posModel.DocCode, false);

                        PrintLog(string.Format("Inserting data to Transmittal status table : {0}", res.Message));

                        string data = serializer.Serialize(posModel);
                        ResultStatus resJobStatus = rfisatClass.InsertJobStatusWithoutCloseConn(conn,
                                polNum, polNum + "-" + tsNum, Int32.Parse(printDate), data, "SMS", docCode, 1, "",
                                scheduleID, DateTime.Now, "Console App NCB Reminder");
                        
                        PrintLog(string.Format("Inserting data to JobStatus table : {0}", res.Message));
                    }

                    else
                    {
                        emailSentFailed++;
                        smsSentFailed++;

                        PrintLog(string.Format("Policy No : {0}, failed to send email and SMS ", polNum));

                        ResultStatus res = rfisatClass.InsertTransmittalStatus(connectionString,
                                posModel.ConsoleScheduleId, posModel.PolicyNo, 0, posModel.Periode, "Auto Send",
                                "Hard Copy", DateTime.Now, posModel.FileGenerateStatus,
                                posModel.FilePathFolder, posModel.FileGenerateMsg, posModel.DownloadLink,
                                null, "Non Email", posModel.MailAddress, posModel.MailMessageStatus,
                                0, string.Empty,
                                string.Empty, null,
                                posModel.MessageId, DateTime.Now, "Non SMS", posModel.SmsNumber,
                                posModel.SmsSendMsgStatus,
                                posModel.Sender, posModel.SmsBody, posModel.BizDivision,
                                posModel.BatchName,
                                posModel.TriggeredBy, Convert.ToString(posModel.ChannelId),
                                posModel.DeliveryStatusCD,
                                string.Empty, null, null, posModel.Message, "System", posModel.LetterNo,
                                posModel.DocCode, false);

                        PrintLog(string.Format("Inserting data to Transmittal status table : {0}", res.Message));

                        string data = serializer.Serialize(posModel);
                        ResultStatus resJobStatus = rfisatClass.InsertJobStatusWithoutCloseConn(conn,
                                polNum, polNum + "-" + tsNum, Int32.Parse(printDate), data, "Hard Copy", docCode, 1, "",
                                scheduleID, DateTime.Now, "Console App NCB Reminder");

                        PrintLog(string.Format("Inserting data to JobStatus table : {0}", res.Message));
                    }
                }

                UpdateConsoleScheduler(conn, scheduleID, emailSentSuccess, emailSentFailed, smsSentSuccess, smsSentFailed);

                conn.Close();
            }
        }

        private static void DeleteFileByPath(string filePath)
        {
            if (File.Exists(filePath))
            {
                File.Delete(filePath);               
            }
        }

        private static IList<POSModel> GetPOSModelAndUpdateValuePath(IList<KeyValuePair<string, string>> valuePairNamePath, string printDate, string tsNum, string docCode, long scheduleID, DataTable dt_File)
        {
            IList<POSModel> postModelList = new List<POSModel>();

            foreach (KeyValuePair<string, string> item in valuePairNamePath)
            {
                DataRow dtRow = dt_File.AsEnumerable().Where(x => (string)x["S23PNO"] == item.Key).FirstOrDefault();
                string cusName = dtRow["S23OWNER"].ToString();
                string gender = dtRow["GENDER"].ToString();
                string emailTo = dtRow["S23EMAIL"].ToString();
                string phoneNumber = dtRow["S23MOB"].ToString();
                string passEmail = DateTime.ParseExact(dtRow["TGL_LAHIR"].ToString(), "yyyyMMdd", CultureInfo.InvariantCulture).ToString("ddMMyyyy");

                postModelList.Add(CreatePOSModelDeleteOriginalFileAndSaveTheCopy(emailTo, printDate, docCode, item, cusName, gender, scheduleID, phoneNumber, tsNum, item.Key, passEmail));
            }

            return postModelList;
        }

        private static void UpdateConsoleScheduler(SqlConnection conn, long schedulerID, int emailSentSuccess, int emailSentFailed, int smsSentSuccess, int smsSentFailed)
        {
            string sql = @"update [e_statement].[console_scheduler] 
                        set mail_sent_success = @emailSentSuccess, mail_sent_failed = @emailSentFailed, sms_sent_success = @smsSentSuccess, sms_sent_failed = @smsSentFailed 
                        where console_scheduler_id = @schedulerID ";

            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@emailSentSuccess", emailSentSuccess);
                cmd.Parameters.AddWithValue("@emailSentFailed", emailSentFailed);
                cmd.Parameters.AddWithValue("@smsSentSuccess", smsSentSuccess);
                cmd.Parameters.AddWithValue("@smsSentFailed", smsSentFailed);
                cmd.Parameters.AddWithValue("@schedulerID", schedulerID);

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                }
            }
        }
      
        private static ResultStatus SaveCompleoToDB(SqlConnection conn, DataTable dt_File)
        {
            int totalRow = dt_File.Rows.Count;
            int totalSuccess = 0;
            int totalFailed = 0;

            string sql = "INSERT INTO [dbo].[NCBLetterExcelDataHistory] ([SEQ] ,[PolicyNo] ,[OwnerName] ,[PlanCode] ,[PlanName] ," +
                    "[RNPD] ,[EFF] ,[PTD] ,[NCBDT] ,[PRM] ,[Address1] ,[Address2] ,[Address3], [Address4] ," +
                    "[City] ,[Phone] ,[BANK] ,[BRNCD] ,[ACC] ,[PMTHOD] ,[PMODE] ,[TDT] ,[Email] ,[Gender], [DOB], [CreatedDate], [CreatedBy], [NOREK] )" +
                    "VALUES(" +
                    "@pSEQ, @pPolicyNo, @pOwnerName, @pPlanCode, @pPlanName," +
                    "@pRNPD ,@pEFF ,@pPTD ,@pNCBDT ,@pPRM ,@pAddress1 ,@pAddress2 ,@pAddress3, @pAddress4 ," +
                    "@pCity ,@pPhone ,@pBANK ,@pBRNCD ,@pACC ,@pPMTHOD ,@pPMODE ,@pTDT ,@pEmail ,@pGender, @pDOB, @pCreatedDate, @pCreatedBy, @pNoRek) ";

            foreach (DataRow dtRow in dt_File.Rows)              
            {
                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@pSEQ", int.Parse(dtRow["S23SEQ"].ToString()));
                    cmd.Parameters.AddWithValue("@pPolicyNo", dtRow["S23PNO"].ToString());
                    cmd.Parameters.AddWithValue("@pOwnerName", dtRow["S23OWNER"].ToString());
                    cmd.Parameters.AddWithValue("@pPlanCode", dtRow["S23PLAN"].ToString());
                    cmd.Parameters.AddWithValue("@pPlanName", dtRow["S23PDES"].ToString());
                    cmd.Parameters.AddWithValue("@pRNPD", decimal.Parse(dtRow["S23RNPD"].ToString()));
                    cmd.Parameters.AddWithValue("@pEFF", DateTime.ParseExact(dtRow["S23EEF"].ToString(), "yyyyMMdd", null));
                    cmd.Parameters.AddWithValue("@pPTD", DateTime.ParseExact(dtRow["S23PTD"].ToString(), "yyyyMMdd", null));
                    cmd.Parameters.AddWithValue("@pNCBDT", int.Parse(dtRow["S23NCBDT"].ToString()));
                    cmd.Parameters.AddWithValue("@pPRM", int.Parse(dtRow["S23PRM"].ToString()));
                    cmd.Parameters.AddWithValue("@pAddress1", dtRow["S23ADDR1"].ToString());
                    cmd.Parameters.AddWithValue("@pAddress2", dtRow["S23ADDR2"].ToString());
                    cmd.Parameters.AddWithValue("@pAddress3", dtRow["S23ADDR3"].ToString());
                    cmd.Parameters.AddWithValue("@pAddress4", dtRow["S23ADDR4"].ToString());
                    cmd.Parameters.AddWithValue("@pCity", dtRow["S23CTY"].ToString());
                    cmd.Parameters.AddWithValue("@pPhone", dtRow["S23MOB"].ToString());
                    cmd.Parameters.AddWithValue("@pBANK", dtRow["S23BANK"].ToString());
                    cmd.Parameters.AddWithValue("@pBRNCD", dtRow["S23BRNCD"].ToString());
                    cmd.Parameters.AddWithValue("@pACC", dtRow["S23ACC"].ToString());
                    cmd.Parameters.AddWithValue("@pPMTHOD", dtRow["S23PMTHD"].ToString());
                    cmd.Parameters.AddWithValue("@pPMODE", dtRow["S23PMOD"].ToString());
                    cmd.Parameters.AddWithValue("@pTDT", DateTime.ParseExact(dtRow["S23TDT"].ToString(), "yyyyMMdd", null));
                    cmd.Parameters.AddWithValue("@pEmail", dtRow["S23EMAIL"].ToString());
                    cmd.Parameters.AddWithValue("@pGender", dtRow["GENDER"].ToString());
                    cmd.Parameters.AddWithValue("@pDOB", DateTime.ParseExact(dtRow["TGL_LAHIR"].ToString(), "yyyyMMdd",null));
                    cmd.Parameters.AddWithValue("@pCreatedDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@pCreatedBy", "NCB Scheduler");
                    cmd.Parameters.AddWithValue("@pNoRek", dtRow["NOMOR_REKENING"].ToString());
                    try
                    {
                        cmd.ExecuteNonQuery();
                        totalSuccess++;
                    }
                    catch (Exception ex)
                    {
                        totalFailed++;
                    }
                }
            }

            ResultStatus rs = SubmitToLogReportDataCompleo(conn, totalRow, totalSuccess, totalFailed);

            return rs;
        }

        private static ResultStatus SubmitToLogReportDataCompleo(SqlConnection conn, int totalRow, int totalSuccess, int totalFailed)
        {
            ResultStatus rs = new ResultStatus();
            string sql = "INSERT INTO [dbo].[LogReportDataCompleo] ([TotalRow] ,[TotalSuccess] ,[TotalFailed] ,[LetterType],[CreatedDate],[CreatedBy])" +
                    "VALUES(" +
                    "@pTotalRow ,@pTotalSuccess ,@pTotalFailed ,@pLetterType ,@pCreatedDate,@pCreatedBy)";

            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@pTotalRow", totalRow);
                cmd.Parameters.AddWithValue("@pTotalSuccess", totalSuccess);
                cmd.Parameters.AddWithValue("@pTotalFailed", totalFailed);
                cmd.Parameters.AddWithValue("@pLetterType", "NCBR");
                cmd.Parameters.AddWithValue("@pCreatedDate", DateTime.Now);
                cmd.Parameters.AddWithValue("@pCreatedBy", "NCB Scheduler");
                try
                {
                    cmd.ExecuteNonQuery();
                    rs.Status = true;
                }
                catch(Exception ex)
                {
                    rs.Status = false;
                    rs.Message = ex.Message;
                }
            }
            return rs;
        }

        private static POSModel CreatePOSModelDeleteOriginalFileAndSaveTheCopy
            (string emailTo, string printDate, string docCode, KeyValuePair<string, string> item, string cusName, string gender, long scheduleID, string phoneNumber, string no_ts, string polNum, string documentPass)
        {
            string pathServer = item.Key + "_" + printDate;
            string filePathCopy = ProtectDoc(item.Value, documentPass, pathServer);
            POSModel posModel = new POSModel();

            posModel.MailAddress = emailTo;
            posModel.Subject = string.Format(ConfigurationManager.AppSettings["SubjectEmail"], polNum);
            posModel.Periode = DateTime.ParseExact(printDate,"ddMMyyyy",CultureInfo.InvariantCulture).ToString("yyyyMMdd");
            posModel.DocCode = docCode;
            posModel.PolicyNo = item.Key;
            posModel.DownloadLink = DownloadLink(string.Format("{0}_{1}_{2}_{3}", docCode, no_ts, item.Key, printDate));
            posModel.TransactionId = "Auto Send";

            posModel.FilePathFolder = @"\" + filePathCopy.Replace(@"\\",@"\");
            posModel.Customer = cusName;
            posModel.Gender = gender;
            posModel.ConsoleScheduleId = scheduleID;
            posModel.FileGenerateStatus = "Success";
            posModel.FileGenerateMsg = "";
            posModel.SendStatus = "Success";
            posModel.MailMessageStatus = "";
            posModel.SmsNumber = phoneNumber;
            posModel.Message = "";
            posModel.LetterNo = no_ts;
            posModel.SmsSendMsgStatus = "";
            posModel.SmsBody = "";
            posModel.Content = "NCB Reminder";

            DeleteFileByPath(item.Value);

            return posModel;
        }

        private static long InsertConsoleSchedule(StoreProcedure _sp, int count, DateTime date)
        {
            long result = 0;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                result = _sp.sp_insert_console_scheduler(conn, count, date);
            }

            return result;
        }

        private static IList<KeyValuePair<string, string>> GetFileNameFromFolder(string folderPath, string extension)
        {            
            IList<KeyValuePair<string, string>> valuePairNamePath = new List<KeyValuePair<string, string>>();

            foreach (string file in Directory.GetFiles(folderPath, extension))
            {
                string fileName = file.Split(new[] { "\\" }, StringSplitOptions.None).Last().Split('_')[0];
                valuePairNamePath.Add(new KeyValuePair<string, string>(fileName, file));
            }            
            return valuePairNamePath;
        }

        public static DataTable GetDataFromExcel(FileStream fsPath)
        {
            DataTable dt = new DataTable();

            //Open the Excel file using ClosedXML.
            using (XLWorkbook workBook = new XLWorkbook(fsPath))
            {
                //Loop through the Worksheets
                foreach (IXLWorksheet workSheet in workBook.Worksheets)
                {
                    //Loop through the Worksheet rows.
                    bool firstRow = true;
                    foreach (IXLRow row in workSheet.RowsUsed())
                    {
                        //Use the first row to add columns to DataTable.
                        if (firstRow)
                        {
                            foreach (IXLCell cell in row.Cells())
                            {
                                if (!string.IsNullOrEmpty(cell.Value.ToString()))
                                {
                                    dt.Columns.Add(cell.Value.ToString());
                                }
                                else
                                {
                                    break;
                                }
                            }
                            firstRow = false;
                        }
                        else
                        {
                            int i = 0;
                            DataRow toInsert = dt.NewRow();
                            foreach (IXLCell cell in row.Cells(1, dt.Columns.Count))
                            {
                                try
                                {
                                    toInsert[i] = cell.Value.ToString();
                                }
                                catch
                                {
                                    continue;
                                }
                                i++;
                            }
                            dt.Rows.Add(toInsert);
                        }
                    }
                }

                //Read the first Sheet from Excel file.
                //IXLWorksheet workSheet = workBook.Worksheets.First();

                //Create a new DataTable.         
                return dt;
            }
        }

        private static string GenerateBodyEmail(string ownerName, string gender)
        {
            string strBodyEmail = "";
            string result = "";
            string strDirectoryApp = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            string strFileTemplate = strDirectoryApp + "\\EmailTemplate\\EmailTemplateNCBReminder.html";
            if (File.Exists(strFileTemplate))
            {
                StreamReader sr = new StreamReader(strFileTemplate);
                strBodyEmail = sr.ReadToEnd();
            }
            else
            {
                throw new Exception("Mail template is not exist");
            }

            result = string.Format(strBodyEmail, gender == "M" ? "Bapak" : gender == "F" ? "Ibu" : "Bapak/Ibu", ownerName);
            return result;
        }

        private static bool IsEmailSent(string emailTo, string emailBody, string filePathCopy, string polNum, SqlConnection conn)
        {
            bool result = true;

            try
            {
                if (IsEmailBlackListed(emailTo, conn))
                    throw new Exception("Email is Blacklisted");

                string username = ConfigurationManager.AppSettings["NetUser"]; 
                string password = ConfigurationManager.AppSettings["NetPass"]; 
                string port = ConfigurationManager.AppSettings["Port"];
                string smtp = ConfigurationManager.AppSettings["SMTP"]; 
                string mailServer = ConfigurationManager.AppSettings["MailServer"]; 
                string sender = ConfigurationManager.AppSettings["Sender"]; 
                string ccEmail = ConfigurationManager.AppSettings["CCEmail"]; 
                string subjectEmail = string.Format(ConfigurationManager.AppSettings["SubjectEmail"], polNum );

                MailMessage mail = new MailMessage();
                SmtpClient smtpServer = new SmtpClient();

                smtpServer.UseDefaultCredentials = false;
                smtpServer.Credentials = new System.Net.NetworkCredential(username, password);

                smtpServer.Port = Convert.ToInt16(port);
                smtpServer.EnableSsl = false;
                smtpServer.Host = smtp;
                mail.From = new MailAddress(mailServer, sender);

                emailTo.Split(';').ToList().ForEach(x => mail.To.Add(x));

                if (!string.IsNullOrEmpty(ccEmail))
                {
                    mail.CC.Add(ccEmail);
                }

                mail.Subject = subjectEmail;
                mail.Body = emailBody;
                mail.IsBodyHtml = true;
         
                Attachment attachment = new Attachment(filePathCopy);

                mail.Attachments.Add(attachment);

                // Image
                // Solution 2 ---------------------------------------------------
                string folderPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\EmailTemplate\\";

                string attachmentPath = folderPath + "headerImg.jpg";
                mail.Attachments.Add(ImageAttachment(attachmentPath));

                attachmentPath = folderPath + "info1Img.jpg";
                mail.Attachments.Add(ImageAttachment(attachmentPath));

                attachmentPath = folderPath + "info2Img.jpg";
                mail.Attachments.Add(ImageAttachment(attachmentPath));

                // End of Solution 2 ---------------------------------------------------

                smtpServer.Send(mail);
                mail.Attachments.Dispose();
            }
            catch (Exception e)
            {
                PrintLog(e.Message);
                result = false;              
            }

            return result;
        }

        private static bool IsEmailBlackListed(string emailTo, SqlConnection conn)
        {
            int result = 0;
            string sql = "select count(*) from Master_Email_Block where email = @pEmail";

            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@pEmail", emailTo);
                result = (int)cmd.ExecuteScalar();
            }

            return result > 0;
        }

        private static string ProtectDoc(string filePath, string docPass, string pathServer)
        {
            string folderPath = string.Format(ConfigurationManager.AppSettings["DestFolderPath"],DateTime.Now.ToString("yyyy"), DateTime.Now.ToString("MMMM"), DateTime.Now.ToString("dd")) ;
            string pathLoc = string.Format(@"{0}\{1}.pdf", folderPath, pathServer);
            //string pathLoc = string.Format("{0}\\{1}", folderPath, filePath.Split(new[] { "\\" }, StringSplitOptions.None).Last());
            FileInfo fileInfo = new FileInfo(folderPath);
            fileInfo.Directory.Create();

            File.Copy(filePath, pathLoc, true);

            //PdfDocument document = PdfReader.Open(filePath);
            //PdfSecuritySettings securitySettings = document.SecuritySettings;

            //securitySettings.UserPassword = "P@ssw0rd";
            //securitySettings.OwnerPassword = docPass;

            //securitySettings.PermitAccessibilityExtractContent = false;
            //securitySettings.PermitAnnotations = false;
            //securitySettings.PermitAssembleDocument = false;
            //securitySettings.PermitExtractContent = false;
            //securitySettings.PermitFormsFill = true;
            //securitySettings.PermitFullQualityPrint = false;
            //securitySettings.PermitModifyDocument = true;
            //securitySettings.PermitPrint = false;
            //document.Save(pathLoc);


            return pathLoc;
        }

        private static Attachment ImageAttachment(string attachmentPath)
        {
            Attachment inline = new Attachment(attachmentPath);
            inline.ContentDisposition.Inline = true;
            inline.ContentDisposition.DispositionType = DispositionTypeNames.Inline;
            inline.ContentId = attachmentPath.Split(new[] { "\\" }, StringSplitOptions.None).Last().Split('.')[0];
            inline.ContentType.MediaType = "image/png";
            inline.ContentType.Name = Path.GetFileName(attachmentPath);

            return inline;
        }

        private static bool IsSmsSent(string phoneNumber, string polNum,string downloadLink, string scheduleID , out string smsMsgBody, POSModel transStatusModel)
        {
            string shortUrlAddr = GetShortUrlAddress(downloadLink, scheduleID);

            smsMsgBody = string.Format(ConfigurationManager.AppSettings["SMSMessage"], shortUrlAddr, polNum);
            transStatusModel.Url = ConfigurationManager.AppSettings["SMSGateway"]; 
            transStatusModel.Username = ConfigurationManager.AppSettings["GatewayUser"]; 
            transStatusModel.Password = ConfigurationManager.AppSettings["GatewayPass"]; 
            transStatusModel.ContentType = ConfigurationManager.AppSettings["SMSContType"]; 
            transStatusModel.Sender = ConfigurationManager.AppSettings["SenderSMS"]; 
            transStatusModel.BizDivision = ConfigurationManager.AppSettings["BizDivision"]; 
            transStatusModel.BatchName = ConfigurationManager.AppSettings["BatchName"]; 
            transStatusModel.TriggeredBy = ConfigurationManager.AppSettings["TriggeredBy"]; 
            transStatusModel.ChannelId = int.Parse(ConfigurationManager.AppSettings["ChannelId"]); 
            transStatusModel.TransactionId = ConfigurationManager.AppSettings["TransactionId"]; 
            transStatusModel.AppId = ConfigurationManager.AppSettings["AppId"]; 
            transStatusModel.Entity = ConfigurationManager.AppSettings["Entity"]; 
            transStatusModel.Service = ConfigurationManager.AppSettings["Service"]; 
            transStatusModel.Operation = ConfigurationManager.AppSettings["Operation"];          
            transStatusModel.Target = phoneNumber;
            transStatusModel.Message = smsMsgBody;
          
            ResultStatus res = new ResultStatus();

            try
            {
                res = SendSms(transStatusModel);
            }
            catch(Exception e )
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                res.Status = false;             
            }
            
            //transStatusModel.SmsSendMsgStatus = res.Status
            
            return res.Status;
        }

        private static string GetShortUrlAddress(string downloadLink, string scheduleID)
        {
            string shortURLAddress = "";
            string URLEipT2Mio = ConfigurationManager.AppSettings["URLEipT2Mio"].ToString();

            ResultStatusFromRequestEipT2Mio resultStatusFromRequestEipT2Mio = new ResultStatusFromRequestEipT2Mio();
            T2M WebRequest = new T2M();
            RequestT2Mio requestMessage = new RequestT2Mio();
            HeaderRequest headerRequestMessage = new HeaderRequest();
            BodyRequest bodyRequestMessage = new BodyRequest();
            CustomerRequest customerRequestMessage = new CustomerRequest();
            HaveCommunicatedMessageRequest haveCommunicatedMessageRequestMessage = new HaveCommunicatedMessageRequest();

            SecurityContext securityContextMessage = new SecurityContext();
            securityContextMessage.username = ConfigurationManager.AppSettings["UsernameEipT2Mio"].ToString();
            securityContextMessage.password = ConfigurationManager.AppSettings["PasswordEipT2Mio"].ToString();

            bodyRequestMessage.transactionId = scheduleID.ToString();
            bodyRequestMessage.operation = ConfigurationManager.AppSettings["OperationEipT2Mio"].ToString();
            bodyRequestMessage.appID = ConfigurationManager.AppSettings["AppIdEipT2Mio"].ToString();
            bodyRequestMessage.entity = ConfigurationManager.AppSettings["EntityEipT2Mio"].ToString();
            bodyRequestMessage.service = ConfigurationManager.AppSettings["ServiceEipT2Mio"].ToString();

            haveCommunicatedMessageRequestMessage.target = downloadLink;
            haveCommunicatedMessageRequestMessage.messageID = ConfigurationManager.AppSettings["MessageIdEipT2Mio"].ToString();
            haveCommunicatedMessageRequestMessage.deliveryStatusCD = ConfigurationManager.AppSettings["DeliveryStatusCdEipT2Mio"].ToString();


            customerRequestMessage.haveCommunicatedMessage = new List<HaveCommunicatedMessageRequest>();

            customerRequestMessage.haveCommunicatedMessage.Add(haveCommunicatedMessageRequestMessage);

            bodyRequestMessage.Customer = customerRequestMessage;

            headerRequestMessage.SecurityContext = securityContextMessage;

            requestMessage.Header = headerRequestMessage;
            requestMessage.Body = bodyRequestMessage;

            T2MioServices t2MioServices = new T2MioServices();

            //unremark this for debug
            System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };

            resultStatusFromRequestEipT2Mio = t2MioServices.Send(URLEipT2Mio, requestMessage);
            if (resultStatusFromRequestEipT2Mio.Status == true)
            {
                shortURLAddress = resultStatusFromRequestEipT2Mio.Result.Body.Customer.
                    haveCommunicatedMessage.FirstOrDefault().replyTo;

            }

            return shortURLAddress;
        }

        private static ResultStatus SendSms(POSModel data)
        {
            ResultStatus ret = new ResultStatus();

            #region SMS EIP
            SMSEIP SMS = new SMSEIP();

            SMS.URL = data.Url;
            SMS.UserName = data.Username;
            SMS.Password = data.Password;
            SMS.ContentType = data.ContentType;
            SMS.sender = data.Sender;
            SMS.bizDivision = data.BizDivision;
            SMS.batchName = data.BatchName;
            SMS.triggeredBy = data.TriggeredBy;
            SMS.channelID = data.ChannelId;
            SMS.transactionId = data.TransactionId;
            SMS.appID = data.AppId;
            SMS.entity = data.Entity;
            SMS.service = data.Service;
            SMS.operation = data.Operation;
            SMS.target = data.Target;
            SMS.message = data.Message;

            ret = SMS.Send();

            if (ret.Status)
            {
                data.DeliveryStatusCD = SMS.deliveryStatusCD;
                data.DeliveryStatusDesc = SMS.deliveryStatusDesc;
                data.MessageId = SMS.messageID;
                data.SmsSendMsgStatus = GetSMSMessageByStatusCode(SMS.deliveryStatusCD);
                if (SMS.deliveryStatusCD == "1")
                {
                    ret.Status = true;
                    ret.Message = "";
                    ret.Result = null;
                }
                else
                {
                    data.SendStatus = "Failed";
                    ret.Status = false;
                    ret.Message = "unsuccessfully sent an sms for the policy number : " + data.PolicyNo;
                    ret.Result = null;
                }
            }
            else
            {
                data.SendStatus = "Failed";
                ret.Status = false;
                ret.Message = ret.Message;
                ret.Result = null;
            }

            #endregion

            return ret;
        }

        private static string GetSMSMessageByStatusCode(string deliveryStatusCD)
        {
            string message = "";
            try
            {
                SqlConnection con = new SqlConnection(connectionString);

                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlCommand cmd = new SqlCommand("sp_Get_SMS_PushMessage_status", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@statusCode", SqlDbType.Char, 10).Value = deliveryStatusCD.Trim();

                message = cmd.ExecuteScalar().ToString();
                cmd.Dispose();
            }
            catch (Exception ex)
            {
                PrintLog(ex.Message);
            }

            return message;
        }

        private static string DownloadLink(string docId)
        {
            string Result = string.Empty;

            EncryptDecryptQueryString ed = new EncryptDecryptQueryString();
            string idEncryption = ed.Encrypt(docId, keyEncrypt);
            Result = linkDownload + idEncryption;

            return Result;
        }

        private static void PrintLog(string msg)
        {
            Console.WriteLine(msg);
            DebugLogger.WriteLog(msg);
        }
    }
}
