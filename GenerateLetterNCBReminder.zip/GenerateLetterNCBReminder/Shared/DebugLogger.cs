﻿using System;
using System.IO;

namespace GenerateLetterNCBReminder.Shared
{
    public static class DebugLogger
    {
        public static void WriteLog(string msg)
        {
            string _folderPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\Logs\\";

            string path = string.Format(@"{0}\{1}\{2}\Log-{3}.txt", _folderPath, DateTime.Now.ToString("yyyy"), DateTime.Now.ToString("MMMM"), DateTime.Now.ToString("yyyy-MM-dd"));
            FileInfo fileInfo = new FileInfo(path);
            fileInfo.Directory.Create();

            using (StreamWriter tw = new StreamWriter(path, true))
            {
                tw.WriteLine(msg);
            }
        }
    }
}
