﻿using MailNotification.Model;
using MailNotification.Repositories.Interface;
using MailNotification.Services.Interface;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace MailNotification.Services
{
    public class LibraryNotificationService : ILibraryNotificationService
    {
        ILibraryNotificationRepository _repo;
        public LibraryNotificationService(ILibraryNotificationRepository repo)
        {
            _repo = repo;
        }

        public string SentEmailNotification()
        {
            string result = "Success"; 
            try
            {
                // Get from sp
                IList<DocumentNotification> listDoc = _repo.GetExpiredDocumentNotificationList();
                IList<NotificationReport> listRpt = new List<NotificationReport>();
                string sendEmailResult = "";

                // Manipulate the data
                foreach (DocumentNotification item in listDoc)
                {
                    string receiver = "";
                    
                    int lvlNotif = 0;

                    if (item.NotifLabel == "H-60")
                    {
                        receiver = item.PIC_Email;
                        lvlNotif = 1;      
                    }
                    else if (item.NotifLabel == "H-30")
                    {
                        receiver = item.PIC_Email + ";" + item.DeptHeadEmail;
                        lvlNotif = 2;
                    }
                    else
                    {
                        receiver = item.PIC_Email + ";" + item.DeptHeadEmail + ";" + item.DivHeadEmail;
                        lvlNotif = 3;
                    }

                                                                             
                    NotificationReport report = new NotificationReport();
                    report.DocumentID = item.DocumentID;
                    report.DepartmentID = item.DepartmentID;
                    report.DivisionID = item.DivisionID;
                    report.Application = "Library";
                    report.NotifLabel = item.NotifLabel;
                    report.Receiver = receiver;
                    report.Subject = item.Title;
                    report.Result = "Success";
                    report.IsSent = true;
                    report.LevelNotif = lvlNotif;
                    report.PIC_Email = item.PIC_Email;

                    listRpt.Add(report);
                }

                IList<KeyValuePair<string, string>> pairList = new List<KeyValuePair<string, string>>();

                // Send email
                listDoc.Select(x => x.PIC_Email).Distinct().ToList().
                    ForEach(x =>
                    {
                        //string emailBody = ComposeEmailBody(listDoc.Where(z => z. == x.PIC_Email).ToList());
                        IList<DocumentNotification> selectedDocByPIC = listDoc.Where(z => z.PIC_Email == x).ToList();
                        string emailBody = ComposeEmailBody(listDoc.Where(z => z.PIC_Email == x).ToList());
                        string receiver = listRpt.OrderByDescending(z => z.LevelNotif).FirstOrDefault(z => z.PIC_Email == x).Receiver;
                        sendEmailResult = SendMail("Review Policy and Procedure Document reminder", emailBody, receiver.Split(';').ToList(), null);
                        pairList.Add(new KeyValuePair<string,string> (x, sendEmailResult ));
                        DebugLogger.WriteLog(receiver);
                    });

                // Save to the DB
                foreach(KeyValuePair<string,string> item in pairList)
                {
                    result = _repo.SaveNotificationReport(listRpt.Where(x => x.PIC_Email == item.Key && item.Value == "Success").ToList());
                }
            }
            catch ( Exception ex)
            {
                result = ex.Message;
            }

            return result;
        }

        private string ComposeEmailBody(IList<DocumentNotification> listDoc)
        {
            int iNo = 1;
            string strBody = "";
            string strBodyEmail = "";
            foreach (DocumentNotification item in listDoc)
            {
                string strTbl = "<tr><td>{no}</td><td width=\"400\">{title}</td><td>{num}</td><td>{date}</td></tr>";
                strBody += 
                    strTbl.Replace("{no}", iNo.ToString())
                    .Replace("{title}", item.Title)
                    .Replace("{num}", item.DocNo)
                    .Replace("{date}", item.ExpiredDate.ToString("dd/MM/yyyy"));
                iNo++;
            }

            string strDirectoryApp = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            string strFileTemplate = strDirectoryApp + "\\MailTemplateLibrary.html";
            if (Directory.Exists(strDirectoryApp) && File.Exists(strFileTemplate))
            {
                StreamReader sr = new StreamReader(strFileTemplate);
                strBodyEmail = sr.ReadToEnd();
                strBodyEmail = strBodyEmail.Replace("{body}", strBody);
            }

            return strBodyEmail;
        }

        public string SendMail(string title, string body, List<string> to, List<string> cc)
        {
            try
            {
                string smtp = ConfigurationManager.AppSettings["smtp"];
                string port = ConfigurationManager.AppSettings["port"];
                string mailSender = ConfigurationManager.AppSettings["mailSender"];

                MailMessage mail = new MailMessage();
                SmtpClient smtpServer = new SmtpClient();

                smtpServer.Port = 25;
                smtpServer.EnableSsl = false;
                smtpServer.Host = smtp;
                mail.From = new MailAddress(mailSender, "Compliance AMFS");
                foreach (var item in to)
                {
                    mail.To.Add(new MailAddress(item));
                }
                if (cc != null)
                {
                    foreach (var item in cc)
                    {
                        mail.CC.Add(new MailAddress(item));
                    }
                }
                mail.Subject = title;
                mail.Body = body;
                mail.IsBodyHtml = true;

                smtpServer.Send(mail);
            }
            catch (Exception ex)
            {
                //LogScheduller(string.Join(",", to), app, docIdentifier, false, ex.Message, frequency);
                return ex.Message;
            }

            //LogScheduller(string.Join(",", to), app, docIdentifier, true, "Success", frequency);
            return "Success";
        }

        private string SendEmailWithAttachments(string strReceiver, string strSubject, string strBody_Email, Boolean isBody_Email_Html, string strFileAttachment)
        {
            string smtp = ConfigurationManager.AppSettings["smtp"];
            string port = ConfigurationManager.AppSettings["port"];

            string mail_server = ConfigurationManager.AppSettings["mail_server"];
            string mail_sender = ConfigurationManager.AppSettings["mail_sender"];
            string mail_bcc = ConfigurationManager.AppSettings["mail_bcc"];
            string strRet = "";
            try
            {
                //string[] strRecArray = strReceiver.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                MailMessage mail = new MailMessage();
                SmtpClient smtpServer = new SmtpClient();

                smtpServer.Port = Convert.ToInt16(port);
                smtpServer.EnableSsl = false;
                smtpServer.Host = smtp;
                mail.From = new MailAddress(mail_server, mail_sender);
                //mail.To.Add(strReceiver);
                foreach (string strRec in strReceiver.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    mail.To.Add(strRec);
                };
                foreach (string str_bcc in mail_bcc.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    mail.Bcc.Add(str_bcc);
                };
                mail.Subject = strSubject;
                mail.Body = strBody_Email;
                mail.IsBodyHtml = isBody_Email_Html;

                if (strFileAttachment.Length > 0)
                {
                    if (File.Exists(strFileAttachment))
                    {
                        System.Net.Mail.Attachment mailAttachment;
                        mailAttachment = new System.Net.Mail.Attachment(strFileAttachment);
                        mail.Attachments.Add(mailAttachment);
                        smtpServer.Send(mail);
                        strRet = "success";
                    }
                    else strRet = "no file attachment.";
                }
                else strRet = "no file attachment.";

            }
            catch (Exception ex)
            {
                strRet = ex.Message.ToString();
                //throw ex;
            }
            return strRet;
        }
    }
}
