﻿using System.Collections.Generic;

namespace MailNotification.Services.Interface
{
    public interface ILibraryNotificationService
    {
        string SendMail(string title, string body, List<string> to, List<string> cc);
        string SentEmailNotification();
    }
}