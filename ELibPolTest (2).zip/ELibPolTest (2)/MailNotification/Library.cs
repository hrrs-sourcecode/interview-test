﻿using System;
using System.Collections.Generic;
using System.Linq;
using E_LibraryPolicy.Constatnt;
using System.IO;
using MailNotification.Model;
using System.Data.Entity;

namespace MailNotification
{
    class Library
    {
        /// <summary>
        /// NotifyLibrary - original by lutfi
        /// </summary>
        public static void NotifyLibrary()
        {
            Entities db = new Entities();
            var ruleSet = db.Settings.Where(x => x.ApplicationName == SettingConst.Library
                            && x.Key != SettingConst.DaysName).ToList().Select(x => Convert.ToInt32(x.Value));
            var tempDays = db.Settings.Where(x => x.ApplicationName == SettingConst.Library
                            && x.Key == SettingConst.DaysName).FirstOrDefault();
            string daysName = "wednesday";
            if (tempDays != null)
            {
                daysName = tempDays.Value.ToLower();
            }
            bool IsSameDay = daysName == DateTime.Now.ToString("dddd").ToLower();

            var listData = (from dept in db.Departments
                            join doc in db.Documents on dept.DepartmentID equals doc.DepartmentID
                            where dept.IsActive == true
                            //aktif ada value expire date
                            && dept.IsNotif == true && (doc.ExpiredDate.HasValue
                            //tgl sama dengan di setting
                            && (ruleSet.Any(x=>x == DbFunctions.DiffDays(DateTime.Now, doc.ExpiredDate.Value))
                            // atau lebih rendah dari yg terendah (notifikasi tetap jalan saat sudah expire)
                            || (DbFunctions.DiffDays(DateTime.Now, doc.ExpiredDate.Value) < ruleSet.Min()
                            && IsSameDay)
                            //atau sudah submit tp blm di approve atasan
                            || (DbFunctions.DiffDays(DateTime.Now,  doc.ExpiredDate.Value).Value > ruleSet.Max()
                            && doc.IsApproved != true)))
                            select new
                            {
                                dept.DepartmentID,
                                doc.DocumentID,
                                Days = DbFunctions.DiffDays(DateTime.Now, doc.ExpiredDate.Value)
                            }).ToList();

            var docDepartment = new List<MailDTO>();
            //grouping berdasarkan department dan cek eskalasi
            foreach (var item in listData)
            {
                var isEscalate = false;
                var temp = docDepartment.Where(x => x.DepartmentID == item.DepartmentID).FirstOrDefault();
                var setting = db.Settings.Where(x => x.ApplicationName == SettingConst.Library
                                                && x.Value == item.Days.ToString()).FirstOrDefault();
                //cek apakah tanggal dibawah min
                if(setting == null)
                {
                    var tmpSetting = db.Settings.Where(x => x.ApplicationName == SettingConst.Library
                            && x.Key != SettingConst.DaysName).ToList().Select(x => Convert.ToInt32(x.Value)).Min();
                    if (tmpSetting > item.Days)
                        isEscalate = true;
                }

                if (temp != null)
                {
                    temp.DocumentID.Add(item.DocumentID);
                    //kalau sudah true tdk perlu di rubah
                    if(!temp.IsEscalate)
                        temp.IsEscalate = isEscalate;
                }
                else
                {
                    var newItem = new MailDTO();
                    newItem.DepartmentID = item.DepartmentID;
                    newItem.DocumentID = new List<int>() { item.DocumentID };
                    newItem.IsEscalate = isEscalate;
                    docDepartment.Add(newItem);

                }
            }

            foreach (var item in docDepartment)
            {
                var department = db.Departments.Find(item.DepartmentID);
                var listReceiver = new List<string>();

                var listDoc = db.Documents.Where(x => item.DocumentID.Any(y=> y == x.DocumentID)).ToList();

                var PIC = db.Users.Find(department.PICUsername);
                listReceiver.Add(PIC.Email);
                if (item.IsEscalate)
                {
                    listReceiver.AddRange(
                        db.Users.Where(x => x.DepartmentID == item.DepartmentID
                        && (x.IsChief == true || x.IsVice == true)).Select(x => x.Email));
                }
                //list document combined

                MailHelper mailHelper = new MailHelper();
                StreamReader sr = new StreamReader("MailTemplateLibrary.html");
                string body = sr.ReadToEnd();
                var count = 1;
                var template = "<tr width=\"400\"><td>{no}</td><td>{title}</td><td>{num}</td><td>{date}</td></tr>";
                if (listDoc != null)
                {
                    var tmp = "";
                    foreach (var doc in listDoc)
                    {
                        tmp += template.Replace("{no}", count.ToString())
                                        .Replace("{title}", doc.Title)
                                        .Replace("{num}", doc.Number)
                                        .Replace("{date}", doc.ExpiredDate.Value.ToString("dd/MM/yyyy"));
                        count++;
                    }
                    body = body.Replace("{body}", tmp);
                    mailHelper.SendMail("Review Policy and Procedure Document reminder",
                            body, listReceiver, null, SettingConst.Library,
                            string.Join(",", listDoc.Select(x => x.DocumentType.DocumentTypeName)), SettingConst.Monthly);
                }

            }

        }

        /// <summary>
        /// NotifyLibrary_New
        /// </summary>
        public static List<sp_Check_Document_Library_Review_Result> NotifyLibrary_New()
        {
            Entities db = new Entities();
            List<sp_Check_Document_Library_Review_Result> listData = db.sp_Check_Document_Library_Review().ToList();



            // group by PIC
            var listDataByPIC = listData
                    .GroupBy(item => item.PIC_Email)
                    .Select(sel => new { pic_email = sel.Key, items = sel.ToList() })
                    .ToList();


            int count = 0;
            foreach (var obj in listDataByPIC)
            {
                var listReceiver = new List<string>();
                listReceiver.Add(obj.pic_email);

                //check datediff <= 30 (notif ke 2, dst)
                if (System.Math.Abs(obj.items[count].DATE_DIFF.Value) <= 30)
                {
                    listReceiver.Add(obj.items[count].DeptHeadEmail);
                }else if (obj.items[0].DATE_DIFF.Value > 0)
                {
                    listReceiver.Add(obj.items[count].DeptHeadEmail);
                };

                //list documents dengan pic yg sama
                int iNo = 1;
                string strBody = ""; 
                foreach(var Lst in obj.items)
                {
                    sp_Check_Document_Library_Review_Result _doc = Lst;
                    string strTbl = "<tr><td>{no}</td><td width=\"400\">{title}</td><td>{num}</td><td>{date}</td></tr>";
                    strBody += strTbl.Replace("{no}", iNo.ToString())
                                                        .Replace("{title}", _doc.Title)
                                                        .Replace("{num}", _doc.Number)
                                                        .Replace("{date}", _doc.ExpiredDate.Value.ToString("dd/MM/yyyy"));
                    iNo++;
                }

                // sending email
                MailHelper mailHelper = new MailHelper();
                //string strPath = AppDomain.CurrentDomain.BaseDirectory + "MailTemplateLibrary.html";
                //StreamReader sr = new StreamReader("MailTemplateLibrary.html");
                //string strBodyEmail = sr.ReadToEnd();

                string strDirectoryApp = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                string strFileTemplate = strDirectoryApp + "\\MailTemplateLibrary.html";
                if (Directory.Exists(strDirectoryApp) && File.Exists(strFileTemplate))
                {
                    StreamReader sr = new StreamReader(strFileTemplate);
                    string strBodyEmail = sr.ReadToEnd();
                    strBodyEmail = strBodyEmail.Replace("{body}", strBody);
                    mailHelper.SendMail("Review Policy and Procedure Document reminder",
                    strBodyEmail, listReceiver, null, SettingConst.Library,
                    string.Join(",", obj.items[count].DocumentTypeID), SettingConst.Monthly);

                }
               

                count++;
            }

            //    // Send Email By Per Documents
            //    int count = 1;
            //foreach (var item in listData)
            //{
            //    var listDoc = db.DocumentTypes.Where(x => x.DocumentTypeID == item.DocumentTypeID).SingleOrDefault();
            //    var listReceiver = new List<string>();
            //    listReceiver.Add(item.PIC_Email);

            //    //check datediff <= 30 (notif ke 2, dst)
            //    if(item.DATE_DIFF <= 30) {
            //        listReceiver.Add(item.DeptHeadEmail);
            //    }


            //    MailHelper mailHelper = new MailHelper();
            //    StreamReader sr = new StreamReader("MailTemplateLibrary.html");
            //    string body = sr.ReadToEnd();

            //    var template = "<tr><td>{no}</td><td>{title}</td><td>{num}</td><td>{date}</td></tr>";
            //    if (item != null)
            //    {
            //        var tmp = "";
            //        tmp += template.Replace("{no}", count.ToString())
            //                                                .Replace("{title}", item.Title)
            //                                                .Replace("{num}", item.Number)
            //                                                .Replace("{date}", item.ExpiredDate.Value.ToString("dd/MM/yyyy"));

            //        body = body.Replace("{body}", tmp);
            //        mailHelper.SendMail("Review Policy and Procedure Document reminder",
            //                body, listReceiver, null, SettingConst.Library,
            //                string.Join(",", listDoc.DocumentTypeName) , SettingConst.Monthly);
            //    }
            //    //count++;
            //}
            return listData;
        }
    }
}
