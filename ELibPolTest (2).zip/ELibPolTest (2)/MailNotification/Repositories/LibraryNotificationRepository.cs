﻿using MailNotification.Model;
using MailNotification.Repositories.Interface;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailNotification.Repositories
{
    public class LibraryNotificationRepository : RepoHelper, ILibraryNotificationRepository
    {
        string strConn = ConfigurationManager.ConnectionStrings["E-Library_Conn_Str"].ConnectionString;
        public IList<DocumentNotification> GetExpiredDocumentNotificationList()
        {
            IList<DocumentNotification> result = new List<DocumentNotification>();
            result = DataReaderWithSP(strConn, "sp_GetExpiredDocumentNotification", null).AsEnumerable().Select(row =>
            new DocumentNotification
            {
                DepartmentID = row["DepartmentID"].ToString(),
                DocNo = row["DocNo"].ToString(),
                DeptHeadEmail = row["DeptHeadEmail"].ToString(),
                DeptHeadUserName = row["DeptHeadUserName"].ToString(),
                DivHeadEmail = row["DivHeadEmail"].ToString(),
                DivHeadUsername = row["DivHeadUsername"].ToString(),
                DivisionID = row["DivisionID"].ToString(),
                DocumentID = row["DocumentID"].ToString(),
                DocumentPath = row["DocumentPath"].ToString(),
                ExpiredDate = (DateTime)row["ExpiredDate"],
                NotifLabel = row["NotifLabel"].ToString(),
                PIC_Email = row["PIC_Email"].ToString(),
                PIC_Name = row["PIC_Name"].ToString(),
                Title = row["Title"].ToString(),
            }).ToList();

            return result;
        }

        public string SaveNotificationReport(IList<NotificationReport> listNotif)
        {
            string result = "Success";
            using (SqlConnection sqlConnection = new SqlConnection(strConn))
            {
                sqlConnection.Open();
                foreach (NotificationReport resp in listNotif)
                {
                    string query = @"insert into NotificationReport([DocumentID],[DivisionID],[DepartmentID],[Receiver],[Subject],[ApplicationName],[NotifLabel],[IsSent],[Result],[CreatedDate],[CreatedBy])
					values (@DocumentID,@DivisionID,@DepartmentID,@Receiver,@Subject,@ApplicationName,@NotifLabel,@IsSent,@Result,@CreatedDate,@CreatedBy)";

                    using (SqlCommand sqlCommand = new SqlCommand(query, sqlConnection))
                    {
                        sqlCommand.CommandType = CommandType.Text;
                        sqlCommand.Parameters.AddWithValue("@DocumentID", resp.DocumentID);
                        sqlCommand.Parameters.AddWithValue("@DivisionID", resp.DivisionID);
                        sqlCommand.Parameters.AddWithValue("@DepartmentID", resp.DepartmentID);
                        sqlCommand.Parameters.AddWithValue("@Receiver", resp.Receiver);
                        sqlCommand.Parameters.AddWithValue("@Subject", resp.Subject);
                        sqlCommand.Parameters.AddWithValue("@ApplicationName", resp.Application);
                        sqlCommand.Parameters.AddWithValue("@NotifLabel", resp.NotifLabel);
                        sqlCommand.Parameters.AddWithValue("@IsSent", true);
                        sqlCommand.Parameters.AddWithValue("@Result", resp.Result);
                        sqlCommand.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                        sqlCommand.Parameters.AddWithValue("@CreatedBy", "Task Scheduler");
                        try
                        {
                            sqlCommand.ExecuteReader();
                            result = $"Successfully insert : {resp.DocumentID} to table NotificationReport";
                            DebugLogger.WriteLog(result);
                        }
                        catch (Exception ex)
                        {
                            result = ex.Message;
                            DebugLogger.WriteLog(ex.Message);
                        }
                    }
                }
                sqlConnection.Close();
            }

            return result;
        }
    }
}
