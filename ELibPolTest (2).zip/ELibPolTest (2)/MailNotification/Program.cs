﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
//using E_LibraryPolicy.Models;
using System.Data;
//using E_LibraryPolicy.Helper;
using System.IO;
using MailNotification.Model;
using MailNotification.Repositories.Interface;
using MailNotification.Repositories;
using MailNotification.Services.Interface;
using MailNotification.Services;
//using E_LibraryPolicy.Helper;

namespace MailNotification
{
    class Program
    {
        static void Main(string[] args)
        {
            string strLog = "";
            strLog = "Scheduler Start..." + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            Console.WriteLine(strLog);
            DebugLogger.WriteLog(strLog);

            ILibraryNotificationRepository repo = new LibraryNotificationRepository();
            ILibraryNotificationService svc = new LibraryNotificationService(repo);

            strLog = svc.SentEmailNotification();

            //IList<DocumentNotification> listDoc = repo.GetExpiredDocumentNotificationList();

            //var lstLibrary = Library.NotifyLibrary_New();

            strLog = "Scheduler End..." + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            Console.WriteLine(strLog);
            DebugLogger.WriteLog(strLog);
        }
    }
}
