﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Web;
using MailNotification.Model;

namespace MailNotification
{
    public class MailHelper
    {
        Entities db = new Entities();
        public string SendMail(string title, string body, List<string> to, List<string> cc, string app, string docIdentifier, string frequency)
        {
            try
            {
                string smtp = ConfigurationManager.AppSettings["smtp"];
                string port = ConfigurationManager.AppSettings["port"];
                string mailSender = ConfigurationManager.AppSettings["mailSender"];

                MailMessage mail = new MailMessage();
                SmtpClient smtpServer = new SmtpClient();

                smtpServer.Port = 25;
                smtpServer.EnableSsl = false;
                smtpServer.Host = smtp;
                mail.From = new MailAddress(mailSender, "Compliance AMFS");
                foreach (var item in to)
                {
                    mail.To.Add(new MailAddress(item));
                }
                if (cc != null)
                {
                    foreach (var item in cc)
                    {
                        mail.CC.Add(new MailAddress(item));
                    }
                }
                mail.Subject = title;
                mail.Body = body;
                mail.IsBodyHtml = true;

                smtpServer.Send(mail);
            }
            catch (Exception ex)
            {
                LogScheduller(string.Join(",", to), app, docIdentifier, false, ex.Message, frequency);
                return ex.Message;
            }

            LogScheduller(string.Join(",", to), app, docIdentifier, true, "Success", frequency);
            return "Success";
        }

        public void LogScheduller(string receiver, string app, string subject, bool isSent, string result, string frequency)
        {
            var log = new SchedullerReport();
            log.Receiver = receiver;
            log.Applications = app;
            log.IsSent = isSent;
            log.Result = result;
            log.Subject = subject;
            log.Frequency = frequency;
            log.CreatedDate = DateTime.Now;

            db.SchedullerReports.Add(log);
            db.SaveChanges();
        }
    }

}