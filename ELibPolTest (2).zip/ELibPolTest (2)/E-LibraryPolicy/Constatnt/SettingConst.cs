﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Constatnt
{
    public class SettingConst
    {
        public const string DaysName = "daysname";

        public const string Once = "Once";
        public const string Daily = "Daily";
        public const string Weekly = "Weekly";
        public const string Monthly = "Monthly";
        public const string Quarterly = "Quarterly";
        public const string HalfYearly = "HalfYearly";
        public const string Yearly = "Yearly";

        public const string Library = "Library";
        public const string Regulatory = "Regulatory";
    }
}