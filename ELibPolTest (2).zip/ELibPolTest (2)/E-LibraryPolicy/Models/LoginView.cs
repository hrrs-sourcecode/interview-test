﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Models
{
    public class LoginView
    {
        [Required]
        [Display(Name = "User Name")]
        public string UserName { get; set; }
        [Required]
        [Display(Name = "Password")]
        public string Password { get; set; }
    }

    public class CustomSerializeModel
    {
        public string Username { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public string EmployeeNumber { get; set; }
        public int DepartmentID { get; set; }
        public bool IsAdminLibrary { get; set; }
        public bool IsAdminRegulatory { get; set; }
        public bool IsPIC { get; set; }
        public bool IsChief { get; set; }
        public bool IsVice { get; set; }

    }
}