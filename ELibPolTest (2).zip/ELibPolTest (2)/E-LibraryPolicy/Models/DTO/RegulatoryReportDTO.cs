﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Models.DTO
{
    public class RegulatoryReportDTO
    {
        public string ReportName { get; set; }
        public string DepartmentName { get; set; }
        public string RegulatoryName { get; set; }
        public string Regulation { get; set; }
        public string Addressee { get; set; }
        public string Schedulle { get; set; }
        public string Status { get; set; }
        public DateTime? SubmissionDate { get; set; }
        public string SubmissionComment { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}