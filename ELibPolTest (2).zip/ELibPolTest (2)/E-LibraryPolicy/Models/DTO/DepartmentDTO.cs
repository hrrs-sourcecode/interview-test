﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Models.DTO
{
    public class DepartmentDTO
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public string DeptHeadEmail { get; set; }        
        public string PICUsername { get; set; }
        public string DivisionID { get; set; }
        public string DivisionName { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<bool> IsNotif { get; set; }
        public int FileCount { get; set; }
        public int FileApprovedCount { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}