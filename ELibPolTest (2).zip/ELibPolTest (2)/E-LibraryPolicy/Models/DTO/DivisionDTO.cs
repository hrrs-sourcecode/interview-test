﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Models.DTO
{
    public class DivisionDTO
    {
        public int DivisionID { get; set; }
        public string DivisionName { get; set; }
        public string DivHeadUsername { get; set; }        
        public string DivHeadEmail { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<bool> IsNotif { get; set; }
        public int DepartmentCount { get; set; }
        public int DepartmentActiveCount { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}