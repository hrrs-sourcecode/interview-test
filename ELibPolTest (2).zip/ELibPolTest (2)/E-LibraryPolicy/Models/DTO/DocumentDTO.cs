﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace E_LibraryPolicy.Models.DTO
{
    public class DocumentDTO
    {
        public int DocumentID { get; set; }
        public Nullable<int> DepartmentID { get; set; }
        public string Title { get; set; }
        public Nullable<int> DocumentTypeID { get; set; }
        public string DocumentTypeName
        {
            get
            {
                using (var db = new Entities())
                {
                    if (DocumentTypeID != null)
                    {
                        return db.DocumentTypes.Find(DocumentTypeID).DocumentTypeName;
                    }
                }
                return "";
            }
            set { }
        }
        public string DepartmentName
        {
            get
            {
                using (var db = new Entities())
                {
                    if (DepartmentID != null)
                    {
                        return db.Departments.Find(DepartmentID).DepartmentName;
                    }
                }
                return "";
            }
            set { }
        }
        public string DocumentPath { get; set; }
        public string AttachmentPath { get; set; }
        public Nullable<System.DateTime> EffectiveDate { get; set; }
        public string Keywords { get; set; }
        public string Number { get; set; }
        public Nullable<bool> IsReviewed { get; set; }
        public Nullable<bool> IsApproved { get; set; }
        public string ApprovedBy { get; set; }
        public string ReviewedBy { get; set; }
        public Nullable<System.DateTime> ExpiredDate { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        public string Options { get; set; }
        public HttpPostedFileBase File { get; set; }
        public HttpPostedFileBase Attachment { get; set; }

        public string PIC_Name { get; set; }

        public string PIC_Email { get; set; }

        public Nullable<bool> IsActive { get; set; }

        public bool IsEditable { get; set; }

        public bool IsDeletable { get; set; }
    }
}
