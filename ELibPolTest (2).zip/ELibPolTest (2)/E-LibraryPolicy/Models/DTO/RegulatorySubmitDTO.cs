﻿using E_LibraryPolicy.Constatnt;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Models.DTO
{
    public class RegulatorySubmitDTO
    {
        public int DepartmentRegulatoryID { get; set; }
        public Nullable<int> DepartmentID { get; set; }
        public Nullable<int> RegulatoryCategoryID { get; set; }
        public string Schedulle { get; set; }
        public DateTime Value { get; set; }
        public string Regulation { get; set; }
        public string Addressee { get; set; }
        public string ReportName { get; set; }
        public string IsFixed { get; set; }
        public string Remarks { get; set; }
        public string RegulatoryName
        {
            get
            {
                using (Entities db = new Entities())
                {
                    try
                    {
                        //return db.RegulatoryTypes.Find(RegulatoryTypeID).RegulatoryTypeName;
                        return db.RegulatoryCategories.Find(RegulatoryCategoryID).RegulatoryCategoryName;
                    }
                    catch { return ""; }

                }
            }
            set { }
        }

        public bool IsSubmited
        {
            get
            {
                using (Entities db = new Entities())
                {
                    var result = db.RegulatoryApprovals.Where(x => x.DepartmentRegulatoryID ==
                                    DepartmentRegulatoryID).OrderByDescending(x => x.CreatedDate);
                    //DateTime valDate = Convert.ToDateTime(Value);
                    //var now = DateTime.Now;
                    //if (Schedulle == SettingConst.Once)
                    //{
                    //    result = db.RegulatoryApprovals.Any(x => x.DepartmentRegulatoryID == DepartmentRegulatoryID);
                    //}
                    //else if (Schedulle == SettingConst.Monthly)
                    //{
                    //    result = db.RegulatoryApprovals.Any(x => x.DepartmentRegulatoryID == DepartmentRegulatoryID);
                    //}
                    //else if (Schedulle == SettingConst.Yearly)
                    //{
                    //    result = db.RegulatoryApprovals.Any(x => x.DepartmentRegulatoryID == DepartmentRegulatoryID);
                    //}

                    if (result != null)
                    {
                        var tmp = result.FirstOrDefault();
                        if (tmp != null)
                        {
                            Status = tmp.Status;
                            Title = tmp.Title;
                            Path = tmp.FilePath;
                            LastSubmitDate = tmp.CreatedDate.Value.ToString("dd/MM/yyyy");
                            Comment = tmp.ReviewComment;
                            SubmissionDate = tmp.SubmissionDate;
                        }
                    }
                    return result != null;
                }
            }
        }
        public string Status { get; set; }
        public string Title { get; set; }
        public string Path { get; set; }
        public string LastSubmitDate { get; set; }
        public string Comment { get; set; }
        public DateTime? SubmissionDate { get; set; }
        public string SubmissionComment { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}