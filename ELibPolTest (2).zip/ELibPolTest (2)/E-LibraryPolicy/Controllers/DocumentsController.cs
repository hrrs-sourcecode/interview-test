﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using AutoMapper;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;
using System.Linq.Dynamic;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Helper;

using ClosedXML.Excel;


namespace E_LibraryPolicy.Controllers
{
    public class SettingConst
    {
        public const string DaysName = "daysname";

        public const string strCreateNewDoc = "Create New Document";
        public const string strEditDoc = "Edit Document";
        public const string Once = "Once";
        public const string Daily = "Daily";
        public const string Weekly = "Weekly";
        public const string Monthly = "Monthly";
        public const string Quarterly = "Quarterly";
        public const string HalfYearly = "HalfYearly";
        public const string Yearly = "Yearly";

        public const string Library = "Library";
        public const string Regulatory = "Regulatory";
    }
    public class DocumentsController : AbstractController<Document, DocumentDTO>
    {
        private Entities db = new Entities();
        // GET: Documents
        public ActionResult Home(int departmentID = 0)
        {
            if (departmentID == 0)
            {
                return RedirectToAction("Index", "Home");
            }
            var department = db.Departments.Find(departmentID);

            var user = (CustomPrincipal)User;
            ViewBag.DocumentTypeID = new SelectList(db.DocumentTypes.Where(x => x.IsActive == true), "DocumentTypeID", "DocumentTypeName");
            IList<Document> documents = new List<Document>();

            ViewBag.IsPIC = user.IsPIC && user.DepartmentID == departmentID;
            //var tmp = db.Users.Where(x => x.DepartmentID == departmentID && x.Username == User.Identity.Name).FirstOrDefault();
            ViewBag.IsChiefOrVice = (user.IsChief && user.DepartmentID == departmentID) || (user.IsVice && user.DepartmentID == departmentID);
            if (departmentID == -1)
            {
                ViewBag.DepartmentName = "All Department";
                documents = db.Documents.ToList();
            }
            else if (department == null || department.IsActive == false)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.DepartmentName = department.DepartmentName;
                documents = db.Documents.ToList();
                //documents = db.Documents.Where(x => x.DepartmentID == departmentID).Include(d => d.Department).Include(d => d.DocumentType).ToList();
            }

            return View(documents);
        }

        public override ActionResult Create(DocumentDTO entry)
        {
            try
            {
                string dir = WebConfigurationManager.AppSettings["DocumentDirectoryPath"];
                //dir = Server.MapPath(dir);
                dir = System.Web.Hosting.HostingEnvironment.MapPath("~/Documents");
                string guid = Guid.NewGuid().ToString();

                if (entry.File != null)
                {                   
                    var fileName = Path.GetFileName(entry.File.FileName);                   
                    var path = Path.Combine(dir, guid + ".pdf");
                    entry.File.SaveAs(path);
                    entry.DocumentPath = path;
                }

                if (entry.Attachment != null)
                {
                    var fileName = Path.GetFileName(entry.File.FileName);
                    var path = Path.Combine(dir, "att_" + guid + ".pdf");
                    entry.File.SaveAs(path);
                    entry.AttachmentPath = path;
                }
                entry.CreatedBy = User.Identity.Name;
                entry.CreatedDate = DateTime.Now;
              
                entry.IsReviewed = false;
                entry.IsApproved = false;
                entry.IsActive = true;
                //entry.IsActive == null ? false: entry.IsActive;

                if (entry.DocumentID != 0)
                {
                    Document prevDoc = db.Documents.FirstOrDefault(x => x.DocumentID == entry.DocumentID);
                    prevDoc.IsActive = false;
                }

                entry.DocumentID = 0;
                Document dataDoc = DTOToEntity(entry);

                var result = db.Set<Document>().Attach(dataDoc);

                db.Entry(dataDoc).State = EntityState.Added;
                db.SaveChanges();

                
                ////Email first time to PIC
                //var listReceiver = new List<string>();                
                //listReceiver.Add(entry.PIC_Email);

                //MailHelper mailHelper = new MailHelper();
                //var EmailTempPath = Server.MapPath("~/MailTemplateLibrary.html");
                //string body;
                //using (StreamReader reader = new StreamReader(EmailTempPath))
                //{
                //    body = reader.ReadToEnd();
                //}

                //var count = 1;
                //var template = "<tr><td>{no}</td><td>{title}</td><td>{num}</td><td>{date}</td><td>{status}</td></tr>";
                //List<Document> listDoc = new List<Document>();
                //listDoc.Add(dataDoc);
                //if (listDoc != null)
                //{
                //    var tmp = "";
                //    tmp += template.Replace("{no}", count.ToString())
                //                    .Replace("{title}", dataDoc.Title)
                //                    .Replace("{num}", dataDoc.Number)
                //                    .Replace("{date}", dataDoc.ExpiredDate.Value.ToString("dd/MM/yyyy"))
                //                    .Replace("{status}", SettingConst.strCreateNewDoc);
                //    count++;
                    
                //    body = body.Replace("{body}", tmp);
                //    string strUrl = WebConfigurationManager.AppSettings["Url_Approve"];
                //    body = body.Replace("{url_approve}", strUrl);
                //    string strDocName = db.DocumentTypes.Where(x => x.DocumentTypeID == dataDoc.DocumentTypeID).FirstOrDefault().ToString();
                //    mailHelper.SendMail("Review Policy and Procedure Document reminder",
                //            body, listReceiver, null, SettingConst.Library,
                //            string.Join(",", strDocName), SettingConst.strCreateNewDoc);
                //}



                return Json("Success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }

        public override ActionResult Edit(DocumentDTO entry)
        {
            try
            {
                string dir = WebConfigurationManager.AppSettings["DocumentDirectoryPath"];
                //dir = Server.MapPath(dir);

                //dir = System.Web.Hosting.HostingEnvironment.MapPath("~/Documents");
                var oldDoc = db.Documents.Find(entry.DocumentID);
                //if (entry.File != null)
                //{
                //    try
                //    {
                //        System.IO.File.Delete(oldDoc.DocumentPath);
                //    }
                //    catch { }

                //    Guid guid = Guid.NewGuid();
                //    var path = Path.Combine(dir, guid.ToString() + ".pdf");
                //    entry.File.SaveAs(path);
                //    oldDoc.DocumentPath = path;
                //}
                //if (entry.Attachment != null)
                //{
                //    try
                //    {
                //        System.IO.File.Delete(oldDoc.AttachmentPath);
                //    }
                //    catch { }

                //    Guid guid = Guid.NewGuid();
                //    var path = Path.Combine(dir, guid.ToString() + ".pdf");
                //    entry.Attachment.SaveAs(path);
                //    oldDoc.AttachmentPath = path;
                //}

                //MapDataObject(oldDoc, entry);
                oldDoc.Title = entry.Title;
                oldDoc.Number = entry.Number; 
                oldDoc.DocumentTypeID = entry.DocumentTypeID;
                oldDoc.Keywords = entry.Keywords;
                oldDoc.EffectiveDate = entry.EffectiveDate;
                oldDoc.ExpiredDate = entry.ExpiredDate;
                oldDoc.ModifiedBy = User.Identity.Name;
                oldDoc.ModifiedDate = DateTime.Now;
                oldDoc.IsApproved = false;
                oldDoc.IsReviewed = false;
                oldDoc.PIC_Name = entry.PIC_Name;
                oldDoc.PIC_Email = entry.PIC_Email;
                oldDoc.IsActive = entry.IsActive == null ? false : entry.IsActive;
                db.SaveChanges();


                ////Email first time to PIC
                //var listReceiver = new List<string>();
                //var department = db.Departments.Find(entry.DepartmentID);
                //listReceiver.Add(entry.PIC_Email);

                //MailHelper mailHelper = new MailHelper();
                //var EmailTempPath = Server.MapPath("~/MailTemplateLibrary.html");
                //string body;
                //using (StreamReader reader = new StreamReader(EmailTempPath))
                //{
                //    body = reader.ReadToEnd();
                //}

                //var count = 1;
                //var template = "<tr><td>{no}</td><td>{title}</td><td>{num}</td><td>{date}</td><td>{status}</td></tr>";
                //List<Document> listDoc = new List<Document>();
                //listDoc.Add(oldDoc);
                //if (listDoc != null)
                //{
                //    var tmp = "";
                //    foreach (var doc in listDoc)
                //    {
                //        tmp += template.Replace("{no}", count.ToString())
                //                        .Replace("{title}", doc.Title)
                //                        .Replace("{num}", doc.Number)
                //                        .Replace("{date}", doc.ExpiredDate.Value.ToString("dd/MM/yyyy"))
                //                        .Replace("{status}", SettingConst.strEditDoc);
                //        count++;
                //    }
                //    body = body.Replace("{body}", tmp);
                //    string strUrl = WebConfigurationManager.AppSettings["Url_Approve"];
                //    body = body.Replace("{url_approve}", strUrl);
                //    mailHelper.SendMail("Review Policy and Procedure Document reminder",
                //            body, listReceiver, null, SettingConst.Library,
                //            string.Join(",", listDoc.Select(x => x.DocumentType.DocumentTypeName)), SettingConst.strEditDoc);
                //}

                return Json("Success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }

        public override ActionResult Delete(DocumentDTO entry)
        {
            try
            {
                var doc = db.Documents.Find(entry.DocumentID);
                try
                {
                    System.IO.File.Delete(doc.DocumentPath);
                }
                catch { }

                db.Documents.Remove(doc);
                db.SaveChanges();
                return Json("Success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }

        public ActionResult GetListDocument(int? departmentID = null, bool? isApproval = null)
        {
            int start = Convert.ToInt32(Request.Form["start"]);
            int lenght = Convert.ToInt32(Request.Form["length"]);
            string searchValue = Request.Form["search[value]"];
            string column = Request.Form["order[0][column]"];
            string sortColumnName = Request.Form["columns[" + column + "][data]"];
            string sortDirection = Request.Form["order[0][dir]"];

            //var allData = db.Set<Document>().Where(x => x.Department.IsActive == true && x.DocumentType.IsActive == true).AsQueryable();

            var allData = db.Documents.AsQueryable();

            var user = (CustomPrincipal)User;

            //list case
            if (departmentID.HasValue && departmentID.Value != 0)
            {
                var department = db.Departments.Find(departmentID.Value);
                //if (departmentID.Value == -1)
                //{
                //    //allData = allData.Where(x => x.IsApproved == true && x.IsReviewed == true && x.ExpiredDate >= DateTime.Now);
                //}
                //else if ((user.IsAdminLibrary || ((user.IsChief || user.IsVice) || user.IsPIC) && user.DepartmentID == departmentID.Value)
                //    || department.PICUsername == user.Username)
                //{
                //    allData = allData.Where(x => x.DepartmentID == departmentID.Value);
                //}
                //else
                //{
                //    allData = allData.Where(x => x.DepartmentID == departmentID.Value && x.IsApproved == true && x.IsReviewed == true && x.ExpiredDate >= DateTime.Now);
                //}

                if (departmentID.Value != -1)
                {
                    allData = allData.Where(x => x.DepartmentID == departmentID.Value);
                }
            }
            //approval case
            else
            {
                //admin
                if (user.IsAdminLibrary)
                {
                    allData = allData.Where(x => x.IsReviewed == false && x.IsApproved == false);
                }
                //PIC, chief or vice
                else if (user.IsVice || user.IsChief)
                {
                    allData = allData.Where(x => x.DepartmentID == user.DepartmentID && x.IsApproved == false && x.IsApproved == false);
                }
                //else
                //{
                //    allData = allData.Where(x => x.PIC_Name == user.Name && x.IsApproved == false && x.IsApproved == false);
                //}
            }

            var total = allData.Count();
            var totalFiltered = total;
            if (!string.IsNullOrEmpty(searchValue))
            {
                var listSearch = searchValue.Split(';').Select(x => x.ToLower());

                allData = allData.Where(x => listSearch.Any(y => x.Title.ToLower().Contains(y))
                                        || listSearch.Any(y => x.Department.DepartmentName.ToLower().Contains(y)) ||
                                         listSearch.Any(y => x.Number.ToLower().Contains(y)) || listSearch.Any(y => x.Keywords.ToLower().Contains(y)) ||
                                         listSearch.Any(y => x.DocumentType.DocumentTypeName.ToLower().Contains(y)));
            }

            if (user.Position == "UserLibrary")
            {
                allData = allData.Where(x => (x.IsApproved == true && x.IsActive == true) || x.PIC_Name == user.Name);
            }

            totalFiltered = allData.Count();

            allData = allData.OrderBy(sortColumnName + " " + sortDirection).AsQueryable();

            allData = allData.Skip(start).Take(lenght).AsQueryable();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Document, DocumentDTO>();
            });
            var iMapper = config.CreateMapper();
            var result = iMapper.Map<IQueryable<Document>, List<DocumentDTO>>(allData);

            // User LDAP 
            IList<DocumentDTO> documentList = result.ToList();

            // User App
            if (user.Position == "UserLibrary")
            {
                documentList.ForEach(x =>
                {
                    if (x.PIC_Name == user.Name)
                    {
                        x.IsEditable = true;
                        if (!x.IsActive.Value || !x.IsApproved.Value)
                        {
                            x.IsDeletable = true;
                        }
                    }
                });
            }

            // SuperAdmin
            else if (user.Position == "SuperAdmin")
            {
                documentList.ForEach(x =>
                {
                    x.IsEditable = true;
                    if (!x.IsActive.Value || !x.IsApproved.Value)
                    {
                        x.IsDeletable = true;
                    }
                });
            }

            // Admin 
            else if (user.IsAdminLibrary)
            {
                documentList.ForEach(x =>
                {
                    x.IsEditable = true;
                    if ((!x.IsActive.Value || !x.IsApproved.Value) && x.PIC_Name == user.Name)
                    {
                        x.IsDeletable = true;
                    }
                });
            }

            return Json(new { data = documentList.ToList(), draw = Request.Form["draw"], recordsFiltered = totalFiltered, recordsTotal = total });
        }

        public ActionResult Approval()
        {
            var user = (CustomPrincipal)User;
            if (user.IsAdminLibrary || user.IsVice || user.IsChief || user.IsPIC)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Home", "Documents");
            }
        }

        public ActionResult DocumentAction(int documentID, bool actions, string comments = "")
        {
            try
            {
                var doc = db.Documents.Find(documentID);
                var user = (CustomPrincipal)User;
                if (!string.IsNullOrEmpty(comments))
                    doc.Comments = comments;

                doc.IsReviewed = true;
                doc.ReviewedBy = user.Username;
                doc.IsApproved = actions;
                doc.ApprovedBy = user.Username; 
                doc.ModifiedDate = DateTime.Now;
                doc.ModifiedBy = user.Username;
                db.SaveChanges();
                return Json("Success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }

        }

        [HttpGet]
        public ActionResult GetFile(string path)
        {
            return File(path, "application/pdf");
        }

        [HttpGet]
        public ActionResult GetAttachmentTemplate(string fileName)
        {
            return File("~/App_Data/"+ fileName, "application/doc", "Template Document.doc");
        }

        public void MapDataObject(Object target, Object source)
        {
            var dataHelper = new DataObjectHelper();
            foreach (var prop in target.GetType().GetProperties())
            {
                if (prop.Name != "Options" || prop.Name != "File")
                {
                    try
                    {
                        var targetValue = dataHelper.GetPropValue(target, prop.Name);
                        var sourceValue = dataHelper.GetPropValue(source, prop.Name);
                        if (sourceValue != null && !targetValue.Equals(sourceValue))
                        {
                            dataHelper.SetPropertyValue(target, prop.Name, sourceValue);
                        }
                    }
                    catch
                    {
                        var a = prop.Name;
                    }
                }

            }
        }

        public ActionResult Report()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GetListReport()
        {
            int start = Convert.ToInt32(Request.Form["start"]);
            int lenght = Convert.ToInt32(Request.Form["length"]);
            string searchValue = Request.Form["search[value]"];
            string column = Request.Form["order[0][column]"];
            string sortCoulmnName = Request.Form["columns[" + column + "][data]"];
            string sortDirection = Request.Form["order[0][dir]"];

            var allData = db.Set<Document>().OrderBy(x => x.CreatedDate).AsQueryable();
            var total = allData.Count();
            var totalFiltered = total;

            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                allData = allData.Where(x => x.Title.ToLower() == searchValue || x.Department.DepartmentName.ToLower() == searchValue ||
                             x.Number.ToLower() == searchValue || x.DocumentType.DocumentTypeName.ToLower() == searchValue);
            }
            totalFiltered = allData.Count();

            allData = allData.Skip(start).Take(lenght).AsQueryable();

            var result = new List<ReportDTO>();
            foreach (var item in allData)
            {
                var tmp = new ReportDTO();
                tmp.Number = item.Number;
                tmp.Category = item.DocumentType.DocumentTypeName;
                tmp.Title = item.Title;
                tmp.Department = item.Department.DepartmentName;
                tmp.PIC = item.Department.PICUsername;
                tmp.EffectiveDate = item.EffectiveDate.HasValue ?
                                    item.EffectiveDate.Value.ToString("dd/MM/yyyy") : "-";
                tmp.ReviewDate = item.ExpiredDate.HasValue ?
                                    item.ExpiredDate.Value.ToString("dd/MM/yyyy") : "-";
                tmp.IsReviewed = item.IsReviewed.HasValue ? item.IsReviewed.Value.ToString() : "-";
                tmp.IsApproved = item.IsApproved.HasValue ? item.IsApproved.Value.ToString() : "-";

                result.Add(tmp);
            }

            return Json(new { data = result.ToList(), draw = Request.Form["draw"], recordsFiltered = totalFiltered, recordsTotal = total });
        }

        public ActionResult DownloadReport()
        {
            var data = new List<ReportDTO>();
            foreach (var item in db.Documents)
            {
                var tmp = new ReportDTO();
                tmp.Number = item.Number;
                tmp.Category = item.DocumentType.DocumentTypeName;
                tmp.Title = item.Title;
                tmp.Department = item.Department.DepartmentName;
                tmp.PIC = item.Department.PICUsername;
                tmp.EffectiveDate = item.EffectiveDate.HasValue ?
                                    item.EffectiveDate.Value.ToString("dd/MM/yyyy") : "-";
                tmp.ReviewDate = item.ExpiredDate.HasValue ?
                                    item.ExpiredDate.Value.ToString("dd/MM/yyyy") : "-";
                tmp.IsReviewed = item.IsReviewed.HasValue ? item.IsReviewed.Value.ToString() : "-";
                tmp.IsApproved = item.IsApproved.HasValue ? item.IsApproved.Value.ToString() : "-";

                data.Add(tmp);
            }
            DataObjectHelper helper = new DataObjectHelper();
            var dt = helper.ToDataTable(data);
            XLWorkbook wb = new XLWorkbook();

            wb.Worksheets.Add(dt, "E-Library Report");
            MemoryStream mSteream = new MemoryStream();
            wb.SaveAs(mSteream);
            return File(mSteream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "E-Library Report.xls");
        }
    }
}
