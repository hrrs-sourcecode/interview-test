﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;

namespace E_LibraryPolicy.Controllers
{
    [CustomAuthorize]
    public class HomeController : Controller
    {
        Entities db = new Entities();
        public ActionResult Index()
        {
            var dept = db.Departments.Where(x => x.IsActive == true).AsQueryable();
            var departmentList = EntityToDTO(dept);
            foreach (var item in departmentList)
            {
                var doc = db.Documents.Where(x => x.DepartmentID == item.DepartmentID);
                item.FileCount = doc.Count();
                //item.FileApprovedCount = doc.Where(x => x.IsApproved == true && x.IsReviewed == true 
                //&& x.ExpiredDate >= DateTime.Now && x.DocumentType.IsActive == true).Count();
                item.FileApprovedCount = doc.Where(x => x.IsApproved == true && x.IsReviewed == true && x.DocumentType.IsActive == true).Count();
            }
            departmentList.Insert(0, new DepartmentDTO()
            {
                DepartmentName = "All Department",
                DepartmentID = -1,
                FileCount = departmentList.Select(x => x.FileCount).Sum(),
                FileApprovedCount = departmentList.Select(x => x.FileApprovedCount).Sum()
            });
            ViewBag.DepartmentList = departmentList;
            return View();
        }

        public ActionResult Dashboard()
        {
            return View();
        }

        protected List<DepartmentDTO> EntityToDTO(IQueryable<Department> entry)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Department, DepartmentDTO>();
            });
            var iMapper = config.CreateMapper();
            var result = iMapper.Map<IQueryable<Department>, List<DepartmentDTO>>(entry);
            return result;
        }
    }
}