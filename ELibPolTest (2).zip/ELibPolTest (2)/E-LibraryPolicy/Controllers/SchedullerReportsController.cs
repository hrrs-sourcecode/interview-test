﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ClosedXML.Excel;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Helper;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Constatnt;

namespace E_LibraryPolicy.Controllers
{
    [CustomAuthorize(IsAdminRegulatory = true, IsAdminLibrary = true)]
    public class SchedullerReportsController : AbstractController<SchedullerReport, SchedullerReport>
    {
        private Entities db = new Entities();
        protected override IQueryable<SchedullerReport> FilterData(string searchValue, IQueryable<SchedullerReport> List)
        {
            var user = (CustomPrincipal)User;
            if (user.IsAdminLibrary && !user.IsAdminRegulatory)
            {
                List = List.Where(x => x.Applications == SettingConst.Library);
            }

            if (user.IsAdminRegulatory && !user.IsAdminLibrary)
            {
                List = List.Where(x => x.Applications == SettingConst.Regulatory);
            }

            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                List = List.Where(x => x.Receiver.ToLower().Contains(searchValue)
                                || x.Subject.ToLower().Contains(searchValue)
                                || x.Result.ToLower().Contains(searchValue));
            }
            return List;
        }

        public ActionResult DownloadReport()
        {
            var data = db.SchedullerReports.ToList();
            var user = (CustomPrincipal)User;
            if (user.IsAdminLibrary && !user.IsAdminRegulatory)
            {
                data = data.Where(x => x.Applications == SettingConst.Library).ToList();
            }

            if (user.IsAdminRegulatory && !user.IsAdminLibrary)
            {
                data = data.Where(x => x.Applications == SettingConst.Regulatory).ToList();
            }
            DataObjectHelper helper = new DataObjectHelper();
            var dt = helper.ToDataTable(data);
            XLWorkbook wb = new XLWorkbook();

            wb.Worksheets.Add(dt, "Scheduller Report");
            MemoryStream mSteream = new MemoryStream();
            wb.SaveAs(mSteream);
            return File(mSteream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Scheduller Report.xls");
        }
    }
}