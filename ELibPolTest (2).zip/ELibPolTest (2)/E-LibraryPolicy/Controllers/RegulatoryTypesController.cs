﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;

namespace E_LibraryPolicy.Controllers
{
    [CustomAuthorize(IsAdminRegulatory = true)]
    public class RegulatoryTypesController : AbstractController<RegulatoryType, RegulatoryTypeDTO>
    {
        protected override IQueryable<RegulatoryType> FilterData(string searchValue, IQueryable<RegulatoryType> List)
        {
            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                List = List.Where(x => x.RegulatoryTypeName.ToLower().Contains(searchValue));
            }
            return List;
        }
    }
}