﻿namespace E_LibraryPolicy.Controllers
{
    internal class Entities
    {
    }
}