﻿using E_LibraryPolicy.CustomAuth;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Web.Security;
using System.DirectoryServices;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Constatnt;

namespace E_LibraryPolicy.Controllers
{
    public class AccountController : Controller
    {
        Entities db = new Entities();
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Login(string ReturnUrl = "")
        {
            ViewBag.ReturnUrl = ReturnUrl;
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginView loginViewModel, string ReturnUrl = "")
        {
            if (ModelState.IsValid)
            {
                string domain = WebConfigurationManager.AppSettings["ActiveDirectoryUrl"];
                string dummy = WebConfigurationManager.AppSettings["DummyLogin"];
                string ldapUser = loginViewModel.UserName;
                string ldapPassword = loginViewModel.Password;

                Session["LoginSession"] = JsonConvert.SerializeObject(loginViewModel);

                if (dummy == "1")
                {
                    ldapUser = WebConfigurationManager.AppSettings["ADUsername"];
                    ldapPassword = WebConfigurationManager.AppSettings["ADPassword"];
                }

                int cookieExpired = 60;
                string cookieName = WebConfigurationManager.AppSettings["cookieName"];
                using (DirectoryEntry entry = new DirectoryEntry(domain, ldapUser, ldapPassword))
                {
                    try
                    {
                        cookieExpired = Int32.Parse(WebConfigurationManager.AppSettings["LoginExpired"]);
                        if (entry.Guid == null)
                        {
                            ModelState.AddModelError("", "Username or Password invalid.");
                            return View();
                        }
                        else
                        {
                            DirectorySearcher search = new DirectorySearcher(entry);

                            search.Filter = "(SAMAccountName=" + loginViewModel.UserName + ")";
                            search.PropertiesToLoad.Add("name");
                            search.PropertiesToLoad.Add("mail");
                            search.PropertiesToLoad.Add("department");
                            search.PropertiesToLoad.Add("title");
                            search.PropertiesToLoad.Add("EMPLOYEENUMBER");

                            SearchResult result = search.FindOne();
                            if (result != null)
                            {
                                CustomSerializeModel userModel = new CustomSerializeModel()
                                {
                                    Username = ldapUser,
                                    Name = (String)result.Properties["name"][0],
                                    Position = result.Properties.Contains("title") ? (String)result.Properties["title"][0] : "",
                                    EmployeeNumber = result.Properties.Contains("EMPLOYEENUMBER") ? (String)result.Properties["EMPLOYEENUMBER"][0] : "",
                                };
                                var user = db.Users.Where(x => x.Username.ToLower() == ldapUser).FirstOrDefault();
                                //normal case
                                if (user != null)
                                {
                                    userModel.IsAdminRegulatory = user.Position == UserConst.AdminRegulatory || user.Position == UserConst.SuperAdmin;
                                    userModel.IsAdminLibrary = user.Position == UserConst.AdminLibrary || user.Position == UserConst.SuperAdmin;
                                    userModel.IsPIC = user.DepartmentID.HasValue ? user.Department.PICUsername == ldapUser : false;
                                    userModel.IsChief = user.IsChief.HasValue ? user.IsChief.Value : false;
                                    userModel.IsVice = user.IsVice.HasValue ? user.IsVice.Value : false;
                                    userModel.DepartmentID = user.DepartmentID.HasValue ? user.DepartmentID.Value : 0;
                                }

                                string userData = JsonConvert.SerializeObject(userModel);
                                FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket
                                    (
                                    1, loginViewModel.UserName, DateTime.Now, DateTime.Now.AddMinutes(cookieExpired), false, userData
                                    );

                                string enTicket = FormsAuthentication.Encrypt(authTicket);
                                HttpCookie faCookie = new HttpCookie(cookieName, enTicket);
                                faCookie.Expires = DateTime.Now.AddMinutes(cookieExpired);
                                Response.Cookies.Add(faCookie);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ModelState.AddModelError("", ex.Message);
                        return View();
                    }

                    if (!string.IsNullOrEmpty(ReturnUrl))
                    {
                        return Redirect(ReturnUrl);
                    }
                    else
                    {
                        return RedirectToAction("Index", "Home");
                    }
                }
            }
            ModelState.AddModelError("", "Invalid state please refresh window or use incognito");
            return View(loginViewModel);
        }

        public ActionResult Logout()
        {
            string cookieName = WebConfigurationManager.AppSettings["cookieName"];
            HttpCookie cookie = new HttpCookie(cookieName, "");
            cookie.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie);

            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Account", null);
        }
    }
}