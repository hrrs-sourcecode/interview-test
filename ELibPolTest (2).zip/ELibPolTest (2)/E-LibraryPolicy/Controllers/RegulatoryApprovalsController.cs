﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;
using E_LibraryPolicy.CustomAuth;
using System.Linq.Dynamic;
using E_LibraryPolicy.Helper;
using E_LibraryPolicy.Constatnt;

namespace E_LibraryPolicy.Controllers
{
    [CustomAuthorize(IsAdminRegulatory = true)]
    public class RegulatoryApprovalsController : AbstractController<RegulatoryApproval, RegulatoryApprovalDTO>
    {
        private Entities db = new Entities();

        protected override IQueryable<RegulatoryApproval> FilterData(string searchValue, IQueryable<RegulatoryApproval> List)
        {
            var user = (CustomPrincipal)User;
            if (user.IsAdminRegulatory)
            {
                List = List.Where(x => x.IsReviewed == null);
            }
            else
            {
                List = Enumerable.Empty<RegulatoryApproval>().AsQueryable();
            }

            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                List = List.Where(x => x.Title.ToLower().Contains(searchValue));
            }
            return List;
        }

        public ActionResult DocumentAction(int documentID, bool actions, string comments = "")
        {
            try
            {
                var doc = db.RegulatoryApprovals.Find(documentID);
                var user = (CustomPrincipal)User;
                if (user.IsAdminRegulatory)
                {
                    doc.IsReviewed = actions;
                    doc.ReviewBy = user.Username;
                    doc.Status = actions? "REVIEWED" : "REJECTED BY ADMIN";
                    if (actions)
                    {
                        if (doc.DepartmentRegulatory.Schedulle == SettingConst.Monthly)
                            doc.DepartmentRegulatory.Value = doc.DepartmentRegulatory.Value.Value.AddMonths(1);
                        else if (doc.DepartmentRegulatory.Schedulle == SettingConst.Quarterly)
                            doc.DepartmentRegulatory.Value = doc.DepartmentRegulatory.Value.Value.AddMonths(3);
                        else if (doc.DepartmentRegulatory.Schedulle == SettingConst.HalfYearly)
                            doc.DepartmentRegulatory.Value = doc.DepartmentRegulatory.Value.Value.AddMonths(6);
                        else if (doc.DepartmentRegulatory.Schedulle == SettingConst.Yearly)
                            doc.DepartmentRegulatory.Value = doc.DepartmentRegulatory.Value.Value.AddYears(1);
                    }
                }
                if (!actions && !string.IsNullOrEmpty(comments))
                    doc.ReviewComment = comments;

                
                doc.ModifiedDate = DateTime.Now;
                doc.ModifiedBy = user.Username;
                db.SaveChanges();
                return Json("Success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }

        }

        public ActionResult History(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("DocumentSubmission", "DepartmentRegulatories");
            }
            var name = db.DepartmentRegulatories.Find(id).ReportName;
            name = name.Length <= 12 ? name : name.Substring(0, 12) + "...";
            ViewBag.ReportName = name;
            return View();
        }

        [HttpPost]
        public virtual ActionResult GetHistoryList(int? id)
        {
            var user = (CustomPrincipal)User;
            int start = Convert.ToInt32(Request.Form["start"]);
            int lenght = Convert.ToInt32(Request.Form["length"]);
            string searchValue = Request.Form["search[value]"];
            string column = Request.Form["order[0][column]"];
            string sortCoulmnName = Request.Form["columns[" + column + "][data]"];
            string sortDirection = Request.Form["order[0][dir]"];

            var allData = db.RegulatoryApprovals.Where(x=>x.DepartmentRegulatoryID == id);
            var total = allData.Count();
            var totalFiltered = total;

            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                allData = allData.Where(x => x.Title.Contains(searchValue)
                            || x.Status.Contains(searchValue) || x.SubmissionDate.ToString().Contains(searchValue)
                            || x.ReviewComment.Contains(searchValue) || x.SubmissionComment.Contains(searchValue));
            }
            try
            {
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }
            catch
            {
                //custom sorting by name
                sortCoulmnName = Request.Form["columns[" + column + "][name]"];
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }
            totalFiltered = allData.Count();

            allData = allData.Skip(start).Take(lenght).AsQueryable();
            var dataHelper = new DataObjectHelper();
            var result = dataHelper.MapEntityDTO<RegulatoryApproval, RegulatoryApprovalDTO>(allData);

            return Json(new { data = result.ToList(), draw = Request.Form["draw"], recordsFiltered = totalFiltered, recordsTotal = total });
        }

        [HttpGet]
        public ActionResult GetFile(string path)
        {
            return File(path, "application/pdf");
        }

    }
}
