﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace E_LibraryPolicy.CustomAuth
{
    /// <summary>
    /// Atribut otorisasi user untuk keamanan User yang diakses pada Controller
    /// </summary>
    public class CustomAuthorizeAttribute : AuthorizeAttribute
    {
        /// <summary>
        /// Mengembalikan data User yang sedang menggnakan aplikasi/login
        /// </summary>
        protected virtual CustomPrincipal CurrentUser
        {
            get { return HttpContext.Current.User as CustomPrincipal; }
        }
        public bool IsAdminLibrary { get; set; }
        public bool IsAdminRegulatory { get; set; }

        /// <summary>
        /// Method AuthorizeCore, method inti dari otorisasi terhadap User untuk pengecekan apakah sebuah Username termasuk ke dalam salah satu Role
        /// </summary>
        /// <param name="httpContext">Parameter httpContext yang didapat dari browser</param>
        /// <returns>Return 'True' jika punya akses, 'False' jika tidak</returns>
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            if (CurrentUser == null)
                return false;

            if (IsAdminLibrary && IsAdminRegulatory)
                return CurrentUser.IsAdminRegulatory || CurrentUser.IsAdminLibrary;

            if (IsAdminLibrary)
                return CurrentUser.IsAdminLibrary;

            if (IsAdminRegulatory)
                return CurrentUser.IsAdminRegulatory;

            return (CurrentUser == null) ? false : true;
        }

        /// <summary>
        /// Method HandleUnauthorizedRequest, method handling untuk mengembalikan Login Error
        /// </summary>
        /// <param name="filterContext">Parameter filterContext yang didapat dari browser</param>
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            RedirectToRouteResult routeData = null;

            if (CurrentUser == null)
            //if (HttpContext.Current.User.Identity.Name == null)
            {
                routeData = new RedirectToRouteResult
                    (new System.Web.Routing.RouteValueDictionary
                    (new
                    {
                        //controller = "Error",
                        //action = "Unauthorized",
                        controller = "Account",
                        action = "Login",
                        ReturnUrl = filterContext.HttpContext.Request.Url
                    }
                    ));
            }
            else
            {
                routeData = new RedirectToRouteResult
                (new System.Web.Routing.RouteValueDictionary
                 (new
                 {
                     controller = "Account",
                     action = "Login",
                     ReturnUrl = filterContext.HttpContext.Request.Url
                 }
                 ));
            }

            filterContext.Result = routeData;
        }

    }
}