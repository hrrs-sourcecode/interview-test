﻿using E_LibraryPolicy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;

namespace E_LibraryPolicy.CustomAuth
{
    /// <summary>
    /// Objek-objek prinsip pada fungsional dasar keamanan login
    /// </summary>
    public class CustomPrincipal : IPrincipal
    {
        #region Identity Properties
        /// <summary>
        /// Propertis yang digunakan dalam identitas login User
        /// </summary>
        public string Username { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public string EmployeeNumber { get; set; }
        public int DepartmentID { get; set; }
        public bool IsAdminLibrary { get; set; }
        public bool IsAdminRegulatory { get; set; }
        public bool IsPIC { get; set; }
        public bool IsChief { get; set; }
        public bool IsVice { get; set; }

        #endregion

        /// <summary>
        /// Method Identity, definisi dari fungsi dasar identitas objek User
        /// </summary>
        public IIdentity Identity
        {
            get; private set;
        }

        /// <summary>
        /// Inisialisasi identitas baru yang merepresentasikan pengguna tertentu
        /// </summary>
        /// <param name="username"></param>
        public CustomPrincipal(string username)
        {
            Identity = new GenericIdentity(username);
        }

        public bool IsInRole(string role)
        {
            throw new NotImplementedException();
        }
    }
}