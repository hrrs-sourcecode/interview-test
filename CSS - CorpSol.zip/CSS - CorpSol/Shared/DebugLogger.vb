﻿Imports System.IO

Public Class DebugLogger

    Public Shared Sub WriteLog(ByVal msg As String)
        Dim folderPath As String = System.Web.Hosting.HostingEnvironment.MapPath("~/Logs")
        Dim pathLoc As String = String.Format("{0}\{1}\{2}\Log-{3}.txt", folderPath, DateTime.Now.ToString("yyyy"), DateTime.Now.ToString("MMMM"), DateTime.Now.ToString("yyyy-MM-dd"))
        Dim fileInfo As FileInfo = New FileInfo(pathLoc)
        fileInfo.Directory.Create()

        Using tw As StreamWriter = New StreamWriter(pathLoc, True)
            tw.WriteLine(msg)
        End Using
    End Sub

    Public Shared Sub WriteLogStamp(ByVal msg As String)
        Dim folderPath As String = System.Web.Hosting.HostingEnvironment.MapPath("~/Logs")
        Dim pathLoc As String = String.Format("{0}\{1}\{2}\Log-{3}.txt", folderPath, DateTime.Now.ToString("yyyy"), DateTime.Now.ToString("MMMM"), DateTime.Now.ToString("yyyy-MM-dd"))
        Dim fileInfo As FileInfo = New FileInfo(pathLoc)
        fileInfo.Directory.Create()

        Using tw As StreamWriter = New StreamWriter(pathLoc, True)
            Dim timeInfo As String = DateTime.Now().ToString("dd-MM-yyyy HH:mm:ss:fff ")
            tw.WriteLine(msg + " : has been hit on " + timeInfo)
        End Using
    End Sub

End Class
