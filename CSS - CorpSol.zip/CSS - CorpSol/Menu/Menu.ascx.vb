﻿Imports System.Data.SqlClient
Imports System.Reflection

Partial Public Class Menu
    Inherits System.Web.UI.UserControl
    Dim Modul As New ClassModul

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim ds As New DataSet()
        ds.Tables.Clear()
        xmlDataSource.Data = ds.GetXml()
        Dim SQL As String = "Select M.MenuID, M.Texts, M.Description, M.ParentID, M.Link " & _
                            "FROM Menu M " & _
                            "INNER JOIN Otorisasi b " & _
                            "ON M.MenuID=b.MenuID " & _
                            "AND M.AppID=b.AppID " & _
                            "Where b.AppID = '1' " & _
                            "AND b.UserID = '" & Session("UserID") & "' ORDER BY MenuID "
        Dim da As New SqlDataAdapter(SQL, Modul.SQLCn)
        da.Fill(ds)
        da.Dispose()
        ds.DataSetName = "Menus"
        ds.Tables(0).TableName = "Menu"
        Dim relation As New DataRelation("ParentChild", ds.Tables("Menu").Columns("MenuID"), ds.Tables("Menu").Columns("Parentid"), True)

        lblUser.Text = Left(Session("UserName"), 20)
        'Add Version @ Login Page
        Dim WebVersion As Assembly = Assembly.GetExecutingAssembly
        Dim WebName As AssemblyName = WebVersion.GetName
        lblVersion.Text = "Ver." & WebName.Version.ToString()

        relation.Nested = True
        ds.Relations.Add(relation)

        xmlDataSource.Data = ds.GetXml
        xmlDataSource.Dispose()
    End Sub

End Class