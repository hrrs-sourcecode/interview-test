﻿Imports System.DirectoryServices
Imports System.Reflection

Partial Public Class Login
    Inherits System.Web.UI.Page
    Dim Modul As New ClassModul
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtUser.Focus()
        Session("txtuser") = ""
        'Add Version @ Login Page
        Dim WebVersion As Assembly = Assembly.GetExecutingAssembly
        Dim WebName As AssemblyName = WebVersion.GetName
        lblVersion.Text = "Ver." & WebName.Version.ToString()
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim Domain As String = ""
        Dim domainAndUsername As String = ""


        Dim IP_dbs As String = Nothing
        Dim Flag_Login As String, Comp_Name As String = Nothing
        Flag_Login = Nothing

        Dim ldapConfig As String = ConfigurationManager.AppSettings("ldap").ToString

        Domain = ldapConfig

        domainAndUsername = "AXA-INDONESIA\" & txtUser.Text

        Dim entry As DirectoryEntry = New DirectoryEntry(Domain, domainAndUsername, txtPass.Text)

        Try
            Dim obj As Object = entry.NativeObject
            Dim search As DirectorySearcher = New DirectorySearcher(entry)
            Dim _path As String

            search.Filter = "(SAMAccountName=" & txtUser.Text & ")"
            search.PropertiesToLoad.Add("cn")
            search.PropertiesToLoad.Add("mail")

            Dim result As SearchResult = search.FindOne()

            If Not (result Is Nothing) Then
                _path = result.Path

                Session.Timeout = 120
                Session("UserID") = CType(result.Properties("cn")(0), String)
                Session("UserName") = CType(result.Properties("cn")(0), String)

                Response.Redirect("~/Menu/Header.aspx", False)
            End If

            Label1.Visible = False
        Catch ex As Exception
            Label1.Visible = True
            Label1.Text = ex.Message.ToString
        End Try

        
    End Sub

    
End Class