Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity.Spatial

<Table("Otorisasi")>
Partial Public Class Otorisasi
    <Key>
    Public Property OtoID As Integer

    Public Property AppID As Integer?

    Public Property MenuID As Integer?

    <StringLength(50)>
    Public Property UserID As String
End Class
