Imports System
Imports System.Data.Entity
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Linq

Partial Public Class ConSql
    Inherits DbContext

    Public Sub New()
        MyBase.New("name=ConSql")
    End Sub

    Public Overridable Property Mst_UserApp As DbSet(Of Mst_UserApp)
    Public Overridable Property mt_vLDAPUser As DbSet(Of mt_vLDAPUser)
    Public Overridable Property Tbl_EC As DbSet(Of Tbl_EC)
    Public Overridable Property Tbl_Premi As DbSet(Of Tbl_Premi)
    Public Overridable Property Menus As DbSet(Of Menu)
    Public Overridable Property Otorisasis As DbSet(Of Otorisasi)

    Protected Overrides Sub OnModelCreating(ByVal modelBuilder As DbModelBuilder)
        modelBuilder.Entity(Of Mst_UserApp)() _
            .Property(Function(e) e.dco_Name) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Mst_UserApp)() _
            .Property(Function(e) e.dco_Email) _
            .IsUnicode(False)

        modelBuilder.Entity(Of mt_vLDAPUser)() _
            .Property(Function(e) e.dco_Name) _
            .IsUnicode(False)

        modelBuilder.Entity(Of mt_vLDAPUser)() _
            .Property(Function(e) e.dco_Email) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.COMPANY_NAME) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.PIC_NAME) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.NO_PHONE_HP) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.EMAIL) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.ADDRESS) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.CLAIM_TYPE) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.CLAIM_NO) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.CLAIM_CLIENT_REF_NO) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.MEMBER_NO) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.MEMBER_NAME) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.PETIRNT_NO) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.PATIENT_NAME) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.INVOICE_DATE) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.NO_INVOICE) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.RECEIVED_DATE) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.PROVIDER) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.ADMISSION_DATE) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.DISCHARGE_DATE) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.TANGGAL_PENAGIHAN_EXCESS_1) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.TANGGAL_PENAGIHAN_EXCESS_2) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.TANGGAL_PENAGIHAN_EXCESS_3) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.TANGGAL_BAYAR_1) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.TANGGAL_BAYAR_2) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.TANGGAL_BAYAR_3) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.SEQ) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.REMARK_COLLECTION) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.REASON) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.STATUS) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.RCL) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.TANGGAL_PENGIRIMAN_HARDCOPY) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.TANGGAL_PROSES) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.TANGGAL_UPLOAD) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.UPLOADED_BY) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_EC)() _
            .Property(Function(e) e.USER) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.BILL_NO) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.NO_BILL_MANUAL) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.NO_TRANSAKSI) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.PAYMENT_MODE) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.ACCOUNT_NAME) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.PRODUCT) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.TYPE_OF_ENDORSMENT) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.RECEIPT) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.RCL) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.REMARK_COLLECTION) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.KETERANGAN) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.STATUS) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.REASON) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.UPLOADED_BY) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Tbl_Premi)() _
            .Property(Function(e) e.USER) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Menu)() _
            .Property(Function(e) e.Texts) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Menu)() _
            .Property(Function(e) e.Description) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Menu)() _
            .Property(Function(e) e.Link) _
            .IsUnicode(False)

        modelBuilder.Entity(Of Otorisasi)() _
            .Property(Function(e) e.UserID) _
            .IsUnicode(False)
    End Sub
End Class
