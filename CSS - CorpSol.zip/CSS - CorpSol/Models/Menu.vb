Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity.Spatial

<Table("Menu")>
Partial Public Class Menu
    <Key>
    <Column(Order:=0)>
    <DatabaseGenerated(DatabaseGeneratedOption.None)>
    Public Property NoID As Integer

    <Key>
    <Column(Order:=1)>
    <DatabaseGenerated(DatabaseGeneratedOption.None)>
    Public Property AppID As Integer

    <Key>
    <Column(Order:=2)>
    <DatabaseGenerated(DatabaseGeneratedOption.None)>
    Public Property MenuID As Integer

    <StringLength(50)>
    Public Property Texts As String

    <StringLength(255)>
    Public Property Description As String

    Public Property ParentID As Integer?

    <StringLength(50)>
    Public Property Link As String

    Public Property LinkID As Integer?
End Class
