Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity.Spatial

Partial Public Class Tbl_Premi
    <DatabaseGenerated(DatabaseGeneratedOption.Identity)>
    Public Property ID_Premi As Integer

    <Key>
    <StringLength(100)>
    Public Property BILL_NO As String

    <StringLength(100)>
    Public Property NO_BILL_MANUAL As String

    <StringLength(100)>
    Public Property NO_TRANSAKSI As String

    <StringLength(100)>
    Public Property PAYMENT_MODE As String

    Public Property PREMI_TAHUNAN As Double?

    Public Property POLICY_NUMBER As Integer?

    <StringLength(250)>
    Public Property ACCOUNT_NAME As String

    Public Property POLICY_EFFECTIVE_DATE As Date?

    <StringLength(100)>
    Public Property PRODUCT As String

    Public Property TOTAL_MEMBER As Integer?

    Public Property PREMIUM_AMOUNT As Double?

    Public Property ADDITION As Double?

    Public Property DELETION As Double?

    Public Property CHANGE_PLAN As Double?

    Public Property FEE_ASO As Double?

    Public Property ASO As Double?

    Public Property TOTAL_ASO As Double?

    Public Property BY_KARTU As Double?

    Public Property PAID As Double?

    Public Property OUTSTANDING As Double?

    Public Property ISSUE_DATE_SYSTEM As Date?

    Public Property INVOICE_DATE As Date?

    <StringLength(250)>
    Public Property TYPE_OF_ENDORSMENT As String

    Public Property TANGGAL_BAYAR_1 As Date?

    Public Property TANGGAL_BAYAR_2 As Date?

    Public Property TANGGAL_BAYAR_3 As Date?

    Public Property TANGGAL_INPUT_G400 As Date?

    <StringLength(100)>
    Public Property RECEIPT As String

    <StringLength(100)>
    Public Property RCL As String

    Public Property REMARK_COLLECTION As String

    Public Property KETERANGAN As String

    <StringLength(100)>
    Public Property STATUS As String

    Public Property TANGGAL_PENAGIHAN_PREMI_1 As Date?

    Public Property TANGGAL_PENAGIHAN_PREMI_2 As Date?

    Public Property TANGGAL_PENAGIHAN_PREMI_3 As Date?

    <StringLength(100)>
    Public Property REASON As String

    Public Property TANGGAL_PROSES As Date?

    Public Property TANGGAL_UPLOAD As Date?

    <StringLength(100)>
    Public Property UPLOADED_BY As String

    <StringLength(100)>
    Public Property USER As String
End Class
