Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity.Spatial

Partial Public Class Mst_UserApp
    <Key>
    <Column(Order:=0)>
    <StringLength(100)>
    Public Property dco_Name As String

    <Key>
    <Column(Order:=1)>
    <StringLength(100)>
    Public Property dco_Email As String
End Class
