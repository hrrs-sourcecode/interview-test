﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity.Spatial

Partial Public Class DataTables

    Public Property draw As Integer
    Public Property recordsTotal As Integer
    Public Property recordsFiltered As Integer

End Class
