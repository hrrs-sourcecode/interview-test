Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity.Spatial

Partial Public Class Tbl_EC
    <Key>
    Public Property ID_Excess As Integer

    Public Property POLICY_NO As Integer?

    <StringLength(250)>
    Public Property COMPANY_NAME As String

    <StringLength(100)>
    Public Property PIC_NAME As String

    <StringLength(100)>
    Public Property NO_PHONE_HP As String

    <StringLength(100)>
    Public Property EMAIL As String

    <StringLength(250)>
    Public Property ADDRESS As String

    <StringLength(100)>
    Public Property CLAIM_TYPE As String

    <StringLength(100)>
    Public Property CLAIM_NO As String

    <StringLength(100)>
    Public Property CLAIM_CLIENT_REF_NO As String

    <StringLength(100)>
    Public Property MEMBER_NO As String

    <StringLength(250)>
    Public Property MEMBER_NAME As String

    <StringLength(100)>
    Public Property PETIRNT_NO As String

    <StringLength(250)>
    Public Property PATIENT_NAME As String

    <StringLength(100)>
    Public Property INVOICE_DATE As String

    <StringLength(100)>
    Public Property NO_INVOICE As String

    <StringLength(100)>
    Public Property RECEIVED_DATE As String

    <StringLength(250)>
    Public Property PROVIDER As String

    <StringLength(100)>
    Public Property ADMISSION_DATE As String

    <StringLength(100)>
    Public Property DISCHARGE_DATE As String

    Public Property BIAYA_PERAWATAN As Double?

    Public Property YANG_DITANGGUNG As Double?

    Public Property TOTAL_EXCESS As Double?

    <StringLength(100)>
    Public Property TANGGAL_PENAGIHAN_EXCESS_1 As String

    <StringLength(100)>
    Public Property TANGGAL_PENAGIHAN_EXCESS_2 As String

    <StringLength(100)>
    Public Property TANGGAL_PENAGIHAN_EXCESS_3 As String

    <StringLength(100)>
    Public Property TANGGAL_BAYAR_1 As String

    <StringLength(100)>
    Public Property TANGGAL_BAYAR_2 As String

    <StringLength(100)>
    Public Property TANGGAL_BAYAR_3 As String

    <StringLength(250)>
    Public Property SEQ As String

    Public Property REMARK_COLLECTION As String

    Public Property PAID As Double?

    Public Property OUTSTANDING As Double?

    <StringLength(250)>
    Public Property REASON As String

    <StringLength(100)>
    Public Property STATUS As String

    <StringLength(100)>
    Public Property RCL As String

    <StringLength(100)>
    Public Property TANGGAL_PENGIRIMAN_HARDCOPY As String

    <StringLength(100)>
    Public Property TANGGAL_PROSES As String

    <StringLength(100)>
    Public Property TANGGAL_UPLOAD As String

    <StringLength(100)>
    Public Property UPLOADED_BY As String

    <StringLength(100)>
    Public Property USER As String
End Class
