﻿Imports System.Configuration
Imports System.Data.SqlClient

Public Class DeleteBase
    Inherits DataAccessBase

    Dim _connectionString As String = ConfigurationManager.ConnectionStrings("ConSql").ToString

#Region "Constanta"


#End Region

End Class
