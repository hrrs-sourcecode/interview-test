﻿Imports System.Configuration
Imports System.Data.SqlClient

Public Class SelectBase
    Inherits DataAccessBase



#Region "Constanta"

    
#End Region

    
End Class
