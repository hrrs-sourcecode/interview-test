﻿Imports System.Configuration
Imports System.Data.SqlClient

Public Class InsertBase
    Inherits DataAccessBase

    Dim _connectionString As String = ConfigurationManager.ConnectionStrings("ConSql").ToString

#Region "Constanta"

    Dim test As String = "sp_Insert_UserApp"
   
#End Region

    Public Function Insert_Userapp(ByVal _name As String, ByVal _email As String) As Integer

        Dim oParam(0) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@jobid", SqlDbType.Int)
        oParam(0).Value = CType(_name, String)

        oParam(0) = New SqlClient.SqlParameter("@jobid", SqlDbType.Int)
        oParam(0).Value = CType(_name, String)

        Return (ExecuteNonQuery(_connectionString, test, CommandType.StoredProcedure, oParam))

    End Function
    
End Class
