﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System
Imports System.Data.OleDb

Public Class UpdateBase
    Inherits DataAccessBase

    Dim _connectionString As String = ConfigurationManager.ConnectionStrings("ConSql").ToString

#Region "Constanta"

    Public Const sp_UPLOADDATAFROMBM As String = "sp_FREEPA_UPLOADDATAFROMBM"
    Public Const sp_UPLOADDATAFROMBM_NO As String = "sp_FREEPA_UPLOADDATAFROMBM_NO"

    Public Const sp_UPLOADDATAFROMBM_YES As String = "sp_FREEPA_UPLOADDATAFROMBM_YES"

    Public Const sp_FREEPA_PA_UPDATE_DOB_EMAIL As String = "sp_FREEPA_PA_UPDATE_DOB_EMAIL"

    Public Const sp_FREEPA_PA_UPLOAD_DATA_CANCELLED As String = "sp_FREEPA_UPLOAD_DATA_CANCELLED"
#End Region

    Public Function UploadFromBM(ByVal _CIF As String, ByVal _accountno As String, ByVal _status As String) As DataTable
        Dim oParam(2) As SqlParameter
        Dim prmoutput As String = ""

        oParam(0) = New SqlClient.SqlParameter("@CIF", SqlDbType.VarChar)
        oParam(0).Value = CType(_CIF, String)

        oParam(1) = New SqlClient.SqlParameter("@AccountNo", SqlDbType.VarChar)
        oParam(1).Value = CType(_accountno, String)

        oParam(2) = New SqlClient.SqlParameter("@Status", SqlDbType.VarChar)
        oParam(2).Value = CType(_status, String)

        Return FillDataset(_connectionString, sp_UPLOADDATAFROMBM, CommandType.StoredProcedure, oParam)

    End Function

    Public Function UploadFromBM_No(ByVal _CIF As String, ByVal _accountno As String, ByVal _status As String) As DataTable
        Dim oParam(2) As SqlParameter
        Dim prmoutput As String = ""

        oParam(0) = New SqlClient.SqlParameter("@CIF", SqlDbType.VarChar)
        oParam(0).Value = CType(_CIF, String)

        oParam(1) = New SqlClient.SqlParameter("@AccountNo", SqlDbType.VarChar)
        oParam(1).Value = CType(_accountno, String)

        oParam(2) = New SqlClient.SqlParameter("@Status", SqlDbType.VarChar)
        oParam(2).Value = CType(_status, String)

        Return FillDataset(_connectionString, sp_UPLOADDATAFROMBM_NO, CommandType.StoredProcedure, oParam)

    End Function

    Public Function UploadfromBMwithOutput(ByVal _CIF As String, ByVal _nameholder As String, ByVal _dobholder As String, ByVal _accountno As String, ByVal _status As String)
        Dim myConnection As New SqlConnection(_connectionString)
        Dim myCommand As New SqlCommand()
        Dim myReader As SqlDataReader

        myCommand.CommandType = CommandType.StoredProcedure
        myCommand.Connection = myConnection
        myCommand.CommandText = sp_UPLOADDATAFROMBM

        myCommand.Parameters.AddWithValue("@CIF", _CIF)
        myCommand.Parameters.AddWithValue("@NameHolder", _nameholder)
        myCommand.Parameters.AddWithValue("@DOBHolder", _dobholder)
        myCommand.Parameters.AddWithValue("@AccountNo", _accountno)
        myCommand.Parameters.AddWithValue("@Status", _status)

        myCommand.Parameters.Add("@prmMessage", SqlDbType.VarChar)
        myCommand.Parameters("@prmMessage").Direction = ParameterDirection.Output
        myCommand.Parameters("@prmMessage").Size = 100

        Try
            myConnection.Open()
            myReader = myCommand.ExecuteReader()

            'Uncomment this line to return proper output value.
            'myReader.Close()
            Return myCommand.Parameters("@prmMessage").Value

        Catch ex As Exception
            Return ""
        Finally
            myConnection.Close()
        End Try

    End Function

    Public Function Update_PA(ByVal AppNo As String, ByVal DOB As String, ByVal Email As String) As Integer
        'Dede add for updating DOB and Email PA
        Dim oParam(2) As SqlParameter
        Dim prmoutput As String = ""

        oParam(0) = New SqlClient.SqlParameter("@appno", SqlDbType.VarChar)
        oParam(0).Value = CType(AppNo, String)

        oParam(1) = New SqlClient.SqlParameter("@dob", SqlDbType.VarChar)
        oParam(1).Value = CType(DOB, String)

        oParam(2) = New SqlClient.SqlParameter("@email", SqlDbType.VarChar)
        oParam(2).Value = CType(Email, String)

        Return ExecuteNonQuery(_connectionString, sp_FREEPA_PA_UPDATE_DOB_EMAIL, CommandType.StoredProcedure, oParam)

    End Function
    Public Function Update_Data_Cancelled(ByVal AppNo As String) As Integer
        'Dede add for updating DOB and Email PA
        Dim oParam(0) As SqlParameter
        Dim prmoutput As String = ""

        oParam(0) = New SqlClient.SqlParameter("@appno", SqlDbType.VarChar)
        oParam(0).Value = CType(AppNo, String)

        Return ExecuteNonQuery(_connectionString, sp_FREEPA_PA_UPLOAD_DATA_CANCELLED, CommandType.StoredProcedure, oParam)

    End Function


End Class
