﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices

Partial Public Class UploadException
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim dr As SqlDataReader

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            DropFill_Type()
            DropFill_PolisType()
            BindGrid("", "", "")
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            'DropFill_Type()

        End If
    End Sub
    Public Sub DropFill_Type()
        Dim ListTemp As ListItem

        drp_type.Items.Clear()
        ddltypes.Items.Clear()
        ListTemp = New ListItem("-- Choose --", "")
        drp_type.Items.Add(ListTemp)
        ddltypes.Items.Add(ListTemp)

        SQL = "SELECT TYPEID,UPPER(TYPENAME) FROM Mst_Type where TYPENAME NOT IN ('Polis Reimburse','Polis Provider')"

        dr = Modul.getAllDatainDR(SQL)

        While dr.Read
            ListTemp = New ListItem(dr(1), dr(0))
            drp_type.Items.Add(ListTemp)
            ddltypes.Items.Add(ListTemp)
        End While

        dr.Close()
        Modul.SQLCn.Close()

    End Sub
    Public Sub DropFill_PolisType()
        Dim ListTemp As ListItem

        ddl_PolisType.Items.Clear()
        ListTemp = New ListItem("-- Choose --", "")
        ddl_PolisType.Items.Add(ListTemp)

        SQL = "SELECT TYPEID,UPPER(TYPENAME) FROM Mst_Type where TYPENAME NOT IN ('Member','Polis')"

        dr = Modul.getAllDatainDR(SQL)

        While dr.Read
            ListTemp = New ListItem(dr(1), dr(0))
            ddl_PolisType.Items.Add(ListTemp)
        End While

        dr.Close()
        Modul.SQLCn.Close()

    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
        txtClientKey.Text = ""
        txtLSurname.Text = ""
        txtReason.Text = ""
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSave.Click
        Try
            Dim _clientKey As String = ""
            Dim _LSurname As String = ""
            Dim _Type As String = ""
            Dim _PolisType As String = ""
            Dim _Reason As String = ""
            'Dim _Mydate As Date

            _clientKey = Trim(txtClientKey.Text.ToUpper)
            _LSurname = Trim(txtLSurname.Text.ToUpper)
            _Type = Trim(drp_type.SelectedValue.ToUpper)
            _PolisType = Trim(ddl_PolisType.SelectedValue.ToUpper)

            If _Type = "PS" Then
                _Type = _PolisType
            End If

            _Reason = Trim(txtReason.Text.ToUpper)

            If ValidasiData(Trim(drp_type.SelectedValue.ToUpper)) = "Success" Then

                Dim dt_check_CLMNUM As New DataTable
                SQL = "SELECT * FROM Mst_EXPayment " & _
                      "WHERE [CLIENT KEY] LIKE '%" & _clientKey & "%' AND [SURNAME] LIKE '%" & _LSurname & "%' AND UPPER(TYPE) LIKE '%" & _Type & "%' AND STATUS='0'"

                dt_check_CLMNUM = Modul.getAllDatainDT(SQL)

                If dt_check_CLMNUM.Rows.Count > 0 Then
                    SQL = "Update Mst_EXPayment set Status=1,USERID='" & Session("username") & "',DATETIME='" & Date.Now.ToString("yyyy-MM-dd HH:mm:ss") & "'," & _
                          "Reason='" & _Reason & "'  where [Client Key]='" & _clientKey & "' "
                Else
                    SQL = "INSERT INTO Mst_EXPayment values('" & _clientKey & "','" & _LSurname & "','" & _Type & "','" & _Reason & "','1','" & Session("username") & "','" & Date.Now.ToString("yyyy-MM-dd HH:mm:ss") & "') "
                End If

                Modul.Eksekusi(SQL)
                lblWarning.Visible = False
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Save Data Sukses'); window.location='UploadException.aspx';", True)
            Else
                lblWarning.Visible = True
                lblWarning.Text = ValidasiData(Trim(drp_type.SelectedValue.ToUpper))
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub

    Protected Sub txtClientKey_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtClientKey.TextChanged
        Try
            SQL = "SELECT LSURNAME FROM CLNTPF WHERE CLNTNUM='" & Trim(txtClientKey.Text.ToUpper) & "'"

            Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
            Modul.SQLAdp.Fill(Dt)

            If Dt.Rows.Count > 0 Then
                txtLSurname.Text = Dt.Rows(0)("LSURNAME")
            Else
                txtLSurname.Text = ""
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try

    End Sub
    Public Sub BindGrid(ByVal CLNUM As String, ByVal SURNAME As String, ByVal Type As String)
        SQL = "SELECT [CLIENT KEY] as [CLIENT NUMBER],SURNAME,UPPER(T.TYPENAME) AS TYPE, REASON FROM Mst_EXPayment E INNER JOIN Mst_Type T ON E.TYPE=T.TYPEID " & _
              "WHERE [CLIENT KEY] LIKE '%" & CLNUM & "%' AND [SURNAME] LIKE '%" & SURNAME & "%' AND UPPER(T.TYPEID) LIKE '%" & Type & "%' AND STATUS='1'"

        Modul.SubBindGridView(SQL, GridException)
    End Sub
    Public Function ValidasiData(ByVal Typename As String)
        Dim dt_Count As New System.Data.DataTable
        Dim result As String = ""

        If Typename = "R" Then
            SQL = "SELECT * FROM PROGPF WHERE PROVORG='" & Trim(txtClientKey.Text.ToUpper) & "' "
            dt_Count = Modul.getAllDatainDT(SQL)

            If dt_Count.Rows.Count > 0 Then
                result = "Success"
            Else
                result = "Invalid Provider Number !!!"
            End If
        ElseIf Typename = "M" Then
            SQL = "SELECT * FROM GMHDPF WHERE CLNTNUM='" & Trim(txtClientKey.Text.ToUpper) & "' "
            dt_Count = Modul.getAllDatainDT(SQL)

            If dt_Count.Rows.Count > 0 Then
                result = "Success"
            Else
                result = "Invalid Member Number !!!"
            End If
        ElseIf Typename = "PS" Then
            SQL = "SELECT * FROM CHDRPF WHERE COWNNUM='" & Trim(txtClientKey.Text.ToUpper) & "' "
            dt_Count = Modul.getAllDatainDT(SQL)

            If dt_Count.Rows.Count > 0 Then
                result = "Success"
            Else
                result = "Invalid Polis Number !!!"
            End If
        Else
            result = "Please choose type of claim !!!"
        End If

        dt_Count.Clear()
        dt_Count.Dispose()
        Return result

    End Function

    Private Sub GridException_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridException.PageIndexChanging
        GridException.PageIndex = e.NewPageIndex
        BindGrid(txtCLNUMBER.Text.Trim, txtsrname.Text.Trim, ddltypes.SelectedValue)
    End Sub

    Private Sub GridException_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridException.PreRender
        If Me.GridException.EditIndex <> -1 Then
            Dim txtCLIENTNUMBER As TextBox = DirectCast(GridException.Rows(GridException.EditIndex).FindControl("txtCLIENTNUMBER"), TextBox)
            Dim txtSURNAME As TextBox = DirectCast(GridException.Rows(GridException.EditIndex).FindControl("txtSURNAME"), TextBox)
            Dim txtTYPE As TextBox = DirectCast(GridException.Rows(GridException.EditIndex).FindControl("txtTYPE"), TextBox)

            If txtCLIENTNUMBER IsNot Nothing Then
                txtCLIENTNUMBER.Enabled = False
            End If
            If txtSURNAME IsNot Nothing Then
                txtSURNAME.Enabled = False
            End If
            If txtTYPE IsNot Nothing Then
                txtTYPE.Enabled = False
            End If
            
        End If
    End Sub

    Private Sub GridException_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridException.RowCancelingEdit
        GridException.EditIndex = -1
        BindGrid(txtCLNUMBER.Text.Trim, txtsrname.Text.Trim, ddltypes.SelectedValue)
    End Sub

    Private Sub GridException_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridException.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim ProductID As String = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "CLIENT NUMBER"))
            Dim lnkbtnresult As Button = DirectCast(e.Row.FindControl("ButtonDelete"), Button)
            If lnkbtnresult IsNot Nothing Then
                lnkbtnresult.Attributes.Add("onclick", (Convert.ToString("javascript:return deleteConfirm('") & ProductID) + "')")
            End If
        End If
    End Sub

    Private Sub GridException_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridException.RowDeleting
        Dim CLIENTNUMBER As String = GridException.DataKeys(e.RowIndex).Values("CLIENT NUMBER").ToString()

        SQL = ""

        SQL = "Update Mst_EXPayment set Status=0,USERID='" & Session("username") & "',DATETIME='" & Date.Now.ToString("yyyy-MM-dd HH:mm:ss") & "'  where [Client Key]='" & CLIENTNUMBER & "'"
        If SQL <> "" Then
            Try
                Modul.Eksekusi(SQL)
                Modul.UserMsgBox(Me, "Deleted Complete !!")
                BindGrid(txtCLNUMBER.Text.Trim, txtsrname.Text.Trim, ddltypes.SelectedValue)

            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try
        End If
    End Sub

    Private Sub GridException_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridException.RowEditing
        GridException.EditIndex = e.NewEditIndex
        BindGrid(txtCLNUMBER.Text.Trim, txtsrname.Text.Trim, ddltypes.SelectedValue)
    End Sub

    Private Sub GridException_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridException.RowUpdating
        Dim txtCLIENTNUMBER As TextBox = DirectCast(GridException.Rows(GridException.EditIndex).FindControl("txtCLIENTNUMBER"), TextBox)
        Dim txtSURNAME As TextBox = DirectCast(GridException.Rows(GridException.EditIndex).FindControl("txtSURNAME"), TextBox)
        Dim Reason As TextBox = DirectCast(GridException.Rows(e.RowIndex).FindControl("txtREASON"), TextBox)

        SQL = ""

        SQL = "Update Mst_EXPayment set Reason='" & Reason.Text.ToUpper & "'  where [Client Key]='" & txtCLIENTNUMBER.Text & "' AND Surname='" & txtSURNAME.Text & "'"
        If SQL <> "" Then
            Try
                Modul.Eksekusi(SQL)
                Modul.UserMsgBox(Me, "Updated Complete")
                GridException.EditIndex = -1
                BindGrid(txtCLNUMBER.Text.Trim, txtsrname.Text.Trim, ddltypes.SelectedValue)

            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try
        End If
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click
        BindGrid(txtCLNUMBER.Text.Trim, txtsrname.Text.Trim, ddltypes.SelectedValue)
    End Sub

    Protected Sub GridException_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridException.SelectedIndexChanged

    End Sub

    Protected Sub drp_type_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles drp_type.SelectedIndexChanged
        If drp_type.SelectedItem.ToString = "POLIS" Then
            ddl_PolisType.Visible = True
        Else
            ddl_PolisType.Visible = False
        End If
    End Sub
End Class