﻿Imports System.Data
Imports System.Data.SqlClient

Partial Public Class EditDataPremi
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim dr As SqlDataReader
    Dim oUpdate As New UpdateBase
    Dim oSelect As New SelectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            BindGrid("", "", "", "", "", "UNPAID")
            trInfoDetail.Visible = False
            trDetail.Visible = False

        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            BindGrid(txtBILLNO.Text, txtNoBillManual.Text, txtPolis.Text, txtACCOUNTNAME.Text, txtRECEIPT.Text, ddl_STATUS.SelectedValue.Trim)
            trInfoDetail.Visible = False
            trDetail.Visible = False
        End If

    End Sub
    Public Sub BindGrid(ByVal BILLNO As String, ByVal NOBILLMANUAL As String, ByVal POLIS As String, ByVal ACCOUNTNAME As String, ByVal RECEIPT As String, ByVal STATUS As String)
        Try

            SQL = "SELECT CASE WHEN BILL_NO IS NULL THEN NO_BILL_MANUAL WHEN BILL_NO = '' THEN NO_BILL_MANUAL ELSE BILL_NO END AS BILL_NO,NO_BILL_MANUAL," & _
                  "POLICY_NUMBER,CONVERT(VARCHAR, CAST(PAID AS MONEY), 1) AS PAID,CASE WHEN (ADDITION + DELETION + [CHANGE PLAN] + BY_KARTU) = 0 AND (FEE_ASO + ASO) = 0 THEN " & _
                  "'0' ELSE CONVERT(VARCHAR,CAST(ROUND(((ADDITION + DELETION + [CHANGE PLAN] + BY_KARTU) + (FEE_ASO + ASO)) - PAID,-1) AS MONEY),1) END AS OUTSTANDING," & _
                  "STATUS,CONVERT(VARCHAR(10),TGL_PROSES,111) as TGL_PROSES2,CONVERT(VARCHAR(10),TGL_BAYAR,111) as TGL_BAYAR2, " & _
                  "RECEIPT,CONVERT(VARCHAR(10),TGL_PENAGIHAN_PREMI,111) as TGL_PENAGIHAN_PREMI21,CONVERT(VARCHAR(10),TGL_PENAGIHAN_PREMI2,111) as TGL_PENAGIHAN_PREMI22, " & _
                  "CONVERT(VARCHAR(10),TGL_PENAGIHAN_PREMI3,111) as TGL_PENAGIHAN_PREMI32,CONVERT(VARCHAR(10),TGL_UPLOAD,111) as TGL_UPLOAD2 " & _
                  "FROM tbl_premi WHERE BILL_NO LIKE '%" & BILLNO & "%' AND NO_BILL_MANUAL LIKE '%" & NOBILLMANUAL & "%' AND POLICY_NUMBER LIKE '%" & POLIS & "%' " & _
                  "AND ACCOUNT_NAME LIKE '%" & ACCOUNTNAME & "%' AND RECEIPT LIKE '%" & RECEIPT & "%'" & _
                  "AND STATUS = '" & STATUS & "' ORDER BY TGL_UPLOAD DESC"
            Modul.SubBindGridView(SQL, GridPremi)

            

            If GridPremi.Rows.Count = 0 Then
                trInfoDetail.Visible = False
                trDetail.Visible = False

                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
               "alert('Data Tidak Ditemukan.');;", True)
            Else
                ViewState("varStatus") = STATUS
                ShowHideColumns()
            End If


            Dim dt_Count As New System.Data.DataTable
            SQL = "SELECT COUNT(*) " & _
                  "FROM tbl_premi WHERE BILL_NO LIKE '%" & BILLNO & "%' AND POLICY_NUMBER LIKE '%" & POLIS & "%' " & _
                  "AND ACCOUNT_NAME LIKE '%" & ACCOUNTNAME & "%' AND RECEIPT LIKE '%" & RECEIPT & "%'" & _
                  "AND STATUS = '" & STATUS & "'"
            dt_Count = Modul.getAllDatainDT(SQL)

            lblTotalData.Text = "Total Data = " & dt_Count.Rows(0)(0).ToString().Trim & " data"

        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub
    Protected Sub GridPremi_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridPremi.RowDataBound

        Dim paid As Decimal = 0
        Dim outstanding As Decimal = 0


        For Each gvRow As GridViewRow In GridPremi.Rows

            If gvRow.RowType = DataControlRowType.DataRow Then
                paid += Convert.ToDecimal(gvRow.Cells(3).Text)
                outstanding += Convert.ToDecimal(gvRow.Cells(4).Text)
            End If

        Next

        ViewState("totalPaid") = Math.Round(paid, 0).ToString()
        ViewState("totalOutstanding") = Math.Round(outstanding, 0).ToString()

    End Sub
    Private Sub GridPremi_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridPremi.PageIndexChanging
        GridPremi.PageIndex = e.NewPageIndex
        BindGrid(txtBILLNO.Text, txtNoBillManual.Text, txtPolis.Text, txtACCOUNTNAME.Text, txtRECEIPT.Text, ddl_STATUS.SelectedValue.Trim)

        ' Show Hide Column
        ShowHideColumns()
    End Sub
    Private Sub ShowHideColumns()



        Dim totalPaid As String = "0"
        Dim totalOutstanding As String = "0"

        totalPaid = ViewState("totalPaid").ToString()
        totalOutstanding = ViewState("totalOutstanding").ToString()

        If (ViewState("varStatus") IsNot Nothing) Then

            Dim status As String = ViewState("varStatus").ToString()


            If status = "PAID" Then

                'If totalPaid > 0 Then
                '    GridPremi.Columns(3).Visible = True
                'Else
                '    GridPremi.HeaderRow.Cells(3).Visible = False

                '    For Each gvr As GridViewRow In GridPremi.Rows
                '        gvr.Cells(3).Visible = False
                '    Next

                'End If

                GridPremi.HeaderRow.Cells(4).Visible = False

                For Each gvr As GridViewRow In GridPremi.Rows
                    gvr.Cells(4).Visible = False
                Next

            Else

                'If totalOutstanding > 0 Then
                '    GridPremi.Columns(4).Visible = True
                'Else
                '    GridPremi.HeaderRow.Cells(4).Visible = False

                '    For Each gvr As GridViewRow In GridPremi.Rows
                '        gvr.Cells(4).Visible = False
                '    Next

                'End If

                GridPremi.HeaderRow.Cells(3).Visible = False

                For Each gvr As GridViewRow In GridPremi.Rows
                    gvr.Cells(3).Visible = False
                Next

            End If


            ViewState("varStatus") = Nothing

        End If

    End Sub
    Private Sub GridPremi_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridPremi.RowCommand
        Try
            If e.CommandName = "SelectHeader" Then

                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = GridPremi.Rows(index)
                Dim myLinkButton As LinkButton
                myLinkButton = selectedRow.Cells(0).Controls(0)

                Dt = oSelect.sp_get_detail_premi(myLinkButton.Text)

                Modul.ShowFocus(Me, trDetail)

                If Dt.Rows.Count > 0 Then

                    txtBillNoDetail.Text = Dt.Rows(0)("BILL_NO").ToString
                    Session("BILL_NO") = Dt.Rows(0)("BILL_NO").ToString
                    txtBillManual.Text = Dt.Rows(0)("NO_BILL_MANUAL").ToString
                    txtPOLICYNODetail.Text = Dt.Rows(0)("POLICY_NUMBER").ToString
                    txtEffectiveDate.Text = Dt.Rows(0)("POLICY_EFFECTIVE_DATE2").ToString
                    txtProduct.Text = Dt.Rows(0)("PRODUCT").ToString
                    txtPaymentMode.Text = Dt.Rows(0)("PAYMENT_MODE").ToString
                    txtTotalMember.Text = Convert.ToDecimal(Dt.Rows(0)("TOTAL_MEMBER")).ToString("#,##0.")
                    txtPaid.Text = Convert.ToDecimal(Dt.Rows(0)("PAID")).ToString("#,##0.")
                    ddl_Status_Detail.Text = Dt.Rows(0)("STATUS").ToString
                    txtTanggalProses.Text = Dt.Rows(0)("TGL_PROSES2").ToString
                    txtTanggalBayar.Text = Dt.Rows(0)("TGL_BAYAR").ToString
                    txtTanggalBayar2.Text = Dt.Rows(0)("TGL_BAYAR2").ToString
                    txtTanggalBayar3.Text = Dt.Rows(0)("TGL_BAYAR3").ToString
                    txtReceipt_Detail.Text = Dt.Rows(0)("RECEIPT").ToString
                    txtTanggalPenagihan.Text = Dt.Rows(0)("TGL_PENAGIHAN_PREMI2").ToString
                    txtTanggalPenagihan2.Text = Dt.Rows(0)("TGL_PENAGIHAN_PREMI22").ToString
                    txtTanggalPenagihan3.Text = Dt.Rows(0)("TGL_PENAGIHAN_PREMI32").ToString
                    txtFeeASO.Text = Convert.ToDecimal(Dt.Rows(0)("FEE_ASO")).ToString("#,##0.")
                    txtASO.Text = Convert.ToDecimal(Dt.Rows(0)("ASO")).ToString("#,##0.")
                    txtAccountNameDetail.Text = Dt.Rows(0)("ACCOUNT_NAME").ToString
                    txtBiayaKartu.Text = Convert.ToDecimal(Dt.Rows(0)("BY_KARTU")).ToString("#,##0.")
                    txtNoTransaksi.Text = Dt.Rows(0)("NO_TRANSAKSI").ToString
                    txtPremiumAmount.Text = Convert.ToDecimal(Dt.Rows(0)("PREMIUM_AMOUNT")).ToString("#,##0.")
                    txtAddition.Text = Convert.ToDecimal(Dt.Rows(0)("ADDITION")).ToString("#,##0.")
                    txtDeletion.Text = Convert.ToDecimal(Dt.Rows(0)("DELETION")).ToString("#,##0.")
                    txtChangePlan.Text = Convert.ToDecimal(Dt.Rows(0)("CHANGE PLAN")).ToString("#,##0.")
                    txtEndorsment.Text = Dt.Rows(0)("TYPE_OF_ENDORSMENT").ToString
                    txtIssueDate.Text = Dt.Rows(0)("ISSUE_DATE (SYSTEM)2").ToString
                    txtTanggalUpload.Text = Dt.Rows(0)("TGL_UPLOAD2").ToString
                    ddl_Reason.Text = Dt.Rows(0)("Reason").ToString

                    txtRemarkCollection.Text = Dt.Rows(0)("REMARK_COLLECTION").ToString
                    txtTotalASO.Text = Convert.ToDecimal(Val(Dt.Rows(0)("FEE_ASO").ToString) + Val(Dt.Rows(0)("ASO").ToString)).ToString("#,##0.")

                    'If txtPremiumAmount.Text = 0 And txtTotalASO.Text = 0 And txtBiayaKartu.Text = 0 Then
                    '    txtOutstanding.Text = 0
                    'ElseIf txtPremiumAmount.Text <> 0 Then
                    '    txtOutstanding.Text = Convert.ToDecimal(Val(Dt.Rows(0)("PREMIUM_AMOUNT"))).ToString("#,##0.")
                    'ElseIf txtTotalASO.Text <> 0 Then
                    '    txtOutstanding.Text = Convert.ToDecimal(Val(Replace(txtTotalASO.Text, ",", ""))).ToString("#,##0.")
                    'ElseIf txtBiayaKartu.Text <> 0 Then
                    '    txtOutstanding.Text = Convert.ToDecimal(Val(Dt.Rows(0)("BY_KARTU"))).ToString("#,##0.")
                    'End If

                    txtOutstanding.Text = Convert.ToDecimal(Dt.Rows(0)("OUTSTANDING")).ToString("#,##0.")
                    txtNoRCL.Text = Dt.Rows(0)("RCL").ToString
                    txtUser.Text = Dt.Rows(0)("User").ToString

                    ' NEW 2020/12/23 - INVOICE_DATE, PREMI_TAHUNAN
                    txtInvoiceDate.Text = Dt.Rows(0)("INVOICE_DATE").ToString
                    txtPremiTahunan.Text = Convert.ToDecimal(Dt.Rows(0)("PREMI_TAHUNAN")).ToString("#,##0.")

                    trInfoDetail.Visible = True
                    trDetail.Visible = True


                    ' Show Hide Column
                    ShowHideColumns()
                End If
            End If
        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            Throw (ex)
        End Try

    End Sub


    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click

    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        Dim vBILL_NO As String
        Dim vBILL_NO_OLD As String
        Dim vNO_BILL_MANUAL As String
        Dim vPOLICY_NUMBER As String
        Dim vPOLICY_EFFECTIVE_DATE As String
        Dim vPRODUCT As String
        Dim vPAYMENT_MODE As String
        Dim vTOTAL_MEMBER As String
        Dim vPAID As String
        Dim vSTATUS As String
        Dim vTGL_PROSES As String
        Dim vTGL_BAYAR As String
        Dim vTGL_BAYAR2 As String
        Dim vTGL_BAYAR3 As String
        Dim vRECEIPT As String
        Dim vTGL_PENAGIHAN_PREMI As String
        Dim vTGL_PENAGIHAN_PREMI2 As String
        Dim vTGL_PENAGIHAN_PREMI3 As String
        Dim vFEE_ASO As String
        Dim vASO As String
        Dim vACCOUNT_NAME As String
        Dim vBY_KARTU As String
        Dim vNO_TRANSAKSI As String
        Dim vPREMIUM_AMOUNT As String
        Dim vADDITION As String
        Dim vDELETION As String
        Dim vCHANGE_PLAN As String
        Dim vTYPE_OF_ENDORSMENT As String
        Dim vISSUE_DATE As String
        Dim vTGL_UPLOAD As String
        Dim vReason As String
        Dim vREMARK_COLLECTION As String
        Dim vOUTSTANDING As String = ""
        Dim vTOTAL_ASO As String = ""
        Dim vRCL As String
        Dim vUSER As String
        Dim query As String = ""
        Dim dt_check As New DataTable
        Dim vINVOICE_DATE As String


        Try
            vBILL_NO = txtBillNoDetail.Text
            vBILL_NO_OLD = Session("BILL_NO").ToString
            vNO_BILL_MANUAL = txtBillManual.Text
            vPOLICY_NUMBER = txtPOLICYNODetail.Text
            vPOLICY_EFFECTIVE_DATE = txtEffectiveDate.Text
            vPRODUCT = txtProduct.Text
            vPAYMENT_MODE = txtPaymentMode.Text
            vTOTAL_MEMBER = txtTotalMember.Text
            vPAID = Replace(txtPaid.Text, ",", "")
            vSTATUS = ddl_Status_Detail.Text
            vTGL_PROSES = txtTanggalProses.Text
            vTGL_BAYAR = txtTanggalBayar.Text
            vTGL_BAYAR2 = txtTanggalBayar2.Text
            vTGL_BAYAR3 = txtTanggalBayar3.Text
            vRECEIPT = txtReceipt_Detail.Text
            vTGL_PENAGIHAN_PREMI = txtTanggalPenagihan.Text
            vTGL_PENAGIHAN_PREMI2 = txtTanggalPenagihan2.Text
            vTGL_PENAGIHAN_PREMI3 = txtTanggalPenagihan3.Text
            vFEE_ASO = Replace(txtFeeASO.Text, ",", "")
            vASO = Replace(txtASO.Text, ",", "")
            vACCOUNT_NAME = txtAccountNameDetail.Text
            vBY_KARTU = Replace(txtBiayaKartu.Text, ",", "")
            vNO_TRANSAKSI = txtNoTransaksi.Text
            vPREMIUM_AMOUNT = Val(Replace(txtAddition.Text, ",", "")) + Val(Replace(txtDeletion.Text, ",", "")) + Val(Replace(txtChangePlan.Text, ",", ""))
            vTOTAL_ASO = Val(Replace(txtASO.Text, ",", "")) + Val(Replace(txtFeeASO.Text, ",", ""))
            vADDITION = Replace(txtAddition.Text, ",", "")
            vDELETION = Replace(txtDeletion.Text, ",", "")
            vCHANGE_PLAN = Replace(txtChangePlan.Text, ",", "")
            vTYPE_OF_ENDORSMENT = txtEndorsment.Text
            vISSUE_DATE = txtIssueDate.Text
            vTGL_UPLOAD = txtTanggalUpload.Text
            vReason = ddl_Reason.Text
            vREMARK_COLLECTION = txtRemarkCollection.Text

            ' NEW 2020/12/23 - INVOICE_DATE
            vINVOICE_DATE = IIf(txtInvoiceDate.Text.Trim.Length = 0, "", txtInvoiceDate.Text.Trim)

            If vPREMIUM_AMOUNT <> 0 Then
                vOUTSTANDING = Val(Replace(vPREMIUM_AMOUNT, ",", "")) - Val(Replace(vPAID, ",", ""))
            ElseIf vTOTAL_ASO <> 0 Then
                vOUTSTANDING = Val(Replace(txtTotalASO.Text, ",", "")) - Val(Replace(vPAID, ",", ""))
            ElseIf vBY_KARTU <> 0 Then
                vOUTSTANDING = Val(Replace(vBY_KARTU, ",", "")) - Val(Replace(vPAID, ",", ""))
            Else
                vOUTSTANDING = 0
            End If

            vRCL = txtNoRCL.Text

            vUSER = UCase(txtUser.Text)

            If vBILL_NO <> vBILL_NO_OLD Then
                dt_check = oSelect.sp_get_detail_premi(vBILL_NO)

                If dt_check.Rows.Count > 0 Then
                    Modul.UserMsgBox(Me, "Duplicate BILL NO !!!")
                Else
                    oUpdate.f_Update_Data_premi(vBILL_NO, vNO_BILL_MANUAL, vNO_TRANSAKSI, vPAYMENT_MODE, vPOLICY_NUMBER, vACCOUNT_NAME,
                                            vPOLICY_EFFECTIVE_DATE, vPRODUCT, vTOTAL_MEMBER, vPREMIUM_AMOUNT, vADDITION, vDELETION, vCHANGE_PLAN,
                                            vFEE_ASO, vASO, vBY_KARTU, vPAID, vOUTSTANDING, vISSUE_DATE, vTYPE_OF_ENDORSMENT, vTGL_BAYAR, vRECEIPT, vRCL, vREMARK_COLLECTION,
                                            vSTATUS, vTGL_PENAGIHAN_PREMI, vTGL_PENAGIHAN_PREMI2, vTGL_PENAGIHAN_PREMI3, vTGL_UPLOAD, vReason, vTGL_PROSES, vTGL_BAYAR2, vTGL_BAYAR3, vUSER, vBILL_NO_OLD,
                    vINVOICE_DATE
                    )

                    trInfoDetail.Visible = False
                    trDetail.Visible = False

                    Modul.UserMsgBox(Me, "Save Completed !!")
                End If

            Else
                oUpdate.f_Update_Data_premi(vBILL_NO, vNO_BILL_MANUAL, vNO_TRANSAKSI, vPAYMENT_MODE, vPOLICY_NUMBER, vACCOUNT_NAME,
                                            vPOLICY_EFFECTIVE_DATE, vPRODUCT, vTOTAL_MEMBER, vPREMIUM_AMOUNT, vADDITION, vDELETION, vCHANGE_PLAN,
                                            vFEE_ASO, vASO, vBY_KARTU, vPAID, vOUTSTANDING, vISSUE_DATE, vTYPE_OF_ENDORSMENT, vTGL_BAYAR, vRECEIPT, vRCL, vREMARK_COLLECTION,
                                            vSTATUS, vTGL_PENAGIHAN_PREMI, vTGL_PENAGIHAN_PREMI2, vTGL_PENAGIHAN_PREMI3, vTGL_UPLOAD, vReason, vTGL_PROSES, vTGL_BAYAR2, vTGL_BAYAR3, vUSER, vBILL_NO_OLD,
                    vINVOICE_DATE
                    )

                trInfoDetail.Visible = False
                trDetail.Visible = False

                Modul.UserMsgBox(Me, "Save Completed !!")
            End If

            'query = "'" & vBILL_NO & "','" & vNO_BILL_MANUAL & "','" & vNO_TRANSAKSI & "','" & vPAYMENT_MODE & "','" & vPOLICY_NUMBER & "','" & vACCOUNT_NAME & "','" & _
            'vPOLICY_EFFECTIVE_DATE & "','" & vPRODUCT & "','"& vTOTAL_MEMBER & "','" & vPREMIUM_AMOUNT & "','" & vADDITION & "','" & vDELETION & "','" & vCHANGE_PLAN & "','" & _
            'vFEE_ASO & "','" & vASO & "','" & vBY_KARTU & "','" & vPAID & "','" & vOUTSTANDING & "','" & vISSUE_DATE & "','" & vTYPE_OF_ENDORSMENT & "','" & vTGL_BAYAR & "','" & vRECEIPT & "','" & vRCL & "','" & vREMARK_COLLECTION & "','" & _
            'vSTATUS & "','" & vTGL_PENAGIHAN_PREMI & "','" & vTGL_PENAGIHAN_PREMI2 & "','" & vTGL_PENAGIHAN_PREMI3 & "','" & vReason & "','" & vTGL_PROSES & "','" & vTGL_UPLOAD & "'"

            

            BindGrid("", "", "", "", "", "UNPAID")


        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            Throw (ex)
        End Try


    End Sub

    Protected Sub txtPremiumAmount_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtPremiumAmount.TextChanged

    End Sub

    Protected Sub txtAddition_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtAddition.TextChanged

    End Sub
End Class