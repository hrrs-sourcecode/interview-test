﻿Imports System.Data.SqlClient
Partial Public Class PopSubmitGERDate
    Inherits System.Web.UI.Page

    Dim Dt As New DataTable
    Dim SQL, x1v9oText As String
    Dim strValue() As String
    Dim Modul As New ClassModul
    Dim submitter As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindGridDetail(Left(Request.QueryString("code"), 4), txtClaimNumber.Text.Trim, txtInvoiceNumber.Text)
            BindSecondaryGrid()
            Me.Focus()
        End If
    End Sub
    Private Function CreateDataTable() As DataTable
        Dim dt As New DataTable()

        dt.Columns.Add("GER")
        dt.Columns.Add("DateGERCreated")
        dt.Columns.Add("ClaimType")
        dt.Columns.Add("ClaimNumber")
        dt.Columns.Add("InvoiceNumber")
        dt.Columns.Add("PolicyNumber")
        dt.Columns.Add("MemberNo")
        dt.Columns.Add("MemberName")
        dt.Columns.Add("PatientNo")
        dt.Columns.Add("PatientName")
        dt.Columns.Add("Amount")
        dt.Columns.Add("UserID")
        dt.AcceptChanges()

        Return dt
    End Function
    Private Sub BindSecondaryGrid()
        Dim dt As DataTable = DirectCast(ViewState("SelectedRecords"), DataTable)
        gvSelected.DataSource = dt
        gvSelected.DataBind()
    End Sub
    Private Sub GetData()
        Dim dt As DataTable
        If ViewState("SelectedRecords") IsNot Nothing Then
            dt = DirectCast(ViewState("SelectedRecords"), DataTable)
        Else
            dt = CreateDataTable()
        End If
        Dim chkAll As CheckBox = DirectCast(gridDetail.HeaderRow.Cells(12).FindControl("chkAll"), CheckBox)
        For i As Integer = 0 To gridDetail.Rows.Count - 1
            If chkAll.Checked Then
                dt = AddRow(gridDetail.Rows(i), dt)
            Else
                Dim chk As CheckBox = DirectCast(gridDetail.Rows(i).Cells(12).FindControl("chk"), CheckBox)
                If chk.Checked Then
                    dt = AddRow(gridDetail.Rows(i), dt)
                Else
                    dt = RemoveRow(gridDetail.Rows(i), dt)
                End If
            End If
        Next
        ViewState("SelectedRecords") = dt
    End Sub
    Private Sub SetData()
        Dim chkAll As CheckBox = DirectCast(gridDetail.HeaderRow.Cells(12).FindControl("chkAll"), CheckBox)
        chkAll.Checked = True
        If ViewState("SelectedRecords") IsNot Nothing Then
            Dim dt As DataTable = DirectCast(ViewState("SelectedRecords"), DataTable)
            For i As Integer = 0 To gridDetail.Rows.Count - 1
                Dim chk As CheckBox = DirectCast(gridDetail.Rows(i).Cells(12).FindControl("chk"), CheckBox)
                If chk IsNot Nothing Then
                    Dim dr As DataRow() = dt.[Select]("ClaimNumber = '" & gridDetail.Rows(i).Cells(3).Text & "'")
                    chk.Checked = dr.Length > 0
                    If Not chk.Checked Then
                        chkAll.Checked = False
                    End If
                End If
            Next
        End If
    End Sub
    Private Function AddRow(ByVal gvRow As GridViewRow, ByVal dt As DataTable) As DataTable
        Dim dr As DataRow() = dt.Select("ClaimNumber = '" & gvRow.Cells(3).Text & "'")
        If dr.Length <= 0 Then
            dt.Rows.Add()
            dt.Rows(dt.Rows.Count - 1)("GER") = gvRow.Cells(0).Text
            dt.Rows(dt.Rows.Count - 1)("DateGERCreated") = gvRow.Cells(1).Text
            dt.Rows(dt.Rows.Count - 1)("ClaimType") = gvRow.Cells(2).Text
            dt.Rows(dt.Rows.Count - 1)("ClaimNumber") = gvRow.Cells(3).Text
            dt.Rows(dt.Rows.Count - 1)("InvoiceNumber") = gvRow.Cells(4).Text
            dt.Rows(dt.Rows.Count - 1)("PolicyNumber") = gvRow.Cells(5).Text
            dt.Rows(dt.Rows.Count - 1)("MemberNo") = gvRow.Cells(6).Text
            dt.Rows(dt.Rows.Count - 1)("MemberName") = gvRow.Cells(7).Text
            dt.Rows(dt.Rows.Count - 1)("PatientNo") = gvRow.Cells(8).Text
            dt.Rows(dt.Rows.Count - 1)("PatientName") = gvRow.Cells(9).Text
            dt.Rows(dt.Rows.Count - 1)("Amount") = gvRow.Cells(10).Text
            dt.Rows(dt.Rows.Count - 1)("UserID") = gvRow.Cells(11).Text

            dt.AcceptChanges()

        End If
        Return dt
    End Function
    Private Function RemoveRow(ByVal gvRow As GridViewRow, ByVal dt As DataTable) As DataTable
        Dim dr As DataRow() = dt.Select("ClaimNumber = '" & gvRow.Cells(3).Text & "'")
        If dr.Length > 0 Then
            dt.Rows.Remove(dr(0))
            dt.AcceptChanges()
        End If
        Return dt
    End Function
    Protected Sub CheckBox_CheckChanged(ByVal sender As Object, ByVal e As EventArgs)
        GetData()
        SetData()
        BindSecondaryGrid()

        Dim totAmount As Double

        For x As Integer = 0 To gvSelected.Rows.Count - 1
            totAmount = totAmount + gvSelected.Rows(x).Cells(10).Text
        Next

        lblAmount.Text = FormatNumber(totAmount, 0)
    End Sub
    Protected Sub OnPaging(ByVal sender As Object, ByVal e As GridViewPageEventArgs)
        GetData()
        gridDetail.PageIndex = e.NewPageIndex
        BindGridDetail(Left(Request.QueryString("code"), 4), txtClaimNumber.Text, txtInvoiceNumber.Text)
        SetData()
    End Sub
    Public Sub BindGridDetail(ByVal GER As String, ByVal CLAIMNO As String, ByVal INVNO As String)

        SQL = "SELECT REPLACE([GER No 1],'''','') as GER,Transdate as [Date GER Created]," &
              "CASE WHEN [Who Paid]='P' THEN 'PROVIDER' WHEN [Who Paid]='C' THEN 'REIMBURSMENT' END as [Claim Type]," &
              "[Claim No] as [Claim Number],[Claim Client Ref No] as [Invoice Number],[Policy No] as [Policy Number]," &
              "[Member No],[Member Name],[Patient No],[Patient Name],CONVERT(varchar, CAST(SUM([Total Amount]) AS money), 1) as Amount,[User ID],'' as REASON FROM Tbl_GER " &
              "WHERE REPLACE([GER No 1],'''','') LIKE '%" & GER & "%' AND [Claim No] LIKE '%" & CLAIMNO & "%' AND [Claim Client Ref No] LIKE '%" & INVNO & "%' " &
              "GROUP BY REPLACE([GER No 1],'''',''),Transdate,CASE WHEN [Who Paid]='P' THEN 'PROVIDER' WHEN [Who Paid]='C' THEN 'REIMBURSMENT' END,[Claim No]," &
              "[Claim Client Ref No],[Policy No],[Member No],[Member Name],[Patient No],[Patient Name],[User ID] ORDER BY [Policy Number] asc,[Member No] asc"

        Modul.SubBindGridView(SQL, gridDetail)

    End Sub
    Protected Sub cmdFind_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdFind.Click
        BindGridDetail(Left(Request.QueryString("code"), 4), txtClaimNumber.Text, txtInvoiceNumber.Text)
        SetData()
        GetData()

        Dim totAmount As Double

        For x As Integer = 0 To gvSelected.Rows.Count - 1
            totAmount = totAmount + gvSelected.Rows(x).Cells(10).Text
        Next

        lblAmount.Text = FormatNumber(totAmount, 0)
    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click

        Try
            Dim ger As String = ""
            Dim claimnumber As String = ""
            Dim claim As String = ""
            Dim CLMNUM As String = ""
            Dim REASON As String = ""

            For Each row As GridViewRow In gvSelected.Rows
                If row.RowType = DataControlRowType.DataRow Then

                    ger = row.Cells(0).Text
                    claimnumber = row.Cells(3).Text

                    claim = Left(claimnumber, 8) & ";" & claim
                    CLMNUM = claimnumber & ";" & CLMNUM

                End If
            Next

            For Each row As GridViewRow In gridDetail.Rows

                If row.RowType = DataControlRowType.DataRow Then
                    ' do somthing with the text box textBox
                    Dim txtReason As TextBox = TryCast(row.FindControl("txtReason"), TextBox)

                    REASON = txtReason.Text

                    If REASON <> "" Then
                        SQL = ""
                        SQL = "UPDATE Tbl_Bucket_Pembayaran SET  REASON='" & REASON & "' " &
                              "WHERE CLAMNUM = '" & Left(row.Cells(3).Text, 8) & "' AND [STATUS GER]='1'"
                        Modul.Eksekusi(SQL)
                    End If

                End If

            Next

            If claimnumber = "" Then

                For Each row As GridViewRow In gridDetail.Rows

                    ger = row.Cells(0).Text
                    claimnumber = row.Cells(3).Text

                    claim = Left(claimnumber, 8) & ";" & claim
                    CLMNUM = claimnumber & ";" & CLMNUM

                Next

                SQL = ""
                SQL = "UPDATE Tbl_GER SET [Submission Date]='" & txtFlipsDate.Text.Trim & "',[Payment Date]='" & txtPaymentDate.Text.Trim & "' " &
                      "WHERE REPLACE([GER No 1],'''','')='" & ger & "'"
                Modul.Eksekusi(SQL)

                SQL = ""
                SQL = "UPDATE Tbl_Bucket_Pembayaran SET [STATUS GER]='0' " &
                      "WHERE CLAMNUM In ('" & Replace(claim, ";", "','") & "') AND [STATUS GER]='1' AND REPLACE([GER No 1],'''','')='" & ger & "'"
                Modul.Eksekusi(SQL)

                SQL = ""
                SQL = "DELETE FROM Tbl_GER WHERE [Claim No] IN ('" & Replace(CLMNUM, ";", "','") & "') AND REPLACE([GER No 1],'''','')='" & ger & "'"
                Modul.Eksekusi(SQL)

                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                "alert('Data has been updated'); window.opener.location='ReportGER.aspx';window.close();", True)

            End If

            SQL = ""
            SQL = "UPDATE Tbl_GER SET [Submission Date]='" & txtFlipsDate.Text.Trim & "',[Payment Date]='" & txtPaymentDate.Text.Trim & "' " &
                  "WHERE REPLACE([GER No 1],'''','')='" & ger & "'"
            Modul.Eksekusi(SQL)

            SQL = ""
            SQL = "UPDATE Tbl_Bucket_Pembayaran SET [STATUS GER]='0' " &
                  "WHERE CLAMNUM Not In ('" & Replace(claim, ";", "','") & "') AND [STATUS GER]='1' AND REPLACE([GER No 1],'''','')='" & ger & "'"
            Modul.Eksekusi(SQL)

            SQL = ""
            SQL = "DELETE FROM Tbl_GER WHERE [Claim No] NOT IN ('" & Replace(CLMNUM, ";", "','") & "') AND REPLACE([GER No 1],'''','')='" & ger & "'"
            Modul.Eksekusi(SQL)

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                "alert('Data has been updated'); window.opener.location='ReportGER.aspx';window.close();", True)

        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)

        End Try

    End Sub
    Private Sub PopSubmitGERDate_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload

    End Sub

    Protected Sub ddl_Page_Size_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl_Page_Size.SelectedIndexChanged
        GetData()
        gridDetail.PageSize = Convert.ToInt32(ddl_Page_Size.SelectedValue)
        BindGridDetail(Left(Request.QueryString("code"), 4), txtClaimNumber.Text, txtInvoiceNumber.Text)
        SetData()
    End Sub
End Class