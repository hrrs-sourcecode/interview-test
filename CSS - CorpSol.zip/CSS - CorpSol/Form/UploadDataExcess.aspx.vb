﻿Imports System.IO
Imports OfficeOpenXml
Partial Public Class UploadDataExcess
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim oInsert As New InsertBase
    Dim oSelect As New SelectBase
    Dim dt_duplicate As New DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub


    'Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSave.Click
    '    If Not txtUpload.HasFile Then
    '        ' Handle file
    '        Modul.UserMsgBox(Me, "File Can't Empty !!")
    '        Exit Sub
    '    End If

    '    Dim strFileName As String = txtUpload.PostedFile.FileName
    '    Dim filename As String = Path.GetFileName(strFileName)
    '    Dim new_path As String = Server.MapPath("Upload\") + filename

    '    txtUpload.PostedFile.SaveAs(new_path)


    '    'Dim uploadedFiles As HttpFileCollection = Request.Files
    '    Dim x As Integer = 0

    '    Dim MyConnection As OleDbConnection
    '    Dim MyCommand_Upload As OleDbDataAdapter
    '    Dim nSukses As Integer = 0
    '    Dim nGagal As Integer = 0

    '    dt_duplicate.Columns.Add("CLAIM_NO")
    '    dt_duplicate.Columns.Add("POLICY_NO")
    '    dt_duplicate.Columns.Add("COMPANY_NAME")
    '    dt_duplicate.Columns.Add("PIC_NAME")
    '    dt_duplicate.Columns.Add("MEMBER_NO")
    '    dt_duplicate.Columns.Add("MEMBER_NAME")
    '    dt_duplicate.Columns.Add("PETIRNT_NO")
    '    dt_duplicate.Columns.Add("PATIENT_NAME")
    '    dt_duplicate.Columns.Add("PROVIDER")
    '    dt_duplicate.Columns.Add("STATUS")
    '    dt_duplicate.Columns.Add("Error Message")

    '    Try

    '        Dim DtData_Upload As New DataTable

    '        MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; " & _
    '                            "data source='" & new_path & " '; " & "Extended Properties=Excel 12.0;")

    '        MyConnection.Open()

    '        Dim dbSchema As DataTable = MyConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
    '        Dim firstSheetName As String = dbSchema.Rows(0)("TABLE_NAME").ToString()

    '        MyCommand_Upload = New OleDbDataAdapter(String.Format("SELECT * FROM [" & firstSheetName & "]", strFileName), MyConnection)
    '        MyCommand_Upload.Fill(DtData_Upload)

    '        For i = 0 To DtData_Upload.Rows.Count
    '            Try
    '                If i = DtData_Upload.Rows.Count Then
    '                    Exit For
    '                End If

    '                Dim vPOLICYNO As Integer = IIf(IsDBNull(DtData_Upload.Rows(i).Item("POLICY_NO")), 0, DtData_Upload.Rows(i).Item("POLICY_NO"))
    '                Dim vCOMPANYNAME As String = DtData_Upload.Rows(i).Item("COMPANY_NAME").ToString
    '                Dim vPIC_NAME As String = DtData_Upload.Rows(i).Item("PIC_NAME").ToString
    '                Dim vNO_PHONE As String = DtData_Upload.Rows(i).Item("NO_PHONE/HP").ToString
    '                Dim vEMAIL As String = DtData_Upload.Rows(i).Item("EMAIL").ToString
    '                Dim vADDRESS As String = DtData_Upload.Rows(i).Item("ADDRESS").ToString
    '                Dim vCLAIMTYPE As String = DtData_Upload.Rows(i).Item("CLAIM_TYPE").ToString
    '                Dim vCLAIM_NO As String = DtData_Upload.Rows(i).Item("CLAIM_NO").ToString
    '                Dim vCLAIM_CLIENT_REF_NO As String = DtData_Upload.Rows(i).Item("CLAIM_CLIENT_REF_NO").ToString
    '                Dim vMEMBER_NO As String = DtData_Upload.Rows(i).Item("MEMBER_NO").ToString
    '                Dim vMEMBER_NAME As String = DtData_Upload.Rows(i).Item("MEMBER_NAME").ToString
    '                Dim vPETIRNT_NO As String = DtData_Upload.Rows(i).Item("PETIRNT_NO").ToString
    '                Dim vPATIENT_NAME As String = DtData_Upload.Rows(i).Item("PATIENT_NAME").ToString

    '                Dim vProvider As String = DtData_Upload.Rows(i).Item("Provider").ToString
    '                Dim vBIAYA_PERAWATAN As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("BIAYA_PERAWATAN")), 0, DtData_Upload.Rows(i).Item("BIAYA_PERAWATAN"))
    '                Dim vYANG_DITANGGUNG As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("YANG_DITANGGUNG")), 0, DtData_Upload.Rows(i).Item("YANG_DITANGGUNG"))
    '                Dim vTOTAL_EXCESS As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("TOTAL_EXCESS")), 0, DtData_Upload.Rows(i).Item("TOTAL_EXCESS"))

    '                Dim vRECEIVED_DATE As String
    '                Dim vTGL_PENAGIHAN_EXCESS As String
    '                Dim vTGL_PENAGIHAN_EXCESS2 As String
    '                Dim vTGL_PENAGIHAN_EXCESS3 As String
    '                Dim vTGL_BAYAR As String
    '                Dim vTGL_BAYAR2 As String
    '                Dim vTGL_BAYAR3 As String
    '                Dim vADMISSION_DATE As String
    '                Dim vDISCHARGE_DATE As String

    '                'Dim strArr() As String
    '                'Dim strArrYear() As String

    '                'Dim strDay_date As String
    '                'Dim strMonth_date As String
    '                'Dim strYear_date As String
    '                'Dim _strIssueDate As String

    '                Dim vIssueDate_RECEIVED_DATE As String = DtData_Upload.Rows(i).Item("RECEIVED_DATE").ToString

    '                'If vIssueDate_RECEIVED_DATE <> "" Then
    '                '    strArr = vIssueDate_RECEIVED_DATE.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    'strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    If strDay_date >= 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("RECEIVED_DATE").ToString = "" Then
    '                    vRECEIVED_DATE = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("RECEIVED_DATE").ToString) = True Then
    '                    vRECEIVED_DATE = "1900-01-01"
    '                Else
    '                    vRECEIVED_DATE = CDate(vIssueDate_RECEIVED_DATE)
    '                End If

    '                Dim vIssueDate_ADMISSION_DATE As String = DtData_Upload.Rows(i).Item("ADMISSION_DATE").ToString

    '                'If vIssueDate_ADMISSION_DATE <> "" Then
    '                '    strArr = vIssueDate_ADMISSION_DATE.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("ADMISSION_DATE").ToString = "" Then
    '                    vADMISSION_DATE = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("ADMISSION_DATE").ToString) = True Then
    '                    vADMISSION_DATE = "1900-01-01"
    '                Else
    '                    vADMISSION_DATE = CDate(vIssueDate_ADMISSION_DATE)
    '                End If

    '                Dim vIssueDate_DISCHARGE_DATE As String = DtData_Upload.Rows(i).Item("DISCHARGE_DATE").ToString

    '                'If vIssueDate_DISCHARGE_DATE <> "" Then
    '                '    strArr = vIssueDate_DISCHARGE_DATE.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("DISCHARGE_DATE").ToString = "" Then
    '                    vDISCHARGE_DATE = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("DISCHARGE_DATE").ToString) = True Then
    '                    vDISCHARGE_DATE = "1900-01-01"
    '                Else
    '                    vDISCHARGE_DATE = CDate(vIssueDate_DISCHARGE_DATE)
    '                End If

    '                Dim vIssueDate_TGL_PENAGIHAN_EXCESS As String = DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_EXCESS").ToString

    '                'If vIssueDate_TGL_PENAGIHAN_EXCESS <> "" Then
    '                '    strArr = vIssueDate_TGL_PENAGIHAN_EXCESS.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_EXCESS").ToString = "" Then
    '                    vTGL_PENAGIHAN_EXCESS = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_EXCESS").ToString) = True Then
    '                    vTGL_PENAGIHAN_EXCESS = "1900-01-01"
    '                Else
    '                    vTGL_PENAGIHAN_EXCESS = CDate(vIssueDate_TGL_PENAGIHAN_EXCESS)
    '                End If

    '                Dim vIssueDate_TGL_PENAGIHAN_EXCESS2 As String = DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_EXCESS2").ToString

    '                'If vIssueDate_TGL_PENAGIHAN_EXCESS2 <> "" Then
    '                '    strArr = vIssueDate_TGL_PENAGIHAN_EXCESS2.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_EXCESS2").ToString = "" Then
    '                    vTGL_PENAGIHAN_EXCESS2 = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_EXCESS2").ToString) = True Then
    '                    vTGL_PENAGIHAN_EXCESS2 = "1900-01-01"
    '                Else
    '                    vTGL_PENAGIHAN_EXCESS2 = CDate(vIssueDate_TGL_PENAGIHAN_EXCESS2)
    '                End If

    '                Dim vIssueDate_TGL_PENAGIHAN_EXCESS3 As String = DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_EXCESS3").ToString

    '                'If vIssueDate_TGL_PENAGIHAN_EXCESS3 <> "" Then
    '                '    strArr = vIssueDate_TGL_PENAGIHAN_EXCESS3.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_EXCESS3").ToString = "" Then
    '                    vTGL_PENAGIHAN_EXCESS3 = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_EXCESS3").ToString) = True Then
    '                    vTGL_PENAGIHAN_EXCESS3 = "1900-01-01"
    '                Else
    '                    vTGL_PENAGIHAN_EXCESS3 = CDate(vIssueDate_TGL_PENAGIHAN_EXCESS3)
    '                End If

    '                Dim vIssueDate_TGL_BAYAR As String = DtData_Upload.Rows(i).Item("TGL_BAYAR").ToString

    '                'If vIssueDate_TGL_BAYAR <> "" Then
    '                '    strArr = vIssueDate_TGL_BAYAR.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_BAYAR").ToString = "" Then
    '                    vTGL_BAYAR = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_BAYAR").ToString) = True Then
    '                    vTGL_BAYAR = "1900-01-01"
    '                Else
    '                    vTGL_BAYAR = CDate(vIssueDate_TGL_BAYAR)
    '                End If

    '                Dim vIssueDate_TGL_BAYAR2 As String = DtData_Upload.Rows(i).Item("TGL_BAYAR2").ToString

    '                'If vIssueDate_TGL_BAYAR2 <> "" Then
    '                '    strArr = vIssueDate_TGL_BAYAR2.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_BAYAR2").ToString = "" Then
    '                    vTGL_BAYAR2 = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_BAYAR2").ToString) = True Then
    '                    vTGL_BAYAR2 = "1900-01-01"
    '                Else
    '                    vTGL_BAYAR2 = CDate(vIssueDate_TGL_BAYAR2)
    '                End If

    '                Dim vIssueDate_TGL_BAYAR3 As String = DtData_Upload.Rows(i).Item("TGL_BAYAR3").ToString

    '                'If vIssueDate_TGL_BAYAR3 <> "" Then
    '                '    strArr = vIssueDate_TGL_BAYAR3.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_BAYAR3").ToString = "" Then
    '                    vTGL_BAYAR3 = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_BAYAR3").ToString) = True Then
    '                    vTGL_BAYAR3 = "1900-01-01"
    '                Else
    '                    vTGL_BAYAR3 = CDate(vIssueDate_TGL_BAYAR3)
    '                End If

    '                Dim vSEQ As String = DtData_Upload.Rows(i).Item("SEQ").ToString
    '                Dim vREMARK_COLLECTION As String = DtData_Upload.Rows(i).Item("REMARK_COLLECTION").ToString
    '                Dim vPaid As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("Paid")), 0, DtData_Upload.Rows(i).Item("Paid"))
    '                Dim vOUTSTANDING As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("OUTSTANDING")), 0, DtData_Upload.Rows(i).Item("OUTSTANDING"))
    '                Dim vReason As String = DtData_Upload.Rows(i).Item("Reason").ToString
    '                Dim vStatus As String = "UNPAID"
    '                'Dim vSTATUS As String = DtData_Upload.Rows(i).Item("STATUS").ToString

    '                Dim vTGL_PROSES As String

    '                Dim vIssueDate_TGL_PROSES As String = DtData_Upload.Rows(i).Item("TGL_PROSES").ToString

    '                'If vIssueDate_TGL_PROSES <> "" Then
    '                '    strArr = vIssueDate_TGL_PROSES.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_PROSES").ToString = "" Then
    '                    vTGL_PROSES = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_PROSES").ToString) = True Then
    '                    vTGL_PROSES = "1900-01-01"
    '                Else
    '                    vTGL_PROSES = CDate(vIssueDate_TGL_PROSES)
    '                End If


    '                Dim vNO_RCL As String = DtData_Upload.Rows(i).Item("NO_RCL").ToString

    '                Dim vTGL_PENGIRIMAN_HARDCOPY As String

    '                Dim vIssueDate_TGL_PENGIRIMAN_HARDCOPY As String = DtData_Upload.Rows(i).Item("TGL_PENGIRIMAN_HARDCOPY").ToString

    '                'If vIssueDate_TGL_PENGIRIMAN_HARDCOPY <> "" Then
    '                '    strArr = vIssueDate_TGL_PENGIRIMAN_HARDCOPY.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")

    '                '    'If strDay_date > 12 Then
    '                '    '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    'Else
    '                '    '    strDay_date = strArr(1).PadLeft(2, "0")
    '                '    '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    'End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If


    '                If DtData_Upload.Rows(i).Item("TGL_PENGIRIMAN_HARDCOPY").ToString = "" Then
    '                    vTGL_PENGIRIMAN_HARDCOPY = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_PENGIRIMAN_HARDCOPY").ToString) = True Then
    '                    vTGL_PENGIRIMAN_HARDCOPY = "1900-01-01"
    '                Else
    '                    vTGL_PENGIRIMAN_HARDCOPY = CDate(vIssueDate_TGL_PENGIRIMAN_HARDCOPY)

    '                End If


    '                'Dim vTGL_UPLOAD As String

    '                'Dim vIssueDate_TGL_UPLOAD = DtData_Upload.Rows(i).Item("TGL_UPLOAD").ToString

    '                'If vIssueDate_TGL_UPLOAD <> "" Then
    '                '    strArr = vIssueDate_TGL_UPLOAD.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If


    '                'If DtData_Upload.Rows(i).Item("TGL_UPLOAD").ToString = "" Then
    '                '    vTGL_UPLOAD = "1900-01-01"
    '                'ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_UPLOAD").ToString) = True Then
    '                '    vTGL_UPLOAD = "1900-01-01"
    '                'Else
    '                '    vTGL_UPLOAD = _strIssueDate

    '                'End If

    '                Dim vNO_INVOICE As String = DtData_Upload.Rows(i).Item("NO_INVOICE").ToString
    '                Dim vUser As String = DtData_Upload.Rows(i).Item("User").ToString

    '                Dt = oSelect.sp_get_detail_EC(vCLAIM_NO)

    '                If Dt.Rows.Count > 0 Then
    '                    dt_duplicate.Rows.Add("'" & vCLAIM_NO, vPOLICYNO, vCOMPANYNAME, vPIC_NAME, vMEMBER_NO, vMEMBER_NAME, vPETIRNT_NO, vPATIENT_NAME, vProvider, vStatus, "DUPLICATE DATA")
    '                    Continue For
    '                Else
    '                    nSukses += 1
    '                    oInsert.f_Insert_Data_EC(vPOLICYNO, vCOMPANYNAME, vPIC_NAME, vNO_PHONE, vEMAIL, vADDRESS, vCLAIMTYPE, vCLAIM_NO, vCLAIM_CLIENT_REF_NO, _
    '                                         vMEMBER_NO, vMEMBER_NAME, vPETIRNT_NO, vPATIENT_NAME, vRECEIVED_DATE, vProvider, vADMISSION_DATE, vDISCHARGE_DATE, _
    '                                         vBIAYA_PERAWATAN, vYANG_DITANGGUNG, vTOTAL_EXCESS, vTGL_PENAGIHAN_EXCESS, vTGL_PENAGIHAN_EXCESS2, vTGL_PENAGIHAN_EXCESS3, _
    '                                         vTGL_BAYAR, vTGL_BAYAR2, vTGL_BAYAR3, vSEQ, vREMARK_COLLECTION, vPaid, vOUTSTANDING, vReason, vSTATUS, vTGL_PROSES, vNO_RCL, _
    '                                         vTGL_PENGIRIMAN_HARDCOPY, vNO_INVOICE, Session("username").ToString, UCase(vUser))
    '                End If


    '            Catch ex As Exception
    '                'Modul.UserMsgBox(Me, "Error On Line : " & i.ToString + 1)
    '                Throw (ex)
    '                DtData_Upload = Nothing

    '                MyConnection.Close()
    '                System.IO.File.Delete(new_path)
    '                'Exit Sub
    '            End Try

    '        Next

    '        nGagal = DtData_Upload.Rows.Count - nSukses
    '        LblSes.Text = nSukses.ToString & " Record"
    '        LblGal.Text = nGagal.ToString & " Record"

    '        If dt_duplicate.Rows.Count > 0 Then
    '            btnGenerateReject.Visible = True
    '            lbl_doubldata.Text = dt_duplicate.Rows.Count.ToString & " Record"
    '            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
    '            "alert('Upload Data Sukses. Terdapat " & dt_duplicate.Rows.Count & " data duplicate');;", True)
    '        Else
    '            btnGenerateReject.Visible = False
    '            lbl_doubldata.Text = ""

    '            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
    '            "alert('Upload Data Sukses');;", True)
    '        End If

    '        DGDuplicateEC.DataSource = dt_duplicate
    '        DGDuplicateEC.DataBind()

    '        DtData_Upload = Nothing

    '        MyConnection.Close()
    '        System.IO.File.Delete(new_path)

    '    Catch ex As Exception
    '        'MsgBox(ex.Message)
    '        Throw (ex)
    '        MyConnection.Close()
    '        'Exit Sub
    '    End Try
    '    '        End If
    '    '    Catch ex As Exception
    '    '    'MsgBox(ex.Message)
    '    '    'Throw (ex)
    '    'End Try
    '    'x += 1
    '    'Loop


    '    'System.IO.File.Delete(userPostedFile.FileName)

    'End Sub

    Protected Sub btnGenerateReject_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGenerateReject.Click
        Try
            Dim filename As String = "UPLOAD_EC_DUPLICATE" & "_" & DateTime.Now.Day.ToString.PadLeft(2, "0") & DateTime.Now.Month.ToString.PadLeft(2, "0") & Strings.Right(DateTime.Now.Year.ToString, 2).PadLeft(2, "0") & ".xls"
            Response.Clear()

            Response.AddHeader("content-disposition", "attachment;filename=" & filename)
            Response.Charset = ""
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Me.EnableViewState = False
            Response.ContentType = "application/vnd.xls"
            Dim StringWrite As New System.IO.StringWriter
            Dim HtmlWrite As New System.Web.UI.HtmlTextWriter(StringWrite)
            Modul.FormatExportedGrid(DGDuplicateEC)
            Modul.ClearControls(DGDuplicateEC)
            DGDuplicateEC.RenderControl(HtmlWrite)

            Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
            Response.Write(style)

            Response.Write(StringWrite.ToString())
            Response.End()
            DGDuplicateEC.Dispose()
            DGDuplicateEC.DataSource = Nothing
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Protected Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        If Not txtUpload.HasFile Then
            ' Handle file
            Modul.UserMsgBox(Me, "File Can't Empty !!")
            Exit Sub
        End If

        Dim strFileName As String = txtUpload.PostedFile.FileName
        Dim filename As String = Path.GetFileName(strFileName)
        Dim new_path As String = Server.MapPath("Upload\") + filename

        txtUpload.PostedFile.SaveAs(new_path)
        Dim file_excel As New FileUpload
        file_excel = txtUpload
        'Upload_File_Excel(file_excel)
        If (file_excel.HasFile AndAlso IO.Path.GetExtension(file_excel.FileName) = ".xlsx") Then
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial
            Using excel = New ExcelPackage(file_excel.PostedFile.InputStream)
                dt_duplicate = New DataTable
                dt_duplicate.Columns.Add("CLAIM_NO")
                dt_duplicate.Columns.Add("POLICY_NO")
                dt_duplicate.Columns.Add("COMPANY_NAME")
                dt_duplicate.Columns.Add("PIC_NAME")
                dt_duplicate.Columns.Add("MEMBER_NO")
                dt_duplicate.Columns.Add("MEMBER_NAME")
                dt_duplicate.Columns.Add("PETIRNT_NO")
                dt_duplicate.Columns.Add("PATIENT_NAME")
                dt_duplicate.Columns.Add("PROVIDER")
                dt_duplicate.Columns.Add("STATUS")
                dt_duplicate.Columns.Add("Error Message")
                Dim nSukses As Integer = 0
                Dim nGagal As Integer = 0
                Dim tbl = New DataTable()
                Dim ws = excel.Workbook.Worksheets.First()
                Dim hasHeader = True ' change it if required '
                ' create DataColumns '
                For Each firstRowCell In ws.Cells(1, 1, 1, ws.Dimension.End.Column)
                    tbl.Columns.Add(If(hasHeader,
                                       firstRowCell.Text,
                                       String.Format("Column {0}", firstRowCell.Start.Column)))
                Next
                ' add rows to DataTable '
                Dim startRow = If(hasHeader, 2, 1)
                For rowNum = startRow To ws.Dimension.End.Row
                    Dim wsRow = ws.Cells(rowNum, 1, rowNum, ws.Dimension.End.Column)
                    Dim row = tbl.NewRow()
                    For Each cell In wsRow
                        row(cell.Start.Column - 1) = cell.Text
                    Next
                    tbl.Rows.Add(row)
                Next

                Dim lstColumn As New List(Of String)
                lstColumn.Add("POLICY_NO")
                lstColumn.Add("COMPANY_NAME")
                lstColumn.Add("PIC_NAME")
                lstColumn.Add("NO_PHONE/HP")
                lstColumn.Add("EMAIL")
                lstColumn.Add("ADDRESS")
                lstColumn.Add("CLAIM_TYPE")
                lstColumn.Add("CLAIM_NO")
                lstColumn.Add("CLAIM_CLIENT_REF_NO")
                lstColumn.Add("MEMBER_NO")
                lstColumn.Add("MEMBER_NAME")
                lstColumn.Add("PETIRNT_NO")
                lstColumn.Add("PATIENT_NAME")
                lstColumn.Add("RECEIVED_DATE")
                lstColumn.Add("Provider")
                lstColumn.Add("ADMISSION_DATE")
                lstColumn.Add("DISCHARGE_DATE")
                lstColumn.Add("BIAYA_PERAWATAN")
                lstColumn.Add("YANG_DITANGGUNG")
                lstColumn.Add("TOTAL_EXCESS")
                lstColumn.Add("TGL_PENAGIHAN_EXCESS")
                lstColumn.Add("TGL_PENAGIHAN_EXCESS2")
                lstColumn.Add("TGL_PENAGIHAN_EXCESS3")
                lstColumn.Add("TGL_BAYAR")
                lstColumn.Add("TGL_BAYAR2")
                lstColumn.Add("TGL_BAYAR3")
                lstColumn.Add("SEQ")
                lstColumn.Add("REMARK_COLLECTION")
                lstColumn.Add("Paid")
                lstColumn.Add("Outstanding")
                lstColumn.Add("Reason")
                lstColumn.Add("TGL_PROSES")
                lstColumn.Add("NO_RCL")
                lstColumn.Add("TGL_PENGIRIMAN_HARDCOPY")
                lstColumn.Add("NO_INVOICE")
                lstColumn.Add("INVOICE_DATE") 'new
                lstColumn.Add("User")

                Dim iColumnCheck As Integer = 0
                If (hasHeader = True And tbl.Rows.Count() > 0) Then
                    ' check column 
                    If (tbl.Columns.Count = lstColumn.Count) Then

                        Dim iColumnIndex As Integer = 0
                        For Each Column As DataColumn In tbl.Columns
                            Dim strTblColumnName As String = Column.ColumnName.Trim.ToLower
                            Dim strLstColumnName As String = lstColumn.Item(iColumnIndex).Trim.ToLower
                            If (strTblColumnName.Equals(strLstColumnName)) Then
                                iColumnCheck = iColumnCheck + 1
                            End If
                            iColumnIndex = iColumnIndex + 1
                        Next
                    End If
                End If
                Dim hasError As Boolean = False
                If (iColumnCheck = tbl.Columns.Count) Then
                    Dim iRowsUpdate As Integer = 0

                    For Each Row As DataRow In tbl.Rows
                        Try

                            Dim vPOLICYNO As Integer = IIf(IsDBNull(Row.Item("POLICY_NO")), 0, Row.Item("POLICY_NO"))
                            Dim vCOMPANYNAME As String = Row.Item("COMPANY_NAME").ToString
                            Dim vPIC_NAME As String = Row.Item("PIC_NAME").ToString
                            Dim vNO_PHONE As String = Row.Item("NO_PHONE/HP").ToString
                            Dim vEMAIL As String = Row.Item("EMAIL").ToString
                            Dim vADDRESS As String = Row.Item("ADDRESS").ToString
                            Dim vCLAIMTYPE As String = Row.Item("CLAIM_TYPE").ToString
                            Dim vCLAIM_NO As String = Row.Item("CLAIM_NO").ToString
                            Dim vCLAIM_CLIENT_REF_NO As String = Row.Item("CLAIM_CLIENT_REF_NO").ToString
                            Dim vMEMBER_NO As String = Row.Item("MEMBER_NO").ToString
                            Dim vMEMBER_NAME As String = Row.Item("MEMBER_NAME").ToString
                            Dim vPETIRNT_NO As String = Row.Item("PETIRNT_NO").ToString
                            Dim vPATIENT_NAME As String = Row.Item("PATIENT_NAME").ToString

                            Dim vProvider As String = Row.Item("Provider").ToString
                            Dim vBIAYA_PERAWATAN As Double = IIf(IsDBNull(Row.Item("BIAYA_PERAWATAN")), 0, IIf(Row.Item("BIAYA_PERAWATAN").ToString.Trim = String.Empty, 0, Row.Item("BIAYA_PERAWATAN")))
                            Dim vYANG_DITANGGUNG As Double = IIf(IsDBNull(Row.Item("YANG_DITANGGUNG")), 0, IIf(Row.Item("YANG_DITANGGUNG").ToString.Trim = String.Empty, 0, Row.Item("YANG_DITANGGUNG")))
                            Dim vTOTAL_EXCESS As Double = IIf(IsDBNull(Row.Item("TOTAL_EXCESS")), 0, IIf(Row.Item("TOTAL_EXCESS").ToString.Trim = String.Empty, 0, Row.Item("TOTAL_EXCESS")))

                            Dim vRECEIVED_DATE As String
                            Dim vTGL_PENAGIHAN_EXCESS As String
                            Dim vTGL_PENAGIHAN_EXCESS2 As String
                            Dim vTGL_PENAGIHAN_EXCESS3 As String
                            Dim vTGL_BAYAR As String
                            Dim vTGL_BAYAR2 As String
                            Dim vTGL_BAYAR3 As String
                            Dim vADMISSION_DATE As String
                            Dim vDISCHARGE_DATE As String

                            Dim vIssueDate_RECEIVED_DATE As String = Row.Item("RECEIVED_DATE").ToString

                            If Row.Item("RECEIVED_DATE").ToString = "" Then
                                vRECEIVED_DATE = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("RECEIVED_DATE")) = True Then
                                vRECEIVED_DATE = "1900-01-01"
                            Else
                                vRECEIVED_DATE = CDate(vIssueDate_RECEIVED_DATE)
                            End If

                            Dim vIssueDate_ADMISSION_DATE As String = Row.Item("ADMISSION_DATE").ToString

                            If Row.Item("ADMISSION_DATE").ToString = "" Then
                                vADMISSION_DATE = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("ADMISSION_DATE")) = True Then
                                vADMISSION_DATE = "1900-01-01"
                            Else
                                vADMISSION_DATE = CDate(vIssueDate_ADMISSION_DATE)
                            End If

                            Dim vIssueDate_DISCHARGE_DATE As String = Row.Item("DISCHARGE_DATE").ToString

                            If Row.Item("DISCHARGE_DATE").ToString = "" Then
                                vDISCHARGE_DATE = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("DISCHARGE_DATE")) = True Then
                                vDISCHARGE_DATE = "1900-01-01"
                            Else
                                vDISCHARGE_DATE = CDate(vIssueDate_DISCHARGE_DATE)
                            End If

                            Dim vIssueDate_TGL_PENAGIHAN_EXCESS As String = Row.Item("TGL_PENAGIHAN_EXCESS").ToString

                            If Row.Item("TGL_PENAGIHAN_EXCESS").ToString = "" Then
                                vTGL_PENAGIHAN_EXCESS = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_PENAGIHAN_EXCESS")) = True Then
                                vTGL_PENAGIHAN_EXCESS = "1900-01-01"
                            Else
                                vTGL_PENAGIHAN_EXCESS = CDate(vIssueDate_TGL_PENAGIHAN_EXCESS)
                            End If

                            Dim vIssueDate_TGL_PENAGIHAN_EXCESS2 As String = Row.Item("TGL_PENAGIHAN_EXCESS2").ToString

                            If Row.Item("TGL_PENAGIHAN_EXCESS2").ToString = "" Then
                                vTGL_PENAGIHAN_EXCESS2 = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_PENAGIHAN_EXCESS2")) = True Then
                                vTGL_PENAGIHAN_EXCESS2 = "1900-01-01"
                            Else
                                vTGL_PENAGIHAN_EXCESS2 = CDate(vIssueDate_TGL_PENAGIHAN_EXCESS2)
                            End If

                            Dim vIssueDate_TGL_PENAGIHAN_EXCESS3 As String = Row.Item("TGL_PENAGIHAN_EXCESS3").ToString


                            If Row.Item("TGL_PENAGIHAN_EXCESS3").ToString = "" Then
                                vTGL_PENAGIHAN_EXCESS3 = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_PENAGIHAN_EXCESS3")) = True Then
                                vTGL_PENAGIHAN_EXCESS3 = "1900-01-01"
                            Else
                                vTGL_PENAGIHAN_EXCESS3 = CDate(vIssueDate_TGL_PENAGIHAN_EXCESS3)
                            End If

                            Dim vIssueDate_TGL_BAYAR As String = Row.Item("TGL_BAYAR").ToString

                            If Row.Item("TGL_BAYAR").ToString = "" Then
                                vTGL_BAYAR = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_BAYAR")) = True Then
                                vTGL_BAYAR = "1900-01-01"
                            Else
                                vTGL_BAYAR = CDate(vIssueDate_TGL_BAYAR)
                            End If

                            Dim vIssueDate_TGL_BAYAR2 As String = Row.Item("TGL_BAYAR2").ToString

                            If Row.Item("TGL_BAYAR2").ToString = "" Then
                                vTGL_BAYAR2 = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_BAYAR2")) = True Then
                                vTGL_BAYAR2 = "1900-01-01"
                            Else
                                vTGL_BAYAR2 = CDate(vIssueDate_TGL_BAYAR2)
                            End If

                            Dim vIssueDate_TGL_BAYAR3 As String = Row.Item("TGL_BAYAR3").ToString

                            If Row.Item("TGL_BAYAR3").ToString = "" Then
                                vTGL_BAYAR3 = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_BAYAR3")) = True Then
                                vTGL_BAYAR3 = "1900-01-01"
                            Else
                                vTGL_BAYAR3 = CDate(vIssueDate_TGL_BAYAR3)
                            End If

                            Dim vSEQ As String = Row.Item("SEQ").ToString
                            Dim vREMARK_COLLECTION As String = Row.Item("REMARK_COLLECTION").ToString
                            Dim vPaid As Double = IIf(IsDBNull(Row.Item("Paid")), 0, IIf(Row.Item("Paid").ToString.Trim = String.Empty, 0, Row.Item("Paid")))
                            Dim vOUTSTANDING As Double = IIf(IsDBNull(Row.Item("OUTSTANDING")), 0, IIf(Row.Item("OUTSTANDING").ToString.Trim = String.Empty, 0, Row.Item("OUTSTANDING")))
                            Dim vReason As String = Row.Item("Reason").ToString
                            Dim vStatus As String = "UNPAID"
                            'Dim vSTATUS As String = Row.Item("STATUS").ToString

                            Dim vTGL_PROSES As String

                            Dim vIssueDate_TGL_PROSES As String = Row.Item("TGL_PROSES").ToString

                            If Row.Item("TGL_PROSES").ToString = "" Then
                                vTGL_PROSES = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_PROSES")) = True Then
                                vTGL_PROSES = "1900-01-01"
                            Else
                                vTGL_PROSES = CDate(vIssueDate_TGL_PROSES)
                            End If


                            Dim vNO_RCL As String = Row.Item("NO_RCL").ToString

                            Dim vTGL_PENGIRIMAN_HARDCOPY As String

                            Dim vIssueDate_TGL_PENGIRIMAN_HARDCOPY As String = Row.Item("TGL_PENGIRIMAN_HARDCOPY").ToString

                            If Row.Item("TGL_PENGIRIMAN_HARDCOPY").ToString = "" Then
                                vTGL_PENGIRIMAN_HARDCOPY = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_PENGIRIMAN_HARDCOPY")) = True Then
                                vTGL_PENGIRIMAN_HARDCOPY = "1900-01-01"
                            Else
                                vTGL_PENGIRIMAN_HARDCOPY = CDate(vIssueDate_TGL_PENGIRIMAN_HARDCOPY)

                            End If

                            Dim vNO_INVOICE As String = Row.Item("NO_INVOICE").ToString
                            Dim vUser As String = Row.Item("User").ToString

                            ' NEW 2020/12/23 - INVOICE_DATE
                            Dim vINVOICE_DATE As String = "1900-01-01"
                            If (Not Row.Item("INVOICE_DATE").ToString = "") And (Not IsDBNull(Row.Item("INVOICE_DATE")) = True) Then
                                vINVOICE_DATE = CDate(Row.Item("INVOICE_DATE").ToString().Trim())
                            End If

                            Dt = oSelect.sp_get_detail_EC(vCLAIM_NO)

                            If Dt.Rows.Count > 0 Then
                                dt_duplicate.Rows.Add("'" & vCLAIM_NO, vPOLICYNO, vCOMPANYNAME, vPIC_NAME, vMEMBER_NO, vMEMBER_NAME, vPETIRNT_NO, vPATIENT_NAME, vProvider, vStatus, "DUPLICATE DATA")

                            Else
                                nSukses += 1
                                '   oInsert.f_Insert_Data_EC(vPOLICYNO, vCOMPANYNAME, vPIC_NAME, vNO_PHONE, vEMAIL, vADDRESS, vCLAIMTYPE, vCLAIM_NO, vCLAIM_CLIENT_REF_NO,
                                'vMEMBER_NO, vMEMBER_NAME, vPETIRNT_NO, vPATIENT_NAME, vRECEIVED_DATE, vProvider, vADMISSION_DATE, vDISCHARGE_DATE,
                                'vBIAYA_PERAWATAN, vYANG_DITANGGUNG, vTOTAL_EXCESS, vTGL_PENAGIHAN_EXCESS, vTGL_PENAGIHAN_EXCESS2, vTGL_PENAGIHAN_EXCESS3,
                                'vTGL_BAYAR, vTGL_BAYAR2, vTGL_BAYAR3, vSEQ, vREMARK_COLLECTION, vPaid, vOUTSTANDING, vReason, vStatus, vTGL_PROSES, vNO_RCL,
                                'vTGL_PENGIRIMAN_HARDCOPY, vNO_INVOICE, Session("username").ToString, UCase(vUser))
                                oInsert.f_Insert_Data_EC(vPOLICYNO, vCOMPANYNAME, vPIC_NAME, vNO_PHONE, vEMAIL, vADDRESS, vCLAIMTYPE, vCLAIM_NO, vCLAIM_CLIENT_REF_NO,
                                vMEMBER_NO, vMEMBER_NAME, vPETIRNT_NO, vPATIENT_NAME, vRECEIVED_DATE, vProvider, vADMISSION_DATE, vDISCHARGE_DATE,
                                vBIAYA_PERAWATAN, vYANG_DITANGGUNG, vTOTAL_EXCESS, vTGL_PENAGIHAN_EXCESS, vTGL_PENAGIHAN_EXCESS2, vTGL_PENAGIHAN_EXCESS3,
                                vTGL_BAYAR, vTGL_BAYAR2, vTGL_BAYAR3, vSEQ, vREMARK_COLLECTION, vPaid, vOUTSTANDING, vReason, vStatus, vTGL_PROSES, vNO_RCL,
                                vTGL_PENGIRIMAN_HARDCOPY, vNO_INVOICE, Session("username").ToString, UCase(vUser), vINVOICE_DATE)
                            End If


                        Catch ex As Exception
                            'Modul.UserMsgBox(Me, "Error On Line : " & i.ToString + 1)
                            ''Throw (ex)
                            hasError = True
                            dt_duplicate.Rows.Add("'" & IIf(IsDBNull(Row.Item("CLAIM_NO")), "", Row.Item("CLAIM_NO")),
                                                  IIf(IsDBNull(Row.Item("POLICY_NO")), 0, Row.Item("POLICY_NO")),
                                                  IIf(IsDBNull(Row.Item("COMPANY_NAME")), "", Row.Item("COMPANY_NAME")),
                                                  IIf(IsDBNull(Row.Item("PIC_NAME")), "", Row.Item("PIC_NAME")),
                                                  IIf(IsDBNull(Row.Item("MEMBER_NO")), "", Row.Item("MEMBER_NO")),
                                                  IIf(IsDBNull(Row.Item("MEMBER_NAME")), "", Row.Item("MEMBER_NAME")),
                                                  IIf(IsDBNull(Row.Item("PETIRNT_NO")), "", Row.Item("PETIRNT_NO")),
                                                  IIf(IsDBNull(Row.Item("PATIENT_NAME")), "", Row.Item("PATIENT_NAME")),
                                                  IIf(IsDBNull(Row.Item("Provider")), "", Row.Item("Provider")),
                                                  "Error",
                                                  ex.Message.ToString & " Line : " & Right(ex.StackTrace.ToString, 4))

                            'Exit For
                        End Try
                        iRowsUpdate = iRowsUpdate + 1
                    Next
                    nGagal = tbl.Rows.Count - nSukses
                    LblSes.Text = nSukses.ToString & " Record"
                    LblGal.Text = nGagal.ToString & " Record"

                    If dt_duplicate.Rows.Count > 0 Then
                        btnGenerateReject.Visible = True
                        lbl_doubldata.Text = dt_duplicate.Rows.Count.ToString & " Record"
                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                        "alert('Upload Data Sukses. Terdapat " & dt_duplicate.Rows.Count & " data duplicate/error');", True)
                    Else
                        btnGenerateReject.Visible = False
                        lbl_doubldata.Text = ""
                        If (hasError) Then
                            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                        "alert('Upload Data Gagal');", True)
                        Else
                            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                        "alert('Upload Data Sukses');", True)
                        End If

                    End If

                    DGDuplicateEC.DataSource = dt_duplicate
                    DGDuplicateEC.DataBind()
                Else
                    Modul.UserMsgBox(Me, "File Excel Columns not match.")
                    'Dim msg = String.Format("Update fail created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3}",
                    'tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count)
                    'UploadStatusLabel.Text = msg
                End If

                tbl = Nothing
            End Using


        Else
            If (file_excel.HasFile) Then
                ' Handle file
                Modul.UserMsgBox(Me, "File Excel must with extension .xlsx only !!")
                Exit Sub
            Else
                ' Handle file
                Modul.UserMsgBox(Me, "File Upload Can't Empty !!")
                Exit Sub
            End If
        End If

        file_excel.Dispose()
        txtUpload.Dispose()
    End Sub

    Protected Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Try
            'Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "alert('Batal upload !');", True)
            Response.Redirect("~/Form/UploadDataExcess.aspx", False)
        Catch ex As Exception
            ex.Message.ToString()
            Throw
        Finally

        End Try
    End Sub

    Protected Sub Btn_Template_Click(sender As Object, e As EventArgs) Handles Btn_Template.Click
        Try
            Dim sPath As String = Server.MapPath("~\TemplateFiles\")
            Response.Clear()
            Response.Charset = ""
            Response.ContentEncoding = System.Text.Encoding.UTF8
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;filename=Template_EC_" + Now.ToString("yyyyMMdd_HHmmss") + ".xlsx")
            'Response.AppendHeader("Content-Disposition", "attachment;filename=Template_Premi_Tahunan.xlsx")
            Response.TransmitFile(sPath & "Template_EC.xlsx")
            Response.Flush()
            Response.End()

        Catch ex As Exception
        End Try
    End Sub
End Class