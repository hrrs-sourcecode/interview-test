﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Reflection
Imports System
Imports System.IO
Imports Ionic.Zip

Partial Public Class ReportRebate
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim oSelect As New SelectBase
    Dim Dt As New System.Data.DataTable
    Dim dr As SqlDataReader
    Dim dt_mbrNo As New System.Data.DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            DropFill_FundType()
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If


    End Sub
    Public Sub DropFill_FundType()
        Dim ListTemp As ListItem

        ddlFundType.Items.Clear()
        ListTemp = New ListItem("Choose", "")
        ddlFundType.Items.Add(ListTemp)

        SQL = "SELECT DISTINCT DESCPF_TR93U_LONGDESC,ACTRPF_INVFCDE FROM IDAS_CORPSOL_TRANSACTION WHERE ACTRPF_INVFCDE NOT IN ('IN','UH') " & _
              "ORDER BY ACTRPF_INVFCDE"

        dr = Modul.getAllDatainDR(SQL)

        While dr.Read
            ListTemp = New ListItem(dr(1), dr(0))
            ddlFundType.Items.Add(ListTemp)
        End While

        dr.Close()
        Modul.SQLCn.Close()

    End Sub
    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click
        Try

            Dim dateFrom As DateTime
            Dim dateTo As DateTime
            Dim sFileName As String = ""
            Dim dtcheckRebate As New DataTable

            dateFrom = CDate(Right(txtFrom.Text, 4) & "-" & Mid(txtFrom.Text, 4, 2) & "-" & Left(txtFrom.Text, 2))
            dateTo = CDate(Right(txtTo.Text, 4) & "-" & Mid(txtTo.Text, 4, 2) & "-" & Left(txtTo.Text, 2))

            If txtFrom.Text.Trim = "" Or txtTo.Text.Trim = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Tidak Boleh Kosong.'); window.location='ReportRebate.aspx';", True)
                Exit Sub
            ElseIf dateTo > dateFrom.AddMonths(1) Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Melebihi Periode Yang Ditentukan.'); window.location='ReportRebate.aspx';", True)
                Exit Sub
            ElseIf txtPolis.Text = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Police Number Tidak Boleh Kosong.'); window.location='ReportRebate.aspx';", True)
                Exit Sub
            End If

            dtcheckRebate.Clear()
            dtcheckRebate = oSelect.sp_check_rebate(txtFrom.Text, txtTo.Text, txtPolis.Text, ddlFundType.SelectedItem.Text)

            If dtcheckRebate.Rows.Count > 0 Then
                If dtcheckRebate.Rows(0)("rebate") < 0 Then
                    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                    "alert('Rebate Kurang dari 0'); window.location='ReportRebate.aspx';", True)
                    Exit Sub
                End If

            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                    "alert('Rebate Tidak Ditemukan.'); window.location='ReportRebate.aspx';", True)
                Exit Sub
            End If

            If ddlReportLevel.SelectedValue.ToString = "Policy Level" Then
                Report_Policy_Level()
            ElseIf ddlReportLevel.SelectedValue.ToString = "Member Level" Then

                Report_Member_Level()

                dt_mbrNo.Clear()
                dt_mbrNo = oSelect.sp_Get_MemberNo(txtFrom.Text, txtTo.Text, txtPolis.Text, txtMemberName.Text, ddlFundType.SelectedItem.Text)


                Using zip As New ZipFile()
                    zip.AlternateEncodingUsage = ZipOption.AsNecessary
                    zip.AddDirectoryByName("Rebate")

                    For x = 0 To dt_mbrNo.Rows.Count - 1

                        sFileName = "Report Rebate " & txtPolis.Text & " - " & dt_mbrNo.Rows(x)("MBRNO") & ".xls"
                        Dim spath As String = Server.MapPath("~/File/" & sFileName)

                        zip.AddFile(spath, "Rebate")
                    Next

                    Response.Clear()
                    Response.Buffer = True
                    Response.AddHeader("Content-Disposition", "inline; filename=" + "Rebate.Zip")
                    Response.Charset = ""
                    Response.Cache.SetCacheability(HttpCacheability.NoCache)
                    Me.EnableViewState = False
                    Response.ContentType = "application/zip"

                    Response.AddHeader("X-Download-Options", "noopen")

                    'Remove the charset from the Content-Type header.
                    Dim style As String = "<style> .text { mso-number-format:\@; } </style> "

                    zip.Save(Response.OutputStream)

                    Dim filePaths() As String = Directory.GetFiles(Server.MapPath("~/File/"))

                    For Each filePath As String In filePaths
                        File.Delete(filePath)
                    Next

                    Response.End()

                End Using
            End If

        Catch ex As Exception

        End Try

    End Sub

    Public Sub Report_Member_Level()
        Dim sFileName As String = ""
        Dim sSheetName As String = ""
        Dim dt_report As New System.Data.DataTable
        Dim path As String = Server.MapPath("~/File/")
        Dim filenames As String() = Directory.GetFiles(path)
        Dim exceltable As New StringBuilder()

        dt_mbrNo = oSelect.sp_Get_MemberNo(txtFrom.Text, txtTo.Text, txtPolis.Text, txtMemberName.Text, ddlFundType.SelectedItem.Text)

        If dt_mbrNo.Rows.Count > 0 Then


            For x = 0 To dt_mbrNo.Rows.Count - 1

                sFileName = "Report Rebate " & txtPolis.Text & " - " & dt_mbrNo.Rows(x)("MBRNO") & ".xls"

                dt_report.Clear()
                dt_report = oSelect.sp_Rebate_Member_Level(txtFrom.Text, txtTo.Text, txtPolis.Text, dt_mbrNo.Rows(x)("MBRNO"), ddlFundType.SelectedItem.Text)

                exceltable.Length = 0
                exceltable.Append("<HTML><BODY><table style=table-layout: fixed>" & _
                                  "<tr><td colspan=4><font size=small face=Calibri><b>Ringkasan Transaksi Rebate</b></font></td>" & _
                                  "<td colspan=4><font size=small face=Calibri>&nbsp;</font></td><td><font size=small face=Calibri>Admin Charge</font></td>" & _
                                  "<td><font size=small face=Calibri>" & dt_report.Rows(0)("AdminCharge").ToString & "%</font></td><td><font size=small face=Calibri>Tiap Akhir Bulan</font></td>" & _
                                  "</tr><tr><td><font size=small face=Calibri><b>" & dt_report.Rows(0)("Name").ToString & "</b></font></td><td><font size=small face=Calibri></font></td>" & _
                                  "<td colspan=6><font size=small face=Calibri>&nbsp;</font></td><td><font size=small face=Calibri>Rebate (%)</font></td>" & _
                                  "<td><font size=small face=Calibri>" & dt_report.Rows(0)("Rebate").ToString & "%</font></td><td><font size=small face=Calibri>Daily</font></td>" & _
                                  "</tr><tr><td><font size=small face=Calibri><b>Nomor Polis</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("PolicyNo").ToString & "</b></font></td>" & _
                                  "<td colspan=6><font size=small face=Calibri>&nbsp;</font></td><td><font size=small face=Calibri>COI</font></td>" & _
                                  "<td><font size=small face=Calibri>" & dt_report.Rows(0)("COI").ToString & "</font></td><td><font size=small face=Calibri>Tiap Ulang Bulan</font></td>" & _
                                  "</tr><tr><td><font size=small face=Calibri><b>Fund Type</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("FundType").ToString & "</b></font></td>" & _
                                  "<td colspan=6><font size=small face=Calibri>&nbsp;</font></td><td><font size=small face=Calibri></font></td>" & _
                                  "<td><font size=small face=Calibri></font></td><td><font size=small face=Calibri></font></td>" & _
                                  "</tr></table><br /><TABLE Border=1 style=table-layout: fixed>")

                exceltable.AppendFormat("<TR>")
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=100px><b>TANGGAL TRANSAKSI</b></TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Redeemtion</b></TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Subscription</b></TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Unit Balance</b></TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>NAV/Unit</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=100px><b>MARKET VALUE (IDR)</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=100px><b>DAILY REBATE</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=100px><b>REBATEE ACCUMULATIVE</b></TD>"))
                exceltable.AppendFormat("</TR>")

                For Each row As DataRow In dt_report.Rows
                    exceltable.AppendFormat("<TR>")

                    exceltable.AppendFormat(String.Concat("<TD>", row("Transaction Date").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("REDEEMTION").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("SUBSCRIPTION").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Unit Balance").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("NAV/Unit").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Market Value").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Daily Rebate").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Rebate Accumulate").ToString(), "</TD>"))

                    exceltable.AppendFormat("</TR>")
                Next


                exceltable.Append("</TABLE></td></tr></table></BODY></HTML>")
                exceltable.ToString()

                Dim file As System.IO.StreamWriter = New System.IO.StreamWriter(Server.MapPath("~/File/" & sFileName))
                file.WriteLine(exceltable.ToString)
                file.Close()

            Next
        Else
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            "alert('Data Tidak Ditemukan.'); window.location='ReportRebate.aspx';", True)

        End If
    End Sub
    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub
    Public Sub Report_Policy_Level()
        Dim sFileName As String = ""
        Dim dt_report As New System.Data.DataTable

        sFileName = "Report Rebate " & txtPolis.Text & ".xls"

        dt_report = oSelect.sp_Rebate_Policy_Level(txtFrom.Text, txtTo.Text, txtPolis.Text, ddlFundType.SelectedItem.Text)

        Dim exceltable As New StringBuilder()

        exceltable.Append("<HTML><BODY><table style=table-layout: fixed>" & _
                          "<tr><td colspan=4><font size=small face=Calibri><b>Ringkasan Transaksi Rebate</b></font></td>" & _
                          "<td colspan=4><font size=small face=Calibri>&nbsp;</font></td><td><font size=small face=Calibri>Admin Charge</font></td>" & _
                          "<td><font size=small face=Calibri>" & dt_report.Rows(0)("AdminCharge").ToString & "%</font></td><td><font size=small face=Calibri>Tiap Akhir Bulan</font></td>" & _
                          "</tr><tr><td><font size=small face=Calibri><b>" & dt_report.Rows(0)("Name").ToString & "</b></font></td><td><font size=small face=Calibri></font></td>" & _
                          "<td colspan=6><font size=small face=Calibri>&nbsp;</font></td><td><font size=small face=Calibri>Rebate (%)</font></td>" & _
                          "<td><font size=small face=Calibri>" & dt_report.Rows(0)("Rebate").ToString & "%</font></td><td><font size=small face=Calibri>Daily</font></td>" & _
                          "</tr><tr><td><font size=small face=Calibri><b>Nomor Polis</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("PolicyNo").ToString & "</b></font></td>" & _
                          "<td colspan=6><font size=small face=Calibri>&nbsp;</font></td><td><font size=small face=Calibri>COI</font></td>" & _
                          "<td><font size=small face=Calibri>" & dt_report.Rows(0)("COI").ToString & "</font></td><td><font size=small face=Calibri>Tiap Ulang Bulan</font></td>" & _
                          "</tr><tr><td><font size=small face=Calibri><b>Fund Type</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("FundType").ToString & "</b></font></td>" & _
                          "<td colspan=6><font size=small face=Calibri>&nbsp;</font></td><td><font size=small face=Calibri></font></td>" & _
                          "<td><font size=small face=Calibri></font></td><td><font size=small face=Calibri></font></td>" & _
                          "</tr></table><br /><TABLE Border=1 style=table-layout: fixed>")

        exceltable.AppendFormat("<TR>")
        exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=100px><b>TANGGAL TRANSAKSI</b></TH>"))
        exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Redeemtion</b></TH>"))
        exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Subscription</b></TH>"))
        exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Unit Balance</b></TH>"))
        exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>NAV/Unit</b></TD>"))
        exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=100px><b>MARKET VALUE (IDR)</b></TD>"))
        exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=100px><b>DAILY REBATE</b></TD>"))
        exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=100px><b>REBATEE ACCUMULATIVE</b></TD>"))
        exceltable.AppendFormat("</TR>")

        For Each row As DataRow In dt_report.Rows
            exceltable.AppendFormat("<TR>")

            exceltable.AppendFormat(String.Concat("<TD>", row("Transaction Date").ToString(), "</TD>"))
            exceltable.AppendFormat(String.Concat("<TD>", row("REDEEMTION").ToString(), "</TD>"))
            exceltable.AppendFormat(String.Concat("<TD>", row("SUBSCRIPTION").ToString(), "</TD>"))
            exceltable.AppendFormat(String.Concat("<TD>", row("Unit Balance").ToString(), "</TD>"))
            exceltable.AppendFormat(String.Concat("<TD>", row("NAV/Unit").ToString(), "</TD>"))
            exceltable.AppendFormat(String.Concat("<TD>", row("Market Value").ToString(), "</TD>"))
            exceltable.AppendFormat(String.Concat("<TD>", row("Daily Rebate").ToString(), "</TD>"))
            exceltable.AppendFormat(String.Concat("<TD>", row("Rebate Accumulate").ToString(), "</TD>"))

            exceltable.AppendFormat("</TR>")
        Next

        exceltable.Append("</TABLE></td></tr></table></BODY></HTML>")
        Response.Clear()
        Response.Buffer = True
        Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
        Response.Charset = ""
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Me.EnableViewState = False
        Response.ContentType = "application/vnd.ms-excel"

        Response.AddHeader("X-Download-Options", "noopen")

        'Remove the charset from the Content-Type header.
        Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
        Response.Write(style)

        Response.Write(exceltable.ToString())

        Response.End()
    End Sub
    Protected Sub ddlFundType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFundType.SelectedIndexChanged
        txtLongDesc.Text = ddlFundType.SelectedValue.ToString
    End Sub

    Protected Sub ddlReportLevel_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlReportLevel.SelectedIndexChanged
        If ddlReportLevel.SelectedValue.ToString = "Member Level" Then
            lblMember.Visible = True
            txtMemberName.Visible = True
        Else
            lblMember.Visible = False
            txtMemberName.Visible = False
        End If
    End Sub

    Protected Sub txtPolis_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtPolis.TextChanged
        Dim dt_Polis As New System.Data.DataTable
        Dim ListTemp As ListItem

        If Len(txtPolis.Text) = 8 Then
            dt_Polis = oSelect.sp_Get_Type_Polis(txtPolis.Text)

            If dt_Polis.Rows.Count = 0 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportRebate.aspx';", True)
                Exit Sub
            End If
            Session("Type") = dt_Polis.Rows(0)("Type").ToString

            If Session("Type") = "DCI" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
                ddlReportLevel.Items.Add("Member Level")
            ElseIf Session("Type") = "DBE" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportRebate.aspx';", True)
            End If

            ddlFundType.Items.Clear()

            For x = 0 To dt_Polis.Rows.Count - 1
                ListTemp = New ListItem(dt_Polis.Rows(x)("Fund"), dt_Polis.Rows(x)("Description"))
                ddlFundType.Items.Add(ListTemp)
            Next

            txtLongDesc.Text = ddlFundType.SelectedValue.ToString

        End If
    End Sub
End Class