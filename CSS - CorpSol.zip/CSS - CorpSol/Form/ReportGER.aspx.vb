﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices
Imports System.Data.OleDb
Imports OfficeOpenXml
Imports OfficeOpenXml.Style
Imports System.Globalization

Partial Public Class ReportGER
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim Obj_Insert As New InsertBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If
            BindGrid("", "", "")
            trGridDetail.Visible = False
            trDetailTitle.Visible = False
            gridDetail.Visible = False
            trButton.Visible = False
            trUpload.Visible = False
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If

        End If
    End Sub
    Public Sub BindGrid(ByVal GER As String, ByVal DateGER As String, ByVal ClaimType As String)

        'SQL = "SELECT [GER No 1] as GER,Transdate as [Date GER Created]," &
        '      "CASE WHEN [Who Paid]='P' THEN 'PROVIDER' WHEN [Who Paid]='C' THEN 'REIMBURSMENT' END as [Claim Type]," &
        '      "COUNT(DISTINCT [Claim No]) as [Total Case],CONVERT(varchar, CAST(SUM([Total Amount]) AS money), 1) as [Amount Paid],[User Created],[Submission Date],[Payment Date] FROM Tbl_GER " &
        '      "WHERE [GER No 1] LIKE '%" & GER & "%' AND Transdate LIKE '%" & DateGER & "%' AND [Who Paid] LIKE '%" & ClaimType & "%' " &
        '      "GROUP BY [GER No 1],Transdate,[Who Paid],[User Created],[Submission Date],[Payment Date] " &
        '      "ORDER BY CAST(RIGHT(Transdate,4) + SUBSTRING(Transdate,4,2) + LEFT(Transdate,2) AS DATETIME) desc,[GER No 1] desc"
        SQL = String.Format("
SELECT [GER No 1] as GER,Transdate as [Date GER Created],
CASE WHEN [Who Paid]='P' THEN 'PROVIDER' WHEN [Who Paid]='C' THEN 'REIMBURSMENT' END as [Claim Type],
COUNT(DISTINCT [Claim No]) as [Total Case], CONVERT(varchar, CAST(SUM([Total Amount]) AS money), 1) as [Amount Paid],
[User Created],[Submission Date],[Payment Date]
FROM Tbl_GER  
WHERE [GER No 1] LIKE '%{0}%' AND Transdate LIKE '%{1}%' AND [Who Paid] LIKE '%{2}%'  
AND (CONVERT(date, Transdate,103) >= CONVERT(date,CONVERT(varchar,DATEADD(year, -1, getdate()),103),103))
GROUP BY [GER No 1],Transdate,[Who Paid],[User Created],[Submission Date],[Payment Date]
ORDER BY CONVERT(date, Transdate,103) DESC,[GER No 1] DESC;
", GER, DateGER, ClaimType)
        Modul.SubBindGridView(SQL.TrimStart.TrimEnd, GridGER)

    End Sub
    Public Sub BindGridDetail(ByVal GER As String, ByVal DateGER As String, ByVal ClaimType As String, ByVal CLAIMNUM As String, ByVal INVOICE As String, ByVal SRVCODE As String)

        SQL = "SELECT [GER No 1] as GER,Transdate as [Date GER Created]," &
              "CASE WHEN [Who Paid]='P' THEN 'PROVIDER' WHEN [Who Paid]='C' THEN 'REIMBURSMENT' END as [Claim Type]," &
              "[Claim No] as [Claim Number],[Procedure Code] as [Service Code],[Claim Client Ref No] as [Invoice Number],[Policy No] as [Policy Number]," &
              "[Member No],[Member Name],[Patient No],[Patient Name],CONVERT(varchar, CAST(Paid AS money), 1) as Amount,Discount,CONVERT(varchar, CAST([Total Amount] AS money), 1) as [Total Amount] FROM Tbl_GER " &
              "WHERE [GER No 1] LIKE '%" & GER & "%' " &
              "AND Transdate LIKE '%" & DateGER & "%' AND [Who Paid] LIKE '%" & ClaimType & "%' AND [Claim No] LIKE '%" & CLAIMNUM & "%' " &
              "AND [Claim Client Ref No] LIKE '%" & INVOICE & "%' AND [Procedure Code] LIKE '%" & SRVCODE & "%' ORDER BY [Policy Number] asc,[Member No] asc"
        'Modul.SubBindGridView(SQL, gridDetail)
        Dim dt As New DataTable
        dt = Modul.getAllDatainDT(SQL)
        If (dt.Rows.Count > 0) Then
            gridDetail.DataSource = dt
            gridDetail.DataBind()
            Session.Add("DataDetails", dt)
        End If


    End Sub

    Protected Sub btnGER_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGER.Click
        Try
            Dim dt_report As New DataTable
            dt_report = Export_GER_To_Excel_By_SP(Session("GER").ToString)

            'Dim strFilters As String = ""

            '            If Session("GER").ToString.Length > 0 Then strFilters = strFilters + String.Format(" AND [GER No 1] LIKE '%{0}%'", Session("GER"))
            '            If Session("DATEGER").ToString.Length > 0 Then strFilters = strFilters + String.Format(" AND [Transdate] LIKE '%{0}%'", Session("DATEGER"))
            '            If Session("claimtype").ToString.Length > 0 Then strFilters = strFilters + String.Format(" AND [Who Paid] LIKE '%{0}%'", Session("claimtype"))
            '            Dim strQuery As String = ""
            '            If strFilters.Length > 0 Then
            '                strFilters = "WHERE " + strFilters.Remove(0, 5)
            '            End If
            '            strQuery = String.Format("
            'SELECT CONVERT(DATE,[Transdate],103) as [Transdate], [Policy No], [Claim Type], [Provorg] as [Provorg], 
            '[Claim No], [Who Paid], 
            'REPLACE(REPLACE(REPLACE(REPLACE(RTRIM([Claim Client Ref No]),' ',''),CHAR(32),''),CHAR(9),''),CHAR(10),'') as [Claim Client Ref No],
            'CONVERT(DATE,[First Report Date],103) as [First Report Date],  
            'CONVERT(DATE,[Claim Form Received On],103) as [Claim Form Received On], [Member No], RTRIM([Member Name]) as [Member Name], 
            '[Patient No], RTRIM([Patient Name]) as [Patient Name], CONVERT(DATE,[Admission Date],103) as [Admission Date], 
            'CONVERT(DATE,[Discharge Date],103) as [Discharge Date], RTRIM([Diagnosis Code]) as [Diagnosis Code], RTRIM([Procedure Code]) as [Procedure Code], 
            '[Limit], [Incurred], [Total Amount] as Paid, [Cover], [Unpaid], 
            'CASE WHEN [Who Paid] = 'C' THEN 0 ELSE [Excess] END as [Excess], 
            'REPLACE(REPLACE(REPLACE(REPLACE(RTRIM([Remarks]),' ',''),CHAR(32),''),CHAR(9),''),CHAR(10),'') as [Remarks],
            '[Claim Status], CONVERT(DATE,[Authorization Date],103) as [Authorization Date],CONVERT(DATE,[Transdate],103) as [Submission Date], 
            '--CONVERT(DATE,[Payment Date],103) as [Payment Date], [GER No 1], [GER No 2], 
            '[Payment Date], [GER No 1], [GER No 2], 
            'CONVERT(DATE,[Transdate],103) as [GER Date], [Date Letter AXA], [User ID],  
            '[Tick], [Payment Type], [Manual], [Discount] FROM Tbl_GER {0}
            'ORDER BY [Policy No],[Member No] ASC;
            '", strFilters)
            '            dt_report = Modul.getAllDatainDT(strQuery)


            ' New, using EEplus
            If dt_report.Rows.Count > 0 Then
                Dim strFileName As String = "", strSheetName As String = ""


                Dim strDateNow As String = Date.Now.ToString("yyyy_MM_dd")

                If dt_report.Rows(0).Item(5).ToString.ToUpper = "P" Then
                    strFileName = String.Format("KLAIM_PROVIDER_{0}_{1}.xlsx", Session("GER"), strDateNow)
                    strSheetName = String.Format("GER_NO_{0}", Session("GER"))
                ElseIf dt_report.Rows(0).Item(5).ToString.ToUpper = "C" Then
                    dt_report.Columns.Remove("Discount")
                    dt_report.AcceptChanges()

                    strFileName = String.Format("KLAIM_REIMBURSMENT_{0}_{1}.xlsx", Session("GER"), strDateNow)
                    strSheetName = String.Format("GER_NO_{0}", Session("GER"))
                End If
                Response.Clear()
                Response.Charset = ""
                Response.ContentEncoding = System.Text.Encoding.UTF8
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

                Response.AddHeader("content-disposition", "attachment;filename=" & strFileName)
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial
                'Writing the excel file
                Using excelPack = New ExcelPackage()

                    Dim ws As ExcelWorksheet = excelPack.Workbook.Worksheets.Add(strSheetName)
                    ws.Cells("A1").LoadFromDataTable(dt_report, True)

                    ' Assign borders
                    ws.Cells(ws.Dimension.Address).Style.Border.Top.Style = ExcelBorderStyle.Thin
                    ws.Cells(ws.Dimension.Address).Style.Border.Left.Style = ExcelBorderStyle.Thin
                    ws.Cells(ws.Dimension.Address).Style.Border.Right.Style = ExcelBorderStyle.Thin
                    ws.Cells(ws.Dimension.Address).Style.Border.Bottom.Style = ExcelBorderStyle.Thin

                    ' panduan kolom data type 
                    ' Date
                    ' 1,8,9,14,15,26,27,28,31
                    ' Number
                    ' 18,19,20,21,22,23,37
                    'Column Alligment -> Amount, Discount, Total Amount
                    For iCol As Integer = 0 To dt_report.Columns.Count - 1
                        Select Case iCol
                            Case 0, 7, 8, 13, 14, 25, 26, 30
                                'ws.Column(iCol + 1).Style.Numberformat.Format = DateTimeFormatInfo.CurrentInfo.ShortDatePattern 'date
                                ws.Column(iCol + 1).Style.Numberformat.Format = "dd/MM/yyyy" 'date
                                ws.Column(iCol + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                            Case 17, 18, 19, 20, 21, 22
                                'ws.Column(iCol + 1).Style.Numberformat.Format = "0" 'integer
                                'ws.Column(iCol + 1).Style.Numberformat.Format = "0.00" 'decimal
                                ws.Column(iCol + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                            Case 36
                                'ws.Column(iCol + 1).Style.Numberformat.Format = "0.00" 'decimal
                                ws.Column(iCol + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                            Case 5 'claim type
                                ws.Column(iCol + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                            Case 6, 16  'Claim Client Ref No dan Procedure Code
                                ws.Column(iCol + 1).Style.Numberformat.Format = "@"
                                ws.Column(iCol + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Left
                            Case Else
                                ws.Column(iCol + 1).Style.HorizontalAlignment = ExcelHorizontalAlignment.General 'general
                        End Select

                    Next
                    'ws.Column(11).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    'ws.Column(14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right

                    'Header style
                    ws.Cells(1, 1, 1, 37).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws.Cells(1, 1, 1, 37).Style.Font.Bold = True

                    ws.Cells(ws.Dimension.Address).AutoFitColumns()

                    Dim MS As New System.IO.MemoryStream()
                    excelPack.SaveAs(MS)
                    MS.WriteTo(HttpContext.Current.Response.OutputStream)
                End Using
                Response.Flush()
                Response.End()


            End If

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
    End Sub

    Private Sub GridGER_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridGER.PageIndexChanging
        GridGER.PageIndex = e.NewPageIndex
        BindGrid(txtGER.Text.Trim, txtDateGER.Text.Trim, ddlClaimType.SelectedValue)
    End Sub

    Private Sub GridGER_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridGER.RowCommand
        If e.CommandName = "SelectGER" Then
            Try
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = GridGER.Rows(index)
                Dim myLinkButton As LinkButton


                If selectedRow.Cells(3).Text.ToUpper = "PROVIDER" Then
                    Session("claimtype") = "P"
                ElseIf selectedRow.Cells(3).Text.ToUpper = "REIMBURSMENT" Then
                    Session("claimtype") = "C"
                Else
                    Session("claimtype") = ""
                End If

                myLinkButton = selectedRow.Cells(0).Controls(0)
                Session("GER") = myLinkButton.Text
                Session("DATEGER") = selectedRow.Cells(2).Text
                Session("Payment Date") = selectedRow.Cells(7).Text
                Session("Submitted Date") = selectedRow.Cells(8).Text

                BindGridDetail(myLinkButton.Text, selectedRow.Cells(1).Text, Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)

                txtGER_NO.Text = Session("GER")
                txtGER_CreatedDate.Text = Session("DATEGER")
                txtGER_Claim_Type.Text = Session("claimtype")
                trDetailTitle.Visible = True
                trGridDetail.Visible = True
                gridDetail.Visible = True
                trButton.Visible = True
                trUpload.Visible = True
            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try

        End If
    End Sub

    Private Sub gridDetail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gridDetail.PageIndexChanging
        gridDetail.PageIndex = e.NewPageIndex
        BindGridDetail(Session("GER"), Session("DATEGER"), Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)
    End Sub

    Protected Sub btnFlips_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnFlips.Click
        Try
            Dim dt_report As New DataTable
            Dim strClaimType As String = If(Session("claimtype") <> vbNullString, Session("claimtype"), "")
            If strClaimType = "P" Then
                'SQL = "SELECT ROW_NUMBER() OVER (ORDER BY CL.LSURNAME) AS No_Urut,'' as Branch_Name,[Claim Client Ref No] as No_Claim,[Policy No] as [Policy Number]," &
                '      "CL.LSURNAME as Insured_Name,CL.LSURNAME as [Owner Name],CASE WHEN DC.BNKACKEY03 IS NULL THEN '' ELSE DC.BNKACKEY03 END as [Account No]," &
                '      "CASE WHEN CLB.BANKACCDSC IS NULL THEN '' ELSE CLB.BANKACCDSC END as [Account Name],'' as [Hubungan dgn Policy Owner]," &
                '      "CASE WHEN DC.BANKKEY03 IS NULL THEN '' ELSE DC.BANKKEY03 END as [Bank Name],Paid as Amount,0 as Tax,0 as Charges,[Total Amount] as [Net Amount]," &
                '      "CASE WHEN [Who Paid]='P' THEN 'PROVIDER' WHEN [Who Paid]='C' THEN 'REIMBURSMENT' END as [PAYMENT TYPE]," &
                '      "'' as POS,[Policy No] as [REF NO],'' as ClassSeq,[Claim Client Ref No] as DESCRIPTION,'' as Billing_Date,'' as Effective_Date,'' as Product FROM Tbl_GER G " &
                '      "LEFT JOIN CLNTPF CL ON REPLACE(G.Provorg,'''','')=CL.CLNTNUM AND CL.VALIDFLAG=1 " &
                '      "LEFT JOIN DCRBPF DC ON REPLACE(G.Provorg,'''','')=DC.CLNTNUM AND DC.VALIDFLAG=1 " &
                '      "LEFT JOIN CLBAPF CLB ON REPLACE(G.Provorg,'''','')=CLB.CLNTNUM AND CLB.VALIDFLAG=1 AND DC.BNKACKEY03=CLB.BANKACCKEY AND DC.BANKKEY03=CLB.BANKKEY " &
                '      "WHERE REPLACE(G.[GER No 1],'''','') LIKE '%" & Session("GER") & "%' " &
                '      "AND G.Transdate LIKE '%" & Session("DATEGER") & "%' AND G.[Who Paid] LIKE '%" & strClaimType & "%' ORDER BY [No_Urut] asc"
                SQL = String.Format("
SELECT
   ROW_NUMBER() OVER (
ORDER BY
   CL.LSURNAME) AS No_Urut,
   '' as Branch_Name,
   G.[Claim Client Ref No] as 'No_Invoice',
   G.[Claim No] as 'No_Claim',
   G.[Policy No] as [Policy Number],
   CL.LSURNAME as Insured_Name,
   CL.LSURNAME as [Owner Name],
   CASE
      WHEN
         DC.BNKACKEY03 IS NULL 
      THEN
         '' 
      ELSE
         DC.BNKACKEY03 
   END
   as [Account No], 
   CASE
      WHEN
         CLB.BANKACCDSC IS NULL 
      THEN
         '' 
      ELSE
         CLB.BANKACCDSC 
   END
   as [Account Name], '' as [Hubungan dgn Policy Owner], 
   CASE
      WHEN
         DC.BANKKEY03 IS NULL 
      THEN
         '' 
      ELSE
         DC.BANKKEY03 
   END
   as [Bank Name], 
--Paid as Amount, --ada permintaan utk opr.yg dibayarkan ke finance
[Total Amount] as [Amount], --ada permintaan utk opr.yg dibayarkan ke finance
0 as Tax, 
0 as Charges, 
[Total Amount] as [Net Amount], 
   CASE
      WHEN
         [Who Paid] = 'P' 
      THEN
         'PROVIDER' 
      WHEN
         [Who Paid] = 'C' 
      THEN
         'REIMBURSMENT' 
   END
   as [PAYMENT TYPE], '' as POS, [Policy No] as [REF NO], '' as ClassSeq, [Claim Client Ref No] as DESCRIPTION, '' as Billing_Date, '' as Effective_Date, '' as Product 
   ,G.[User Created] as 'User'
   ,ISNULL(BP.[CLAIMCUR],'IDR') as 'Currency' 
FROM
   Tbl_GER G 
   LEFT JOIN 
      Tbl_Bucket_Pembayaran BP 
      ON BP.[GER No 1] = G.[GER No 1]
   LEFT JOIN
      CLNTPF CL 
      ON REPLACE(G.Provorg, '''', '') = CL.CLNTNUM 
      AND CL.VALIDFLAG = 1 
   LEFT JOIN
      DCRBPF DC 
      ON REPLACE(G.Provorg, '''', '') = DC.CLNTNUM 
      AND DC.VALIDFLAG = 1 
   LEFT JOIN
      CLBAPF CLB 
      ON REPLACE(G.Provorg, '''', '') = CLB.CLNTNUM 
      AND CLB.VALIDFLAG = 1 
      AND DC.BNKACKEY03 = CLB.BANKACCKEY 
      AND DC.BANKKEY03 = CLB.BANKKEY 
WHERE
   REPLACE(G.[GER No 1], '''', '') LIKE '%{0}%' 
   AND G.Transdate LIKE '%{1}%' 
   AND G.[Who Paid] LIKE '%{2}%' 
GROUP BY  
G.[Claim Client Ref No]
,G.[Claim No]
,G.[Policy No]
,CL.LSURNAME
,DC.BNKACKEY03
,DC.BANKKEY03 
,CLB.BANKACCDSC
,G.[Total Amount]
,G.[Who Paid]
,G.[Policy No]
,G.[Claim Client Ref No]
,BP.[CLAIMCUR]
,G.[User Created]
,G.[Procedure Code] 
ORDER BY
   [No_Urut] asc
", Session("GER"), Session("DATEGER"), strClaimType)
            ElseIf strClaimType = "C" Then
                'SQL = "SELECT ROW_NUMBER() OVER (ORDER BY [Policy No]) AS No_Urut,'' as Branch_Name,[Claim No] as No_Claim,[Policy No] as [Policy Number]," &
                '      "CL.LSURNAME as Insured_Name,CL.LSURNAME as [Owner Name],CASE WHEN DC.BNKACKEY03 IS NULL THEN '' ELSE DC.BNKACKEY03 END as [Account No]," &
                '      "CASE WHEN CLB.BANKACCDSC IS NULL THEN '' ELSE CLB.BANKACCDSC END as [Account Name],'' as [Hubungan dgn Policy Owner]," &
                '      "CASE WHEN DC.BANKKEY03 IS NULL THEN '' ELSE DC.BANKKEY03 END as [Bank Name],Paid as Amount,0 as Tax,0 as Charges,[Total Amount] as [Net Amount]," &
                '      "CASE WHEN [Who Paid]='P' THEN 'PROVIDER' WHEN [Who Paid]='C' THEN 'REIMBURSMENT' END as [PAYMENT TYPE],'' as POS,[Policy No] as [REF NO]," &
                '      "'' as ClassSeq,'CORPORATE SOLUTION' as DESCRIPTION,'' as Billing_Date,'' as Effective_Date,'' as Product FROM Tbl_GER G " &
                '      "LEFT JOIN GMHDPF GM ON G.CLNTNUM=GM.CLNTNUM AND RIGHT(G.[Member No],2)=GM.DPNTNO AND G.[Policy No]=GM.CHDRNUM AND LEFT(G.[Member No],5)= GM.MBRNO LEFT JOIN CLNTPF CL ON GM.CLNTNUM=CL.CLNTNUM AND CL.VALIDFLAG=1 " &
                '      "LEFT JOIN DCRBPF DC ON G.CLNTNUM=DC.CLNTNUM AND DC.VALIDFLAG=1 LEFT JOIN CLBAPF CLB ON G.CLNTNUM=CLB.CLNTNUM AND CLB.VALIDFLAG=1 AND DC.BNKACKEY03=CLB.BANKACCKEY AND DC.BANKKEY03=CLB.BANKKEY " &
                '      "WHERE REPLACE(G.[GER No 1],'''','') LIKE '%" & Session("GER") & "%' " &
                '      "AND G.Transdate LIKE '%" & Session("DATEGER") & "%' AND G.[Who Paid] LIKE '%" & strClaimType & "%' ORDER BY [No_Urut] asc"
                SQL = String.Format("
SELECT
   ROW_NUMBER() OVER (
ORDER BY
   G.[Claim Client Ref No]) AS No_Urut,
   '' as Branch_Name,
   G.[Claim Client Ref No] as 'No_Invoice',
   G.[Claim No] as 'No_Claim',
   G.[Policy No] as [Policy Number],
   CL.LSURNAME as Insured_Name,
   CL.LSURNAME as [Owner Name],
   CASE
      WHEN
         DC.BNKACKEY03 IS NULL 
      THEN
         '' 
      ELSE
         DC.BNKACKEY03 
   END
   as [Account No], 
   CASE
      WHEN
         CLB.BANKACCDSC IS NULL 
      THEN
         '' 
      ELSE
         CLB.BANKACCDSC 
   END
   as [Account Name], '' as [Hubungan dgn Policy Owner], 
   CASE
      WHEN
         DC.BANKKEY03 IS NULL 
      THEN
         '' 
      ELSE
         DC.BANKKEY03 
   END
   as [Bank Name], 
--Paid as Amount, --ada permintaan utk opr.yg dibayarkan ke finance
[Total Amount] as [Amount], --ada permintaan utk opr.yg dibayarkan ke finance
0 as Tax, 
0 as Charges, 
[Total Amount] as [Net Amount], 
   CASE
      WHEN
         [Who Paid] = 'P' 
      THEN
         'PROVIDER' 
      WHEN
         [Who Paid] = 'C' 
      THEN
         'REIMBURSMENT' 
   END
   as [PAYMENT TYPE], '' as POS, [Policy No] as [REF NO], '' as ClassSeq, 'CORPORATE SOLUTION' as DESCRIPTION, '' as Billing_Date, '' as Effective_Date, '' as Product 
    ,G.[User Created] as 'User'
   ,ISNULL(BP.[CLAIMCUR],'IDR') as 'Currency' 

FROM
   Tbl_GER G
    LEFT JOIN 
      Tbl_Bucket_Pembayaran BP 
      ON BP.[GER No 1] = G.[GER No 1]
   LEFT JOIN
      GMHDPF GM 
      ON G.CLNTNUM = GM.CLNTNUM 
      AND RIGHT(G.[Member No], 2) = GM.DPNTNO 
      AND G.[Policy No] = GM.CHDRNUM 
      AND LEFT(G.[Member No], 5) = GM.MBRNO 
   LEFT JOIN
      CLNTPF CL 
      ON GM.CLNTNUM = CL.CLNTNUM 
      AND CL.VALIDFLAG = 1 
   LEFT JOIN
      DCRBPF DC 
      ON G.CLNTNUM = DC.CLNTNUM 
      AND DC.VALIDFLAG = 1 
   LEFT JOIN
      CLBAPF CLB 
      ON G.CLNTNUM = CLB.CLNTNUM 
      AND CLB.VALIDFLAG = 1 
      AND DC.BNKACKEY03 = CLB.BANKACCKEY 
      AND DC.BANKKEY03 = CLB.BANKKEY 
WHERE
   REPLACE(G.[GER No 1], '''', '') LIKE '%{0}%' 
   AND G.Transdate LIKE '%{1}%' 
   AND G.[Who Paid] LIKE '%{2}%' 
GROUP BY  
G.[Claim Client Ref No]
,G.[Claim No]
,G.[Policy No]
,CL.LSURNAME
,DC.BNKACKEY03
,DC.BANKKEY03 
,CLB.BANKACCDSC
,G.[Total Amount]
,G.[Who Paid]
,G.[Policy No]
,G.[Claim Client Ref No]
,BP.[CLAIMCUR]
,G.[User Created]
,G.[Procedure Code] 
ORDER BY
  G.[Claim Client Ref No],G.[Claim No]  ASC
", Session("GER"), Session("DATEGER"), strClaimType)
            End If

            dt_report = Modul.getAllDatainDT(SQL)

            If dt_report.Rows.Count > 0 Then
                'Dim sFileName As String = ""

                'Dim sysdate As Date = Date.Now.Date

                'If dt_report.Rows(0).Item(14).ToString.ToUpper = "PROVIDER" Then
                '    sFileName = "Upload.xls"
                'ElseIf dt_report.Rows(0).Item(14).ToString.ToUpper = "REIMBURSMENT" Then
                '    sFileName = "Upload.xls"
                'End If

                'Dim GridView1 As New GridView()
                'GridView1.AllowPaging = False
                'GridView1.DataSource = dt_report
                'GridView1.DataBind()

                'Response.Clear()
                'Response.Buffer = True
                'Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                'Response.Charset = ""
                'Response.Cache.SetCacheability(HttpCacheability.NoCache)
                'Me.EnableViewState = False
                'Response.ContentType = "application/vnd.ms-excel"

                'Dim StringWrite As New System.IO.StringWriter
                'Dim HtmlWrite As New System.Web.UI.HtmlTextWriter(StringWrite)

                'For Each r As GridViewRow In GridView1.Rows
                '    If r.RowType = DataControlRowType.DataRow Then
                '        For columnIndex As Integer = 0 To r.Cells.Count - 1
                '            r.Cells(columnIndex).Attributes.Add("class", "text")
                '        Next
                '    End If
                'Next

                'GridView1.RenderControl(HtmlWrite)

                'Response.AddHeader("X-Download-Options", "noopen")

                ''Remove the charset from the Content-Type header.
                'Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                'Response.Write(style)

                'Response.Write(StringWrite.ToString())
                'Response.End()

                Response.Clear()
                Response.Charset = ""
                Response.ContentEncoding = System.Text.Encoding.UTF8
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                Dim strDateNow As String = Now.ToString("yyyyMMdd_HHmmss")
                Response.AddHeader("content-disposition", "attachment;filename=Doc_Flips_" + Session("GER") + "_" + strDateNow + ".xlsx")
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial
                'Writing the excel file
                Using excelPack = New ExcelPackage()

                    Dim ws As ExcelWorksheet = excelPack.Workbook.Worksheets.Add("Doc_Flips_" + Session("GER") + "_" + strDateNow)
                    ws.Cells("A1").LoadFromDataTable(dt_report, True)
                    ws.Cells(ws.Dimension.Address).AutoFitColumns()
                    ' Assign borders
                    ws.Cells(ws.Dimension.Address).Style.Border.Top.Style = ExcelBorderStyle.Thin
                    ws.Cells(ws.Dimension.Address).Style.Border.Left.Style = ExcelBorderStyle.Thin
                    ws.Cells(ws.Dimension.Address).Style.Border.Right.Style = ExcelBorderStyle.Thin
                    ws.Cells(ws.Dimension.Address).Style.Border.Bottom.Style = ExcelBorderStyle.Thin

                    'Column Alligment -> Amount, Discount, Total Amount
                    ws.Column(11).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    ws.Column(14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right

                    'Header style
                    ws.Cells(1, 1, 1, 25).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws.Cells(1, 1, 1, 25).Style.Font.Bold = True

                    Dim MS As New System.IO.MemoryStream()
                    excelPack.SaveAs(MS)
                    MS.WriteTo(HttpContext.Current.Response.OutputStream)
                End Using
                Response.Flush()
                Response.End()


            End If

        Catch ex As Exception

            'MsgBox(ex.Message)
            'Throw (ex)

        End Try
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click
        BindGrid(txtGER.Text.Trim, txtDateGER.Text.Trim, ddlClaimType.SelectedValue)
    End Sub

    Protected Sub btnSearchDetail_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearchDetail.Click
        BindGridDetail(Session("GER"), Session("DATEGER"), Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)
    End Sub

    Private Sub gridDetail_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles gridDetail.PreRender
        If Me.gridDetail.EditIndex <> -1 Then
            Dim txtGER As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtGER"), TextBox)
            Dim txtDateGERCreated As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtDateGERCreated"), TextBox)
            Dim txtClaimType As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtClaimType"), TextBox)
            Dim txtClaimNumber As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtClaimNumber"), TextBox)
            Dim txtServiceCode As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtServiceCode"), TextBox)
            Dim txtInvoiceNumber As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtInvoiceNumber"), TextBox)
            Dim txtPolicyNumber As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtPolicyNumber"), TextBox)
            Dim txtMemberNo As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtMemberNo"), TextBox)
            Dim txtMemberName As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtMemberName"), TextBox)
            Dim txtPatientNo As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtPatientNo"), TextBox)
            Dim txtPatientName As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtPatientName"), TextBox)
            Dim txtAmount As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtAmount"), TextBox)
            Dim txtDiscount As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtDiscount"), TextBox)
            Dim txtTotalAmount As TextBox = DirectCast(gridDetail.Rows(gridDetail.EditIndex).FindControl("txtTotalAmount"), TextBox)

            If txtGER IsNot Nothing Then
                txtGER.Enabled = False
            End If
            If txtDateGERCreated IsNot Nothing Then
                txtDateGERCreated.Enabled = False
            End If
            If txtClaimType IsNot Nothing Then
                txtClaimType.Enabled = False
            End If
            If txtClaimNumber IsNot Nothing Then
                txtClaimNumber.Enabled = False
            End If
            If txtServiceCode IsNot Nothing Then
                txtServiceCode.Enabled = False
            End If
            If txtInvoiceNumber IsNot Nothing Then
                txtInvoiceNumber.Enabled = False
            End If
            If txtPolicyNumber IsNot Nothing Then
                txtPolicyNumber.Enabled = False
            End If
            If txtMemberNo IsNot Nothing Then
                txtMemberNo.Enabled = False
            End If
            If txtMemberName IsNot Nothing Then
                txtMemberName.Enabled = False
            End If
            If txtPatientNo IsNot Nothing Then
                txtPatientNo.Enabled = False
            End If
            If txtPatientName IsNot Nothing Then
                txtPatientName.Enabled = False
            End If
            If txtAmount IsNot Nothing Then
                txtAmount.Enabled = False
            End If
            'If txtDiscount IsNot Nothing Then
            '    txtDiscount.Enabled = False
            'End If
            If txtTotalAmount IsNot Nothing Then
                txtTotalAmount.Enabled = False
            End If

        End If
    End Sub

    Private Sub gridDetail_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles gridDetail.RowCancelingEdit
        gridDetail.EditIndex = -1
        BindGridDetail(Session("GER"), Session("DATEGER"), Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)
    End Sub

    Private Sub gridDetail_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles gridDetail.RowDeleting
        Dim CLIENTNUMBER As String = gridDetail.DataKeys(e.RowIndex).Values("Claim Number").ToString()
        Dim SQL2 As String

        If Trim(Session("Payment Date")) = "&nbsp;" And Trim(Session("Submitted Date")) = "&nbsp;" Then
            Try
                SQL = ""

                SQL = "Delete Tbl_GER where [Claim No]='" & CLIENTNUMBER & "' AND [GER No 1] = '" & Session("GER") & "';"
                SQL2 = "Update Tbl_Bucket_Pembayaran set [STATUS GER]='0' where [CLAMNUM]='" & Left(CLIENTNUMBER, 8) & "' AND [GCOCCNO]='" & Right(CLIENTNUMBER, 2) & "' AND [GER No 1] = '" & Session("GER") & "';"


                Modul.Eksekusi(SQL)
                Modul.Eksekusi(SQL2)
                Modul.UserMsgBox(Me, "Deleted Complete !!")
                BindGridDetail(Session("GER"), Session("DATEGER"), Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)
                BindGrid(txtGER.Text.Trim, txtDateGER.Text.Trim, ddlClaimType.SelectedValue)

            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try
        End If



    End Sub
    Private Sub gridDetail_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles gridDetail.RowEditing
        gridDetail.EditIndex = -1
        If Session("claimtype") = "P" And Trim(Session("Payment Date")) = "&nbsp;" And Trim(Session("Submitted Date")) = "&nbsp;" Then
            gridDetail.EditIndex = e.NewEditIndex
            BindGridDetail(Session("GER"), Session("DATEGER"), Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)
            'Else
            '    BindGridDetail(Session("GER"), Session("DATEGER"), Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)
        End If

    End Sub

    'Private Sub gridDetail_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles gridDetail.RowUpdating
    '    Dim GER As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtGER"), TextBox)
    '    Dim ClaimNumber As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtClaimNumber"), TextBox)
    '    Dim ServiceCode As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtServiceCode"), TextBox)
    '    Dim Discount As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtDiscount"), TextBox)
    '    Dim Amount As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtAmount"), TextBox)

    '    SQL = ""
    '    If Discount.Text = "" Then
    '        Discount.Text = "0"
    '    End If

    '    SQL = "UPDATE Tbl_GER SET Discount=" & Discount.Text & ", [Total Amount]=" & Amount.Text - Discount.Text & " " &
    '          "WHERE REPLACE([GER No 1],'''','') LIKE '%" & GER.Text & "%' AND [Claim No] LIKE '%" & ClaimNumber.Text & "%' " &
    '          "AND [Procedure Code] LIKE '%" & ServiceCode.Text & "%' AND Paid LIKE '%" & Replace(Replace(Amount.Text, ",", ""), ".00", "") & "%'"

    '    If SQL <> "" Then
    '        Try
    '            Modul.Eksekusi(SQL)
    '            Modul.UserMsgBox(Me, "Updated Complete ")
    '            gridDetail.EditIndex = -1
    '            BindGridDetail(Session("GER"), Session("DATEGER"), Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)
    '            BindGrid(txtGER.Text.Trim, txtDateGER.Text.Trim, ddlClaimType.SelectedValue)

    '        Catch ex As Exception
    '            MsgBox(ex.Message)
    '            Throw (ex)
    '        End Try
    '    End If
    'End Sub
    Private Sub gridDetail_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles gridDetail.RowUpdating
        Dim GER As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtGER"), TextBox)
        Dim ClaimNumber As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtClaimNumber"), TextBox)
        Dim ServiceCode As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtServiceCode"), TextBox)
        Dim Discount As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtDiscount"), TextBox)
        Dim Amount As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtAmount"), TextBox)
        Dim TransDate As TextBox = DirectCast(gridDetail.Rows(e.RowIndex).FindControl("txtDateGERCreated"), TextBox)

        SQL = ""
        If Discount.Text = "" Then
            Discount.Text = "0"
        End If

        Dim dDisc As Decimal = 0
        dDisc = Convert.ToDecimal(Discount.Text)

        Try
            Update_GER_By_SP(GER.Text, ClaimNumber.Text, ServiceCode.Text, TransDate.Text, dDisc)
            Modul.UserMsgBox(Me, "Updated Complete ")
            gridDetail.EditIndex = -1
            BindGridDetail(Session("GER"), Session("DATEGER"), Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)
            BindGrid(txtGER.Text.Trim, txtDateGER.Text.Trim, ddlClaimType.SelectedValue)

        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try

    End Sub
    Private Sub Update_GER_By_SP(strGER_NO As String, strClaim_No As String, strService_Code As String, strTrans_Date As String, dDiscount As Decimal)

        Dim xParam(4) As SqlClient.SqlParameter

        xParam(0) = New SqlClient.SqlParameter("@GER_No", SqlDbType.VarChar)
        xParam(0).Value = CType(strGER_NO, String)

        xParam(1) = New SqlClient.SqlParameter("@Claim_No", SqlDbType.VarChar)
        xParam(1).Value = CType(strClaim_No, String)

        xParam(2) = New SqlClient.SqlParameter("@Service_Code", SqlDbType.VarChar)
        xParam(2).Value = CType(strService_Code, String)

        xParam(3) = New SqlClient.SqlParameter("@Trans_Date", SqlDbType.VarChar)
        xParam(3).Value = CType(strTrans_Date, String)

        xParam(4) = New SqlClient.SqlParameter("@Disc", SqlDbType.VarChar)
        xParam(4).Value = CType(dDiscount, String)


        Try
            Dim strConn As String = ConfigurationManager.ConnectionStrings("ConSql").ConnectionString
            Modul.ExecuteNonQuery(strConn, "sp_Update_GER_Discount", CommandType.StoredProcedure, xParam)

        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try

    End Sub

    Protected Sub btn_Upload_File_Click(sender As Object, e As EventArgs) Handles btn_Upload_File.Click
        'Checking file content length and Extension must be .xlsx  
        If (fu_Update_Discount.HasFile AndAlso IO.Path.GetExtension(fu_Update_Discount.FileName) = ".xlsx") Then
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial
            Using excel = New ExcelPackage(fu_Update_Discount.PostedFile.InputStream)
                Dim tbl = New DataTable()
                Dim ws = excel.Workbook.Worksheets.First()
                Dim hasHeader = True ' change it if required '
                ' create DataColumns '
                For Each firstRowCell In ws.Cells(1, 1, 1, ws.Dimension.End.Column)
                    tbl.Columns.Add(If(hasHeader,
                                       firstRowCell.Text,
                                       String.Format("Column {0}", firstRowCell.Start.Column)))
                Next
                ' add rows to DataTable '
                Dim startRow = If(hasHeader, 2, 1)
                For rowNum = startRow To ws.Dimension.End.Row
                    Dim wsRow = ws.Cells(rowNum, 1, rowNum, ws.Dimension.End.Column)
                    Dim row = tbl.NewRow()
                    For Each cell In wsRow
                        row(cell.Start.Column - 1) = cell.Text
                    Next
                    tbl.Rows.Add(row)
                Next
                Dim iColumnCheck As Integer = 0
                Dim lstColumn As New List(Of String)
                lstColumn.Add("GER")
                lstColumn.Add("Date GER Created")
                lstColumn.Add("Claim Type")
                lstColumn.Add("Claim Number")
                lstColumn.Add("Service Code")
                lstColumn.Add("Invoice Number")
                lstColumn.Add("Policy Number")
                lstColumn.Add("Member No")
                lstColumn.Add("Member Name")
                lstColumn.Add("Patient No")
                lstColumn.Add("Patient Name")
                lstColumn.Add("Amount")
                lstColumn.Add("Discount")
                lstColumn.Add("Total Amount")

                If (hasHeader = True And tbl.Rows.Count() > 0) Then
                    ' check column 
                    If (tbl.Columns.Count = lstColumn.Count) Then
                        Dim iColumnIndex As Integer = 0
                        For Each Column As DataColumn In tbl.Columns
                            If (lstColumn.Item(iColumnIndex) = Column.ColumnName) Then
                                iColumnCheck = iColumnCheck + 1
                            End If
                            iColumnIndex = iColumnIndex + 1
                        Next
                    End If
                End If

                If (iColumnCheck = tbl.Columns.Count) Then
                    'Update disc to GER via sp_Update_GER_Discount
                    Dim iRowsUpdate As Integer = 0
                    For Each Row As DataRow In tbl.Rows
                        'Dim strGer_No As String = Session("GER").ToString().Trim
                        Dim strGer_No As String = Row.Item("GER").ToString().Trim
                        If (strGer_No = Session("GER").ToString().Trim) Then
                            Dim strTransDate As String = Row.Item("Date GER Created").ToString().Trim
                            Dim strCliam_No As String = Row.Item("Claim Number").ToString().Trim
                            Dim strPro_Code As String = Row.Item("Service Code").ToString().Trim
                            Dim strDiscount As String = IIf(Row.Item("Discount").ToString() = "", 0, Row.Item("Discount").ToString().Trim)
                            Dim strTotal As String = IIf(Row.Item("Total Amount").ToString() = "", 0, Row.Item("Total Amount").ToString().Trim)
                            Dim dDisc As Decimal = 0
                            dDisc = Convert.ToDecimal(strDiscount)
                            'Dim dTot As Decimal = 0
                            'dTot = Convert.ToDecimal(strTotal)

                            Update_GER_By_SP(strGer_No, strCliam_No, strPro_Code, strTransDate, dDisc)
                            iRowsUpdate = iRowsUpdate + 1
                            UploadStatusLabel.Text = String.Format("Proses Update row : {0}/{1}", iRowsUpdate, iColumnCheck)
                        End If
                    Next
                    'If (iRowsUpdate = tbl.Rows.Count) Then
                    '    Modul.UserMsgBox(Me, "Updated Complete")
                    '    Dim msg = String.Format("Update successfully created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3} Tot.Update : {4}/{1}",
                    '                   tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count, iRowsUpdate)
                    '    UploadStatusLabel.Text = msg
                    'Else
                    '    Modul.UserMsgBox(Me, "Updated Complete")
                    '    Dim msg = String.Format("Update successfully created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3} Tot.Update : {4}/{1}",
                    '                   tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count, iRowsUpdate)
                    '    UploadStatusLabel.Text = msg
                    'End If
                    Dim dCount As Double = 0
                    dCount = (iRowsUpdate / tbl.Rows.Count) * 100

                    Modul.UserMsgBox(Me, String.Format("Updated Complete :{0}%", dCount))
                    Dim msg = String.Format("Update successfully created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3} Tot.Update : {4}/{1}",
                                   tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count, iRowsUpdate)
                    UploadStatusLabel.Text = msg

                    gridDetail.EditIndex = -1
                    BindGridDetail(Session("GER"), Session("DATEGER"), Session("claimtype"), txtClaim.Text.Trim, txtInvoice.Text.Trim, txtServiceCode.Text.Trim)
                    BindGrid(txtGER.Text.Trim, txtDateGER.Text.Trim, ddlClaimType.SelectedValue)

                Else
                    Modul.UserMsgBox(Me, "Updated Failed")
                    Dim msg = String.Format("Update fail created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3}",
                    tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count)
                    UploadStatusLabel.Text = msg
                End If


            End Using
        Else
            If (fu_Update_Discount.HasFile) Then
                Modul.UserMsgBox(Me, "Please Select a File Excel .xlsx only.")
                UploadStatusLabel.Text = "Not right format Excel-file."
            Else
                Modul.UserMsgBox(Me, "Please Select a File first.")
                UploadStatusLabel.Text = "None Excel-file."
            End If
        End If
    End Sub

    Protected Sub btn_Template_Click(sender As Object, e As EventArgs) Handles btn_Template.Click

        Dim dtDetails = New DataTable()
        dtDetails = Session("DataDetails")
        If (dtDetails.Rows.Count > 0) Then
            Response.Clear()
            Response.Charset = ""
            Response.ContentEncoding = System.Text.Encoding.UTF8
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;filename=GridDataDetail_" + Session("GER") + ".xlsx")
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial
            'Writing the excel file
            Using excelPack = New ExcelPackage()

                'Session("GER"), Session("DATEGER"), Session("claimtype")
                Dim ws As ExcelWorksheet = excelPack.Workbook.Worksheets.Add("GridDataDetail_" + Session("GER") + ".xlsx")
                ws.Cells("A1").LoadFromDataTable(dtDetails, True)
                ws.Cells(ws.Dimension.Address).AutoFitColumns()

                'fill formula auto sum column 12, 13 at 14
                For index As Integer = 1 To dtDetails.Rows.Count
                    Dim mCell = ws.Cells(index + 1, 14)
                    mCell.Formula = String.Format("=({0}-{1})", ws.Cells(index + 1, 12).Address, ws.Cells(index + 1, 13).Address)
                Next

                'Column Alligment -> Amount, Discount, Total Amount
                ws.Column(12).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                ws.Column(13).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                ws.Column(14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right

                'Column Style
                ws.Column(13).Style.Fill.PatternType = ExcelFillStyle.Solid
                ws.Column(13).Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightYellow)
                ''number format
                ws.Column(12).Style.Numberformat.Format = "#,##0.#0"
                ws.Column(13).Style.Numberformat.Format = "#,##0.#0"
                ws.Column(14).Style.Numberformat.Format = "#,##0.#0"

                'Header style
                ws.Cells(1, 1, 1, 14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                ws.Cells(1, 1, 1, 14).Style.Font.Bold = True

                'Lock
                'ws.Protection.SetPassword("Ax@t0wer123")
                'ws.Protection.IsProtected = True '--------Protect whole sheet
                'ws.Column(13).Style.Locked = False '-------Unlock 3Rd column


                Dim MS As New System.IO.MemoryStream()
                excelPack.SaveAs(MS)
                MS.WriteTo(HttpContext.Current.Response.OutputStream)
            End Using
            Response.Flush()
            Response.End()
        End If
    End Sub

    Protected Sub btnDeleteGER_Click(sender As Object, e As EventArgs) Handles btnDeleteGER.Click
        Try
            Dim strGER As String = Session("GER").ToString().Trim
            If strGER.Length > 0 Then
                Dim strQueryRollBack As String = ""
                strQueryRollBack = strQueryRollBack + String.Format("delete From [dbo].[Tbl_GER] Where [GER No 1] in ({0});", strGER)
                strQueryRollBack = strQueryRollBack + String.Format("UPDATE [dbo].Tbl_Bucket_Pembayaran Set [STATUS GER] = 0, [Ger No 1]= '' WHERE [GER No 1] in ({0});", strGER)
                Obj_Insert.f_Execute_Text_Transaction(strQueryRollBack)
                ' Modul.UserMsgBox(Me, "Delete GER : '" + strGER + "' Sukses")
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "alert('Delete GER : " + strGER + " Sukses');window.location='ReportGER.aspx';", True)
            End If

        Catch ex As Exception

        End Try

    End Sub

    Protected Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='ReportGER.aspx';", True)
    End Sub

    Private Function Export_GER_To_Excel_By_SP(strGER_NO As String) As DataTable
        Dim dtRet = New DataTable
        Dim xParam(0) As SqlClient.SqlParameter

        xParam(0) = New SqlClient.SqlParameter("@GER_No", SqlDbType.VarChar)
        xParam(0).Value = CType(strGER_NO, String)

        Try
            Dim strConn As String = ConfigurationManager.ConnectionStrings("ConSql").ConnectionString
            'Modul.ExecuteNonQuery(strConn, "sp_Export_GER_To_Excel", CommandType.StoredProcedure, xParam)
            dtRet = Modul.FillDataset("sp_Export_GER_To_Excel", CommandType.StoredProcedure, xParam)
        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try
        Return dtRet
    End Function
End Class
