﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Reflection
Imports System
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Web
Imports System.IO
Imports Ionic.Zip
Imports System.Threading

Partial Public Class ReportTransaction
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Dim dr As SqlDataReader
    Dim dt_mbrNo As New System.Data.DataTable
    Dim oSelect As New SelectBase
    Dim oInsert As New InsertBase
    Dim CrystalReportViewer1 As New CrystalDecisions.Web.CrystalReportViewer
    Dim fundtype As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            CalendarExtender3.StartDate = DateTime.ParseExact("02092021", "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture)
            CalendarExtender4.StartDate = DateTime.ParseExact("02092021", "ddMMyyyy", System.Globalization.CultureInfo.InvariantCulture)

            DropFill_FundType()
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If

        'btnPreview.Attributes.Add("onclick", "jvPopup();return false;")
    End Sub
    Public Sub DropFill_FundType()
        Dim ListTemp As ListItem

        ddlFundType.Items.Clear()
        ListTemp = New ListItem("All", "")
        ddlFundType.Items.Add(ListTemp)

        SQL = "SELECT DISTINCT DESCPF_TR93U_LONGDESC,ACTRPF_INVFCDE FROM IDAS_CORPSOL_TRANSACTION WHERE ACTRPF_INVFCDE NOT IN ('IN','UH') " & _
              "ORDER BY ACTRPF_INVFCDE"


        dr = Modul.getAllDatainDR(SQL)

        While dr.Read
            ListTemp = New ListItem(dr(1), dr(0))
            ddlFundType.Items.Add(ListTemp)
        End While

        dr.Close()
        Modul.SQLCn.Close()

    End Sub
    Public Sub BindGridTransaction(ByVal fund As String)

        SQL = "SELECT * FROM Tmp_Transaction_New_Report where [fund type] LIKE '%" & fund & "%' ORDER BY MemberNo"

        Modul.SubBindGridView(SQL, GridTransaction)

    End Sub
    Protected Sub ddlFundType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFundType.SelectedIndexChanged
        txtLongDesc.Text = ddlFundType.SelectedValue.ToString
        Session("FundType") = ddlFundType.SelectedItem.Text

        If ddlReportLevel.SelectedValue.ToString = "Member Level" Then
            If ddlFundType.SelectedItem.Text = "All" Then
                fundtype = ""
            Else
                fundtype = ddlFundType.SelectedItem.Text
            End If

            BindGridTransaction(IIf(ddlFundType.SelectedValue = "All", "", ddlFundType.SelectedValue))
        End If

    End Sub
    Protected Sub ddlReportLevel_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlReportLevel.SelectedIndexChanged
        If ddlReportLevel.SelectedValue.ToString = "Member Level" Then
            lblMember.Visible = True
            txtMemberName.Visible = True
            lblTemplate.Visible = True
            ddlTemplate.Visible = True

            If ddlTemplate.SelectedItem.Text = "New Report" Then
                GridTransaction.Visible = True
            Else
                GridTransaction.Visible = False
            End If

        Else
            lblTemplate.Visible = False
            ddlTemplate.Visible = False
            lblMember.Visible = False
            txtMemberName.Visible = False
            GridTransaction.Visible = False
        End If
    End Sub
    Protected Sub txtPolis_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtPolis.TextChanged
        Dim dt_Polis As New System.Data.DataTable
        Dim ListTemp As ListItem

        If Len(txtPolis.Text) = 8 Then
            dt_Polis = oSelect.sp_Get_Type_Polis(txtPolis.Text)

            If dt_Polis.Rows.Count = 0 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportTransaction.aspx';", True)
                Exit Sub
            End If
            Session("Type") = dt_Polis.Rows(0)("Type").ToString

            If Session("Type") = "DCI" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
                ddlReportLevel.Items.Add("Member Level")
            ElseIf Session("Type") = "DBE" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportTransaction.aspx';", True)
            End If

            ddlFundType.Items.Clear()
            ListTemp = New ListItem("All", "All")
            ddlFundType.Items.Add(ListTemp)

            For x = 0 To dt_Polis.Rows.Count - 1
                ListTemp = New ListItem(dt_Polis.Rows(x)("Fund"), dt_Polis.Rows(x)("Description"))
                ddlFundType.Items.Add(ListTemp)
            Next

            txtLongDesc.Text = ddlFundType.SelectedValue.ToString

        End If
    End Sub
    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click
        Try

            'Dim dateFrom As DateTime
            'Dim dateTo As DateTime
            Dim sFileName As String = ""

            'dateFrom = CDate(Right(txtFrom.Text, 4) & "-" & Mid(txtFrom.Text, 4, 2) & "-" & Left(txtFrom.Text, 2))
            'dateTo = CDate(Right(txtTo.Text, 4) & "-" & Mid(txtTo.Text, 4, 2) & "-" & Left(txtTo.Text, 2))

            If txtFrom.Text.Trim = "" Or txtTo.Text.Trim = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Tidak Boleh Kosong.'); window.location='ReportTransaction.aspx';", True)
                Exit Sub
                'ElseIf dateTo > dateFrom.AddMonths(1) Then
                '    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                '    "alert('Transaction Date Melebihi Periode Yang Ditentukan.'); window.location='ReportTransaction.aspx';", True)
                '    Exit Sub
            ElseIf txtPolis.Text = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Police Number Tidak Boleh Kosong.'); window.location='ReportTransaction.aspx';", True)
                Exit Sub
            End If

            If ddlFundType.SelectedItem.Text = "All" Then
                fundtype = ""
            Else
                fundtype = ddlFundType.SelectedItem.Text
            End If

            DebugLogger.WriteLog(String.Format("{0},{1},{2},{3},{4},{5}", txtFrom.Text, txtTo.Text, txtPolis.Text, "", fundtype, ddlReportLevel.SelectedItem.Text))
            If ddlTemplate.SelectedItem.Text = "Default Report" Then
                Default_Report(fundtype)
            ElseIf ddlTemplate.SelectedItem.Text = "New Report" Then
                New_Report(fundtype)
            End If

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try

    End Sub
    Public Sub Default_Report(ByVal fundtype As String)
        Dim crystalReport As New ReportDocument()
        Dim sName As String
        Dim dtReport As New DataTable
        Dim dtSubReport As New DataTable


        crystalReport.Load(Server.MapPath("~/Report/Report_Transaction.rpt"))

        If ddlReportLevel.SelectedItem.Text = "Policy Level" Then

            sName = txtPolis.Text
            dtReport.Clear()
            dtReport = oSelect.sp_Report_Transaction(txtFrom.Text, txtTo.Text, txtPolis.Text, "", fundtype, ddlReportLevel.SelectedItem.Text)
            dtSubReport.Clear()
            dtSubReport = oSelect.sp_Sub_Report_Transaction(txtFrom.Text, txtTo.Text, fundtype, txtPolis.Text)


            If dtReport.Rows.Count > 0 Then

                crystalReport.SetParameterValue(0, txtFrom.Text)
                crystalReport.SetParameterValue(1, txtTo.Text)
                crystalReport.SetParameterValue(2, txtPolis.Text)
                crystalReport.SetParameterValue(3, "")
                crystalReport.SetParameterValue(4, fundtype)
                crystalReport.SetParameterValue(5, ddlReportLevel.SelectedItem.Text)

                crystalReport.SetDataSource(dtReport)
                crystalReport.Subreports(0).SetDataSource(dtSubReport)

                CrystalReportViewer1.HasExportButton = "True"
                CrystalReportViewer1.ReportSourceID = "CrystalReportSource1"
                CrystalReportViewer1.ReportSource = crystalReport

                Dim formatType As ExportFormatType = ExportFormatType.PortableDocFormat
                formatType = ExportFormatType.PortableDocFormat

                Response.AddHeader("X-Download-Options", "noopen")

                crystalReport.ExportToHttpResponse(formatType, Response, True, sName)

                Response.[End]()
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan.'); window.location='ReportTransaction.aspx';", True)
            End If
        Else
            dt_mbrNo = oSelect.sp_Get_MemberNo(txtFrom.Text, txtTo.Text, txtPolis.Text, txtMemberName.Text, fundtype)

            If dt_mbrNo.Rows.Count > 0 Then

                For z = 0 To dt_mbrNo.Rows.Count - 1
                    sName = txtPolis.Text & " - " & dt_mbrNo.Rows(z)("MBRNO") & ".pdf"

                    dtReport.Clear()
                    dtReport = oSelect.sp_Report_Transaction(txtFrom.Text, txtTo.Text, txtPolis.Text, dt_mbrNo.Rows(z)("MBRNO"), fundtype, ddlReportLevel.SelectedItem.Text)
                    dtSubReport.Clear()
                    dtSubReport = oSelect.sp_Sub_Report_Transaction_Member(txtFrom.Text, txtTo.Text, fundtype, txtPolis.Text, dt_mbrNo.Rows(z)("MBRNO"))

                    DebugLogger.WriteLog(String.Format("{0},{1},{2},{3},{4},{5}", txtFrom.Text, txtTo.Text, txtPolis.Text, dt_mbrNo.Rows(z)("MBRNO"), fundtype, ddlReportLevel.SelectedItem.Text))

                    crystalReport.SetParameterValue(0, txtFrom.Text)
                    crystalReport.SetParameterValue(1, txtTo.Text)
                    crystalReport.SetParameterValue(2, txtPolis.Text)
                    crystalReport.SetParameterValue(3, dt_mbrNo.Rows(z)("MBRNO"))
                    crystalReport.SetParameterValue(4, ddlFundType.SelectedItem.Text)
                    crystalReport.SetParameterValue(5, ddlReportLevel.SelectedItem.Text)

                    crystalReport.SetDataSource(dtReport)
                    crystalReport.Subreports(0).SetDataSource(dtSubReport)

                    CrystalReportViewer1.HasExportButton = "True"
                    CrystalReportViewer1.ReportSourceID = "CrystalReportSource1"
                    CrystalReportViewer1.ReportSource = crystalReport

                    Dim formatType As ExportFormatType = ExportFormatType.PortableDocFormat
                    formatType = ExportFormatType.PortableDocFormat

                    crystalReport.ExportToDisk(formatType, Server.MapPath("~/File/" & sName))

                Next

                Using zip As New ZipFile()
                    zip.AlternateEncodingUsage = ZipOption.AsNecessary
                    zip.AddDirectoryByName("TransactionReport")

                    For x = 0 To dt_mbrNo.Rows.Count - 1

                        sName = txtPolis.Text & " - " & dt_mbrNo.Rows(x)("MBRNO") & ".pdf"
                        Dim spath As String = Server.MapPath("~/File/" & sName)

                        zip.AddFile(spath, "TransactionReport")
                    Next

                    Response.Clear()
                    Response.Buffer = True
                    Response.AddHeader("Content-Disposition", "inline; filename=" + "TransactionReport.Zip")
                    Response.Charset = ""
                    Response.Cache.SetCacheability(HttpCacheability.NoCache)
                    Me.EnableViewState = False
                    Response.ContentType = "application/zip"

                    Response.AddHeader("X-Download-Options", "noopen")

                    'Remove the charset from the Content-Type header.
                    Dim style As String = "<style> .text { mso-number-format:\@; } </style> "

                    zip.Save(Response.OutputStream)

                    Dim filePaths() As String = Directory.GetFiles(Server.MapPath("~/File/"))

                    For Each filePath As String In filePaths
                        File.Delete(filePath)
                    Next

                    Response.End()

                End Using
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan.'); window.location='ReportTransaction.aspx';", True)
            End If

        End If
    End Sub

    Public Sub New_Report(ByVal fundtype As String)
        Dim crystalReport As New ReportDocument()
        Dim rSections As Sections
        Dim rSection As Section
        Dim sReportObjects As ReportObjects
        Dim sReportObject As ReportObject
        Dim subReportObject As SubreportObject
        Dim subReportDoc As ReportDocument
        Dim sName As String
        Dim dtReport As New DataTable
        Dim dtSubReport_ContributionType As New DataTable
        Dim dtSubReport_FundType As New DataTable
        Dim dtSubReport_TransactionNew As New DataTable
        Dim txtPeriode As TextObject
        Dim txtRincian As TextObject

        crystalReport.Load(Server.MapPath("~/Report/Report_Transaction_New.rpt"))

        dt_mbrNo = oSelect.sp_Get_MemberNo(txtFrom.Text, txtTo.Text, txtPolis.Text, txtMemberName.Text, fundtype)

        If dt_mbrNo.Rows.Count > 0 Then

            For z = 0 To dt_mbrNo.Rows.Count - 1
                sName = txtPolis.Text & " - " & dt_mbrNo.Rows(z)("MBRNO") & ".pdf"

                dtReport.Clear()
                dtReport = oSelect.sp_New_Report_Transaction(txtFrom.Text, txtTo.Text, txtPolis.Text, dt_mbrNo.Rows(z)("MBRNO"), fundtype)

                dtSubReport_ContributionType.Clear()
                dtSubReport_ContributionType = oSelect.sp_Sub_New_Report_Transaction_Contribution_Type(txtFrom.Text, txtTo.Text, txtPolis.Text, dt_mbrNo.Rows(z)("MBRNO"), fundtype)

                dtSubReport_FundType.Clear()
                dtSubReport_FundType = oSelect.sp_Sub_New_Report_Transaction_Fund(txtPolis.Text, txtFrom.Text, txtTo.Text)

                dtSubReport_TransactionNew.Clear()
                dtSubReport_TransactionNew = oSelect.sp_Sub_New_Report_Transaction(txtFrom.Text, txtTo.Text, txtPolis.Text, dt_mbrNo.Rows(z)("MBRNO"), fundtype)

                txtPeriode = crystalReport.ReportDefinition.ReportObjects("txtPeriode")
                txtPeriode.Text = txtFrom.Text & " - " & txtTo.Text


                rSections = crystalReport.ReportDefinition.Sections


                For Each rSection In rSections

                    sReportObjects = rSection.ReportObjects

                    For Each sReportObject In sReportObjects

                        If sReportObject.Kind = ReportObjectKind.SubreportObject Then

                            SubreportObject = sReportObject

                            subReportDoc = SubreportObject.OpenSubreport(SubreportObject.SubreportName)

                            If subReportDoc.Name = "Presentase" Then
                                txtRincian = subReportDoc.ReportDefinition.ReportObjects.Item("txtRincian")

                                txtRincian.Text = "RINGKASAN PORTOFOLIO ANDA PER TANGGAL " & txtTo.Text & " :"
                            End If
                            

                        End If

                    Next

                Next




                'crystalReport.SetParameterValue(0, txtFrom.Text)
                'crystalReport.SetParameterValue(1, txtTo.Text)
                'crystalReport.SetParameterValue(2, txtPolis.Text)
                'crystalReport.SetParameterValue(3, dt_mbrNo.Rows(z)("MBRNO"))
                'crystalReport.SetParameterValue(4, ddlFundType.SelectedItem.Text)
                'crystalReport.SetParameterValue(5, ddlReportLevel.SelectedItem.Text)

                crystalReport.SetDataSource(dtReport)
                crystalReport.Subreports("Contribution_Type").SetDataSource(dtSubReport_ContributionType)
                crystalReport.Subreports("fund_type").SetDataSource(dtSubReport_FundType)
                crystalReport.Subreports("Presentase").SetDataSource(dtSubReport_TransactionNew)
                crystalReport.Subreports("Market_Value").SetDataSource(dtSubReport_TransactionNew)

                CrystalReportViewer1.HasExportButton = "True"
                CrystalReportViewer1.ReportSourceID = "CrystalReportSource1"
                CrystalReportViewer1.ReportSource = crystalReport

                Dim formatType As ExportFormatType = ExportFormatType.PortableDocFormat
                formatType = ExportFormatType.PortableDocFormat

                crystalReport.ExportToDisk(formatType, Server.MapPath("~/File/" & sName))

            Next

            Using zip As New ZipFile()
                zip.AlternateEncodingUsage = ZipOption.AsNecessary
                zip.AddDirectoryByName("NewTransactionReport")

                For x = 0 To dt_mbrNo.Rows.Count - 1

                    sName = txtPolis.Text & " - " & dt_mbrNo.Rows(x)("MBRNO") & ".pdf"
                    Dim spath As String = Server.MapPath("~/File/" & sName)

                    zip.AddFile(spath, "NewTransactionReport")
                Next

                Response.Clear()
                Response.Buffer = True
                Response.AddHeader("Content-Disposition", "inline; filename=" + "NewTransactionReport.Zip")
                Response.Charset = ""
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Me.EnableViewState = False
                Response.ContentType = "application/zip"

                Response.AddHeader("X-Download-Options", "noopen")

                'Remove the charset from the Content-Type header.
                Dim style As String = "<style> .text { mso-number-format:\@; } </style> "

                zip.Save(Response.OutputStream)

                Dim filePaths() As String = Directory.GetFiles(Server.MapPath("~/File/"))

                For Each filePath As String In filePaths
                    File.Delete(filePath)
                Next

                Response.End()

            End Using
        Else
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            "alert('Data Tidak Ditemukan.'); window.location='ReportTransaction.aspx';", True)
        End If

    End Sub

    Protected Sub ddlTemplate_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlTemplate.SelectedIndexChanged

        If ddlTemplate.SelectedItem.Text = "New Report" Then

            If ddlFundType.SelectedItem.Text = "All" Then
                fundtype = ""
            Else
                fundtype = ddlFundType.SelectedItem.Text
            End If

            oInsert.f_Create_MemberNo(txtFrom.Text, txtTo.Text, txtPolis.Text, txtMemberName.Text, fundtype)
            BindGridTransaction(IIf(ddlFundType.SelectedValue = "All", "", ddlFundType.SelectedValue))

            GridTransaction.Visible = True

        Else
            GridTransaction.Visible = False
        End If
    End Sub

    Private Sub GridTransaction_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridTransaction.PageIndexChanging
        GridTransaction.PageIndex = e.NewPageIndex
        BindGridTransaction(IIf(ddlFundType.SelectedValue = "All", "", ddlFundType.SelectedValue))
    End Sub

    Private Sub GridTransaction_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridTransaction.PreRender
        If Me.GridTransaction.EditIndex <> -1 Then
            Dim txtMemberNo As TextBox = DirectCast(GridTransaction.Rows(GridTransaction.EditIndex).FindControl("txtMemberNo"), TextBox)
            Dim txtFundType As TextBox = DirectCast(GridTransaction.Rows(GridTransaction.EditIndex).FindControl("txtFundType"), TextBox)
            Dim txt3Bulan As TextBox = DirectCast(GridTransaction.Rows(GridTransaction.EditIndex).FindControl("txt3Bulan"), TextBox)
            Dim txt1Tahun As TextBox = DirectCast(GridTransaction.Rows(GridTransaction.EditIndex).FindControl("txt1Tahun"), TextBox)

            If txtMemberNo IsNot Nothing Then
                txtMemberNo.Enabled = False
            End If

            If txtFundType IsNot Nothing Then
                txtFundType.Enabled = False
            End If

        End If
    End Sub

    Private Sub GridTransaction_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridTransaction.RowCancelingEdit
        GridTransaction.EditIndex = -1
        BindGridTransaction(IIf(ddlFundType.SelectedValue = "All", "", ddlFundType.SelectedValue))
    End Sub

    Private Sub GridTransaction_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridTransaction.RowEditing
        GridTransaction.EditIndex = e.NewEditIndex
        BindGridTransaction(IIf(ddlFundType.SelectedValue = "All", "", ddlFundType.SelectedValue))
    End Sub

    Private Sub GridTransaction_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridTransaction.RowUpdating
        Dim MemberNo As TextBox = DirectCast(GridTransaction.Rows(e.RowIndex).FindControl("txtMemberNo"), TextBox)
        Dim FundType As TextBox = DirectCast(GridTransaction.Rows(e.RowIndex).FindControl("txtFundType"), TextBox)
        Dim TigaBulan As TextBox = DirectCast(GridTransaction.Rows(e.RowIndex).FindControl("txt3Bulan"), TextBox)
        Dim SatuTahun As TextBox = DirectCast(GridTransaction.Rows(e.RowIndex).FindControl("txt1Tahun"), TextBox)

        SQL = ""

        If TigaBulan.Text = "" Then
            TigaBulan.Text = "0"
        ElseIf SatuTahun.Text = "" Then
            SatuTahun.Text = "0"
        End If

        SQL = "UPDATE Tmp_Transaction_New_Report SET [3 BULAN TERAKHIR]=" & TigaBulan.Text & ", [1 TAHUN TERAKHIR]=" & SatuTahun.Text & " " & _
              "WHERE MemberNo= '" & MemberNo.Text & "' AND [Fund Type] LIKE '%" & FundType.Text & "%'"

        If SQL <> "" Then
            Try
                Modul.Eksekusi(SQL)
                GridTransaction.EditIndex = -1
                BindGridTransaction(IIf(ddlFundType.SelectedValue = "All", "", ddlFundType.SelectedValue))

            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try
        End If
    End Sub

    Protected Sub GridTransaction_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridTransaction.SelectedIndexChanged

    End Sub
End Class