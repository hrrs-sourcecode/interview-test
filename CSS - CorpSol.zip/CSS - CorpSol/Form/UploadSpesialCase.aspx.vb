﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices
Imports System.Data.OleDb
Imports System.IO
Partial Public Class UploadSpesialCase
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub


    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSave.Click
        If Not txtUploadHeader.HasFile Then
            ' Handle file
            Modul.UserMsgBox(Me, "File Header Can't Empty !!")
            Exit Sub
        End If

        If Not txtUploadDetail.HasFile Then
            ' Handle file
            Modul.UserMsgBox(Me, "File Detail Can't Empty !!")
            Exit Sub
        End If

        Dim strFileName As String = txtUploadHeader.PostedFile.FileName
        Dim filename As String = Path.GetFileName(strFileName)
        Dim new_path As String = Server.MapPath("Upload\") + filename


        Dim strFileNameDetail As String = txtUploadDetail.PostedFile.FileName
        Dim filenameDetail As String = Path.GetFileName(strFileNameDetail)
        Dim new_pathDetail As String = Server.MapPath("Upload\") + filenameDetail

        txtUploadHeader.PostedFile.SaveAs(new_path)
        txtUploadDetail.PostedFile.SaveAs(new_pathDetail)


        'Dim uploadedFiles As HttpFileCollection = Request.Files
        Dim x As Integer = 0

        Dim MyConnection As OleDbConnection
        Dim MyCommand_Upload As OleDbDataAdapter


        'Do Until x = uploadedFiles.Count
        '    Dim userPostedFile As HttpPostedFile = uploadedFiles(x)
        '    Try
        '        If (userPostedFile.ContentLength > 0) Then

        Try

            Dim DtData_Upload As New DataTable

            MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; " & _
                                "data source='" & new_path & " '; " & "Extended Properties=Excel 12.0;")

            MyConnection.Open()

            MyCommand_Upload = New OleDbDataAdapter(String.Format("SELECT * FROM [Header$]", strFileName), MyConnection)
            MyCommand_Upload.Fill(DtData_Upload)

            For i = 0 To DtData_Upload.Rows.Count
                Try
                    If i = DtData_Upload.Rows.Count Then
                        Exit For
                    End If

                    Dim vCLMCOY As String = DtData_Upload.Rows(i).Item(0).ToString.ToUpper
                    Dim vCLAMNUM As String = DtData_Upload.Rows(i).Item(1).ToString.ToUpper
                    Dim vGCOCCNO As String = DtData_Upload.Rows(i).Item(2).ToString.ToUpper
                    Dim vCHDRNUM As String = DtData_Upload.Rows(i).Item(3).ToString.ToUpper
                    Dim vMBRNO As String = DtData_Upload.Rows(i).Item(4).ToString.ToUpper
                    Dim vDPNTNO As String = DtData_Upload.Rows(i).Item(5).ToString.ToUpper
                    Dim vCLNTCOY As String = DtData_Upload.Rows(i).Item(6).ToString.ToUpper
                    Dim vCLNTNUM As String = DtData_Upload.Rows(i).Item(7).ToString.ToUpper
                    Dim vGCSTS As String = DtData_Upload.Rows(i).Item(8).ToString.ToUpper
                    Dim vCLAIMCUR As String = DtData_Upload.Rows(i).Item(9).ToString.ToUpper
                    Dim vCRATE As Integer = DtData_Upload.Rows(i).Item(10).ToString.ToUpper
                    Dim vPRODTYP As String = DtData_Upload.Rows(i).Item(11).ToString.ToUpper
                    Dim vGRSKCLS As String = DtData_Upload.Rows(i).Item(12).ToString.ToUpper
                    Dim vDTEVISIT As Integer = DtData_Upload.Rows(i).Item(13).ToString.ToUpper
                    Dim vDTEDCHRG As Integer = DtData_Upload.Rows(i).Item(14).ToString.ToUpper
                    Dim vGCDIAGCD As String = DtData_Upload.Rows(i).Item(15).ToString.ToUpper
                    Dim vPLANNO As String = DtData_Upload.Rows(i).Item(16).ToString.ToUpper
                    Dim vPREAUTNO As String = DtData_Upload.Rows(i).Item(17).ToString.ToUpper
                    Dim vPROVORG As String = DtData_Upload.Rows(i).Item(18).ToString.ToUpper
                    Dim vAREACDE As String = DtData_Upload.Rows(i).Item(19).ToString.ToUpper
                    Dim vREFERRER As String = DtData_Upload.Rows(i).Item(20).ToString.ToUpper
                    Dim vCLAMTYPE As String = DtData_Upload.Rows(i).Item(21).ToString.ToUpper
                    Dim vTIMEHH As Integer = DtData_Upload.Rows(i).Item(22).ToString.ToUpper
                    Dim vTIMEMM As Integer = DtData_Upload.Rows(i).Item(23).ToString.ToUpper
                    Dim vCLIENT_CLAIM_REF As String = DtData_Upload.Rows(i).Item(24).ToString.ToUpper
                    Dim vGCDTHCLM As String = DtData_Upload.Rows(i).Item(25).ToString.ToUpper
                    Dim vAPAIDAMT As Integer = DtData_Upload.Rows(i).Item(26).ToString.ToUpper
                    Dim vREQNTYPE As String = DtData_Upload.Rows(i).Item(27).ToString.ToUpper
                    Dim vCRDTCARD As String = DtData_Upload.Rows(i).Item(28).ToString.ToUpper
                    Dim vWHOPAID As String = DtData_Upload.Rows(i).Item(29).ToString.ToUpper
                    Dim vDTEKNOWN As Integer = DtData_Upload.Rows(i).Item(30).ToString.ToUpper
                    Dim vGCFRPDTE As Integer = DtData_Upload.Rows(i).Item(31).ToString.ToUpper
                    Dim vRECVD_DATE As Integer = DtData_Upload.Rows(i).Item(32).ToString.ToUpper
                    Dim vMCFROM As Integer = DtData_Upload.Rows(i).Item(33).ToString.ToUpper
                    Dim vMCTO As Integer = DtData_Upload.Rows(i).Item(34).ToString.ToUpper
                    Dim vGDEDUCT As Integer = DtData_Upload.Rows(i).Item(35).ToString.ToUpper
                    Dim vCOPAY As Integer = DtData_Upload.Rows(i).Item(36).ToString.ToUpper
                    Dim vMBRTYPE As String = DtData_Upload.Rows(i).Item(37).ToString.ToUpper
                    Dim vPROVNET As String = DtData_Upload.Rows(i).Item(38).ToString.ToUpper
                    Dim vAAD As Integer = DtData_Upload.Rows(i).Item(39).ToString.ToUpper
                    Dim vTHIRDRCVY As String = DtData_Upload.Rows(i).Item(40).ToString.ToUpper
                    Dim vTHIRDPARTY As String = DtData_Upload.Rows(i).Item(41).ToString.ToUpper
                    Dim vTLMBRSHR As Integer = DtData_Upload.Rows(i).Item(42).ToString.ToUpper
                    Dim vTLHMOSHR As Integer = DtData_Upload.Rows(i).Item(43).ToString.ToUpper
                    Dim vDATEAUTH As Integer = DtData_Upload.Rows(i).Item(44).ToString.ToUpper
                    Dim vGCAUTHBY As String = DtData_Upload.Rows(i).Item(45).ToString.ToUpper
                    Dim vGCOPRSCD As String = DtData_Upload.Rows(i).Item(46).ToString.ToUpper
                    Dim vREVLINK As String = DtData_Upload.Rows(i).Item(47).ToString.ToUpper
                    Dim vREVERSAL_IND As String = DtData_Upload.Rows(i).Item(48).ToString.ToUpper
                    Dim vTPRCVPND As String = DtData_Upload.Rows(i).Item(49).ToString.ToUpper
                    Dim vPENDFROM As String = DtData_Upload.Rows(i).Item(50).ToString.ToUpper
                    Dim vMMPROD As String = DtData_Upload.Rows(i).Item(51).ToString.ToUpper
                    Dim vHMOSHRMM As Integer = DtData_Upload.Rows(i).Item(52).ToString.ToUpper
                    Dim vTAKEUP As String = DtData_Upload.Rows(i).Item(53).ToString.ToUpper
                    Dim vDATACONV As String = DtData_Upload.Rows(i).Item(54).ToString.ToUpper
                    Dim vCLRATE As Integer = DtData_Upload.Rows(i).Item(55).ToString.ToUpper
                    Dim vREFNO As String = DtData_Upload.Rows(i).Item(56).ToString.ToUpper
                    Dim vUPDATE_IND As String = DtData_Upload.Rows(i).Item(57).ToString.ToUpper
                    Dim vPREMRCVY As Integer = DtData_Upload.Rows(i).Item(58).ToString.ToUpper
                    Dim vDATEAUTH1 As Integer = DtData_Upload.Rows(i).Item(59).ToString.ToUpper
                    Dim vDATEAUTH2 As Integer = DtData_Upload.Rows(i).Item(60).ToString.ToUpper
                    Dim vGCAUTHBY1 As String = DtData_Upload.Rows(i).Item(61).ToString.ToUpper
                    Dim vGCAUTHBY2 As String = DtData_Upload.Rows(i).Item(62).ToString.ToUpper
                    Dim vCASHLESS As String = DtData_Upload.Rows(i).Item(63).ToString.ToUpper
                    Dim vTPAREFNO As String = DtData_Upload.Rows(i).Item(64).ToString.ToUpper
                    Dim vINWARDNO As String = DtData_Upload.Rows(i).Item(65).ToString.ToUpper
                    Dim vICD101L As String = DtData_Upload.Rows(i).Item(66).ToString.ToUpper
                    Dim vICD102L As String = DtData_Upload.Rows(i).Item(67).ToString.ToUpper
                    Dim vICD103L As String = DtData_Upload.Rows(i).Item(68).ToString.ToUpper
                    Dim vREGCLM As String = DtData_Upload.Rows(i).Item(69).ToString.ToUpper
                    Dim vGCCAUSCD As String = DtData_Upload.Rows(i).Item(70).ToString.ToUpper
                    Dim vUSER_PROFILE As String = DtData_Upload.Rows(i).Item(71).ToString.ToUpper
                    Dim vJOB_NAME As String = DtData_Upload.Rows(i).Item(72).ToString.ToUpper
                    Dim vDATIME As String = Left(DtData_Upload.Rows(i).Item(73).ToString.ToUpper, 10)
                    Dim vTLCFAMT As Integer = DtData_Upload.Rows(i).Item(74).ToString.ToUpper

                    SQL = "DELETE FROM TRN_HDR_SPECIAL_CASE WHERE CLAMNUM='" & vCLAMNUM & "' "
                    Modul.Eksekusi(SQL)

                    SQL = "INSERT INTO TRN_HDR_SPECIAL_CASE values('" & vCLMCOY & "','" & vCLAMNUM & "','" & vGCOCCNO & "', " & _
                          "'" & vCHDRNUM & "','" & vMBRNO & "','" & vDPNTNO & "','" & vCLNTCOY & "','" & vCLNTNUM & "','" & vGCSTS & "', " & _
                          "'" & vCLAIMCUR & "','" & vCRATE & "','" & vPRODTYP & "','" & vGRSKCLS & "','" & vDTEVISIT & "','" & vDTEDCHRG & "', " & _
                          "'" & vGCDIAGCD & "','" & vPLANNO & "','" & vPREAUTNO & "','" & vPROVORG & "','" & vAREACDE & "','" & vREFERRER & "', " & _
                          "'" & vCLAMTYPE & "','" & vTIMEHH & "','" & vTIMEMM & "','" & vCLIENT_CLAIM_REF & "','" & vGCDTHCLM & "','" & vAPAIDAMT & "', " & _
                          "'" & vREQNTYPE & "','" & vCRDTCARD & "','" & vWHOPAID & "','" & vDTEKNOWN & "','" & vGCFRPDTE & "','" & vRECVD_DATE & "', " & _
                          "'" & vMCFROM & "','" & vMCTO & "','" & vGDEDUCT & "','" & vCOPAY & "','" & vMBRTYPE & "','" & vPROVNET & "', " & _
                          "'" & vAAD & "','" & vTHIRDRCVY & "','" & vTHIRDPARTY & "','" & vTLMBRSHR & "','" & vTLHMOSHR & "','" & vDATEAUTH & "', " & _
                          "'" & vGCAUTHBY & "','" & vGCOPRSCD & "','" & vREVLINK & "','" & vREVERSAL_IND & "','" & vTPRCVPND & "','" & vPENDFROM & "', " & _
                          "'" & vMMPROD & "','" & vHMOSHRMM & "','" & vTAKEUP & "','" & vDATACONV & "','" & vCLRATE & "','" & vREFNO & "', " & _
                          "'" & vUPDATE_IND & "','" & vPREMRCVY & "','" & vDATEAUTH1 & "','" & vDATEAUTH2 & "','" & vGCAUTHBY1 & "','" & vGCAUTHBY2 & "', " & _
                          "'" & vCASHLESS & "','" & vTPAREFNO & "','" & vINWARDNO & "','" & vICD101L & "','" & vICD102L & "','" & vICD103L & "', " & _
                          "'" & vREGCLM & "','" & vGCCAUSCD & "','" & vUSER_PROFILE & "','" & vJOB_NAME & "','" & vDATIME & "','" & vTLCFAMT & "','06',0)"
                    Modul.Eksekusi(SQL)


                Catch ex As Exception
                    'MsgBox(ex.Message)
                    'Throw (ex)
                End Try

            Next

            DtData_Upload = Nothing

            'ElseIf x = 1 Then

            Dim DtData_Upload_Detail As New DataTable

            MyConnection.Close()

            MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; " & _
                                "data source='" & new_pathDetail & " '; " & "Extended Properties=Excel 12.0;")

            MyConnection.Open()

            MyCommand_Upload = New OleDbDataAdapter(String.Format("SELECT * FROM [Detail$]", strFileNameDetail), MyConnection)
            MyCommand_Upload.Fill(DtData_Upload_Detail)
            Dim vCLAMNUM2 As String = ""

            For i = 0 To DtData_Upload_Detail.Rows.Count
                Try
                    If i = DtData_Upload_Detail.Rows.Count Then
                        Exit For
                    End If

                    Dim vCLMCOY As String = DtData_Upload_Detail.Rows(i).Item(0).ToString.ToUpper
                    Dim vCLAMNUM As String = DtData_Upload_Detail.Rows(i).Item(1).ToString.ToUpper
                    Dim vGCOCCNO As String = DtData_Upload_Detail.Rows(i).Item(2).ToString.ToUpper
                    Dim vGCBENSEQ As Integer = DtData_Upload_Detail.Rows(i).Item(3).ToString.ToUpper
                    Dim vDATEFRM As Integer = DtData_Upload_Detail.Rows(i).Item(4).ToString.ToUpper
                    Dim vDATETO As Integer = DtData_Upload_Detail.Rows(i).Item(5).ToString.ToUpper
                    Dim vNOFDAY As Integer = DtData_Upload_Detail.Rows(i).Item(6).ToString.ToUpper
                    Dim vSRVCCODE As String = DtData_Upload_Detail.Rows(i).Item(7).ToString.ToUpper
                    Dim vNOFUNIT As Integer = DtData_Upload_Detail.Rows(i).Item(8).ToString.ToUpper
                    Dim vPOS As String = DtData_Upload_Detail.Rows(i).Item(9).ToString.ToUpper
                    Dim vINCURRED As Integer = DtData_Upload_Detail.Rows(i).Item(10).ToString.ToUpper
                    Dim vSYPYPROV As Integer = DtData_Upload_Detail.Rows(i).Item(11).ToString.ToUpper
                    Dim vPAYPROV As Integer = DtData_Upload_Detail.Rows(i).Item(12).ToString.ToUpper
                    Dim vGDEDUCT As Integer = DtData_Upload_Detail.Rows(i).Item(13).ToString.ToUpper
                    Dim vCOPAY As Integer = DtData_Upload_Detail.Rows(i).Item(14).ToString.ToUpper
                    Dim vSYMBRSHR As Integer = DtData_Upload_Detail.Rows(i).Item(15).ToString.ToUpper
                    Dim vMBRSHARE As Integer = DtData_Upload_Detail.Rows(i).Item(16).ToString.ToUpper
                    Dim vSYHMOSHR As Integer = DtData_Upload_Detail.Rows(i).Item(17).ToString.ToUpper
                    Dim vHMOSHARE As Integer = DtData_Upload_Detail.Rows(i).Item(18).ToString.ToUpper
                    Dim vBENCDE As String = DtData_Upload_Detail.Rows(i).Item(19).ToString.ToUpper
                    Dim vFEESCHID As String = DtData_Upload_Detail.Rows(i).Item(20).ToString.ToUpper
                    Dim vWHRULE As String = DtData_Upload_Detail.Rows(i).Item(21).ToString.ToUpper
                    Dim vWHSLAB As String = DtData_Upload_Detail.Rows(i).Item(22).ToString.ToUpper
                    Dim vFEEBASIS As String = DtData_Upload_Detail.Rows(i).Item(23).ToString.ToUpper
                    Dim vCLNTCOY As String = DtData_Upload_Detail.Rows(i).Item(24).ToString.ToUpper
                    Dim vPROVIND As String = DtData_Upload_Detail.Rows(i).Item(25).ToString.ToUpper
                    Dim vPROVCAP As String = DtData_Upload_Detail.Rows(i).Item(26).ToString.ToUpper
                    Dim vNETLEVEL As String = DtData_Upload_Detail.Rows(i).Item(27).ToString.ToUpper
                    Dim vFESCHMTH As String = DtData_Upload_Detail.Rows(i).Item(28).ToString.ToUpper
                    Dim vNETDKEY As String = DtData_Upload_Detail.Rows(i).Item(29).ToString.ToUpper
                    Dim vPFSDKEY As String = DtData_Upload_Detail.Rows(i).Item(30).ToString.ToUpper
                    Dim vBENCDEFLG As String = DtData_Upload_Detail.Rows(i).Item(31).ToString.ToUpper
                    Dim vHMOSHRMM As Integer = DtData_Upload_Detail.Rows(i).Item(32).ToString.ToUpper
                    Dim vBNFTGRP As String = DtData_Upload_Detail.Rows(i).Item(33).ToString.ToUpper
                    Dim vOUBNFGP As String = DtData_Upload_Detail.Rows(i).Item(34).ToString.ToUpper
                    Dim vZDAYCOV As Integer = DtData_Upload_Detail.Rows(i).Item(35).ToString.ToUpper
                    Dim vZCHRGDAY As Integer = DtData_Upload_Detail.Rows(i).Item(36).ToString.ToUpper
                    Dim vZHSLMTUP As String = DtData_Upload_Detail.Rows(i).Item(37).ToString.ToUpper
                    Dim vMMINBFGP As String = DtData_Upload_Detail.Rows(i).Item(38).ToString.ToUpper
                    Dim vMMOUBFGP As String = DtData_Upload_Detail.Rows(i).Item(39).ToString.ToUpper
                    Dim vAMTDISAL As Integer = DtData_Upload_Detail.Rows(i).Item(40).ToString.ToUpper
                    Dim vTPADIFF As Integer = DtData_Upload_Detail.Rows(i).Item(41).ToString.ToUpper
                    Dim vINVOICENO As String = DtData_Upload_Detail.Rows(i).Item(42).ToString.ToUpper
                    Dim vEXTRMTYP As String = DtData_Upload_Detail.Rows(i).Item(43).ToString.ToUpper
                    Dim vGCDIAGCD As String = DtData_Upload_Detail.Rows(i).Item(44).ToString.ToUpper
                    Dim vUSER_PROFILE As String = DtData_Upload_Detail.Rows(i).Item(45).ToString.ToUpper
                    Dim vJOB_NAME As String = DtData_Upload_Detail.Rows(i).Item(46).ToString.ToUpper
                    Dim vDATIME As String = Left(DtData_Upload_Detail.Rows(i).Item(47).ToString.ToUpper, 10)


                    If vCLAMNUM2 <> vCLAMNUM Then
                        SQL = "DELETE FROM TRN_DTL_SPECIAL_CASE WHERE CLAMNUM='" & vCLAMNUM & "' "
                        Modul.Eksekusi(SQL)

                        vCLAMNUM2 = vCLAMNUM
                    End If


                    SQL = "INSERT INTO TRN_DTL_SPECIAL_CASE values('" & vCLMCOY & "','" & vCLAMNUM & "','" & vGCOCCNO & "', " & _
                          "'" & vGCBENSEQ & "','" & vDATEFRM & "','" & vDATETO & "','" & vNOFDAY & "','" & vSRVCCODE & "', " & _
                          "'" & vNOFUNIT & "','" & vPOS & "','" & vINCURRED & "','" & vSYPYPROV & "', " & _
                          "'" & vPAYPROV & "','" & vGDEDUCT & "','" & vCOPAY & "','" & vSYMBRSHR & "','" & vMBRSHARE & "','" & vSYHMOSHR & "', " & _
                          "'" & vHMOSHARE & "','" & vBENCDE & "','" & vFEESCHID & "','" & vWHRULE & "','" & vWHSLAB & "','" & vFEEBASIS & "', " & _
                          "'" & vCLNTCOY & "','" & vPROVIND & "', " & _
                          "'" & vPROVCAP & "','" & vNETLEVEL & "','" & vFESCHMTH & "','" & vNETDKEY & "','" & vPFSDKEY & "','" & vBENCDEFLG & "', " & _
                          "'" & vHMOSHRMM & "','" & vBNFTGRP & "','" & vOUBNFGP & "','" & vZDAYCOV & "','" & vZCHRGDAY & "','" & vZHSLMTUP & "', " & _
                          "'" & vMMINBFGP & "','" & vMMOUBFGP & "','" & vAMTDISAL & "','" & vTPADIFF & "','" & vINVOICENO & "','" & vEXTRMTYP & "', " & _
                          "'" & vGCDIAGCD & "','" & vUSER_PROFILE & "','" & vJOB_NAME & "','" & vDATIME & "')"
                    Modul.Eksekusi(SQL)


                Catch ex As Exception
                    'MsgBox(ex.Message)
                    'Throw (ex)
                End Try

            Next

            DtData_Upload_Detail = Nothing
            'End If

            MyConnection.Close()

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
        '        End If
        '    Catch ex As Exception
        '    'MsgBox(ex.Message)
        '    'Throw (ex)
        'End Try
        'x += 1
        'Loop


        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
        "alert('Upload Data Sukses'); window.location='UploadSpesialCase.aspx';", True)
        'System.IO.File.Delete(userPostedFile.FileName)

    End Sub
End Class