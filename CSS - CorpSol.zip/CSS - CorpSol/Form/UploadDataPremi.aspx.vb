﻿'Imports System.Data
'Imports System.Data.SqlClient
'Imports System.DirectoryServices
'Imports System.Data.OleDb
Imports System.IO
Imports OfficeOpenXml
'Imports OfficeOpenXml.Style
Partial Public Class UploadDataPremi
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim oInsert As New InsertBase
    Dim oSelect As New SelectBase
    Dim dt_duplicate As New DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub


    'Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSave.Click
    '    If Not txtUpload.HasFile Then
    '        ' Handle file
    '        Modul.UserMsgBox(Me, "File Can't Empty !!")
    '        Exit Sub
    '    End If

    '    Dim strFileName As String = txtUpload.PostedFile.FileName
    '    Dim filename As String = Path.GetFileName(strFileName)
    '    Dim new_path As String = Server.MapPath("Upload\") + filename

    '    txtUpload.PostedFile.SaveAs(new_path)


    '    'Dim uploadedFiles As HttpFileCollection = Request.Files
    '    Dim x As Integer = 0

    '    Dim MyConnection As OleDbConnection
    '    Dim MyCommand_Upload As OleDbDataAdapter
    '    Dim nSukses As Integer = 0
    '    Dim nGagal As Integer = 0


    '    'Do Until x = uploadedFiles.Count
    '    '    Dim userPostedFile As HttpPostedFile = uploadedFiles(x)
    '    '    Try
    '    '        If (userPostedFile.ContentLength > 0) Then

    '    Try

    '        Dim DtData_Upload As New DataTable

    '        MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; " &
    '                            "data source='" & new_path & " '; " & "Extended Properties=Excel 12.0;")

    '        MyConnection.Open()

    '        Dim dbSchema As DataTable = MyConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
    '        Dim firstSheetName As String = dbSchema.Rows(0)("TABLE_NAME").ToString()

    '        MyCommand_Upload = New OleDbDataAdapter("SELECT * FROM [" & firstSheetName & "]", MyConnection)
    '        MyCommand_Upload.Fill(DtData_Upload)

    '        MyConnection.Close()

    '        System.IO.File.Delete(new_path)

    '        dt_duplicate.Columns.Add("BILL_NO")
    '        dt_duplicate.Columns.Add("NO_BILL_MANUAL")
    '        dt_duplicate.Columns.Add("PAYMENT_MODE")
    '        dt_duplicate.Columns.Add("POLICY_NUMBER")
    '        dt_duplicate.Columns.Add("ACCOUNT_NAME")
    '        dt_duplicate.Columns.Add("PRODUCT")
    '        dt_duplicate.Columns.Add("STATUS")
    '        dt_duplicate.Columns.Add("Error Message")

    '        'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
    '        '    "alert('" & DtData_Upload.Rows.Count & "');;", True)

    '        'Exit Sub

    '        For i = 0 To DtData_Upload.Rows.Count
    '            Try
    '                If i = DtData_Upload.Rows.Count Then
    '                    Exit For
    '                End If

    '                Dim vBILLNO As String = DtData_Upload.Rows(i).Item("BILL_NO").ToString
    '                Dim vBILLNOMANUAL As String = DtData_Upload.Rows(i).Item("NO_BILL_MANUAL").ToString
    '                Dim vNOTRANSAKSI As String = DtData_Upload.Rows(i).Item("NO_TRANSAKSI").ToString
    '                Dim vPAYMENTMODE As String = DtData_Upload.Rows(i).Item("PAYMENT_MODE").ToString
    '                Dim vPOLICYNO As Integer = IIf(IsDBNull(DtData_Upload.Rows(i).Item("POLICY_NUMBER")), 0, DtData_Upload.Rows(i).Item("POLICY_NUMBER"))
    '                Dim vACCOUNTNAME As String = DtData_Upload.Rows(i).Item("ACCOUNT_NAME").ToString
    '                Dim vPRODUCT As String = DtData_Upload.Rows(i).Item("PRODUCT").ToString
    '                Dim vTOTALMEMBER As Integer = IIf(IsDBNull(DtData_Upload.Rows(i).Item("TOTAL_MEMBER")), 0, DtData_Upload.Rows(i).Item("TOTAL_MEMBER"))
    '                Dim vPREMIUMAMOUNT As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("PREMIUM_AMOUNT")), 0, DtData_Upload.Rows(i).Item("PREMIUM_AMOUNT"))
    '                Dim vADDITION As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("ADDITION")), 0, DtData_Upload.Rows(i).Item("ADDITION"))
    '                Dim vDELETION As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("DELETION")), 0, DtData_Upload.Rows(i).Item("DELETION"))
    '                Dim vCHANGEPLAN As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("CHANGE PLAN")), 0, DtData_Upload.Rows(i).Item("CHANGE PLAN"))
    '                Dim vFEE_ASO As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("FEE_ASO")), 0, DtData_Upload.Rows(i).Item("FEE_ASO"))
    '                Dim vASO As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("ASO")), 0, DtData_Upload.Rows(i).Item("ASO"))
    '                Dim vBY_KARTU As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("BY_KARTU")), 0, DtData_Upload.Rows(i).Item("BY_KARTU"))
    '                Dim vPAID As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("PAID")), 0, DtData_Upload.Rows(i).Item("PAID"))
    '                Dim vOUTSTANDING As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("OUTSTANDING")), 0, DtData_Upload.Rows(i).Item("OUTSTANDING"))
    '                Dim vTYPE_OF_ENDORSMENT As String = DtData_Upload.Rows(i).Item("TYPE_OF_ENDORSMENT").ToString

    '                Dim vTGL_BAYAR As String
    '                Dim vTGL_BAYAR2 As String
    '                Dim vTGL_BAYAR3 As String
    '                Dim vTGL_INPUTG400 As String
    '                Dim vISSUE_DATE As String
    '                Dim vEFFECTIVEDATE As String

    '                'Dim strArr() As String
    '                'Dim strArrYear() As String

    '                'Dim strDay_date As String
    '                'Dim strMonth_date As String
    '                'Dim strYear_date As String
    '                'Dim _strIssueDate As String

    '                'If vIssueDate_RECEIVED_DATE <> "" Then
    '                '    strArr = vIssueDate_RECEIVED_DATE.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                Dim vIssueDate_POLICY_EFFECTIVE_DATE As String = DtData_Upload.Rows(i).Item("POLICY_EFFECTIVE_DATE").ToString

    '                'If vIssueDate_POLICY_EFFECTIVE_DATE <> "" Then
    '                '    strArr = vIssueDate_POLICY_EFFECTIVE_DATE.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If

    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                Dim isNotPolicyEffectiveDate As Boolean = False

    '                If String.IsNullOrEmpty(vIssueDate_POLICY_EFFECTIVE_DATE) Then
    '                    vEFFECTIVEDATE = "1900-01-01"
    '                    isNotPolicyEffectiveDate = True
    '                ElseIf IsDBNull(vIssueDate_POLICY_EFFECTIVE_DATE) Then
    '                    vEFFECTIVEDATE = "1900-01-01"
    '                    isNotPolicyEffectiveDate = True
    '                ElseIf Not IsDate(vIssueDate_POLICY_EFFECTIVE_DATE) Then
    '                    vEFFECTIVEDATE = "1900-01-01"
    '                    isNotPolicyEffectiveDate = True
    '                Else
    '                    vEFFECTIVEDATE = CDate(vIssueDate_POLICY_EFFECTIVE_DATE)
    '                End If



    '                Dim vIssueDate_ISSUE_DATE As String = DtData_Upload.Rows(i).Item("ISSUE_DATE (SYSTEM)").ToString

    '                'If vIssueDate_ISSUE_DATE <> "" Then
    '                '    strArr = vIssueDate_ISSUE_DATE.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If


    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                Dim isNotIssueDate As Boolean = False

    '                If String.IsNullOrEmpty(vIssueDate_ISSUE_DATE) Then
    '                    vISSUE_DATE = "1900-01-01"
    '                    isNotIssueDate = True
    '                ElseIf IsDBNull(vIssueDate_ISSUE_DATE) Then
    '                    vISSUE_DATE = "1900-01-01"
    '                    isNotIssueDate = True
    '                ElseIf Not IsDate(vIssueDate_ISSUE_DATE) Then
    '                    vISSUE_DATE = "1900-01-01"
    '                    isNotIssueDate = True
    '                Else
    '                    vISSUE_DATE = CDate(vIssueDate_ISSUE_DATE)
    '                End If

    '                Dim vIssueDate_TGL_INPUT As String = DtData_Upload.Rows(i).Item("TGL_INPUT G400").ToString

    '                'If vIssueDate_TGL_INPUT <> "" Then
    '                '    strArr = vIssueDate_TGL_INPUT.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If


    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_INPUT G400").ToString = "" Then
    '                    vTGL_INPUTG400 = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_INPUT G400").ToString) = True Then
    '                    vTGL_INPUTG400 = "1900-01-01"
    '                Else
    '                    vTGL_INPUTG400 = CDate(vIssueDate_TGL_INPUT)
    '                End If

    '                Dim vIssueDate_TGL_BAYAR As String = DtData_Upload.Rows(i).Item("TGL_BAYAR").ToString

    '                'If vIssueDate_TGL_BAYAR <> "" Then
    '                '    strArr = vIssueDate_TGL_BAYAR.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If


    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_BAYAR").ToString = "" Then
    '                    vTGL_BAYAR = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_BAYAR").ToString) = True Then
    '                    vTGL_BAYAR = "1900-01-01"
    '                Else
    '                    vTGL_BAYAR = CDate(vIssueDate_TGL_BAYAR)
    '                End If

    '                Dim vIssueDate_TGL_BAYAR2 As String = DtData_Upload.Rows(i).Item("TGL_BAYAR2").ToString

    '                'If vIssueDate_TGL_BAYAR2 <> "" Then
    '                '    strArr = vIssueDate_TGL_BAYAR2.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If

    '                '    strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_BAYAR2").ToString = "" Then
    '                    vTGL_BAYAR2 = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_BAYAR2").ToString) = True Then
    '                    vTGL_BAYAR2 = "1900-01-01"
    '                Else
    '                    vTGL_BAYAR2 = CDate(vIssueDate_TGL_BAYAR2)
    '                End If

    '                Dim vIssueDate_TGL_BAYAR3 As String = DtData_Upload.Rows(i).Item("TGL_BAYAR3").ToString

    '                'If vIssueDate_TGL_BAYAR3 <> "" Then
    '                '    strArr = vIssueDate_TGL_BAYAR3.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If


    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_BAYAR3").ToString = "" Then
    '                    vTGL_BAYAR3 = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_BAYAR3").ToString) = True Then
    '                    vTGL_BAYAR3 = "1900-01-01"
    '                Else
    '                    vTGL_BAYAR3 = CDate(vIssueDate_TGL_BAYAR3)
    '                End If


    '                Dim vRECEIPT As String = DtData_Upload.Rows(i).Item("RECEIPT").ToString
    '                Dim vRCL As Double = IIf(IsDBNull(DtData_Upload.Rows(i).Item("RCL")), 0, DtData_Upload.Rows(i).Item("RCL"))
    '                Dim vREMARK_COLLECTION As String = DtData_Upload.Rows(i).Item("REMARK_COLLECTION").ToString
    '                Dim vKETERANGAN As String = DtData_Upload.Rows(i).Item("KETERANGAN").ToString
    '                'Dim vSTATUS As String = DtData_Upload.Rows(i).Item("STATUS").ToString
    '                Dim vSTATUS As String = "UNPAID"

    '                Dim vTGL_PENAGIHAN_PREMI As String
    '                Dim vTGL_PENAGIHAN_PREMI2 As String
    '                Dim vTGL_PENAGIHAN_PREMI3 As String

    '                Dim vIssueDate_TGL_PENAGIHAN_PREMI As String = DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_PREMI").ToString

    '                'If vIssueDate_TGL_PENAGIHAN_PREMI <> "" Then
    '                '    strArr = vIssueDate_TGL_PENAGIHAN_PREMI.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If


    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_PREMI").ToString = "" Then
    '                    vTGL_PENAGIHAN_PREMI = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_PREMI").ToString) = True Then
    '                    vTGL_PENAGIHAN_PREMI = "1900-01-01"
    '                Else
    '                    vTGL_PENAGIHAN_PREMI = CDate(vIssueDate_TGL_PENAGIHAN_PREMI)
    '                End If

    '                Dim vIssueDate_TGL_PENAGIHAN_PREMI2 As String = DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_PREMI2").ToString

    '                'If vIssueDate_TGL_PENAGIHAN_PREMI2 <> "" Then
    '                '    strArr = vIssueDate_TGL_PENAGIHAN_PREMI2.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If


    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_PREMI2").ToString = "" Then
    '                    vTGL_PENAGIHAN_PREMI2 = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_PREMI2").ToString) = True Then
    '                    vTGL_PENAGIHAN_PREMI2 = "1900-01-01"
    '                Else
    '                    vTGL_PENAGIHAN_PREMI2 = CDate(vIssueDate_TGL_PENAGIHAN_PREMI2)
    '                End If

    '                Dim vIssueDate_TGL_PENAGIHAN_PREMI3 As String = DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_PREMI3").ToString

    '                'If vIssueDate_TGL_PENAGIHAN_PREMI3 <> "" Then
    '                '    strArr = vIssueDate_TGL_PENAGIHAN_PREMI3.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If


    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_PREMI3").ToString = "" Then
    '                    vTGL_PENAGIHAN_PREMI3 = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_PENAGIHAN_PREMI3").ToString) = True Then
    '                    vTGL_PENAGIHAN_PREMI3 = "1900-01-01"
    '                Else
    '                    vTGL_PENAGIHAN_PREMI3 = CDate(vIssueDate_TGL_PENAGIHAN_PREMI3)
    '                End If

    '                Dim vReason As String = DtData_Upload.Rows(i).Item("Reason").ToString

    '                Dim vTGL_PROSES As String

    '                Dim vIssueDate_TGL_PROSES As String = DtData_Upload.Rows(i).Item("TGL_PROSES").ToString

    '                'If vIssueDate_TGL_PROSES <> "" Then
    '                '    strArr = vIssueDate_TGL_PROSES.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(1).PadLeft(2, "0")

    '                '    If strDay_date > 12 Then
    '                '        strDay_date = strArr(0).PadLeft(2, "0")
    '                '        strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    Else
    '                '        strDay_date = strArr(1).PadLeft(2, "0")
    '                '        strMonth_date = strArr(0).PadLeft(2, "0")
    '                '    End If


    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date + " 00:00:00"
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If

    '                If DtData_Upload.Rows(i).Item("TGL_PROSES").ToString = "" Then
    '                    vTGL_PROSES = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_PROSES").ToString) = True Then
    '                    vTGL_PROSES = "1900-01-01"
    '                Else
    '                    vTGL_PROSES = CDate(vIssueDate_TGL_PROSES)
    '                End If

    '                'Dim vTGL_UPLOAD As String
    '                'Dim vIssueDate_TGL_UPLOAD = DtData_Upload.Rows(i).Item("TGL_UPLOAD").ToString

    '                'If vIssueDate_TGL_UPLOAD <> "" Then
    '                '    strArr = vIssueDate_TGL_UPLOAD.Split("/")
    '                '    strArrYear = strArr(2).Split(" ")
    '                '    strDay_date = strArr(0).PadLeft(2, "0")
    '                '    strMonth_date = strArr(1).PadLeft(2, "0")
    '                '    strYear_date = strArrYear(0)
    '                '    _strIssueDate = strYear_date + "-" + strMonth_date + "-" + strDay_date
    '                'Else
    '                '    _strIssueDate = ""
    '                'End If


    '                'If DtData_Upload.Rows(i).Item("TGL_UPLOAD").ToString = "" Then
    '                '    vTGL_UPLOAD = "1900-01-01"
    '                'ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TGL_UPLOAD").ToString) = True Then
    '                '    vTGL_UPLOAD = "1900-01-01"
    '                'Else
    '                '    vTGL_UPLOAD = _strIssueDate
    '                'End If

    '                Dim vUser As String = DtData_Upload.Rows(i).Item("User").ToString

    '                If vBILLNO = "" Or IsDBNull(vBILLNO) = True Then
    '                    vBILLNO = vBILLNOMANUAL
    '                End If

    '                Dt = oSelect.sp_get_detail_premi(vBILLNO)

    '                If Dt.Rows.Count > 0 Then
    '                    dt_duplicate.Rows.Add("'" & vBILLNO, vBILLNOMANUAL, vPAYMENTMODE, vPOLICYNO, vACCOUNTNAME, vPRODUCT, vSTATUS, "DUPLICATE DATA")
    '                ElseIf isNotPolicyEffectiveDate Then
    '                    dt_duplicate.Rows.Add("'" & vBILLNO, vBILLNOMANUAL, vPAYMENTMODE, vPOLICYNO, vACCOUNTNAME, vPRODUCT, vSTATUS, "INVALID FORMAT POLICY EFFECTIVE DATE")
    '                ElseIf isNotIssueDate Then
    '                    dt_duplicate.Rows.Add("'" & vBILLNO, vBILLNOMANUAL, vPAYMENTMODE, vPOLICYNO, vACCOUNTNAME, vPRODUCT, vSTATUS, "INVALID FORMAT ISSUE DATE")
    '                Else
    '                    nSukses += 1

    '                    oInsert.f_Insert_Data_premi(vBILLNO, vBILLNOMANUAL, vNOTRANSAKSI, vPAYMENTMODE, vPOLICYNO, vACCOUNTNAME, vEFFECTIVEDATE,
    '                                                vPRODUCT, vTOTALMEMBER, vPREMIUMAMOUNT, vADDITION, vDELETION, vCHANGEPLAN, vFEE_ASO, vASO,
    '                                                vBY_KARTU, vPAID, vOUTSTANDING, vISSUE_DATE, vTYPE_OF_ENDORSMENT, vTGL_BAYAR, vTGL_BAYAR2, vTGL_BAYAR3, vTGL_INPUTG400,
    '                                                vRECEIPT, vRCL, vREMARK_COLLECTION, vKETERANGAN, vSTATUS, vTGL_PENAGIHAN_PREMI, vTGL_PENAGIHAN_PREMI2,
    '                                                vTGL_PENAGIHAN_PREMI3, vReason, vTGL_PROSES, Session("username").ToString, UCase(vUser))
    '                End If

    '            Catch ex As Exception
    '                'Modul.UserMsgBox(Me, "Error On Line : " & i.ToString + 1)
    '                Throw (ex)
    '                DtData_Upload = Nothing
    '                MyConnection.Close()
    '                'Exit Sub
    '            End Try

    '        Next

    '        nGagal = DtData_Upload.Rows.Count - nSukses
    '        LblSes.Text = nSukses.ToString & " Record"
    '        LblGal.Text = nGagal.ToString & " Record"

    '        If dt_duplicate.Rows.Count > 0 Then
    '            btnGenerateReject.Visible = True
    '            lbl_doubldata.Text = dt_duplicate.Rows.Count.ToString & " Record"
    '            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
    '            "alert('Upload Data Sukses. Terdapat " & dt_duplicate.Rows.Count & " data duplicate');;", True)
    '        Else
    '            btnGenerateReject.Visible = False
    '            lbl_doubldata.Text = ""

    '            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
    '            "alert('Upload Data Sukses');;", True)
    '        End If

    '        DGDuplicatePremi.DataSource = dt_duplicate
    '        DGDuplicatePremi.DataBind()

    '        DtData_Upload = Nothing

    '    Catch ex As Exception
    '        'Modul.UserMsgBox(Me, ex.Message)
    '        Throw (ex)
    '        MyConnection.Close()
    '        'Exit Sub
    '    End Try

    '    'System.IO.File.Delete(userPostedFile.FileName)

    'End Sub

    Protected Sub btnGenerateReject_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGenerateReject.Click
        Try
            Dim filename As String = "UPLOAD_PREMI_DUPLICATE" & "_" & DateTime.Now.Day.ToString.PadLeft(2, "0") & DateTime.Now.Month.ToString.PadLeft(2, "0") & Strings.Right(DateTime.Now.Year.ToString, 2).PadLeft(2, "0") & ".xls"
            Response.Clear()
            Response.Charset = ""
            Response.ContentEncoding = System.Text.Encoding.UTF8
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = "application/vnd.xls"
            Response.AddHeader("content-disposition", "attachment;filename=" & filename)

            Me.EnableViewState = False
            Dim StringWrite As New System.IO.StringWriter
            Dim HtmlWrite As New System.Web.UI.HtmlTextWriter(StringWrite)
            Modul.FormatExportedGrid(DGDuplicatePremi)
            Modul.ClearControls(DGDuplicatePremi)
            DGDuplicatePremi.RenderControl(HtmlWrite)

            Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
            Response.Write(style)

            Response.Write(StringWrite.ToString())
            Response.End()
            DGDuplicatePremi.Dispose()
            DGDuplicatePremi.DataSource = Nothing
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function CleanDate(ByVal tgl As String) As String
        Dim value As String
        Dim strArr_date() As String
        Dim strArrYear_date() As String

        Dim strDay_date As String
        Dim strMonth_date As String
        Dim strYear_date As String
        Dim _strvEffectiveDate As String

        value = Replace(tgl, "-", "/")
        strArr_date = value.Split("/")

        strArrYear_date = strArr_date(2).Split(" ")
        strDay_date = strArr_date(0).PadLeft(2, "0")
        strMonth_date = strArr_date(1).PadLeft(2, "0")
        strYear_date = strArrYear_date(0)

        If Len(strDay_date) = 1 Then
            strDay_date = "0" & strDay_date
        End If

        If strMonth_date = "Jan" Then
            strMonth_date = "01"
        ElseIf strMonth_date = "Feb" Then
            strMonth_date = "02"
        ElseIf strMonth_date = "Mar" Then
            strMonth_date = "03"
        ElseIf strMonth_date = "Apr" Then
            strMonth_date = "04"
        ElseIf strMonth_date = "May" Then
            strMonth_date = "05"
        ElseIf strMonth_date = "Jun" Then
            strMonth_date = "06"
        ElseIf strMonth_date = "Jul" Then
            strMonth_date = "07"
        ElseIf strMonth_date = "Aug" Then
            strMonth_date = "08"
        ElseIf strMonth_date = "Sept" Then
            strMonth_date = "09"
        ElseIf strMonth_date = "Oct" Then
            strMonth_date = "10"
        ElseIf strMonth_date = "Nov" Then
            strMonth_date = "11"
        ElseIf strMonth_date = "Dec" Then
            strMonth_date = "12"
        End If

        If Len(strYear_date) = 2 Then
            strYear_date = "20" & strYear_date
        End If

        _strvEffectiveDate = strYear_date + "-" + strMonth_date + "-" + strDay_date

        Return _strvEffectiveDate

    End Function

    Protected Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        If Not txtUpload.HasFile Then
            ' Handle file
            Modul.UserMsgBox(Me, "File Can't Empty !!")
            Exit Sub
        End If
        If Not txtUpload.FileContent.Length > (10 * 1024) Then
            ' Handle file
            Modul.UserMsgBox(Me, "File size of Excel is too large.(10Mb)")
            Exit Sub
        End If

        Dim strFileName As String = txtUpload.PostedFile.FileName
        Dim filename As String = Path.GetFileName(strFileName)
        Dim new_path As String = Server.MapPath("Upload\") + filename

        txtUpload.PostedFile.SaveAs(new_path)
        Dim file_excel As New FileUpload
        file_excel = txtUpload
        'Upload_File_Excel(file_excel)
        If (file_excel.HasFile AndAlso IO.Path.GetExtension(file_excel.FileName) = ".xlsx") Then
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial
            Using excel = New ExcelPackage(file_excel.PostedFile.InputStream)
                dt_duplicate = New DataTable
                dt_duplicate.Columns.Add("BILL_NO")
                dt_duplicate.Columns.Add("NO_BILL_MANUAL")
                dt_duplicate.Columns.Add("PAYMENT_MODE")
                dt_duplicate.Columns.Add("POLICY_NUMBER")
                dt_duplicate.Columns.Add("ACCOUNT_NAME")
                dt_duplicate.Columns.Add("PRODUCT")
                dt_duplicate.Columns.Add("STATUS")
                dt_duplicate.Columns.Add("Error Message")
                Dim nSukses As Integer = 0
                Dim nGagal As Integer = 0
                Dim tbl = New DataTable()
                Dim ws = excel.Workbook.Worksheets.First()
                Dim hasHeader = True ' change it if required '
                ' create DataColumns '
                For Each firstRowCell In ws.Cells(1, 1, 1, ws.Dimension.End.Column)
                    tbl.Columns.Add(If(hasHeader,
                                       firstRowCell.Text,
                                       String.Format("Column {0}", firstRowCell.Start.Column)))
                Next
                ' add rows to DataTable '
                Dim startRow = If(hasHeader, 2, 1)
                For rowNum = startRow To ws.Dimension.End.Row
                    Dim wsRow = ws.Cells(rowNum, 1, rowNum, ws.Dimension.End.Column)
                    Dim row = tbl.NewRow()
                    For Each cell In wsRow
                        row(cell.Start.Column - 1) = cell.Text
                    Next
                    tbl.Rows.Add(row)
                Next

                Dim lstColumn As New List(Of String)
                lstColumn.Add("BILL_NO")
                lstColumn.Add("NO_BILL_MANUAL")
                lstColumn.Add("NO_TRANSAKSI")
                lstColumn.Add("PAYMENT_MODE")
                lstColumn.Add("POLICY_NUMBER")
                lstColumn.Add("ACCOUNT_NAME")
                lstColumn.Add("POLICY_EFFECTIVE_DATE")
                lstColumn.Add("PRODUCT")
                lstColumn.Add("TOTAL_MEMBER")
                lstColumn.Add("PREMIUM_AMOUNT")
                lstColumn.Add("ADDITION")
                lstColumn.Add("DELETION")
                lstColumn.Add("CHANGE PLAN")
                lstColumn.Add("FEE_ASO")
                lstColumn.Add("ASO")
                lstColumn.Add("BY_KARTU")
                lstColumn.Add("PAID")
                lstColumn.Add("OUTSTANDING")
                lstColumn.Add("ISSUE_DATE (SYSTEM)")
                lstColumn.Add("INVOICE_DATE") 'new
                lstColumn.Add("TYPE_OF_ENDORSMENT")
                lstColumn.Add("TGL_BAYAR")
                lstColumn.Add("TGL_BAYAR2")
                lstColumn.Add("TGL_BAYAR3")
                lstColumn.Add("TGL_INPUT G400")
                lstColumn.Add("RECEIPT")
                lstColumn.Add("RCL")
                lstColumn.Add("REMARK_COLLECTION")
                lstColumn.Add("KETERANGAN")
                lstColumn.Add("TGL_PENAGIHAN_PREMI")
                lstColumn.Add("TGL_PENAGIHAN_PREMI2")
                lstColumn.Add("TGL_PENAGIHAN_PREMI3")
                lstColumn.Add("Reason") 'unused
                lstColumn.Add("TGL_PROSES")
                lstColumn.Add("User")
                Dim iColumnCheck As Integer = 0
                If (hasHeader = True And tbl.Rows.Count() > 0) Then
                    ' check column 
                    If (tbl.Columns.Count = lstColumn.Count) Then

                        Dim iColumnIndex As Integer = 0
                        For Each Column As DataColumn In tbl.Columns
                            Dim strTblColumnName As String = Column.ColumnName.Trim.ToLower
                            Dim strLstColumnName As String = lstColumn.Item(iColumnIndex).Trim.ToLower
                            If (strTblColumnName.Equals(strLstColumnName)) Then
                                iColumnCheck = iColumnCheck + 1
                            End If
                            iColumnIndex = iColumnIndex + 1
                        Next
                    End If
                End If

                Dim hasError As Boolean = False
                If (iColumnCheck = tbl.Columns.Count) Then
                    Dim iRowsUpdate As Integer = 0

                    For Each Row As DataRow In tbl.Rows
                        Try

                            Dim vBILLNO As String = If(IsDBNull(Row.Item("BILL_NO")), "", Row.Item("BILL_NO").ToString())
                            Dim vBILLNOMANUAL As String = If(IsDBNull(Row.Item("NO_BILL_MANUAL")), "", Row.Item("NO_BILL_MANUAL").ToString())
                            Dim vNOTRANSAKSI As String = If(IsDBNull(Row.Item("NO_TRANSAKSI")), "", Row.Item("NO_TRANSAKSI").ToString())
                            Dim vPAYMENTMODE As String = If(IsDBNull(Row.Item("PAYMENT_MODE")), "", Row.Item("PAYMENT_MODE").ToString())
                            Dim vPOLICYNO As Integer = IIf(IsDBNull(Row.Item("POLICY_NUMBER")), 0, Convert.ToInt32(Row.Item("POLICY_NUMBER").ToString().Trim()))
                            Dim vACCOUNTNAME As String = If(IsDBNull(Row.Item("ACCOUNT_NAME")), "", Row.Item("ACCOUNT_NAME").ToString())
                            Dim vPRODUCT As String = If(IsDBNull(Row.Item("PRODUCT")), "", Row.Item("PRODUCT").ToString())
                            Dim vTOTALMEMBER As Integer = 0
                            Dim vPREMIUMAMOUNT As Double = 0
                            Dim vADDITION As Double = 0
                            Dim vDELETION As Double = 0
                            Dim vCHANGEPLAN As Double = 0
                            Dim vFEE_ASO As Double = 0
                            Dim vASO As Double = 0
                            Dim vBY_KARTU As Double = 0
                            Dim vPAID As Double = 0
                            Dim vOUTSTANDING As Double = 0
                            Dim vTYPE_OF_ENDORSMENT As String = Row.Item("TYPE_OF_ENDORSMENT").ToString().Trim()
                            If (Row.Item("TOTAL_MEMBER").ToString().Trim().Length > 0 And IsDBNull(Row.Item("TOTAL_MEMBER")) = False) Then
                                vTOTALMEMBER = Convert.ToInt32(Row.Item("TOTAL_MEMBER").ToString().Trim())
                            End If
                            If (Row.Item("PREMIUM_AMOUNT").ToString().Trim().Length > 0 And IsDBNull(Row.Item("PREMIUM_AMOUNT")) = False) Then
                                vPREMIUMAMOUNT = Convert.ToDouble(Row.Item("PREMIUM_AMOUNT").ToString().Trim())
                            End If
                            If (Row.Item("ADDITION").ToString().Trim().Length > 0 And IsDBNull(Row.Item("ADDITION")) = False) Then
                                vADDITION = Convert.ToDouble(Row.Item("ADDITION").ToString().Trim())
                            End If
                            If (Row.Item("DELETION").ToString().Trim().Length > 0 And IsDBNull(Row.Item("DELETION")) = False) Then
                                vDELETION = Convert.ToDouble(Row.Item("DELETION").ToString().Trim())
                            End If
                            If (Row.Item("CHANGE PLAN").ToString().Trim().Length > 0 And IsDBNull(Row.Item("CHANGE PLAN")) = False) Then
                                vCHANGEPLAN = Convert.ToDouble(Row.Item("CHANGE PLAN").ToString().Trim())
                            End If
                            If (Row.Item("FEE_ASO").ToString().Trim().Length > 0 And IsDBNull(Row.Item("FEE_ASO")) = False) Then
                                vFEE_ASO = Convert.ToDouble(Row.Item("FEE_ASO").ToString().Trim())
                            End If
                            If (Row.Item("ASO").ToString().Trim().Length > 0 And IsDBNull(Row.Item("ASO")) = False) Then
                                vASO = Convert.ToDouble(Row.Item("ASO").ToString().Trim())
                            End If
                            If (Row.Item("BY_KARTU").ToString().Trim().Length > 0 And IsDBNull(Row.Item("BY_KARTU")) = False) Then
                                vBY_KARTU = Convert.ToDouble(Row.Item("BY_KARTU").ToString().Trim())
                            End If
                            If (Row.Item("PAID").ToString().Trim().Length > 0 And IsDBNull(Row.Item("PAID")) = False) Then
                                vPAID = Convert.ToDouble(Row.Item("PAID").ToString().Trim())
                            End If
                            If (Row.Item("OUTSTANDING").ToString().Trim().Length > 0 And IsDBNull(Row.Item("OUTSTANDING")) = False) Then
                                vOUTSTANDING = Convert.ToDouble(Row.Item("OUTSTANDING").ToString().Trim())
                            End If

                            Dim vTGL_BAYAR As String
                            Dim vTGL_BAYAR2 As String
                            Dim vTGL_BAYAR3 As String
                            Dim vTGL_INPUTG400 As String
                            Dim vISSUE_DATE As String
                            Dim vEFFECTIVEDATE As String
                            Dim vINVOICE_DATE As String

                            Dim vIssueDate_POLICY_EFFECTIVE_DATE As String = Row.Item("POLICY_EFFECTIVE_DATE").ToString().Trim()

                            Dim isNotPolicyEffectiveDate As Boolean = False

                            If String.IsNullOrEmpty(vIssueDate_POLICY_EFFECTIVE_DATE) Then
                                vEFFECTIVEDATE = "1900-01-01"
                                isNotPolicyEffectiveDate = True
                            ElseIf IsDBNull(vIssueDate_POLICY_EFFECTIVE_DATE) Then
                                vEFFECTIVEDATE = "1900-01-01"
                                isNotPolicyEffectiveDate = True
                            ElseIf Not IsDate(vIssueDate_POLICY_EFFECTIVE_DATE) Then
                                vEFFECTIVEDATE = "1900-01-01"
                                isNotPolicyEffectiveDate = True
                            Else
                                vEFFECTIVEDATE = CDate(vIssueDate_POLICY_EFFECTIVE_DATE)
                            End If

                            Dim vIssueDate_ISSUE_DATE As String = Row.Item("ISSUE_DATE (SYSTEM)").ToString().Trim()

                            Dim isNotIssueDate As Boolean = False

                            If String.IsNullOrEmpty(vIssueDate_ISSUE_DATE) Then
                                vISSUE_DATE = "1900-01-01"
                                isNotIssueDate = True
                            ElseIf IsDBNull(vIssueDate_ISSUE_DATE) Then
                                vISSUE_DATE = "1900-01-01"
                                isNotIssueDate = True
                            ElseIf Not IsDate(vIssueDate_ISSUE_DATE) Then
                                vISSUE_DATE = "1900-01-01"
                                isNotIssueDate = True
                            Else
                                vISSUE_DATE = CDate(vIssueDate_ISSUE_DATE)
                            End If

                            ' NEW 2020/12/23 - INVOICE_DATE
                            If Row.Item("INVOICE_DATE").ToString = "" Then
                                vINVOICE_DATE = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("INVOICE_DATE").ToString) = True Then
                                vINVOICE_DATE = "1900-01-01"
                            Else
                                vINVOICE_DATE = CDate(Row.Item("INVOICE_DATE").ToString().Trim())
                            End If


                            Dim vIssueDate_TGL_INPUT As String = Row.Item("TGL_INPUT G400").ToString().Trim()

                            If Row.Item("TGL_INPUT G400").ToString = "" Then
                                vTGL_INPUTG400 = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_INPUT G400").ToString) = True Then
                                vTGL_INPUTG400 = "1900-01-01"
                            Else
                                vTGL_INPUTG400 = CDate(vIssueDate_TGL_INPUT)
                            End If

                            Dim vIssueDate_TGL_BAYAR As String = Row.Item("TGL_BAYAR").ToString().Trim()

                            If Row.Item("TGL_BAYAR").ToString = "" Then
                                vTGL_BAYAR = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_BAYAR").ToString) = True Then
                                vTGL_BAYAR = "1900-01-01"
                            Else
                                vTGL_BAYAR = CDate(vIssueDate_TGL_BAYAR)
                            End If

                            Dim vIssueDate_TGL_BAYAR2 As String = Row.Item("TGL_BAYAR2").ToString().Trim()

                            If Row.Item("TGL_BAYAR2").ToString = "" Then
                                vTGL_BAYAR2 = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_BAYAR2").ToString) = True Then
                                vTGL_BAYAR2 = "1900-01-01"
                            Else
                                vTGL_BAYAR2 = CDate(vIssueDate_TGL_BAYAR2)
                            End If

                            Dim vIssueDate_TGL_BAYAR3 As String = Row.Item("TGL_BAYAR3").ToString().Trim()

                            If Row.Item("TGL_BAYAR3").ToString = "" Then
                                vTGL_BAYAR3 = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_BAYAR3").ToString) = True Then
                                vTGL_BAYAR3 = "1900-01-01"
                            Else
                                vTGL_BAYAR3 = CDate(vIssueDate_TGL_BAYAR3)
                            End If

                            Dim vRECEIPT As String = Row.Item("RECEIPT").ToString().Trim()
                            Dim vRCL As Double = 0
                            If (Row.Item("RCL").ToString().Trim().Length > 0 And IsDBNull(Row.Item("RCL")) = False) Then
                                vRCL = Convert.ToDouble(Row.Item("RCL").ToString().Trim())
                            End If
                            Dim vREMARK_COLLECTION As String = If(IsDBNull(Row.Item("REMARK_COLLECTION")), "", Row.Item("REMARK_COLLECTION").ToString())
                            Dim vKETERANGAN As String = If(IsDBNull(Row.Item("KETERANGAN")), "", Row.Item("KETERANGAN").ToString())
                            'Dim vSTATUS As String = Row.Item("STATUS").ToString
                            Dim vSTATUS As String = "UNPAID"

                            Dim vTGL_PENAGIHAN_PREMI As String
                            Dim vTGL_PENAGIHAN_PREMI2 As String
                            Dim vTGL_PENAGIHAN_PREMI3 As String

                            Dim vIssueDate_TGL_PENAGIHAN_PREMI As String = Row.Item("TGL_PENAGIHAN_PREMI").ToString().Trim()

                            If Row.Item("TGL_PENAGIHAN_PREMI").ToString = "" Then
                                vTGL_PENAGIHAN_PREMI = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_PENAGIHAN_PREMI").ToString) = True Then
                                vTGL_PENAGIHAN_PREMI = "1900-01-01"
                            Else
                                vTGL_PENAGIHAN_PREMI = CDate(vIssueDate_TGL_PENAGIHAN_PREMI)
                            End If

                            Dim vIssueDate_TGL_PENAGIHAN_PREMI2 As String = Row.Item("TGL_PENAGIHAN_PREMI2").ToString().Trim()

                            If Row.Item("TGL_PENAGIHAN_PREMI2").ToString = "" Then
                                vTGL_PENAGIHAN_PREMI2 = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_PENAGIHAN_PREMI2").ToString) = True Then
                                vTGL_PENAGIHAN_PREMI2 = "1900-01-01"
                            Else
                                vTGL_PENAGIHAN_PREMI2 = CDate(vIssueDate_TGL_PENAGIHAN_PREMI2)
                            End If

                            Dim vIssueDate_TGL_PENAGIHAN_PREMI3 As String = Row.Item("TGL_PENAGIHAN_PREMI3").ToString().Trim()

                            If Row.Item("TGL_PENAGIHAN_PREMI3").ToString = "" Then
                                vTGL_PENAGIHAN_PREMI3 = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_PENAGIHAN_PREMI3").ToString) = True Then
                                vTGL_PENAGIHAN_PREMI3 = "1900-01-01"
                            Else
                                vTGL_PENAGIHAN_PREMI3 = CDate(vIssueDate_TGL_PENAGIHAN_PREMI3)
                            End If

                            Dim vReason As String = If(IsDBNull(Row.Item("Reason")), "", Row.Item("Reason").ToString())

                            Dim vTGL_PROSES As String

                            If Row.Item("TGL_PROSES").ToString = "" Then
                                vTGL_PROSES = "1900-01-01"
                            ElseIf IsDBNull(Row.Item("TGL_PROSES").ToString) = True Then
                                vTGL_PROSES = "1900-01-01"
                            Else
                                vTGL_PROSES = CDate(Row.Item("TGL_PROSES").ToString().Trim())
                            End If

                            Dim vUser As String = Row.Item("User").ToString

                            If String.IsNullOrEmpty(vBILLNO) = True Then
                                vBILLNO = vBILLNOMANUAL
                            End If

                            Dt = oSelect.sp_get_detail_premi(vBILLNO)

                            If Dt.Rows.Count > 0 Then
                                dt_duplicate.Rows.Add("'" & vBILLNO, vBILLNOMANUAL, vPAYMENTMODE, vPOLICYNO, vACCOUNTNAME, vPRODUCT, vSTATUS, "DUPLICATE DATA")
                            ElseIf isNotPolicyEffectiveDate Then
                                dt_duplicate.Rows.Add("'" & vBILLNO, vBILLNOMANUAL, vPAYMENTMODE, vPOLICYNO, vACCOUNTNAME, vPRODUCT, vSTATUS, "INVALID FORMAT POLICY EFFECTIVE DATE")
                            ElseIf isNotIssueDate Then
                                dt_duplicate.Rows.Add("'" & vBILLNO, vBILLNOMANUAL, vPAYMENTMODE, vPOLICYNO, vACCOUNTNAME, vPRODUCT, vSTATUS, "INVALID FORMAT ISSUE DATE")
                            Else
                                nSukses += 1

                                'oInsert.f_Insert_Data_premi(vBILLNO, vBILLNOMANUAL, vNOTRANSAKSI, vPAYMENTMODE, vPOLICYNO, vACCOUNTNAME, vEFFECTIVEDATE,
                                '                        vPRODUCT, vTOTALMEMBER, vPREMIUMAMOUNT, vADDITION, vDELETION, vCHANGEPLAN, vFEE_ASO, vASO,
                                '                        vBY_KARTU, vPAID, vOUTSTANDING, vISSUE_DATE, vTYPE_OF_ENDORSMENT, vTGL_BAYAR, vTGL_BAYAR2, vTGL_BAYAR3, vTGL_INPUTG400,
                                '                        vRECEIPT, vRCL, vREMARK_COLLECTION, vKETERANGAN, vSTATUS, vTGL_PENAGIHAN_PREMI, vTGL_PENAGIHAN_PREMI2,
                                '                        vTGL_PENAGIHAN_PREMI3, vReason, vTGL_PROSES, Session("username").ToString, UCase(vUser))

                                ' NEW 2020/12/23 - INVOICE_DATE
                                oInsert.f_Insert_Data_premi(vBILLNO, vBILLNOMANUAL, vNOTRANSAKSI, vPAYMENTMODE, vPOLICYNO, vACCOUNTNAME, vEFFECTIVEDATE,
                                                        vPRODUCT, vTOTALMEMBER, vPREMIUMAMOUNT, vADDITION, vDELETION, vCHANGEPLAN, vFEE_ASO, vASO,
                                                        vBY_KARTU, vPAID, vOUTSTANDING, vISSUE_DATE, vTYPE_OF_ENDORSMENT, vTGL_BAYAR, vTGL_BAYAR2, vTGL_BAYAR3, vTGL_INPUTG400,
                                                        vRECEIPT, vRCL, vREMARK_COLLECTION, vKETERANGAN, vSTATUS, vTGL_PENAGIHAN_PREMI, vTGL_PENAGIHAN_PREMI2,
                                                        vTGL_PENAGIHAN_PREMI3, vReason, vTGL_PROSES, Session("username").ToString, UCase(vUser), vINVOICE_DATE)
                            End If
                            'nSukses += 1
                            'Modul.UserMsgBox(Me, "Upload File Excel Success.")
                        Catch ex As Exception
                            'Modul.UserMsgBox(Me, "Error Message : " & ex.Message.ToString)
                            'Throw (ex)
                            hasError = True
                            dt_duplicate.Rows.Add("'" & If(IsDBNull(Row.Item("BILL_NO")), "", Row.Item("BILL_NO").ToString()),
                                                  If(IsDBNull(Row.Item("NO_BILL_MANUAL")), "", Row.Item("NO_BILL_MANUAL").ToString()),
                                                  If(IsDBNull(Row.Item("PAYMENT_MODE")), "", Row.Item("PAYMENT_MODE").ToString()),
                                                  IIf(IsDBNull(Row.Item("POLICY_NUMBER")), 0, Convert.ToInt32(Row.Item("POLICY_NUMBER").ToString().Trim())),
                                                  If(IsDBNull(Row.Item("ACCOUNT_NAME")), "", Row.Item("ACCOUNT_NAME").ToString()),
                                                  If(IsDBNull(Row.Item("PRODUCT")), "", Row.Item("PRODUCT").ToString()),
                                                  "Error", ex.Message.ToString & " Line : " & Right(ex.StackTrace.ToString, 4))
                            'Exit For
                        End Try
                        iRowsUpdate = iRowsUpdate + 1
                    Next

                    nGagal = tbl.Rows.Count - nSukses
                    LblSes.Text = nSukses.ToString & " Record"
                    LblGal.Text = nGagal.ToString & " Record"

                    If dt_duplicate.Rows.Count > 0 Then
                        btnGenerateReject.Visible = True
                        lbl_doubldata.Text = dt_duplicate.Rows.Count.ToString & " Record"
                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                        "alert('Upload Data Sukses. Terdapat " & dt_duplicate.Rows.Count & " data duplicate/error');", True)
                    Else
                        btnGenerateReject.Visible = False
                        lbl_doubldata.Text = ""

                        'If (hasError) Then
                        '    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                        '"alert('Upload Data Gagal');", True)
                        'Else
                        '    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                        '"alert('Upload Data Sukses');", True)
                        'End If
                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                        "alert('Upload Data Sukses');", True)
                    End If


                    DGDuplicatePremi.DataSource = dt_duplicate
                    DGDuplicatePremi.DataBind()
                Else
                    Modul.UserMsgBox(Me, "File Excel Columns not match.")
                    'Dim msg = String.Format("Update fail created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3}",
                    'tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count)
                    'UploadStatusLabel.Text = msg
                End If


                tbl = Nothing
            End Using


        Else
            If (file_excel.HasFile) Then
                ' Handle file
                Modul.UserMsgBox(Me, "File Excel must with extension .xlsx only !!")
                Exit Sub
            Else
                ' Handle file
                Modul.UserMsgBox(Me, "File Upload Can't Empty !!")
                Exit Sub
            End If
        End If

        file_excel.Dispose()
        txtUpload.Dispose()
    End Sub

    Protected Sub Btn_Template_Click(sender As Object, e As EventArgs) Handles Btn_Template.Click
        Try
            Dim sPath As String = Server.MapPath("~\TemplateFiles\")
            Response.Clear()
            Response.Charset = ""
            Response.ContentEncoding = System.Text.Encoding.UTF8
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;filename=Template_Premi_" + Now.ToString("yyyyMMdd_HHmmss") + ".xlsx")
            'Response.AppendHeader("Content-Disposition", "attachment;filename=Template_Premi_Tahunan.xlsx")
            Response.TransmitFile(sPath & "Template_Premi.xlsx")
            Response.Flush()
            Response.End()

        Catch ex As Exception
        End Try
    End Sub

    Protected Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Try
            'Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "alert('Batal upload !');", True)
            Response.Redirect("~/Form/UploadDataPremi.aspx", False)
        Catch ex As Exception
            ex.Message.ToString()
            Throw
        Finally

        End Try
    End Sub
End Class