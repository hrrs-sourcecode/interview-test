﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices
Imports System.Data.OleDb
Partial Public Class ReportPaymenttoflips
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

        End If
    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSave.Click

        If Not txtUpload.HasFile Then
            ' Handle file
            Modul.UserMsgBox(Me, "File Detail Can't Empty !!")
            Exit Sub
        End If

        Dim filepath As String = "~\Form\ReportPaymenttoflips.aspx"
        Dim uploadedFiles As HttpFileCollection = Request.Files
        Dim x As Integer = 0

        Dim MyConnection As OleDbConnection
        Dim MyCommand_Upload As OleDbDataAdapter



        Dim userPostedFile As HttpPostedFile = uploadedFiles(x)
        Try
            If (userPostedFile.ContentLength > 0) Then

                Dim DtData_Upload As New DataTable

                MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; " & _
                                    "data source='" & userPostedFile.FileName & " '; " & "Extended Properties=Excel 12.0;")

                MyConnection.Open()

                If x = 0 Then

                    MyCommand_Upload = New OleDbDataAdapter(String.Format("SELECT * FROM [KLAIM PROVIDER 28042016$]", userPostedFile.FileName), MyConnection)
                    MyCommand_Upload.Fill(DtData_Upload)

                    For i = 0 To DtData_Upload.Rows.Count
                        Try
                            If i = DtData_Upload.Rows.Count Then
                                Exit For
                            End If

                            Dim vTRANSDATE As String = Left(DtData_Upload.Rows(i).Item(0).ToString.ToUpper, 10)
                            Dim vPOLICYNO As String = DtData_Upload.Rows(i).Item(1).ToString.ToUpper
                            Dim vCLAIMTYPE As String = DtData_Upload.Rows(i).Item(2).ToString.ToUpper
                            Dim vPROVORG As String = Replace(DtData_Upload.Rows(i).Item(3).ToString.ToUpper, "'", "")
                            Dim vCLAIMNO As String = DtData_Upload.Rows(i).Item(4).ToString.ToUpper
                            Dim vWHOPAID As String = DtData_Upload.Rows(i).Item(5).ToString.ToUpper
                            Dim vCLIENT_CLAIM_REF As String = DtData_Upload.Rows(i).Item(6).ToString.ToUpper
                            Dim vFIRSTREPORTDATE As String = DtData_Upload.Rows(i).Item(7).ToString.ToUpper
                            Dim vCLAIMFORMRECEIVEDON As String = DtData_Upload.Rows(i).Item(8).ToString.ToUpper
                            Dim vMEMBERNO As String = DtData_Upload.Rows(i).Item(9).ToString.ToUpper
                            Dim vMEMBERNAME As String = DtData_Upload.Rows(i).Item(10).ToString.ToUpper
                            Dim vPATIENTNO As String = DtData_Upload.Rows(i).Item(11).ToString.ToUpper
                            Dim vPATIENTNAME As String = DtData_Upload.Rows(i).Item(12).ToString.ToUpper
                            Dim vADMISSIONDATE As String = Left(DtData_Upload.Rows(i).Item(13).ToString.ToUpper, 10)
                            Dim vDISCHARGEDATE As String = Left(DtData_Upload.Rows(i).Item(14).ToString.ToUpper, 10)
                            Dim vDIAGNOSISCODE As String = DtData_Upload.Rows(i).Item(15).ToString.ToUpper
                            Dim vPROCEDURECODE As String = DtData_Upload.Rows(i).Item(16).ToString.ToUpper
                            Dim vLIMIT As Integer = DtData_Upload.Rows(i).Item(17).ToString.ToUpper
                            Dim vINCURRED As Integer = DtData_Upload.Rows(i).Item(18).ToString.ToUpper
                            Dim vPAID As Integer = DtData_Upload.Rows(i).Item(19).ToString.ToUpper
                            Dim vCOVER As Integer = DtData_Upload.Rows(i).Item(20).ToString.ToUpper
                            Dim vUNPAID As Integer = DtData_Upload.Rows(i).Item(21).ToString.ToUpper
                            Dim vEXCESS As Integer = DtData_Upload.Rows(i).Item(22).ToString.ToUpper
                            Dim vREMARKS As String = DtData_Upload.Rows(i).Item(23).ToString.ToUpper
                            Dim vCLAIMSTATUS As String = DtData_Upload.Rows(i).Item(24).ToString.ToUpper
                            Dim vAUTHORIZATIONDATE As String = Left(DtData_Upload.Rows(i).Item(25).ToString.ToUpper, 10)
                            Dim vSUBMISSIONDATE As String = Left(DtData_Upload.Rows(i).Item(26).ToString.ToUpper, 10)
                            Dim vPAYMENTDATE As String = Left(DtData_Upload.Rows(i).Item(27).ToString.ToUpper, 10)
                            Dim vGERNO1 As String = Replace(DtData_Upload.Rows(i).Item(28).ToString.ToUpper, "'", "")
                            Dim vGERNO2 As String = Replace(DtData_Upload.Rows(i).Item(29).ToString.ToUpper, "'", "")
                            Dim vGERDATE As String = DtData_Upload.Rows(i).Item(30).ToString.ToUpper
                            Dim vDATELETTERAXA As String = DtData_Upload.Rows(i).Item(31).ToString.ToUpper
                            Dim vUSERID As String = DtData_Upload.Rows(i).Item(32).ToString.ToUpper
                            Dim vTICK As String = DtData_Upload.Rows(i).Item(33).ToString.ToUpper
                            Dim vPAYMENTTYPE As String = DtData_Upload.Rows(i).Item(34).ToString.ToUpper
                            Dim vMANUAL As String = DtData_Upload.Rows(i).Item(35).ToString.ToUpper


                            SQL = "INSERT INTO Tbl_FLIPS values('" & vTRANSDATE & "','" & vPOLICYNO & "','" & vCLAIMTYPE & "', " & _
                                  "'" & vPROVORG & "','" & vCLAIMNO & "','" & vWHOPAID & "','" & vCLIENT_CLAIM_REF & "','" & vFIRSTREPORTDATE & "', " & _
                                  "'" & vCLAIMFORMRECEIVEDON & "','" & vMEMBERNO & "','" & vMEMBERNAME & "','" & vPATIENTNO & "','" & vPATIENTNAME & "', " & _
                                  "'" & vADMISSIONDATE & "','" & vDISCHARGEDATE & "','" & vDIAGNOSISCODE & "','" & vPROCEDURECODE & "','" & vLIMIT & "', " & _
                                  "'" & vINCURRED & "','" & vPAID & "','" & vCOVER & "','" & vUNPAID & "','" & vEXCESS & "','" & vREMARKS & "', " & _
                                  "'" & vCLAIMSTATUS & "','" & vAUTHORIZATIONDATE & "','" & vSUBMISSIONDATE & "','" & vPAYMENTDATE & "','" & vGERNO1 & "', " & _
                                  "'" & vGERNO2 & "','" & vGERDATE & "','" & vDATELETTERAXA & "','" & vUSERID & "','" & vTICK & "','" & vPAYMENTTYPE & "','" & vMANUAL & "')"
                            Modul.Eksekusi(SQL)


                        Catch ex As Exception

                        End Try

                    Next

                    DtData_Upload = Nothing

                End If

                MyConnection.Close()
                
            End If

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            "alert('Upload Data Sukses'); window.location='ReportPaymenttoflips.aspx';", True)
            'SQL = "TRUNCATE TABLE TRN_HDR_SPECIAL_CASE "
            'Modul.Eksekusi(SQL)
        Catch ex As Exception

            MsgBox(ex.Message)
            Throw (ex)

        End Try


        
        'System.IO.File.Delete(userPostedFile.FileName)

    End Sub
End Class