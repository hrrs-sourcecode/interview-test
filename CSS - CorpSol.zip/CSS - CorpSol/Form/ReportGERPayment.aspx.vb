﻿Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.Office.Interop
Imports Microsoft.Office.Interop.Excel
Imports System.Reflection
Imports System
Partial Public Class ReportGERPayment
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub

    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click
        Try
            Dim dt_report As New System.Data.DataTable

            If txtFrom.Text.Trim = "" Or txtTo.Text.Trim = "" Then
                Exit Sub
            End If
            'dt_report.Columns.Add("Date Submitted")
            'dt_report.Columns.Add("GER No.")
            'dt_report.Columns.Add("Date GER Created")
            'dt_report.Columns.Add("Claim Type")
            'dt_report.Columns.Add("Total Case")
            'dt_report.Columns.Add("Amont Paid")

            SQL = "SELECT [Submission Date] as [Date Submitted],'GR'+ REPLACE([GER No 1],'''','') as [GER No.],Transdate as [Date GER Created]," & _
                  "CASE WHEN [Who Paid] = 'P' THEN 'Provider' ELSE 'Reimbursement' END as [Claim Type],COUNT(0) as [Total Case],SUM([Total Amount]) as [Amount Paid] FROM Tbl_GER " & _
                  "WHERE Transdate >='" & txtFrom.Text.Trim & "' AND Transdate <='" & txtTo.Text.Trim & "' Group BY [Submission Date],'GR'+ REPLACE([GER No 1],'''',''),Transdate,[Who Paid]"
            dt_report = Modul.getAllDatainDT(SQL)

            'For x = 0 To Dt.Rows.Count - 1
            '    dt_report.Rows.Add(Dt.Rows(x).Item(0).ToString.ToUpper(), Dt.Rows(x).Item(1).ToString.ToUpper(), Dt.Rows(x).Item(2).ToString.ToUpper(), _
            '                       Dt.Rows(x).Item(3).ToString(), Dt.Rows(x).Item(4).ToString.ToUpper(), Format(Dt.Rows(x).Item(5), "#,##0"))
            'Next

            If dt_report.Rows.Count > 0 Then
                Dim sFileName As String = ""

                sFileName = "CLAIM PAYMENT REPORT (GER) " & Replace(txtFrom.Text.Trim, "/", "") & " To " & Replace(txtFrom.Text.Trim, "/", "") & ".xls"

                'Dim GridView1 As New GridView()
                'GridView1.AllowPaging = False
                'GridView1.DataSource = dt_report
                'GridView1.DataBind()

                Dim exceltable As New StringBuilder()

                exceltable.Append("<HTML><BODY><table><tr><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>" & _
                                  "<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td></tr><tr>" & _
                                  "<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>" & _
                                  "<td><font size=3 face=Tahoma><b>Claim Payment Report (GER) </b></font></td></tr></table>" & _
                                 "<table><tr><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>" & _
                                 "<td>Periode</td><td>" & txtFrom.Text.Trim & " s/d " & txtTo.Text.Trim & "</td></tr><tr>" & _
                                 "<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>" & _
                                 "<td>Report Date</td><td>" & Date.Now.ToString("dd/MM/yyyy") & "</td></tr></table><br /><table><tr>" & _
                                 "<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td><td><TABLE Border=1>")
                exceltable.AppendFormat("<TR>")

                exceltable.AppendFormat(String.Concat("<TD>Date Submitted</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>GER No.</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Date GER Created</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Claim Type</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Total Case</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Amount Paid</TD>"))

                exceltable.AppendFormat("</TR>")

                For Each row As DataRow In dt_report.Rows
                    exceltable.AppendFormat("<TR>")

                    exceltable.AppendFormat(String.Concat("<TD>", row("Date Submitted").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("GER No.").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Date GER Created").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Claim Type").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Total Case").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Amount Paid").ToString(), "</TD>"))
                    
                    exceltable.AppendFormat("</TR>")
                Next

                exceltable.Append("</TABLE></td></tr></table></BODY></HTML>")

                Response.Clear()
                Response.Buffer = True
                Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                Response.Charset = ""
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Me.EnableViewState = False
                Response.ContentType = "application/vnd.ms-excel"
                
                Response.AddHeader("X-Download-Options", "noopen")

                'Remove the charset from the Content-Type header.
                Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                Response.Write(style)

                Response.Write(exceltable.ToString())

                'Response.Clear()
                'Response.Buffer = True
                'Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                'Response.Charset = ""
                'Response.Cache.SetCacheability(HttpCacheability.NoCache)
                'Me.EnableViewState = False
                'Response.ContentType = "application/vnd.ms-excel"
                'Dim StringWrite As New System.IO.StringWriter
                'Dim HtmlWrite As New System.Web.UI.HtmlTextWriter(StringWrite)

                'GridView1.RenderControl(HtmlWrite)

                'Response.AddHeader("X-Download-Options", "noopen")

                ''Remove the charset from the Content-Type header.
                'Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                'Response.Write(style)

                'Response.Write(StringWrite.ToString())
                Response.End()

            End If

        Catch ex As Exception

        End Try
    End Sub


    Public Sub ExportExcel(ByVal sfilename As String, ByVal dt_report As System.Data.DataTable)
        Dim newFilePath As String = Server.MapPath("Report\") + sfilename
        Dim objExcel As ApplicationClass = Nothing
        Dim objBooks As Workbooks = Nothing
        Dim objBook As _Workbook = Nothing
        Dim objSheets As Sheets = Nothing
        Dim objSheet As _Worksheet = Nothing
        Dim objRange As Range = Nothing
        Dim row As Integer = 6, col As Integer = 2
        Dim Mydate As Date

        objExcel = New ApplicationClass()
        objBooks = objExcel.Workbooks
        objBook = objBooks.Add(XlWBATemplate.xlWBATWorksheet)

        'Print column heading in the excel sheet
        Dim j As Integer = col

        For Each column As DataColumn In dt_report.Columns
            objSheets = objBook.Worksheets
            objSheet = DirectCast(objSheets.Item(1), _Worksheet)
            objRange = DirectCast(objSheet.Cells(row, j), Range)
            objRange.Value2 = column.ColumnName
            objRange.Columns.WrapText = True
            objRange.Font.Bold = True
            objRange.Font.Name = "Tahoma"
            objRange.Font.Size = 10
            'objRange.HorizontalAlignment = "Center"
            'objRange.VerticalAlignment = "Center"
            objRange.BorderAround()
            objRange.Columns.AutoFit()
            j += 1
        Next
        row += 1

        Dim count As Integer = dt_report.Columns.Count

        For Each dataRow As DataRow In dt_report.Rows
            Dim k As Integer = col
            For i As Integer = 0 To count - 1
                objRange = DirectCast(objSheet.Cells(row, k), Range)
                objRange.Value2 = dataRow(i).ToString()
                objRange.Font.Name = "Tahoma"
                objRange.Font.Size = 10
                'objRange.VerticalAlignment = "Center"
                objRange.BorderAround()
                objRange.Rows.AutoFit()
                k += 1
            Next
            row += 1
        Next


        objRange = DirectCast(objSheet.Cells(2, 2), Range)
        objRange.Font.Bold = True
        objRange.Font.Name = "Tahoma"
        objRange.Value2 = "Claim Payment Report (GER)"

        objRange = DirectCast(objSheet.Cells(3, 2), Range)
        objRange.Value2 = "Periode"

        objRange = DirectCast(objSheet.Cells(4, 2), Range)
        objRange.Value2 = "Report date"

        objRange = DirectCast(objSheet.Cells(3, 3), Range)
        objRange.Value2 = txtFrom.Text.Trim & " s/d " & txtTo.Text.Trim

        objRange = DirectCast(objSheet.Cells(4, 3), Range)
        objRange.Value2 = Mydate.ToString("dd/MM/yyyy")


        'Save Excel document
        objSheet.Name = "Sheet1"

        Dim report As String = Server.MapPath("Report\")
        If Not System.IO.Directory.Exists(report) Then
            System.IO.Directory.CreateDirectory(report)
        End If
        Dim reportName As String = Server.MapPath("Report\" + sfilename)
        If System.IO.File.Exists(reportName) Then
            System.IO.File.Delete(reportName)
        End If

        Dim sAppPath As String = Server.MapPath("Report\" + sfilename)
        Dim sPath As String = Request.ApplicationPath + "\Report\" + sfilename

        Dim objOpt As Object = Missing.Value
        objBook.SaveAs(newFilePath, objOpt, objOpt, objOpt, objOpt, objOpt, _
         XlSaveAsAccessMode.xlNoChange, objOpt, objOpt, objOpt, objOpt, objOpt)
        objBook.Close(False, objOpt, objOpt)

        Dim TheFile As System.IO.FileInfo = New System.IO.FileInfo(sAppPath)
        If (TheFile.Exists) Then

            Response.ContentType = "application/vnd.ms-excel"
            Response.AddHeader("Content-Disposition", "inline; filename=" + sfilename)

            Response.AddHeader("X-Download-Options", "noopen")

            'Remove the charset from the Content-Type header.
            Response.Charset = ""
            Response.WriteFile(TheFile.FullName)
            Response.End()

            'Response.Redirect(sPath)
        End If

        objExcel = Nothing
        objBooks = Nothing
        objBook = Nothing
        objSheets = Nothing
        objSheet = Nothing
        objRange = Nothing
        ReleaseComObject(objExcel)
        ReleaseComObject(objBooks)
        ReleaseComObject(objBook)
        ReleaseComObject(objSheets)
        ReleaseComObject(objSheet)
        ReleaseComObject(objRange)
    End Sub

    Public Sub ReleaseComObject(ByVal reference As Object)
        Try
            While System.Runtime.InteropServices.Marshal.ReleaseComObject(reference) <= 0
            End While
        Catch
        End Try
    End Sub
End Class