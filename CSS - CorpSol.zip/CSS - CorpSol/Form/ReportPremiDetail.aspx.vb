﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices
Imports System.Data.OleDb
Imports Microsoft.Office.Interop
Imports System.IO
Partial Public Class ReportPremiDetail
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim oSelect As New SelectBase
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If
            BindGrid("", "", "")
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If

            BindGrid(txtPOLICYNO.Text.Trim, ddlStatus.SelectedValue.ToString, ddlReason.SelectedValue.ToString)
        End If
    End Sub
    Public Sub BindGrid(ByVal POLICY_NO As String, ByVal STATUS As String, ByVal REASON As String)
        Dt = oSelect.sp_Create_Report_Premi_Detail(POLICY_NO, STATUS, REASON)
        GridPremi.DataSource = Dt
        GridPremi.DataBind()
        lblTotal.Text = Dt.Rows.Count & " Data"
    End Sub

    Protected Sub btnReport_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReport.Click
        Try
            Dim dt_report As New DataTable

            dt_report = oSelect.sp_Create_Report_Premi_Detail(txtPOLICYNO.Text.Trim, ddlStatus.SelectedValue.ToString, ddlReason.SelectedValue.ToString)

            If dt_report.Rows.Count > 0 Then
                Dim sFileName As String = ""

                Dim sysdate As Date = Date.Now.Date

                sFileName = "REPORT PREMI " & Replace(sysdate.ToString("dd/MM/yyyy"), "/", "") & ".xls"

                Dim GridView1 As New GridView()
                GridView1.AllowPaging = False
                GridView1.AllowSorting = False
                GridView1.DataSource = dt_report
                GridView1.DataBind()

                Response.Clear()
                Response.Buffer = True
                Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                Response.Charset = ""
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Me.EnableViewState = False
                Response.ContentType = "application/vnd.ms-excel"
                Dim StringWrite As New System.IO.StringWriter
                Dim HtmlWrite As New System.Web.UI.HtmlTextWriter(StringWrite)

                For Each r As GridViewRow In GridView1.Rows
                    If r.RowType = DataControlRowType.DataRow Then
                        For columnIndex As Integer = 0 To r.Cells.Count - 1
                            r.Cells(columnIndex).Attributes.Add("class", "text")
                        Next
                    End If
                Next

                GridView1.RenderControl(HtmlWrite)

                Response.AddHeader("X-Download-Options", "noopen")

                'Remove the charset from the Content-Type header.
                Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                Response.Write(style)

                Response.Write(StringWrite.ToString())
                Response.End()
            End If

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
    End Sub

    Private Sub GridPremi_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridPremi.PageIndexChanging
        GridPremi.PageIndex = e.NewPageIndex
        BindGrid(txtPOLICYNO.Text.Trim, ddlStatus.SelectedValue.ToString, ddlReason.SelectedValue.ToString)
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click

    End Sub

    Protected Sub btnReportSummary_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReportSummary.Click
        GeDataPremiSummary()
    End Sub
    Private Sub GeDataPremiSummary()
        Try
            Dt = oSelect.sp_Create_Report_Summary_Premi_Pivot

            Dim initialCatalogOleDB As String = ConfigurationManager.AppSettings("initialCatalogOleDB").ToString()
            Dim dataSourceOleDB As String = ConfigurationManager.AppSettings("dataSourceOleDB").ToString()
            Dim userIdOleDB As String = ConfigurationManager.AppSettings("userIdOleDB").ToString()
            Dim passOleDB As String = ConfigurationManager.AppSettings("passOleDB").ToString()


            Dim connection As String = "OLEDB;Provider=SQLOLEDB.1;Password=" + passOleDB +
                                   ";Persist Security Info=True;User ID=" + userIdOleDB +
                                   ";Initial Catalog=" + initialCatalogOleDB +
                                   ";Data Source=" + dataSourceOleDB

            Dim command As String = Dt.Rows(0).Item(0).ToString
            Dim app As Excel.Application = New Microsoft.Office.Interop.Excel.Application()
            Dim workbook As Excel.Workbook = CType(app.Workbooks.Add(Type.Missing), Microsoft.Office.Interop.Excel.Workbook)
            Dim sheet As Excel.Worksheet = CType(workbook.ActiveSheet, Microsoft.Office.Interop.Excel.Worksheet)
            Dim range As Excel.Range
            Dim dt_detail As New DataTable

            dt_detail = oSelect.sp_Create_Report_Detail_Premi_Pivot()

            range = sheet.Range("B1:B" & dt_detail.Rows.Count + 1)
            range.NumberFormat = "@"



            ' create textfile detail premi
            Dim sb As StringBuilder = New StringBuilder()
            Dim strDelimiter As String = ", "


            ' CREATE HEADER 
            sb.Append("ID_Premi")
            sb.Append(strDelimiter)
            sb.Append("BILL_NO")
            sb.Append(strDelimiter)
            sb.Append("NO_BILL_MANUAL")
            sb.Append(strDelimiter)
            sb.Append("NO_TRANSAKSI")
            sb.Append(strDelimiter)
            sb.Append("PAYMENT_MODE")
            sb.Append(strDelimiter)
            sb.Append("POLICY_NUMBER")
            sb.Append(strDelimiter)
            sb.Append("ACCOUNT_NAME")
            sb.Append(strDelimiter)
            sb.Append("POLICY_EFFECTIVE_DATE")
            sb.Append(strDelimiter)
            sb.Append("PRODUCT")
            sb.Append(strDelimiter)
            sb.Append("TOTAL_MEMBER")
            sb.Append(strDelimiter)
            sb.Append("PREMIUM_AMOUNT")
            sb.Append(strDelimiter)
            sb.Append("ADDITION")
            sb.Append(strDelimiter)
            sb.Append("DELETION")
            sb.Append(strDelimiter)
            sb.Append("CHANGE PLAN")
            sb.Append(strDelimiter)
            sb.Append("FEE_ASO")
            sb.Append(strDelimiter)
            sb.Append("ASO")
            sb.Append(strDelimiter)
            sb.Append("BY_KARTU")
            sb.Append(strDelimiter)
            sb.Append("PAID")
            sb.Append(strDelimiter)
            sb.Append("OUTSTANDING")
            sb.Append(strDelimiter)
            sb.Append("ISSUE_DATE (SYSTEM)")
            sb.Append(strDelimiter)
            sb.Append("TYPE_OF_ENDORSMENT")
            sb.Append(strDelimiter)
            sb.Append("TGL_BAYAR")
            sb.Append(strDelimiter)
            sb.Append("TGL_BAYAR2")
            sb.Append(strDelimiter)
            sb.Append("TGL_BAYAR3")
            sb.Append(strDelimiter)
            sb.Append("TGL_INPUT G400")
            sb.Append(strDelimiter)
            sb.Append("RECEIPT")
            sb.Append(strDelimiter)
            sb.Append("RCL")
            sb.Append(strDelimiter)
            sb.Append("REMARK_COLLECTION")
            sb.Append(strDelimiter)
            sb.Append("KETERANGAN")
            sb.Append(strDelimiter)
            sb.Append("STATUS")
            sb.Append(strDelimiter)
            sb.Append("TGL_PENAGIHAN_PREMI")
            sb.Append(strDelimiter)
            sb.Append("TGL_PENAGIHAN_PREMI2")
            sb.Append(strDelimiter)
            sb.Append("TGL_PENAGIHAN_PREMI3")
            sb.Append(strDelimiter)
            sb.Append("Reason")
            sb.Append(strDelimiter)
            sb.Append("TGL_PROSES")
            sb.Append(strDelimiter)
            sb.Append("TGL_UPLOAD")
            sb.Append(strDelimiter)
            sb.Append("STATUS_POLIS")
            sb.Append(strDelimiter)
            sb.Append("GROUP_NAME")
            sb.Append(strDelimiter)
            sb.Append("Aging_Paid")
            sb.Append(strDelimiter)
            sb.Append("Aging Code_Paid")
            sb.Append(strDelimiter)
            sb.Append("Aging_OS")
            sb.Append(strDelimiter)
            sb.Append("Aging Code_OS")
            sb.Append(strDelimiter)
            sb.Append("TGL_CUT_OFF" + System.Environment.NewLine)


            If dt_detail.Rows.Count > 0 Then

                For Each dr As DataRow In dt_detail.Rows

                    sb.Append(dr("ID_Premi").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("BILL_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("NO_BILL_MANUAL").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("NO_TRANSAKSI").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("PAYMENT_MODE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("POLICY_NUMBER").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("ACCOUNT_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("POLICY_EFFECTIVE_DATE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("PRODUCT").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TOTAL_MEMBER").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("PREMIUM_AMOUNT").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("ADDITION").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("DELETION").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("CHANGE PLAN").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("FEE_ASO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("ASO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("BY_KARTU").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("PAID").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("OUTSTANDING").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("ISSUE_DATE (SYSTEM)").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TYPE_OF_ENDORSMENT").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_BAYAR").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_BAYAR2").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_BAYAR3").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_INPUT G400").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("RECEIPT").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("RCL").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("REMARK_COLLECTION").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("KETERANGAN").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("STATUS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PENAGIHAN_PREMI").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PENAGIHAN_PREMI2").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PENAGIHAN_PREMI3").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Reason").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PROSES").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_UPLOAD").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("STATUS_POLIS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("GROUP_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging_Paid").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging Code_Paid").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging_OS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging Code_OS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(DateTime.Now.ToString() + System.Environment.NewLine)

                Next

            End If

            Dim textfileName As String = "datadetailpremi.txt"
            Dim path = Server.MapPath("~/Report/")

            Dim csvFilename As String = "Report Summary Premi " & Strings.Right(DateTime.Now.Year.ToString, 4).PadLeft(4, "0") & DateTime.Now.Month.ToString.PadLeft(2, "0") & DateTime.Now.Day.ToString.PadLeft(2, "0") & ".csv"
            Dim sAppPath As String = Server.MapPath("~/Report/" + csvFilename)

            'Rename File
            ' IF exist delete excel file
            Dim excelFilename = csvFilename.Replace("csv", "xlsx")


            ' IF exist delete excel detail
            If File.Exists(path + excelFilename) Then
                File.Delete(path + excelFilename)
            End If

            ' IF exist delete csv detail
            If File.Exists(path + csvFilename) Then
                File.Delete(path + csvFilename)
            End If

            ' IF exist delete textfile
            If File.Exists(path + textfileName) Then
                File.Delete(path + textfileName)
            End If


            File.WriteAllText(path + textfileName, sb.ToString())


            range = sheet.Range(sheet.Cells(1, 1), sheet.Cells(dt_detail.Rows.Count + 1, dt_detail.Columns.Count))
            range.EntireColumn.AutoFit()

            Dim border As Microsoft.Office.Interop.Excel.Borders = range.Borders
            border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous


            workbook.SaveAs(sAppPath)
            workbook.Close()
            app.Quit()


            releaseObject(sheet)
            releaseObject(workbook)
            releaseObject(app)


            ' import textfile to sheet excel
            Dim ConnectionString As String

            ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" & _
                               "Data Source=" & sAppPath & ";Extended Properties=""Excel 12.0;HDR=Yes;Format=CSVDelimited"""

            Dim ExcelConnection As New System.Data.OleDb.OleDbConnection(ConnectionString)


            'CREATE SHEET DETAIL
            ExcelConnection.Open()

            Dim SQLString1 As String = "Select * INTO [Detail] FROM [Text;DATABASE=" & path & "].[" & textfileName & "]"

            Dim ExcelCommand1 As New System.Data.OleDb.OleDbCommand(SQLString1, ExcelConnection)
            ExcelCommand1.ExecuteNonQuery()
            ExcelConnection.Close()


            File.Copy(path + csvFilename, path + excelFilename)


            ' IF exist delete csv detail
            If File.Exists(path + csvFilename) Then
                File.Delete(path + csvFilename)
            End If

            ' IF exist delete textfile
            If File.Exists(path + textfileName) Then
                File.Delete(path + textfileName)
            End If


            ' Active Sheet 
            ActiveSheet(path, excelFilename)


            ' Create Pivot Table Paid
            CreatePivotTablePaid(path, excelFilename)


            ' Create Pivot Table Outstanding
            CreatePivotTableOutstanding(path, excelFilename)


            Dim TheFile As System.IO.FileInfo = New System.IO.FileInfo(path + excelFilename)

            Response.ContentType = "application/vnd.ms-excel"
            Response.AddHeader("Content-Disposition", "inline; filename=" + excelFilename)
            Response.AddHeader("X-Download-Options", "noopen")

            'Remove the charset from the Content-Type header.
            Response.Charset = ""
            Response.WriteFile(TheFile.FullName)

            Response.End()


        Catch ex As Exception
            'Throw ex
            Modul.UserMsgBox(Me, ex.Message)
        End Try
    End Sub

    Private Sub CreatePivotTablePaid(ByVal path As String, ByVal excelFilename As String)

        Dim appNew As Excel.Application = New Excel.Application
        Dim xlWorkbook As Excel.Workbook = appNew.Workbooks.Open(path + excelFilename)

        Dim xlWorksheet = CType(xlWorkbook.Sheets("Detail"), Excel.Worksheet)
        xlWorksheet.Activate()


        Dim xlSheet = CType(xlWorkbook.Sheets("Paid"), Excel.Worksheet)

        Dim range As Excel.Range = xlWorkbook.Worksheets("Detail").Range("A1:AQ1048576")
        xlWorkbook.Names.Add("Range1", range)
        Dim pc As Excel.PivotCache = xlWorkbook.PivotCaches().Add(Excel.XlPivotTableSourceType.xlDatabase, "Range1")

        Dim pivotTable As Excel.PivotTable = pc.CreatePivotTable(xlSheet.Range("A1"), "Paid")

        pivotTable.MergeLabels = True
        pivotTable.ErrorString = ""
        pivotTable.DisplayErrorString = True
        pivotTable.NullString = "-"
        pivotTable.LayoutRowDefault = Excel.XlLayoutRowType.xlOutlineRow

        'To be professional or merely resuable, the name could be passed as paramete

        With pivotTable.PivotFields("STATUS")
            .Orientation = Excel.XlPivotFieldOrientation.xlPageField
            .Position = 1
        End With

        With pivotTable.PivotFields("TGL_PROSES")
            .Orientation = Excel.XlPivotFieldOrientation.xlPageField
            .Position = 1
        End With

        With pivotTable.PivotFields("POLICY_NUMBER")
            .Orientation = Excel.XlPivotFieldOrientation.xlRowField
            .Position = 1
        End With

        With pivotTable.PivotFields("GROUP_NAME")
            .Orientation = Excel.XlPivotFieldOrientation.xlRowField
            .Position = 1
        End With

        With pivotTable.PivotFields("Aging Code_Paid")
            .Orientation = Excel.XlPivotFieldOrientation.xlColumnField
            .Position = 1
            '.AutoSort((Int())Excel.XlSortOrder.xlDescending
        End With

        With pivotTable.PivotFields("PAID")
            .Orientation = Excel.XlPivotFieldOrientation.xlDataField
            .Function = Excel.XlConsolidationFunction.xlSum
            .NumberFormat = "#,##0.00"
            .Position = 1
        End With

        pivotTable.CompactLayoutRowHeader = "COMPANY NAME AND POLICY NUMBER"


        xlWorkbook.Save()
        xlWorkbook.Close()
        appNew.Quit()

        releaseObject(xlWorksheet)
        releaseObject(xlWorkbook)
        releaseObject(appNew)

    End Sub

    Public Sub CreatePivotTableOutstanding(ByVal path As String, ByVal excelFilename As String)

        Dim appNew As Excel.Application = New Excel.Application
        Dim xlWorkbook As Excel.Workbook = appNew.Workbooks.Open(path + excelFilename)

        Dim xlWorksheet = CType(xlWorkbook.Sheets("Detail"), Excel.Worksheet)
        xlWorksheet.Activate()


        Dim xlSheet = CType(xlWorkbook.Sheets("Outstanding"), Excel.Worksheet)

        Dim range As Excel.Range = xlWorkbook.Worksheets("Detail").Range("A1:AQ1048576")
        xlWorkbook.Names.Add("Range1", range)
        Dim pc As Excel.PivotCache = xlWorkbook.PivotCaches().Add(Excel.XlPivotTableSourceType.xlDatabase, "Range1")

        Dim pivotTable As Excel.PivotTable = pc.CreatePivotTable(xlSheet.Range("A1"), "Outstanding")

        pivotTable.MergeLabels = True
        pivotTable.ErrorString = ""
        pivotTable.DisplayErrorString = True
        pivotTable.NullString = "-"
        pivotTable.LayoutRowDefault = Excel.XlLayoutRowType.xlOutlineRow

        'To be professional or merely resuable, the name could be passed as parameter
        'With pivotTable.PivotFields("TGL_PROSES")
        '    .Orientation = Excel.XlPivotFieldOrientation.xlPageField
        '    .Position = 1
        'End With

        With pivotTable.PivotFields("STATUS")
            .Orientation = Excel.XlPivotFieldOrientation.xlPageField
            .Position = 1
        End With

        With pivotTable.PivotFields("POLICY_NUMBER")
            .Orientation = Excel.XlPivotFieldOrientation.xlRowField
            .Position = 1
        End With

        With pivotTable.PivotFields("GROUP_NAME")
            .Orientation = Excel.XlPivotFieldOrientation.xlRowField
            .Position = 1
        End With

        With pivotTable.PivotFields("Aging Code_OS")
            .Orientation = Excel.XlPivotFieldOrientation.xlColumnField
            .Position = 1
        End With

        With pivotTable.PivotFields("OUTSTANDING")
            .Orientation = Excel.XlPivotFieldOrientation.xlDataField
            .Function = Excel.XlConsolidationFunction.xlSum
            .NumberFormat = "#,##0.00"
            .Position = 1
        End With

        pivotTable.CompactLayoutRowHeader = "GROUP NAME AND POLICY NUMBER"


        xlWorkbook.Save()
        xlWorkbook.Close()
        appNew.Quit()

        releaseObject(xlWorksheet)
        releaseObject(xlWorkbook)
        releaseObject(appNew)

    End Sub

    Public Sub ActiveSheet(ByVal path As String, ByVal excelFilename As String)

        Dim appNew As Microsoft.Office.Interop.Excel.Application = New Microsoft.Office.Interop.Excel.Application()
        Dim xlWorkbook As Microsoft.Office.Interop.Excel.Workbook = appNew.Workbooks.Open(path + excelFilename)


        ' Sheet Report Data
        Dim xlWorksheet = CType(xlWorkbook.Sheets("Detail"), Excel.Worksheet)
        xlWorksheet.Activate()
        xlWorksheet.Cells.EntireColumn.AutoFit()


        Dim xlSheet3 = CType(xlWorkbook.Sheets.Add(After:=xlWorkbook.Worksheets(2)), Excel.Worksheet)
        xlSheet3.Name = "Paid"


        Dim xlSheet6 = CType(xlWorkbook.Sheets.Add(After:=xlWorkbook.Worksheets(3)), Excel.Worksheet)
        xlSheet6.Name = "Outstanding"


        ' DELETE WORKSHEET Report Data
        xlWorkbook.Application.DisplayAlerts = False
        xlWorkbook.Sheets("Sheet1").Delete()
        xlWorkbook.Application.DisplayAlerts = True

        xlWorkbook.Save()
        xlWorkbook.Close()
        appNew.Quit()


        releaseObject(xlWorksheet)
        releaseObject(xlWorkbook)
        releaseObject(appNew)

    End Sub

    Private Sub releaseObject(ByVal obj As Object)

        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try

    End Sub
End Class