﻿Imports System.Data
Imports System.Data.SqlClient

Imports MKB.TimePicker
Imports System.Net.Mail
Imports System.Net.Mime
Imports System.Net
Imports System.Security.Cryptography.X509Certificates
Imports System.Net.Security
Imports System.Text.RegularExpressions
Partial Public Class CallNote
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim dr As SqlDataReader
    Dim oInsert As New InsertBase
    Dim oSelect As New SelectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            trListPremi.Visible = False
            trListExcess.Visible = False
            trTittleListExcess.Visible = False
            trTittleListPremi.Visible = False
            trCallNote.Visible = False
            trReminder.Visible = False

            MN_CallNote.Items(0).Selected = True
            BindReminderList()
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            'trInfoDetail.Visible = False
            'trDetail.Visible = False
        End If


    End Sub

    Public Sub BindGridPremi(ByVal POLIS As String, ByVal USER As String, ByVal STATUS As String)
        Try
            SQL = "SELECT POLICY_NUMBER,ACCOUNT_NAME,SUM(PREMIUM_AMOUNT) as PREMIUM_AMOUNT,SUM(ADDITION) as ADDITION,SUM(DELETION) as DELETION," & _
                  "SUM([CHANGE PLAN]) as [CHANGE PLAN],SUM(FEE_ASO) as FEE_ASO,SUM(ASO) as ASO,SUM(FEE_ASO + ASO) AS TOTAL_ASO," & _
                  "SUM(BY_KARTU) as BY_KARTU,SUM(PAID) as PAID,SUM(OUTSTANDING) as OUTSTANDING,[STATUS],[USER] FROM TBL_PREMI " & _
                  "WHERE POLICY_NUMBER LIKE '%" & POLIS & "%' AND [USER] LIKE '%" & USER & "%' AND [STATUS]='" & STATUS & "' GROUP BY POLICY_NUMBER,ACCOUNT_NAME,[STATUS],[USER] ORDER BY POLICY_NUMBER"
            Modul.SubBindGridView(SQL, GridListPremi)

            'If GridListPremi.Rows.Count = 0 Then
            '    trListPremi.Visible = False
            '    trTittleListPremi.Visible = False
            '    trCallNote.Visible = False
            'Else
            '    trListPremi.Visible = True
            '    trTittleListPremi.Visible = True
            '    trCallNote.Visible = True
            'End If

            Dim dt_Count_Premi As New System.Data.DataTable
            SQL = "SELECT COUNT(*) FROM (SELECT POLICY_NUMBER,[STATUS],[USER] FROM TBL_PREMI " & _
                  "WHERE POLICY_NUMBER LIKE '%" & POLIS & "%' AND [USER] LIKE '%" & USER & "%' AND [STATUS]='" & STATUS & "' GROUP BY POLICY_NUMBER,ACCOUNT_NAME,[STATUS],[USER]) a"
            dt_Count_Premi = Modul.getAllDatainDT(SQL)

            lblTotalDataPremi.Text = "Total Data = " & dt_Count_Premi.Rows(0)(0).ToString().Trim & " data"
            txtPhoneNumber.Text = ""
            txtNote.Text = ""

        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub
    Public Sub BindGridExcess(ByVal POLIS As String, ByVal USER As String, ByVal STATUS As String)
        Try
            SQL = "SELECT POLICY_NO,COMPANY_NAME,SUM(BIAYA_PERAWATAN) AS BIAYA_PERAWATAN,SUM(YANG_DITANGGUNG) AS YANG_DITANGGUNG," & _
                  "SUM(TOTAL_EXCESS) AS TOTAL_EXCESS,SUM(PAID) AS PAID,SUM(OUTSTANDING) AS OUTSTANDING,[STATUS],[USER] FROM TBL_EC " & _
                  "WHERE POLICY_NO LIKE '%" & POLIS & "%' AND [USER] LIKE '%" & USER & "%' AND [STATUS]='" & STATUS & "' GROUP BY POLICY_NO,COMPANY_NAME,[STATUS],[USER]"
            Modul.SubBindGridView(SQL, GridListExcess)

            'If GridListExcess.Rows.Count = 0 Then
            '    trListExcess.Visible = False
            '    trTittleListExcess.Visible = False
            '    trCallNote.Visible = False
            'Else
            '    trListExcess.Visible = True
            '    trTittleListExcess.Visible = True
            '    trCallNote.Visible = True
            'End If

            Dim dt_Count_Excess As New System.Data.DataTable
            SQL = "SELECT COUNT(*) FROM (SELECT POLICY_NO,COMPANY_NAME,SUM(BIAYA_PERAWATAN) AS BIAYA_PERAWATAN,SUM(YANG_DITANGGUNG) AS YANG_DITANGGUNG," & _
                  "SUM(TOTAL_EXCESS) AS TOTAL_EXCESS,SUM(PAID) AS PAID,SUM(OUTSTANDING) AS OUTSTANDING,[STATUS],[USER] FROM TBL_EC " & _
                  "WHERE POLICY_NO LIKE '%" & POLIS & "%' AND [USER] LIKE '%" & USER & "%' AND [STATUS]='" & STATUS & "' GROUP BY POLICY_NO,COMPANY_NAME,[STATUS],[USER]) A"
            dt_Count_Excess = Modul.getAllDatainDT(SQL)

            lblTotalDataExcess.Text = "Total Data = " & dt_Count_Excess.Rows(0)(0).ToString().Trim & " data"
            txtPhoneNumber.Text = ""
            txtNote.Text = ""


        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub

    Public Sub BindGridNoteList(ByVal POLIS As String)
        Try
            SQL = "SELECT *,CONVERT(VARCHAR(25),CREATEDATE,103) AS CREATEDATE2 FROM CALLNOTE " & _
                  "WHERE POLICYNO LIKE '%" & POLIS & "%' AND ISREMINDER='N' ORDER BY CALLNOTEID DESC"
            Modul.SubBindGridView(SQL, GridNoteList)

            If GridNoteList.Rows.Count = 0 Then
                lblNoteList.Visible = True
                lblTotalNoteList.Visible = False
            Else
                lblNoteList.Visible = False
                lblTotalNoteList.Visible = True
            End If

            Dim dt_Count_Excess As New System.Data.DataTable
            SQL = "SELECT COUNT(*) FROM CALLNOTE " & _
                  "WHERE POLICYNO LIKE '%" & POLIS & "%' AND ISREMINDER='N'"

            dt_Count_Excess = Modul.getAllDatainDT(SQL)

            If dt_Count_Excess.Rows.Count > 0 Then
                lblTotalNoteList.Text = "Total Data = " & dt_Count_Excess.Rows(0)(0).ToString().Trim & " data"
            End If


        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub
    Public Sub BindGridReminderList(ByVal POLIS As String)
        Try
            SQL = "SELECT *,CONVERT(VARCHAR(25),CREATEDATE,103) AS CREATEDATE2," & _
                  "CONVERT(VARCHAR(25),REMINDERDATE,103) AS REMINDERDATE2 FROM CALLNOTE " & _
                  "WHERE POLICYNO LIKE '%" & POLIS & "%' AND ISREMINDER='Y' AND [SEND MAIL]='N' ORDER BY CALLNOTEID DESC"
            Modul.SubBindGridView(SQL, GridReminderList)

            If GridReminderList.Rows.Count = 0 Then
                lblReminder.Visible = True
                lblTotalReminderList.Visible = False
            Else
                lblReminder.Visible = False
                lblTotalReminderList.Visible = True
            End If

            Dim dt_Count_Excess As New System.Data.DataTable
            SQL = "SELECT COUNT(*) FROM CALLNOTE " & _
                  "WHERE POLICYNO LIKE '%" & POLIS & "%' AND ISREMINDER='Y' AND [SEND MAIL]='N'"

            dt_Count_Excess = Modul.getAllDatainDT(SQL)

            If dt_Count_Excess.Rows.Count > 0 Then
                lblTotalReminderList.Text = "Total Data = " & dt_Count_Excess.Rows(0)(0).ToString().Trim & " data"
            End If


        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub

    Protected Sub Menu1_MenuItemClick(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MenuEventArgs) Handles MN_CallNote.MenuItemClick
        MultiView1.ActiveViewIndex = Int32.Parse(e.Item.Value)
        'Make the selected menu item reflect the correct imageurl

        Modul.ShowFocus(Me, MN_CallNote)

        MN_CallNote.Items(0).ImageUrl = "~/Images/CallNoteUnSelectedtab.png"
        MN_CallNote.Items(1).ImageUrl = "~/Images/NoteListUnSelectedtab.png"
        MN_CallNote.Items(2).ImageUrl = "~/Images/ReminderListUnSelectedtab.png"

        Select Case e.Item.Value
            Case 0
                MN_CallNote.Items(0).ImageUrl = "~/Images/CallNoteSelectedtab.png"
                trReminder.Visible = False
            Case 1
                MN_CallNote.Items(1).ImageUrl = "~/Images/NoteListSelectedtab.png"
                trReminder.Visible = False
            Case 2
                MN_CallNote.Items(2).ImageUrl = "~/Images/ReminderListSelectedtab.png"
                trReminder.Visible = False
        End Select
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click
        BindGridPremi(txtPolis.Text, txtUSER.Text, ddl_STATUS.SelectedValue.Trim)
        BindGridExcess(txtPolis.Text, txtUSER.Text, ddl_STATUS.SelectedValue.Trim)
        BindGridNoteList(txtPolis.Text)
        BindGridReminderList(txtPolis.Text)
        lblpolisnote.Text = txtPolis.Text
        Session("startdate") = Date.Now.ToString("yyyy-MM-dd hh:mm:ss")
        trCallNote.Visible = False
        trListPremi.Visible = True
        trListExcess.Visible = True
        trTittleListExcess.Visible = True
        trTittleListPremi.Visible = True
        trReminder.Visible = True
    End Sub

    Private Sub GridListPremi_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridListPremi.PageIndexChanging
        GridListPremi.PageIndex = e.NewPageIndex
        BindGridPremi(txtPolis.Text, txtUSER.Text, ddl_STATUS.SelectedValue.Trim)
    End Sub

    Private Sub GridListPremi_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridListPremi.RowCommand
        Try
            If e.CommandName = "SelectHeader" Then

                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = GridListPremi.Rows(index)
                Dim myLinkButton As LinkButton
                myLinkButton = selectedRow.Cells(0).Controls(0)

                lblpolisnote.Text = myLinkButton.Text
                Session("startdate") = Date.Now.ToString("yyyy-MM-dd hh:mm:ss")

                BindGridExcess(myLinkButton.Text, txtUSER.Text, ddl_STATUS.SelectedValue.Trim)
                BindGridPremi(myLinkButton.Text, txtUSER.Text, ddl_STATUS.SelectedValue.Trim)
                BindGridNoteList(myLinkButton.Text)
                BindGridReminderList(myLinkButton.Text)

                trCallNote.Visible = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GridListPremi_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridListPremi.SelectedIndexChanged

    End Sub

    Private Sub GridListExcess_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridListExcess.PageIndexChanging
        GridListExcess.PageIndex = e.NewPageIndex
        BindGridExcess(txtPolis.Text, txtUSER.Text, ddl_STATUS.SelectedValue.Trim)
    End Sub

    Private Sub GridListExcess_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridListExcess.RowCommand
        Try
            If e.CommandName = "SelectHeader" Then

                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = GridListExcess.Rows(index)
                Dim myLinkButton As LinkButton
                myLinkButton = selectedRow.Cells(0).Controls(0)

                lblpolisnote.Text = myLinkButton.Text
                Session("startdate") = Date.Now.ToString("yyyy-MM-dd hh:mm:ss")

                BindGridExcess(myLinkButton.Text, txtUSER.Text, ddl_STATUS.SelectedValue.Trim)
                BindGridPremi(myLinkButton.Text, txtUSER.Text, ddl_STATUS.SelectedValue.Trim)
                BindGridNoteList(myLinkButton.Text)
                BindGridReminderList(myLinkButton.Text)

                trCallNote.Visible = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GridListExcess_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridListExcess.SelectedIndexChanged
        
    End Sub

    'Protected Sub RDSolved_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles RDSolved.CheckedChanged
    '    If RDSolved.Checked = True Then
    '        RDUnsolved.Checked = False
    '    End If
    'End Sub

    'Protected Sub RDUnsolved_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles RDUnsolved.CheckedChanged
    '    If RDUnsolved.Checked = True Then
    '        RDSolved.Checked = False
    '    End If
    'End Sub
    Public Sub BindReminderList()

        rdReminder.Items.Clear()
        rdReminder.Items.Add(New ListItem("None", "None"))
        rdReminder.Items.Add(New ListItem("Reminder 1 day (" & DateAdd(DateInterval.Day, 1, Now).ToString("dd/MM/yyyy") & ")", "day1"))
        rdReminder.Items.Add(New ListItem("Reminder 2 day (" & DateAdd(DateInterval.Day, 2, Now).ToString("dd/MM/yyyy") & ")", "day2"))
        rdReminder.Items.Add(New ListItem("Reminder by time", "time"))
        rdReminder.Items.Add(New ListItem("Other (yyyy-MM-dd)", "Other"))

        rdReminder.Items(0).Selected = True

    End Sub
    Protected Sub btnReminder_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReminder.Click
        trReminder.Visible = True

    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        Dim vPHONE_NUMBER As String
        Dim vNOTE As String
        Dim vREMINDER As String = ""
        Dim vISREMINDER As String = ""
        Dim vTYPEID As String = ""
        Dim vPOLICYNO As String = ""


        Try
            vPHONE_NUMBER = txtPhoneNumber.Text
            vNOTE = txtNote.Text
            vPOLICYNO = lblpolisnote.Text

            If rdReminder.SelectedValue = "None" Then
                vISREMINDER = "N"
                vTYPEID = "CALLNOTE"
            ElseIf rdReminder.SelectedValue = "day1" Then
                vISREMINDER = "Y"
                vTYPEID = "REMINDER"
                vREMINDER = DateAdd(DateInterval.Day, 1, Now).ToString("yyyy-MM-dd")
            ElseIf rdReminder.SelectedValue = "day2" Then
                vISREMINDER = "Y"
                vTYPEID = "REMINDER"
                vREMINDER = DateAdd(DateInterval.Day, 2, Now).ToString("yyyy-MM-dd")
            ElseIf rdReminder.SelectedValue = "time" Then
                vISREMINDER = "Y"
                vTYPEID = "REMINDER"

                Dim dateReminder As DateTime = DateTime.Now.ToString("yyyy-MM-dd")

                Dim timeReminder As DateTime = DateTime.Parse(String.Format("{0}:{1}:{2} {3}", tsReminder.Hour, tsReminder.Minute, tsReminder.Second, tsReminder.AmPm))
                timeReminder = Convert.ToDateTime(timeReminder).ToString("h:mm:ss tt")

                vREMINDER = dateReminder + " " + timeReminder

            ElseIf rdReminder.SelectedValue = "Other" Then

                vISREMINDER = "Y"
                vTYPEID = "REMINDER"
                vREMINDER = Convert.ToDateTime(txtOther.Text).ToString("yyyy-MM-dd")

            End If

            oInsert.f_Create_CallNote(vPHONE_NUMBER, vNOTE, vPOLICYNO, Session("username").ToString, vREMINDER, vISREMINDER, _
                                        vTYPEID, Session("startdate").ToString(), Date.Now.ToString("yyyy-MM-dd hh: mm:ss"))

            BindGridNoteList(vPOLICYNO)
            BindGridReminderList(vPOLICYNO)


            'Dim note As String = ""

            'note = "Phone Number    : " + vPHONE_NUMBER + "<br><br>" +
            '       "Note            : " + vNOTE + "<br><br>" +
            '       "Policy Number   : " + vPOLICYNO + "<br><br>" +
            '       "Reminder        : " + vREMINDER + "<br><br>"


            'If vISREMINDER = "Y" Then
            '    SendEmail("", note)
            'End If


            Modul.UserMsgBox(Me, "Save Completed and Notification has been noted !!")


        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            Throw (ex)
        End Try

    End Sub

    Private Sub GridNoteList_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridNoteList.PageIndexChanging
        GridNoteList.PageIndex = e.NewPageIndex
        BindGridNoteList(lblpolisnote.Text)
    End Sub

    Private Sub GridNoteList_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridNoteList.PreRender
        If Me.GridNoteList.EditIndex <> -1 Then
            Dim txtCALLNOTEID As TextBox = DirectCast(GridNoteList.Rows(GridNoteList.EditIndex).FindControl("txtCALLNOTEID"), TextBox)
            Dim txtCREATEBY As TextBox = DirectCast(GridNoteList.Rows(GridNoteList.EditIndex).FindControl("txtCREATEBY"), TextBox)
            Dim txtCREATEDATE As TextBox = DirectCast(GridNoteList.Rows(GridNoteList.EditIndex).FindControl("txtCREATEDATE"), TextBox)
            Dim txtREMINDERDATE As TextBox = DirectCast(GridNoteList.Rows(GridNoteList.EditIndex).FindControl("txtREMINDERDATE"), TextBox)

            If txtCALLNOTEID IsNot Nothing Then
                txtCALLNOTEID.Enabled = False
            End If
            If txtCREATEBY IsNot Nothing Then
                txtCREATEBY.Enabled = False
            End If
            If txtCREATEDATE IsNot Nothing Then
                txtCREATEDATE.Enabled = False
            End If
            If txtREMINDERDATE IsNot Nothing Then
                txtREMINDERDATE.Enabled = False
            End If

        End If
    End Sub

    Private Sub GridNoteList_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridNoteList.RowCancelingEdit
        GridNoteList.EditIndex = -1
        BindGridNoteList(lblpolisnote.Text)
    End Sub

    Private Sub GridNoteList_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridNoteList.RowEditing
        GridNoteList.EditIndex = e.NewEditIndex
        BindGridNoteList(lblpolisnote.Text)
    End Sub

    Private Sub GridNoteList_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridNoteList.RowUpdating
        Dim PHONENUMBER As TextBox = DirectCast(GridNoteList.Rows(e.RowIndex).FindControl("txtPHONENUMBER"), TextBox)
        Dim NOTE As TextBox = DirectCast(GridNoteList.Rows(e.RowIndex).FindControl("txtNOTE"), TextBox)
        Dim CALLNOTEID As TextBox = DirectCast(GridNoteList.Rows(e.RowIndex).FindControl("txtCALLNOTEID"), TextBox)

        SQL = ""

        SQL = "UPDATE CALLNOTE SET PHONENUMBER='" & PHONENUMBER.Text & "', NOTE='" & NOTE.Text & "' " & _
              "WHERE CALLNOTEID='" & CALLNOTEID.Text & "' AND POLICYNO='" & lblpolisnote.Text & "' AND ISREMINDER='N' "

        If SQL <> "" Then
            Try
                Modul.Eksekusi(SQL)
                Modul.UserMsgBox(Me, "Updated Complete ")
                GridNoteList.EditIndex = -1
                BindGridNoteList(lblpolisnote.Text)

            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try
        End If
    End Sub

    Protected Sub GridNoteList_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridNoteList.SelectedIndexChanged

    End Sub

    Private Sub GridReminderList_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridReminderList.PageIndexChanging
        GridReminderList.PageIndex = e.NewPageIndex
        BindGridReminderList(lblpolisnote.Text)
    End Sub

    Private Sub GridReminderList_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridReminderList.PreRender
        If Me.GridReminderList.EditIndex <> -1 Then
            Dim txtCALLNOTEID As TextBox = DirectCast(GridReminderList.Rows(GridReminderList.EditIndex).FindControl("txtCALLNOTEID"), TextBox)
            Dim txtCREATEBY As TextBox = DirectCast(GridReminderList.Rows(GridReminderList.EditIndex).FindControl("txtCREATEBY"), TextBox)
            Dim txtCREATEDATE As TextBox = DirectCast(GridReminderList.Rows(GridReminderList.EditIndex).FindControl("txtCREATEDATE"), TextBox)
            Dim txtREMINDERDATE As TextBox = DirectCast(GridReminderList.Rows(GridReminderList.EditIndex).FindControl("txtREMINDERDATE"), TextBox)

            If txtCALLNOTEID IsNot Nothing Then
                txtCALLNOTEID.Enabled = False
            End If
            If txtCREATEBY IsNot Nothing Then
                txtCREATEBY.Enabled = False
            End If
            If txtCREATEDATE IsNot Nothing Then
                txtCREATEDATE.Enabled = False
            End If
            If txtREMINDERDATE IsNot Nothing Then
                txtREMINDERDATE.Enabled = False
            End If
        End If
    End Sub

    Private Sub GridReminderList_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridReminderList.RowCancelingEdit
        GridReminderList.EditIndex = -1
        BindGridReminderList(lblpolisnote.Text)
    End Sub

    Private Sub GridReminderList_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridReminderList.RowEditing
        GridReminderList.EditIndex = e.NewEditIndex
        BindGridReminderList(lblpolisnote.Text)
    End Sub

    Private Sub GridReminderList_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridReminderList.RowUpdating
        Dim PHONENUMBER As TextBox = DirectCast(GridReminderList.Rows(e.RowIndex).FindControl("txtPHONENUMBER"), TextBox)
        Dim NOTE As TextBox = DirectCast(GridReminderList.Rows(e.RowIndex).FindControl("txtNOTE"), TextBox)
        Dim CALLNOTEID As TextBox = DirectCast(GridReminderList.Rows(e.RowIndex).FindControl("txtCALLNOTEID"), TextBox)

        SQL = ""

        SQL = "UPDATE CALLNOTE SET PHONENUMBER='" & PHONENUMBER.Text & "', NOTE='" & NOTE.Text & "' " & _
              "WHERE CALLNOTEID='" & CALLNOTEID.Text & "' AND POLICYNO='" & lblpolisnote.Text & "' AND ISREMINDER='Y' "

        If SQL <> "" Then
            Try
                Modul.Eksekusi(SQL)
                Modul.UserMsgBox(Me, "Updated Complete ")
                GridReminderList.EditIndex = -1
                BindGridReminderList(lblpolisnote.Text)

            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try
        End If
    End Sub
    Private Sub SendEmail(ByVal TARGET As String, ByVal REMINDER As String)

        Dim ConSql As String = ConfigurationManager.ConnectionStrings("ConSql").ConnectionString
        Dim ccEmail As String = ConfigurationManager.AppSettings("CcEmail").ToString

        Dim smtp As String = ConfigurationManager.AppSettings("smtp").ToString
        Dim port As String = ConfigurationManager.AppSettings("port").ToString
        Dim isAuth As String = ConfigurationManager.AppSettings("isAuth").ToString
        Dim username As String = ConfigurationManager.AppSettings("username").ToString
        Dim password As String = ConfigurationManager.AppSettings("password").ToString
        Dim mailServer As String = ConfigurationManager.AppSettings("mailServer").ToString
        Dim sender As String = ConfigurationManager.AppSettings("sender").ToString


        Dim dtEmail As New DataTable

        Dim emailto As String = ""

        If (Session("username") IsNot Nothing) Then

            SQL = "select dco_Email from Mst_UserApp where dco_Name = '" + Session("username").ToString() + "'"
            dtEmail = Modul.getAllDatainDT(SQL)

            If dtEmail.Rows.Count > 0 Then

                emailto = dtEmail.Rows(0)("dco_Email").ToString()

            End If

        End If

        Dim mail As MailMessage = New MailMessage()
        Dim smtpServer As SmtpClient = New SmtpClient()

        smtpServer.UseDefaultCredentials = False
        smtpServer.Credentials = New System.Net.NetworkCredential(username, password)

        smtpServer.Port = Convert.ToInt16(port)
        smtpServer.EnableSsl = False
        smtpServer.Host = smtp
        mail.From = New MailAddress(mailServer, sender)


        mail.To.Add(emailto)
        mail.CC.Add(ccEmail)

        mail.Subject = "Reminder Call Corpsol"
        mail.Body = "Dear All, <br><br><br>This is notification from Corpsol System : <br><br>" + REMINDER + "<br><br><br><br>Regards,<br><br><br><br> Corpsol Admin"
        mail.IsBodyHtml = True

        smtpServer.Send(mail)

        mail.Attachments.Dispose()

    End Sub

    Public Function validateEmail(ByVal emailAddress) As Boolean

        Dim email As New Regex("([\w-+]+(?:\.[\w-+]+)*@(?:[\w-]+\.)+[a-zA-Z]{2,7})")
        If email.IsMatch(emailAddress) Then
            Return True
        Else
            Return False
        End If

    End Function
    Protected Sub GridReminderList_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridReminderList.SelectedIndexChanged

    End Sub
End Class