﻿Imports System.Data.SqlClient
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Web
Partial Public Class PopReportTransaction
    Inherits System.Web.UI.Page

    Dim Dt As New DataTable
    Dim SQL, x1v9oText As String
    Dim strValue() As String
    Dim Modul As New ClassModul
    Dim submitter As String
    Dim oSelect As New SelectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim dtReport As New DataTable
            Dim crystalReport As New ReportDocument()
            Dim seq As String()

            If Request.QueryString("x1v9o") Is Nothing Then
                Response.Write("<script type='text/javascript'>" & vbCrLf)
                Response.Write("window.opener.location='UserRequest.aspx;" & vbCrLf)
                Response.Write("window.close();" & vbCrLf)
                Response.Write("</script>")
            End If

            seq = Split(Request.QueryString("x1v9o"), ";")

            crystalReport.Load(Server.MapPath("~/Report/Report_Transaction.rpt"))

            dtReport = oSelect.sp_Report_Transaction(seq(0), seq(1), seq(2), "", Session("FundType").ToString, Session("LvlRpt").ToString)

            DebugLogger.WriteLog(String.Format("{0},{1},{2},{3},{4},{5}", seq(0), seq(0), seq(0), "", Session("FundType").ToString, Session("LvlRpt").ToString))

            crystalReport.SetParameterValue(0, seq(0))
            crystalReport.SetParameterValue(1, seq(1))
            crystalReport.SetParameterValue(2, seq(2))
            crystalReport.SetParameterValue(3, "")
            crystalReport.SetParameterValue(4, Session("FundType").ToString)
            crystalReport.SetParameterValue(5, Session("LvlRpt").ToString)

            crystalReport.SetDataSource(dtReport)
            CrystalReportViewer1.HasExportButton = "True"
            CrystalReportViewer1.ReportSourceID = "CrystalReportSource1"
            CrystalReportViewer1.ReportSource = crystalReport

        End If
    End Sub
End Class