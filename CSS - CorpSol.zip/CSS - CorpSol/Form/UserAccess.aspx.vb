﻿Imports System.Data
Imports System.Data.SqlClient

Partial Public Class UserAccess
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            BindGrid("")

            If Session("txtuser") <> "" Then
                txtUser.Text = Session("txtuser")
                BindGrid(txtUser.Text)
            Else
                txtUser.Text = ""
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If

        btnFind.Attributes.Add("onclick", "jvPopup('01');return false;")
    End Sub
    Public Sub BindGrid(ByVal userid As String)
        'SQL = "SELECT NoID,Texts,Description FROM MENU ORDER BY NoID "
        SQL = "SELECT NoID,Texts,[Description],'True' as IsSelected FROM Menu " & _
              "LEFT JOIN Otorisasi ON Menu.MenuID=Otorisasi.MenuID WHERE userid = '" & userid & "' " & _
              "UNION ALL SELECT NoID,Texts,[Description],'False' AS IsSelected FROM menu where NoID NOT IN ( " & _
              "SELECT NoID FROM menu LEFT JOIN Otorisasi ON Menu.MenuID=Otorisasi.MenuID WHERE userid ='" & userid & "') ORDER BY NoID"
        Modul.SubBindGridView(SQL, GridAccess)

    End Sub

    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSave.Click
        Try

            SQL = "DELETE FROM OTORISASI WHERE UserID LIKE '%" & txtUser.Text.Trim & "%'"
            Modul.Eksekusi(SQL)

            For Each row As GridViewRow In GridAccess.Rows
                If row.RowType = DataControlRowType.DataRow Then
                    Dim chkRow As CheckBox = TryCast(row.Cells(0).FindControl("chkRow"), CheckBox)
                    If chkRow.Checked Then
                        Dim NoId As String = TryCast(row.Cells(2).FindControl("lblId"), Label).Text
                        SQL = ""
                        SQL = "INSERT INTO OTORISASI (AppID, MenuID, UserID) values('1','" & NoId & "','" & txtUser.Text.Trim & "') "
                        Modul.Eksekusi(SQL)
                    End If
                End If
            Next

            txtUser.Text = ""

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            "alert('Save User Access Success'); window.location='UserAccess.aspx';", True)

        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub
End Class