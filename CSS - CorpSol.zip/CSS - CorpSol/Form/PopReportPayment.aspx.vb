﻿Imports System.Data.SqlClient
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Web
Partial Public Class PopReportPayment
    Inherits System.Web.UI.Page

    Dim Dt As New DataTable
    Dim SQL, x1v9oText As String
    Dim strValue() As String
    Dim Modul As New ClassModul
    Dim submitter As String
    Dim oSelect As New SelectBase
    Private Function f_DisplayReportAsWeb(ByRef crViewer As CrystalDecisions.Web.CrystalReportViewer)
        crViewer.HasToggleGroupTreeButton = False
        crViewer.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None
        crViewer.HasGotoPageButton = False
        crViewer.HasPageNavigationButtons = False
        crViewer.HasRefreshButton = False
        crViewer.HasZoomFactorList = False
        crViewer.HasPrintButton = False
        crViewer.HasExportButton = False
        crViewer.HasDrilldownTabs = False
        crViewer.HasDrillUpButton = False
        crViewer.DisplayToolbar = False
        crViewer.DisplayStatusbar = False
        crViewer.BorderStyle = False
        crViewer.HasToggleParameterPanelButton = False
        crViewer.HasSearchButton = False
        crViewer.HasCrystalLogo = False
        crViewer.DocumentView = CrystalDecisions.Shared.DocumentViewType.WebLayout


    End Function
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim dtRefund As New DataTable
            Dim crystalReport As New ReportDocument()
            Dim NoSurat As String


            NoSurat = GenerateNoSurat()

            crystalReport.Load(Server.MapPath("~/Report/claim_bayar.rpt"))

            crystalReport.SetParameterValue(0, Request.QueryString("code"))
            crystalReport.SetParameterValue(1, NoSurat)

            dtRefund = oSelect.LetterPaymentClaim(Request.QueryString("code"), NoSurat)

            crystalReport.SetDataSource(dtRefund)
            'CrystalReportViewer1.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None
            'CrystalReportViewer1.HasToggleGroupTreeButton = False
            'CrystalReportViewer1.HasExportButton = True
            f_DisplayReportAsWeb(CrystalReportViewer1)
            CrystalReportViewer1.ReportSourceID = "CrystalReportSource1"
            CrystalReportViewer1.ReportSource = crystalReport

        End If
    End Sub
    Public Function GenerateNoSurat()
        Dim dt As New System.Data.DataTable
        Dim dt_NoSurat As New System.Data.DataTable
        Dim NoSurat As Integer
        Dim numbering As String
        Dim ID As String = ""


        SQL = "SELECT * FROM Tbl_NoSurat_Payment WHERE YEAR=" & Year(Date.Now) & " AND CLAIMNO='" & Left(Request.QueryString("code"), 8) & "' AND GCOCCNO='" & Right(Request.QueryString("code"), 2) & "' "
        Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
        Modul.SQLAdp.Fill(dt_NoSurat)

        If dt_NoSurat.Rows.Count > 0 Then
            If dt_NoSurat.Rows(0).Item(0).ToString <> "" Then
                NoSurat = Val(dt_NoSurat.Rows(0).Item(0).ToString)
                numbering = Microsoft.VisualBasic.Right("0000000" & NoSurat, 7)
                ID = numbering
            Else
                SQL = "SELECT TOP 1 NUMBER FROM Tbl_NoSurat_Payment WHERE YEAR=" & Year(Date.Now) & " ORDER BY NUMBER DESC"
                Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
                Modul.SQLAdp.Fill(dt)

                If dt.Rows.Count > 0 Then
                    If dt.Rows(0).Item(0).ToString <> "" Then
                        NoSurat = Val(dt.Rows(0).Item(0).ToString) + 1
                        numbering = Microsoft.VisualBasic.Right("0000000" & NoSurat, 7)
                        ID = numbering
                    End If
                Else
                    ID = "0000001"
                End If

            End If
        Else
            SQL = "SELECT TOP 1 NUMBER FROM Tbl_NoSurat_Payment WHERE YEAR=" & Year(Date.Now) & " ORDER BY NUMBER DESC"
            Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
            Modul.SQLAdp.Fill(dt)

            If dt.Rows.Count > 0 Then
                If dt.Rows(0).Item(0).ToString <> "" Then
                    NoSurat = Val(dt.Rows(0).Item(0).ToString) + 1
                    numbering = Microsoft.VisualBasic.Right("0000000" & NoSurat, 7)
                    ID = numbering
                End If
            Else
                ID = "0000001"
            End If

        End If

        Return ID
    End Function

End Class