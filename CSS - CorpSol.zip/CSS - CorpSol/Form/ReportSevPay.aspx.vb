﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Reflection
Imports System
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Web
Imports System.IO
Imports Ionic.Zip

Partial Public Class ReportSevPay
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Dim dr As SqlDataReader
    Dim oSelect As New SelectBase
    Dim CrystalReportViewer1 As New CrystalReportViewer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            DropFill_FundType()
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If

        btnPreview.Attributes.Add("onclick", "jvPopup();return false;")
    End Sub
    Public Sub DropFill_FundType()
        Dim ListTemp As ListItem

        ddlFundType.Items.Clear()
        ListTemp = New ListItem("Choose", "")
        ddlFundType.Items.Add(ListTemp)

        SQL = "SELECT DISTINCT LONGDESC,RIGHT(RTRIM(DESCITEM),2) as SHORTDESC FROM DESCPF D " & _
              "INNER JOIN IDAS_CORPSOL_TRANSACTION T ON T.ACTRPF_INVFCDE=RIGHT(RTRIM(D.DESCITEM),2) where D.descpfx = 'IT' and desccoy = '3' and desctabl = 'TR93C'"


        dr = Modul.getAllDatainDR(SQL)

        While dr.Read
            ListTemp = New ListItem(dr(1), dr(0))
            ddlFundType.Items.Add(ListTemp)
        End While

        dr.Close()
        Modul.SQLCn.Close()

    End Sub
    Protected Sub ddlFundType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFundType.SelectedIndexChanged
        txtLongDesc.Text = ddlFundType.SelectedValue.ToString
        Session("FundType") = ddlFundType.SelectedItem.Text
    End Sub
    Protected Sub ddlReportLevel_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlReportLevel.SelectedIndexChanged
        If ddlReportLevel.SelectedValue.ToString = "Member Level" Then
            lblMember.Visible = True
            txtMemberName.Visible = True
        Else
            lblMember.Visible = False
            txtMemberName.Visible = False
        End If
    End Sub
    Protected Sub txtPolis_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtPolis.TextChanged
        Dim dt_Polis As New System.Data.DataTable
        Dim ListTemp As ListItem

        If Len(txtPolis.Text) = 8 Then
            dt_Polis = oSelect.sp_Get_Type_Polis(txtPolis.Text)

            If dt_Polis.Rows.Count = 0 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportTransaction.aspx';", True)
                Exit Sub
            End If
            Session("Type") = dt_Polis.Rows(0)("Type").ToString

            If Session("Type") = "DCI" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
                ddlReportLevel.Items.Add("Member Level")
            ElseIf Session("Type") = "DBE" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportTransaction.aspx';", True)
            End If

            ddlFundType.Items.Clear()

            For x = 0 To dt_Polis.Rows.Count - 1
                ListTemp = New ListItem(dt_Polis.Rows(x)("Fund"), dt_Polis.Rows(x)("Description"))
                ddlFundType.Items.Add(ListTemp)
            Next

            txtLongDesc.Text = ddlFundType.SelectedValue.ToString

        End If
    End Sub
    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click
        Try
            Dim dtReport As New DataTable
            Dim crystalReport As New ReportDocument()

            Dim dateFrom As DateTime
            Dim dateTo As DateTime
            Dim sFileName As String = ""

            dateFrom = CDate(Right(txtFrom.Text, 4) & "-" & Mid(txtFrom.Text, 4, 2) & "-" & Left(txtFrom.Text, 2))
            dateTo = CDate(Right(txtTo.Text, 4) & "-" & Mid(txtTo.Text, 4, 2) & "-" & Left(txtTo.Text, 2))

            If txtFrom.Text.Trim = "" Or txtTo.Text.Trim = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Tidak Boleh Kosong.'); window.location='ReportSevPay.aspx';", True)
                Exit Sub
            ElseIf dateTo > dateFrom.AddMonths(1) Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Melebihi Periode Yang Ditentukan.'); window.location='ReportSevPay.aspx';", True)
                Exit Sub
            ElseIf txtPolis.Text = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Police Number Tidak Boleh Kosong.'); window.location='ReportSevPay.aspx';", True)
                Exit Sub
            End If

            crystalReport.Load(Server.MapPath("~/Report/Report_Transaction.rpt"))

            dtReport = oSelect.sp_Report_Transaction(txtFrom.Text, txtTo.Text, txtPolis.Text, "", ddlFundType.SelectedItem.Text, Session("LvlRpt").ToString)

            crystalReport.SetParameterValue(0, txtFrom.Text)
            crystalReport.SetParameterValue(1, txtTo.Text)
            crystalReport.SetParameterValue(2, txtPolis.Text)
            crystalReport.SetParameterValue(3, "")
            crystalReport.SetParameterValue(4, ddlFundType.SelectedItem.Text)

            crystalReport.SetDataSource(dtReport)
            CrystalReportViewer1.HasExportButton = "True"
            CrystalReportViewer1.ReportSourceID = "CrystalReportSource1"
            CrystalReportViewer1.ReportSource = crystalReport

            Dim formatType As ExportFormatType = ExportFormatType.PortableDocFormat
            formatType = ExportFormatType.PortableDocFormat

            Response.AddHeader("X-Download-Options", "noopen")

            crystalReport.ExportToHttpResponse(formatType, Response, True, "Transaction Report to Nasabah" & txtPolis.Text)

            Response.[End]()

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try

    End Sub
End Class