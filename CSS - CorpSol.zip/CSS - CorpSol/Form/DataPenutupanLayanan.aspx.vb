﻿Imports System.IO
Imports OfficeOpenXml
Imports OfficeOpenXml.Style

Public Class DataPenutupanLayanan
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim oSelect As New SelectBase
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If

        End If
    End Sub

    Protected Sub btnReportPremi_Click(sender As Object, e As EventArgs) Handles btnReportPremi.Click
        Try
            Dim dt_report As New DataTable

            'dt_report = oSelect.sp_Create_Report_Premi_Detail(txtPOLICYNO.Text.Trim, ddlStatus.SelectedValue.ToString, ddlReason.SelectedValue.ToString)
            dt_report = oSelect.sp_Create_Data_Penutupan_Layanan_Premi(txtPOLICYNO.Text.Trim, ddlStatus.SelectedValue.ToString, ddlReason.SelectedValue.ToString)

            If dt_report.Rows.Count > 0 Then
                'Dim sFileName As String = ""

                'Dim sysdate As Date = Date.Now.Date

                'sFileName = "DATA_PENUTUPAN_LAYANAN_PREMI_" & Replace(sysdate.ToString("dd/MM/yyyy"), "/", "") & ".xlsx"

                'Dim GridView1 As New GridView()
                'GridView1.AllowPaging = False
                'GridView1.AllowSorting = False
                'GridView1.DataSource = dt_report
                'GridView1.DataBind()

                'Response.Clear()
                'Response.Buffer = True
                'Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                'Response.Charset = ""
                'Response.Cache.SetCacheability(HttpCacheability.NoCache)
                'Me.EnableViewState = False
                'Response.ContentType = "application/vnd.ms-excel"
                'Dim StringWrite As New System.IO.StringWriter
                'Dim HtmlWrite As New System.Web.UI.HtmlTextWriter(StringWrite)

                'For Each r As GridViewRow In GridView1.Rows
                '    If r.RowType = DataControlRowType.DataRow Then
                '        For columnIndex As Integer = 0 To r.Cells.Count - 1
                '            r.Cells(columnIndex).Attributes.Add("class", "text")
                '        Next
                '    End If
                'Next

                'GridView1.RenderControl(HtmlWrite)

                'Response.AddHeader("X-Download-Options", "noopen")

                ''Remove the charset from the Content-Type header.
                'Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                'Response.Write(style)

                'Response.Write(StringWrite.ToString())
                'Response.End()

                Response.Clear()
                Response.Charset = ""
                Response.ContentEncoding = System.Text.Encoding.UTF8
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                Response.AddHeader("content-disposition", "attachment;filename=DATA_PENUTUPAN_LAYANAN_PREMI_" + Now.ToString("yyyy_MM_dd") + ".xlsx")

                Using package = New ExcelPackage()
                    Dim ws As ExcelWorksheet =
                    package.Workbook.Worksheets.Add("DATA_PENUTUPAN_LAYANAN_PREMI")
                    ws.Cells("A1").LoadFromDataTable(dt_report, True)
                    'Adding style to the header
                    ws.Row(1).Height = 20
                    Dim headerRowStyle = ws.Row(1).Style
                    headerRowStyle.Font.Bold = True
                    headerRowStyle.Font.Color.SetColor(System.Drawing.Color.Black)
                    ws.Row(1).Style.ShrinkToFit = False
                    ws.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws.Cells(ws.Dimension.Address).AutoFitColumns()
                    'Adding style to column number by index
                    'PREMIUM_AMOUNT  ADDITION	DELETION	CHANGE PLAN	FEE_ASO	ASO	BY_KARTU	PAID	OUTSTANDING	PREMI_TAHUNAN	Tot_Outstanding	2%_PREMI_TAHUNAN
                    '11              12	        13	        14	        15	    16	17	        18	    19	        45	            46	            47
                    ws.Column(11).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(12).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(13).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(14).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(15).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(16).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(17).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(18).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(19).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(45).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(46).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(47).Style.Numberformat.Format = "#,##0.00"

                    Using MS As New System.IO.MemoryStream()
                        package.SaveAs(MS)
                        MS.WriteTo(Response.OutputStream)
                    End Using
                End Using
                Response.Flush()
                Response.End()
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "info", "alert('Data Penutupan Layanan Premi tidak ada data.');", True)
            End If

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
    End Sub

    Protected Sub btnReportEC_Click(sender As Object, e As EventArgs) Handles btnReportEC.Click
        Try
            Dim dt_report As New DataTable

            dt_report = oSelect.sp_Create_Data_Penutupan_Layanan_EC(txtPOLICYNO.Text, "", "", ddlReason.SelectedValue.ToString, ddlStatus.SelectedValue.ToString)

            If dt_report.Rows.Count > 0 Then
                'Dim sFileName As String = ""

                'Dim sysdate As Date = Date.Now.Date

                'sFileName = "DATA_PENUTUPAN_LAYANAN_EC_" & Replace(sysdate.ToString("dd/MM/yyyy"), "/", "") & ".xls"

                'Dim GridView1 As New GridView()
                'GridView1.AllowPaging = False
                'GridView1.AllowSorting = False
                'GridView1.DataSource = dt_report
                'GridView1.DataBind()

                'Response.Clear()
                'Response.Buffer = True
                'Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                'Response.Charset = ""
                'Response.Cache.SetCacheability(HttpCacheability.NoCache)
                'Me.EnableViewState = False
                'Response.ContentType = "application/vnd.ms-excel"
                'Dim StringWrite As New System.IO.StringWriter
                'Dim HtmlWrite As New System.Web.UI.HtmlTextWriter(StringWrite)

                'For Each r As GridViewRow In GridView1.Rows
                '    If r.RowType = DataControlRowType.DataRow Then
                '        For columnIndex As Integer = 0 To r.Cells.Count - 1
                '            r.Cells(columnIndex).Attributes.Add("class", "text")
                '        Next
                '    End If
                'Next

                'GridView1.RenderControl(HtmlWrite)

                'Response.AddHeader("X-Download-Options", "noopen")

                ''Remove the charset from the Content-Type header.
                'Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                'Response.Write(style)

                'Response.Write(StringWrite.ToString())
                'Response.End()

                Response.Clear()
                Response.Charset = ""
                Response.ContentEncoding = System.Text.Encoding.UTF8
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                Response.AddHeader("content-disposition", "attachment;filename=DATA_PENUTUPAN_LAYANAN_EC_" + Now.ToString("yyyy_MM_dd") + ".xlsx")

                Using package = New ExcelPackage()
                    Dim ws As ExcelWorksheet =
                    package.Workbook.Worksheets.Add("DATA_PENUTUPAN_LAYANAN_EC")
                    ws.Cells("A1").LoadFromDataTable(dt_report, True)
                    'Adding style to the header
                    ws.Row(1).Height = 20
                    Dim headerRowStyle = ws.Row(1).Style
                    headerRowStyle.Font.Bold = True
                    headerRowStyle.Font.Color.SetColor(System.Drawing.Color.Black)
                    ws.Row(1).Style.ShrinkToFit = False
                    ws.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws.Cells(ws.Dimension.Address).AutoFitColumns()
                    'Adding style to column number by index
                    'BIAYA_PERAWATAN = 20, YANG_DITANGGUNG = 21, TOTAL_EXCESS = 22
                    'Paid = 31,	OUTSTANDING = 32
                    'PREMI_TAHUNAN = 51, Tot_Outstanding = 52, 2%_PREMI_TAHUNAN = 53

                    ws.Column(20).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(21).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(22).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(31).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(32).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(51).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(52).Style.Numberformat.Format = "#,##0.00"
                    ws.Column(53).Style.Numberformat.Format = "#,##0.00"

                    Using MS As New System.IO.MemoryStream()
                        package.SaveAs(MS)
                        MS.WriteTo(Response.OutputStream)
                    End Using
                End Using
                Response.Flush()
                Response.End()
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "info", "alert('Data Penutupan Layanan EC tidak ada data.');", True)
            End If

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
    End Sub
End Class