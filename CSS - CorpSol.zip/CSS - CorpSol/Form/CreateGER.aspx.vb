﻿Imports System.Data
Imports System.Data.SqlClient
'Imports Microsoft.Office.Interop
'Imports Microsoft.Office.Interop.Excel
Imports System.Reflection
Imports OfficeOpenXml
Imports OfficeOpenXml.Style

Partial Public Class CreateGER
    Inherits System.Web.UI.Page

    Dim SQL, SQL1, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Dim Dt_GridGER As New System.Data.DataTable
    Dim Obj_Insert As New InsertBase
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            'Bind_DDL_PROVIDER()
            'BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, ddlProviderCode.SelectedValue.Trim)
            BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, txtProviderCode.Text.Trim)
            BindSecondaryGrid()
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            lblSubTotalMemberShare.Text = "0"
            'GetData()
            'BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue)
            'SetData()
            If ViewState("SelectedRecords") IsNot Nothing Then
                Dim dt As DataTable = DirectCast(ViewState("SelectedRecords"), DataTable)
                ViewState("SelectedRecords") = dt
            End If



        End If

    End Sub
    Private Function CreateDataTable() As DataTable
        Dim dt As New DataTable()

        dt.Columns.Add("CLAIMNUMBER")
        dt.Columns.Add("POLISNO")
        dt.Columns.Add("NOPESERTA")
        dt.Columns.Add("DEPENDENTNO")
        dt.Columns.Add("INVOICENUMBER")
        dt.Columns.Add("STATUS")
        dt.Columns.Add("CLAIMTYPE")
        dt.Columns.Add("MEMBERSHARE")
        dt.Columns.Add("HMOSHARE")
        dt.Columns.Add("PROVIDERCODE")
        dt.Columns.Add("DISCOUNT")
        dt.AcceptChanges()

        Return dt
    End Function
    Private Sub BindSecondaryGrid()
        Dim dt As DataTable = DirectCast(ViewState("SelectedRecords"), DataTable)
        gvSelected.DataSource = dt
        gvSelected.DataBind()

    End Sub
    Private Sub GetData()

        Try
            Dim dt As DataTable
            Dim countMBRSHARE As Double
            Dim countHMOSHARE As Double
            Dim countDISCOUNT As Double

            If ViewState("SelectedRecords") IsNot Nothing Then
                dt = DirectCast(ViewState("SelectedRecords"), DataTable)
            Else
                dt = CreateDataTable()
            End If
            Dim chkAll As CheckBox = DirectCast(GridGER.HeaderRow _
                                .Cells(9).FindControl("chkAll"), CheckBox)
            For i As Integer = 0 To GridGER.Rows.Count - 1
                If chkAll.Checked Then
                    dt = AddRow(GridGER.Rows(i), dt)
                    countMBRSHARE = countMBRSHARE + GridGER.Rows(i).Cells(7).Text
                    countHMOSHARE = countHMOSHARE + GridGER.Rows(i).Cells(8).Text
                    countDISCOUNT = countDISCOUNT + GridGER.Rows(i).Cells(10).Text
                Else
                    Dim chk As CheckBox = DirectCast(GridGER.Rows(i) _
                                    .Cells(9).FindControl("chk"), CheckBox)
                    If chk.Checked Then
                        dt = AddRow(GridGER.Rows(i), dt)
                        countMBRSHARE = countMBRSHARE + GridGER.Rows(i).Cells(7).Text
                        countHMOSHARE = countHMOSHARE + GridGER.Rows(i).Cells(8).Text
                        countDISCOUNT = countDISCOUNT + GridGER.Rows(i).Cells(10).Text
                    Else
                        dt = RemoveRow(GridGER.Rows(i), dt)
                    End If
                End If
            Next

            lblSubTotalMemberShare.Text = "0"
            lblSubTotalMemberShare.Text = FormatNumber(countMBRSHARE, 0)

            lblSubTotalHMOShare.Text = "0"
            lblSubTotalHMOShare.Text = FormatNumber(countHMOSHARE, 0)

            lblSubTotalIncurred.Text = "0"
            lblSubTotalIncurred.Text = FormatNumber(countMBRSHARE + countHMOSHARE, 0)

            lblSubTotalDiscount.Text = "0"
            lblSubTotalDiscount.Text = FormatNumber(countDISCOUNT, 0)

            Dim totBefDisc As Decimal = 0
            totBefDisc = Convert.ToDecimal(lblSubTotalIncurred.Text)
            Dim totDisc As Decimal = 0
            totDisc = Convert.ToDecimal(lblSubTotalDiscount.Text)

            lblSubTotalIncurredAfterDiscount.Text = "0"
            lblSubTotalIncurredAfterDiscount.Text = FormatNumber(totBefDisc - totDisc, 0)

            ViewState("SelectedRecords") = dt
        Catch ex As Exception

        End Try
    End Sub
    Private Sub SetData()
        Try
            Dim chkAll As CheckBox = DirectCast(GridGER.HeaderRow.Cells(9).FindControl("chkAll"), CheckBox)
            'chkAll.Checked = True
            If ViewState("SelectedRecords") IsNot Nothing Then
                Dim dt As DataTable = DirectCast(ViewState("SelectedRecords"), DataTable)
                For i As Integer = 0 To GridGER.Rows.Count - 1
                    Dim chk As CheckBox = DirectCast(GridGER.Rows(i).Cells(9).FindControl("chk"), CheckBox)
                    If chk IsNot Nothing Then
                        Dim dr As DataRow() = dt.[Select]("CLAIMNUMBER = '" & GridGER.Rows(i).Cells(0).Text & "'")
                        chk.Checked = dr.Length > 0
                        If Not chk.Checked Then
                            chkAll.Checked = False
                        End If
                    End If
                Next
                ViewState("SelectedRecords") = dt
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Function AddRow(ByVal gvRow As GridViewRow, ByVal dt As DataTable) As DataTable
        Dim dr As DataRow() = dt.Select("CLAIMNUMBER = '" & gvRow.Cells(0).Text & "'")

        If dr.Length <= 0 Then
            dt.Rows.Add()
            dt.Rows(dt.Rows.Count - 1)("CLAIMNUMBER") = gvRow.Cells(0).Text
            dt.Rows(dt.Rows.Count - 1)("POLISNO") = gvRow.Cells(1).Text
            dt.Rows(dt.Rows.Count - 1)("NOPESERTA") = gvRow.Cells(2).Text
            dt.Rows(dt.Rows.Count - 1)("DEPENDENTNO") = gvRow.Cells(3).Text
            dt.Rows(dt.Rows.Count - 1)("INVOICENUMBER") = gvRow.Cells(4).Text
            dt.Rows(dt.Rows.Count - 1)("STATUS") = gvRow.Cells(5).Text
            dt.Rows(dt.Rows.Count - 1)("CLAIMTYPE") = gvRow.Cells(6).Text
            dt.Rows(dt.Rows.Count - 1)("MEMBERSHARE") = gvRow.Cells(7).Text
            dt.Rows(dt.Rows.Count - 1)("HMOSHARE") = gvRow.Cells(8).Text
            dt.Rows(dt.Rows.Count - 1)("PROVIDERCODE") = gvRow.Cells(9).Text
            dt.Rows(dt.Rows.Count - 1)("DISCOUNT") = gvRow.Cells(10).Text

            dt.AcceptChanges()
        End If

        Return dt
    End Function
    Private Function RemoveRow(ByVal gvRow As GridViewRow, ByVal dt As DataTable) As DataTable
        Dim dr As DataRow() = dt.Select("CLAIMNUMBER = '" _
                                    & gvRow.Cells(0).Text & "'")
        If dr.Length > 0 Then
            dt.Rows.Remove(dr(0))
            dt.AcceptChanges()
        End If
        Return dt
    End Function
    Protected Sub CheckBox_CheckChanged(ByVal sender As Object, ByVal e As EventArgs)
        GetData()
        SetData()
        BindSecondaryGrid()

        Dim totMBRSHARE As Double
        Dim totHMOSHARE As Double
        Dim totDISCOUNT As Double

        For x As Integer = 0 To gvSelected.Rows.Count - 1
            totMBRSHARE = totMBRSHARE + gvSelected.Rows(x).Cells(7).Text
            totHMOSHARE = totHMOSHARE + gvSelected.Rows(x).Cells(8).Text
            totDISCOUNT = totDISCOUNT + gvSelected.Rows(x).Cells(10).Text
        Next

        lblTotMBRSHARE.Text = FormatNumber(totMBRSHARE, 0)
        lblTotHMOSHARE.Text = FormatNumber(totHMOSHARE, 0)

        lblTotIncurred.Text = "0"
        lblTotIncurred.Text = FormatNumber(totMBRSHARE + totHMOSHARE, 0)

        lblTotDiscount.Text = FormatNumber(totDISCOUNT, 0)

        Dim totBefDisc = 0
        totBefDisc = Convert.ToDecimal(lblTotIncurred.Text)
        Dim totDisc = 0
        totDisc = Convert.ToDecimal(lblTotDiscount.Text)

        lblTotIncurredAfterDiscount.Text = "0"
        lblTotIncurredAfterDiscount.Text = FormatNumber(totBefDisc - totDisc, 0)

    End Sub
    Protected Sub OnPaging(ByVal sender As Object, ByVal e As GridViewPageEventArgs) Handles GridGER.PageIndexChanging
        '' Dim dt As DataTable = CType(GridGER.DataSource, DataTable)
        'Dim dt As DataTable = DirectCast(ViewState("DataGridView"), DataTable)
        GetData()

        'GridGER.DataSource = dt
        GridGER.PageIndex = e.NewPageIndex
        'GridGER.DataBind()

        'BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, ddlProviderCode.SelectedValue.Trim)
        BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, txtProviderCode.Text.Trim)
        SetData()
    End Sub
    Public Sub BindGrid(ByVal CLAMNUM As String, ByVal CHDRNUM As String, ByVal INVOICE As String, ByVal WHOPAID As String, ByVal Status As String, ByVal PROVIDERCODE As String)
        Try
            Dim dt_ExPayment As New System.Data.DataTable
            SQL = "SELECT * from Tbl_Bucket_Pending WHERE CLAMNUM='" & Left(CLAMNUM, 8) & "' AND GCOCCNO='" & Right(CLAMNUM, 2) & "' AND REASON='02'"
            dt_ExPayment = Modul.getAllDatainDT(SQL)

            If dt_ExPayment.Rows.Count > 0 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
                    "alert('Claim " & Left(CLAMNUM, 8) & " Sedang diHold');;", True)
            End If
            Dim dt_Grid_GER As DataTable = New System.Data.DataTable
            dt_Grid_GER.Columns.Add(New DataColumn("CLAIM NUMBER", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("POLIS NO", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("NO PESERTA", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("DEPENDENT NO", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("INVOICE NUMBER", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("STATUS", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("CLAIM TYPE", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("MEMBER SHARE", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("HMO SHARE", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("REASON", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("PROVIDER CODE", GetType(String)))
            dt_Grid_GER.Columns.Add(New DataColumn("Discount", GetType(String)))

            If Status = "Active" Then
                'SQL = "SELECT CLAMNUM  + '-' + GCOCCNO as [CLAIM NUMBER], CHDRNUM as [POLIS NO], MBRNO as [NO PESERTA], DPNTNO as [DEPENDENT NO], CLIENT_CLAIM_REF as [INVOICE NUMBER]," & _
                '  "GCSTS as [STATUS], CASE WHEN WhoPaid='P' THEN 'PROVIDER' WHEN WhoPaid='C' THEN 'REIMBURSMENT' END as [CLAIM TYPE], CONVERT(varchar, CAST(TLMBRSHR AS money), 1) as [MEMBER SHARE], " & _
                '  "CONVERT(varchar, CAST(TLHMOSHR AS money), 1) as [HMO SHARE], REASON FROM Tbl_Bucket_Pembayaran " & _
                '  "WHERE CLAMNUM LIKE '%" & Left(CLAMNUM, 8) & "%' AND GCOCCNO LIKE '%" & Right(CLAMNUM, 2) & "%' AND CHDRNUM LIKE '%" & CHDRNUM & "%' AND CLIENT_CLAIM_REF LIKE '%" & INVOICE & "%' AND WHOPAID LIKE '%" & WHOPAID & "%' " & _
                '  "AND [STATUS GER]=0 ORDER BY [CLAIM NUMBER]"

                ' add [Procedure Code]
                Dim strSQL As String = "
SELECT TOP(1000)
   B.CLAMNUM + '-' + B.GCOCCNO as [CLAIM NUMBER],
   B.CHDRNUM as [POLIS NO],
   B.MBRNO as [NO PESERTA],
   B.DPNTNO as [DEPENDENT NO],
   B.CLIENT_CLAIM_REF as [INVOICE NUMBER],
   B.GCSTS as [STATUS],
   CASE
      WHEN
         B.WhoPaid = 'P' 
      THEN
         'PROVIDER' 
      WHEN
         B.WhoPaid = 'C' 
      THEN
         'REIMBURSMENT' 
   END
   as [CLAIM TYPE], CONVERT(varchar, CAST(B.TLMBRSHR AS money), 1) as [MEMBER SHARE], CONVERT(varchar, CAST(B.TLHMOSHR AS money), 1) as [HMO SHARE], B.REASON 
   ,B.PROVORG AS [PROVIDER CODE]
   ,SUM(ISNULL(D.Discount,0)) as 'Discount'
FROM
   Tbl_Bucket_Pembayaran B 
LEFT JOIN [dbo].[Tbl_Bucket_Pembayaran_Discount] D
  ON D.[CLAMNUM] = B.[CLAMNUM]
  AND D.[GCOCCNO] = B.[GCOCCNO]
  AND D.[CHDRNUM] = B.[CHDRNUM]
  AND D.[MBRNO] = B.[MBRNO]
  AND D.[DPNTNO] = B.[DPNTNO]
  AND D.[PROVORG] = B.[PROVORG]
"
                Dim strSQLWhere As String = String.Format("
WHERE
    B.CLAMNUM LIKE '%{0}%' 
    AND B.GCOCCNO LIKE '%{1}%' 
    AND B.CHDRNUM LIKE '%{2}%' 
    AND B.CLIENT_CLAIM_REF LIKE '%{3}%' 
    AND B.WHOPAID LIKE '%{4}%' 
    AND B.[STATUS GER] = {5} 
    AND B.PROVORG LIKE '%{6}%'
--AND (YEAR(CONVERT(varchar(10),[DATIME],23))) 
--BETWEEN (YEAR(convert(varchar(10),getdate(),23)) - 1) 
--AND (YEAR(convert(varchar(10),getdate(),23))) 
GROUP BY B.[DATIME],B.CLAMNUM,B.GCOCCNO,B.CHDRNUM, B.MBRNO,B.DPNTNO, B.CLIENT_CLAIM_REF,B.GCSTS,B.WhoPaid,
B.TLMBRSHR,B.TLHMOSHR,B.REASON,B.PROVORG
-- ORDER BY [CLAIM NUMBER] DESC
ORDER BY B.[DATIME] DESC;", Left(CLAMNUM, 8), Right(CLAMNUM, 2), CHDRNUM, INVOICE, WHOPAID, 0, PROVIDERCODE)

                SQL = strSQL.Trim + " " + strSQLWhere.Trim

                'Modul.SubBindGridView(SQL, GridGER)
                dt_Grid_GER = Modul.getAllDatainDT(SQL)

                GridGER.DataSource = dt_Grid_GER
                GridGER.DataBind()

                'Dim dt_Count As New System.Data.DataTable
                'SQL = "SELECT COUNT(0) as 'COUNT_ROWS' FROM Tbl_Bucket_Pembayaran " &
                '      "WHERE CLAMNUM LIKE '%" & Left(CLAMNUM, 8) & "%' AND GCOCCNO LIKE '%" & Right(CLAMNUM, 2) & "%' AND CHDRNUM LIKE '%" & CHDRNUM & "%' AND CLIENT_CLAIM_REF LIKE '%" & INVOICE & "%' AND WHOPAID LIKE '%" & WHOPAID & "%' " &
                '       "AND [STATUS GER]=0 " & "AND PROVORG like '%" & PROVIDERCODE & "%'"
                ''"AND [STATUS GER]=0 " & "AND PROVORG like '%" & PROVIDERCODE & "%' AND (YEAR(CONVERT(varchar(10),[DATIME],23))) BETWEEN (YEAR(convert(varchar(10),getdate(),23)) - 1) AND (YEAR(convert(varchar(10),getdate(),23)))"

                'dt_Count = Modul.getAllDatainDT(SQL)

                ''lblTotRow.Text = dt_Count.Rows(0)(0).ToString().Trim
                'lblTotRow.Text = dt_Count.Rows(0)("COUNT_ROWS").ToString().Trim
                lblTotRow.Text = dt_Grid_GER.Rows.Count.ToString()

            Else
                'SQL = "SELECT CLAMNUM  + '-' + GCOCCNO as [CLAIM NUMBER], CHDRNUM as [POLIS NO], MBRNO as [NO PESERTA], DPNTNO as [DEPENDENT NO], CLIENT_CLAIM_REF as [INVOICE NUMBER]," & _
                '  "GCSTS as [STATUS], CASE WHEN WhoPaid='P' THEN 'PROVIDER' WHEN WhoPaid='C' THEN 'REIMBURSMENT' END as [CLAIM TYPE], CONVERT(varchar, CAST(TLMBRSHR AS money), 1) as [MEMBER SHARE], " & _
                '  "CONVERT(varchar, CAST(TLHMOSHR AS money), 1) as [HMO SHARE], REASON FROM Tbl_Bucket_Pembayaran " & _
                '  "WHERE CLAMNUM LIKE '%" & Left(CLAMNUM, 8) & "%' AND GCOCCNO LIKE '%" & Right(CLAMNUM, 2) & "%' AND CHDRNUM LIKE '%" & CHDRNUM & "%' AND CLIENT_CLAIM_REF LIKE '%" & INVOICE & "%' AND WHOPAID LIKE '%" & WHOPAID & "%' " & _
                '  "AND [STATUS GER]=0 AND REASON <>'' ORDER BY [CLAIM NUMBER]"
                'Modul.SubBindGridView(SQL, GridGER)

                ' add [Procedure Code]
                Dim strSQL As String = "
SELECT TOP(1000)
   B.CLAMNUM + '-' + B.GCOCCNO as [CLAIM NUMBER],
   B.CHDRNUM as [POLIS NO],
   B.MBRNO as [NO PESERTA],
   B.DPNTNO as [DEPENDENT NO],
   B.CLIENT_CLAIM_REF as [INVOICE NUMBER],
   B.GCSTS as [STATUS],
   CASE
      WHEN
         B.WhoPaid = 'P' 
      THEN
         'PROVIDER' 
      WHEN
         B.WhoPaid = 'C' 
      THEN
         'REIMBURSMENT' 
   END
   as [CLAIM TYPE], CONVERT(varchar, CAST(B.TLMBRSHR AS money), 1) as [MEMBER SHARE], CONVERT(varchar, CAST(B.TLHMOSHR AS money), 1) as [HMO SHARE], B.REASON 
   --,F.SRVCCODE AS [PROVIDER CODE]
   ,B.PROVORG AS [PROVIDER CODE]
   ,SUM(ISNULL(D.Discount,0)) as 'Discount'
FROM
   Tbl_Bucket_Pembayaran B 
LEFT JOIN [dbo].[Tbl_Bucket_Pembayaran_Discount] D
  ON D.[CLAMNUM] = B.[CLAMNUM]
  AND D.[GCOCCNO] = B.[GCOCCNO]
  AND D.[CHDRNUM] = B.[CHDRNUM]
  AND D.[MBRNO] = B.[MBRNO]
  AND D.[DPNTNO] = B.[DPNTNO]
  AND D.[PROVORG] = B.[PROVORG]
"
                Dim strSQLWhere As String = String.Format("
WHERE
    B.CLAMNUM LIKE '%{0}%' 
    AND B.GCOCCNO LIKE '%{1}%' 
    AND B.CHDRNUM LIKE '%{2}%' 
    AND B.CLIENT_CLAIM_REF LIKE '%{3}%' 
    AND B.WHOPAID LIKE '%{4}%' 
    AND B.[STATUS GER] = {5} 
    AND B.REASON <>''
    AND B.PROVORG LIKE '%{6}%'
--AND (YEAR(CONVERT(varchar(10),[DATIME],23))) 
--BETWEEN (YEAR(convert(varchar(10),getdate(),23)) - 1) 
--AND (YEAR(convert(varchar(10),getdate(),23))) 
GROUP BY B.[DATIME],B.CLAMNUM,B.GCOCCNO,B.CHDRNUM, B.MBRNO,B.DPNTNO, B.CLIENT_CLAIM_REF,B.GCSTS,B.WhoPaid,
B.TLMBRSHR,B.TLHMOSHR,B.REASON,B.PROVORG
-- ORDER BY [CLAIM NUMBER] DESC
ORDER BY B.[DATIME] DESC;", Left(CLAMNUM, 8), Right(CLAMNUM, 2), CHDRNUM, INVOICE, WHOPAID, 1, PROVIDERCODE)

                SQL = strSQL + strSQLWhere

                'Modul.SubBindGridView(SQL, GridGER)
                dt_Grid_GER = Modul.getAllDatainDT(SQL)

                GridGER.DataSource = dt_Grid_GER
                GridGER.DataBind()

                'Dim dt_Count As New System.Data.DataTable
                'SQL = "SELECT COUNT(0) as 'COUNT_ROWS' FROM Tbl_Bucket_Pembayaran " &
                '      "WHERE CLAMNUM LIKE '%" & Left(CLAMNUM, 8) & "%' AND GCOCCNO LIKE '%" & Right(CLAMNUM, 2) & "%' AND CHDRNUM LIKE '%" & CHDRNUM & "%' AND CLIENT_CLAIM_REF LIKE '%" & INVOICE & "%' AND WHOPAID LIKE '%" & WHOPAID & "%' " &
                '       "AND [STATUS GER]=0 AND REASON <> '' " & "AND PROVORG like '%" & PROVIDERCODE & "%'"
                ''"AND [STATUS GER]=0 AND REASON <> '' " & "AND PROVORG like '%" & PROVIDERCODE & "%' AND (YEAR(CONVERT(varchar(10),[DATIME],23))) BETWEEN (YEAR(convert(varchar(10),getdate(),23)) - 1) AND (YEAR(convert(varchar(10),getdate(),23)))"
                'dt_Count = Modul.getAllDatainDT(SQL)

                'lblTotRow.Text = dt_Count.Rows(0)(0).ToString().Trim
                'lblTotRow.Text = dt_Count.Rows(0)("COUNT_ROWS").ToString().Trim
                lblTotRow.Text = dt_Grid_GER.Rows.Count.ToString()

            End If
            ' check 
            'Dt.Columns.Add("CLAIMNUMBER")
            'Dt.Columns.Add("POLISNO")
            'Dt.Columns.Add("NOPESERTA")
            'Dt.Columns.Add("DEPENDENTNO")
            'Dt.Columns.Add("INVOICENUMBER")
            'Dt.Columns.Add("STATUS")
            'Dt.Columns.Add("CLAIMTYPE")
            'Dt.Columns.Add("MEMBERSHARE")
            'Dt.Columns.Add("HMOSHARE")
            'Dt.Columns.Add("PROVIDERCODE")
            'Dt.Columns.Add("DISCOUNT")
            If dt_Grid_GER IsNot Nothing Then
                If dt_Grid_GER.Rows.Count > 0 Then
                    If dt_Grid_GER.Rows(0).Item("CLAIM NUMBER").ToString.Length > 0 Then
                        If ViewState("SelectedRecords") IsNot Nothing Then
                            Dim dt_select As DataTable = DirectCast(ViewState("SelectedRecords"), DataTable)
                            'Dim dt_res As New DataTable
                            'dt_res.Columns.Add(New DataColumn("CLAIM NUMBER", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("POLIS NO", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("NO PESERTA", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("DEPENDENT NO", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("INVOICE NUMBER", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("STATUS", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("CLAIM TYPE", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("MEMBER SHARE", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("HMO SHARE", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("REASON", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("PROVIDER CODE", GetType(String)))
                            'dt_res.Columns.Add(New DataColumn("Discount", GetType(String)))
                            Dim strSelect As String = ""
                            For Each row As DataRow In dt_select.Rows
                                strSelect = String.Format("[CLAIM NUMBER] = '{0}' AND [POLIS NO] = '{1}' AND [NO PESERTA] = '{2}' AND [DEPENDENT NO] = '{3}' AND [INVOICE NUMBER] = '{4}'",
                                                                                       row.Item("CLAIMNUMBER").ToString,
                                                                                       row.Item("POLISNO").ToString,
                                                                                       row.Item("NOPESERTA").ToString,
                                                                                       row.Item("DEPENDENTNO").ToString,
                                                                                       row.Item("INVOICENUMBER").ToString)

                                If (dt_Grid_GER.Select(strSelect).Count > 0) Then
                                    Dim dt_res As New DataTable
                                    dt_res = dt_Grid_GER.Select(strSelect).CopyToDataTable
                                    row.Item("DISCOUNT") = dt_res.Rows(0).Item("DISCOUNT")
                                End If

                            Next
                            ViewState("SelectedRecords") = dt_select
                        End If
                    End If
                End If
            End If



        Catch ex As Exception
            Modul.UserMsgBox(Me, ex.Message.ToString)
            Throw (ex)
        End Try
    End Sub

    Protected Sub btnGenerate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGenerate.Click
        GENERATE_GER_TRUE()
    End Sub

    '    Public Sub GENERATE_GER_TRUE()

    '        Try
    '            Dim GER As String = GenerateID()
    '            Dim lstRet As New List(Of String)
    '            For Each row As GridViewRow In gvSelected.Rows
    '                If row.RowType = DataControlRowType.DataRow Then

    '                    Dim ClaimNumber As String = row.Cells(0).Text
    '                    Dim PolisNo As String = row.Cells(1).Text
    '                    Dim Invoice As String = Replace(row.Cells(4).Text, "amp;amp;", "")
    '                    Dim WhoPaid As String = row.Cells(6).Text

    '                    If WhoPaid.ToUpper = "PROVIDER" Then
    '                        WhoPaid = "P"
    '                    ElseIf WhoPaid.ToUpper = "REIMBURSMENT" Then
    '                        WhoPaid = "C"
    '                    Else
    '                        WhoPaid = ""
    '                    End If

    '                    SQL = "INSERT INTO [dbo].[Tbl_GER]
    '(
    '[Transdate],[Policy No],[Claim Type],[CLNTNUM],[Provorg],[Claim No],[Who Paid],[Claim Client Ref No]
    ',[First Report Date],[Claim Form Received On],[Member No],[Member Name],[Patient No],[Patient Name],[Admission Date]
    ',[Discharge Date],[Diagnosis Code],[Procedure Code],[Limit],[Incurred],[Paid],[Cover],[Unpaid],[Excess]
    ',[Remarks],[Claim Status],[Authorization Date],[Submission Date],[Payment Date],[GER No 1],[GER No 2],[GER Date]
    ',[Date Letter AXA],[User ID],[Tick],[Payment Type],[Manual],[User Created],[Discount],[Total Amount]
    ') "
    '                    'SQL1 = "SELECT CONVERT(VARCHAR(10),GETDATE(),103) as TRANSDATE,B.CHDRNUM as [POLIS NO],PRODTYP as [CLAIM TYPE],C.CLNTNUM,PROVORG as PROVORG," &
    '                    '       "B.CLAMNUM  + '-' + B.GCOCCNO as [CLAIM NO],WHOPAID as [Who Paid],CLIENT_CLAIM_REF as [Claim Client Ref No]," &
    '                    '       "CASE WHEN GCFRPDTE='99999999' THEN '06/06/06' ELSE CONVERT(VARCHAR(10),CONVERT(date,CAST(GCFRPDTE AS VARCHAR(8))),103) END as [First Report Date]," &
    '                    '       "CASE WHEN RECVD_DATE='99999999' THEN '06/06/06' ELSE CONVERT(VARCHAR(10),CONVERT(date,CAST(RECVD_DATE AS VARCHAR(8))),103) END as [Claim Form Received On]," &
    '                    '       "B.MBRNO + '-00' as [Member No],C.MBRNAME as [Member Name],B.MBRNO + '-' + D.DPNTNO as [Patient No],D.MBRNAMEED as [Patient Name]," &
    '                    '       "CASE WHEN DTEVISIT='99999999' THEN '06/06/06' ELSE CONVERT(VARCHAR(10),CONVERT(date,CAST(DTEVISIT AS VARCHAR(8))),103) END as [Admission Date]," &
    '                    '       "CASE WHEN DTEDCHRG='99999999' THEN '06/06/06' ELSE CONVERT(VARCHAR(10),CONVERT(date,CAST(DTEDCHRG AS VARCHAR(8))),103) END as [Discharge Date]," &
    '                    '       "B.GCDIAGCD as [Diagnosis Code],F.SRVCCODE AS [Procedure Code],0 as [LIMIT],INCURRED,CASE WHEN WHOPAID='P' THEN HMOSHARE + MBRSHARE WHEN WHOPAID='C' THEN HMOSHARE END as [PAID],HMOSHARE as [COVER]," &
    '                    '       "CASE WHEN WHOPAID='P' THEN 0 WHEN WHOPAID='C' THEN MBRSHARE END as [UNPAID],MBRSHARE as [EXCESS],INVOICENO as [REMARKS], " &
    '                    '       "GCSTS as [CLAIM STATUS],CASE WHEN DATEAUTH='99999999' THEN '06/06/06' ELSE CONVERT(VARCHAR(10),CONVERT(date,CAST(DATEAUTH AS VARCHAR(8))),103) END as [AUTHORIZATION DATE], " &
    '                    '       "'' as [SUBMISSION DATE],'' as [PAYMENT DATE],'" & GER & "' as [GER No 1],'' as [GER No 2],'' as [GER Date],'' as [Date Letter AXA],B.GCAUTHBY as [USER ID],'' as TICK," &
    '                    '       "'' as [PAYMENT DATE],'' as [MANUAL],'" & Session("UserName") & "' as [User Created], " & " ISNULL(B.DISCOUNT,0) as Discount," &
    '                    '       "CASE WHEN WHOPAID='P' THEN HMOSHARE + MBRSHARE WHEN WHOPAID='C' THEN HMOSHARE END as [Total Amount] " &
    '                    '       "FROM Tbl_Bucket_Pembayaran B " &
    '                    '       "LEFT JOIN ( SELECT gmhdpf.CHDRNUM,gmhdpf.MBRNO,clntpf.LSURNAME as MBRNAME,CLNTPF.CLNTNUM FROM GMHDPF INNER JOIN CLNTPF ON GMHDPF.CLNTNUM = Clntpf.CLNTNUM WHERE CLNTPF.VALIDFLAG = '1' AND gmhdpf.DPNTNO = '00') C " &
    '                    '       "ON B.CHDRNUM=C.CHDRNUM AND B.MBRNO=C.MBRNO LEFT JOIN ( SELECT gmhdpf.CHDRNUM,gmhdpf.DPNTNO,gmhdpf.MBRNO,clntpf.LSURNAME as MBRNAMEED FROM GMHDPF " &
    '                    '       "INNER JOIN CLNTPF on GMHDPF.CLNTNUM = Clntpf.CLNTNUM where CLNTPF.VALIDFLAG = '1' ) D ON D.CHDRNUM=C.CHDRNUM AND D.MBRNO=C.MBRNO AND " &
    '                    '       "B.DPNTNO=D.DPNTNO LEFT JOIN Tbl_Duplicate_GCLDPF F ON B.CLAMNUM=F.CLAMNUM AND B.GCOCCNO=F.GCOCCNO WHERE B.CLAMNUM LIKE '%" & Left(ClaimNumber, 8).Trim & "%' AND B.GCOCCNO  LIKE '%" & Right(ClaimNumber, 2).Trim & "%'  AND B.CHDRNUM LIKE '%" & PolisNo.Trim & "%' " &
    '                    '       "AND B.CLIENT_CLAIM_REF LIKE '%" & Invoice.Trim & "%' AND B.WHOPAID LIKE '%" & WhoPaid.Trim & "%' AND [STATUS GER]=0"

    '                    SQL1 = String.Format("
    '(SELECT CONVERT(VARCHAR(10), GETDATE(), 103) AS TRANSDATE,
    '       B.CHDRNUM AS [POLIS NO],
    '       B.PRODTYP AS [CLAIM TYPE],
    '       C.CLNTNUM,
    '       B.PROVORG,
    '       B.CLAMNUM + '-' + B.GCOCCNO AS [CLAIM NO],
    '       B.WHOPAID AS [Who Paid],
    '       B.CLIENT_CLAIM_REF AS [Claim Client Ref No],
    '       CASE
    '           WHEN GCFRPDTE = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(GCFRPDTE AS VARCHAR(8))), 103)
    '       END AS [First Report Date],
    '       CASE
    '           WHEN RECVD_DATE = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(RECVD_DATE AS VARCHAR(8))), 103)
    '       END AS [Claim Form Received],
    '       B.MBRNO + '-00' AS [Member No],
    '       C.MBRNAME AS [Member Name],
    '       B.MBRNO + '-' + D.DPNTNO AS [Patient No],
    '       D.MBRNAMEED AS [Patient Name],
    '       CASE
    '           WHEN DTEVISIT = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(DTEVISIT AS VARCHAR(8))), 103)
    '       END AS [Admission Date],
    '       CASE
    '           WHEN DTEDCHRG = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(DTEDCHRG AS VARCHAR(8))), 103)
    '       END AS [Discharge Date],
    '       B.GCDIAGCD AS [Diagnosis Code],
    '       F.SRVCCODE AS [Procedure Code],
    '       0 AS LIMIT,
    '       F.INCURRED,
    '       CASE
    '           WHEN WHOPAID = 'P' THEN HMOSHARE + MBRSHARE
    '           WHEN WHOPAID = 'C' THEN HMOSHARE
    '       END AS PAID,
    '       F.HMOSHARE AS COVER,
    '       CASE
    '           WHEN WHOPAID = 'P' THEN 0
    '           WHEN WHOPAID = 'C' THEN MBRSHARE
    '       END AS UNPAID,
    '       F.MBRSHARE AS EXCESS,
    '       F.INVOICENO AS REMARKS,
    '       B.GCSTS AS [CLAIM STATUS],
    '       CASE
    '           WHEN DATEAUTH = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(DATEAUTH AS VARCHAR(8))), 103)
    '       END AS [AUTHORIZATION DATE],
    '       '' AS [SUBMISSION DATE],
    '       '' AS [PAYMENT DATE],
    '       '{0}' AS [GER No 1],
    '       '' AS [GER No 2],
    '       '' AS [GER Date],
    '       '' AS [Date Letter AXA],
    '       B.GCAUTHBY AS [USER ID],
    '       '' AS TICK,
    '       '' AS [PAYMENT DATE],
    '       '' AS MANUAL,
    '       '{1}' AS [User Created],
    '       ISNULL(DISC.DISCOUNT, 0) AS Discount,
    '       CASE
    '           WHEN B.WHOPAID = 'P' THEN ((B.[TLMBRSHR] + B.[TLHMOSHR]) - ISNULL(DISC.DISCOUNT, 0))
    '           WHEN B.WHOPAID = 'C' THEN (B.[TLHMOSHR] - ISNULL(DISC.DISCOUNT, 0))
    '       END AS [Total Amount]
    'FROM Tbl_Bucket_Pembayaran AS B
    'INNER JOIN [Tbl_Bucket_Pembayaran_Discount] as DISC
    'ON DISC.[CLAMNUM] = B.[CLAMNUM]
    '  AND DISC.[GCOCCNO] = B.[GCOCCNO]
    '  AND DISC.[CHDRNUM] = B.[CHDRNUM]
    '  AND DISC.[MBRNO] = B.[MBRNO]
    '  AND DISC.[DPNTNO] = B.[DPNTNO]
    '  AND DISC.[PROVORG] = B.[PROVORG]
    'LEFT OUTER JOIN
    '  (SELECT GMHDPF.CHDRNUM,
    '          GMHDPF.MBRNO,
    '          CLNTPF.LSURNAME AS MBRNAME,
    '          CLNTPF.CLNTNUM
    '   FROM GMHDPF
    '   INNER JOIN CLNTPF ON GMHDPF.CLNTNUM = CLNTPF.CLNTNUM
    '   WHERE (CLNTPF.VALIDFLAG = '1')
    '     AND (GMHDPF.DPNTNO = '00')) AS C ON B.CHDRNUM = C.CHDRNUM
    'AND B.MBRNO = C.MBRNO
    'LEFT OUTER JOIN
    '  (SELECT GMHDPF.CHDRNUM,
    '          GMHDPF.DPNTNO,
    '          GMHDPF.MBRNO,
    '          CLNTPF.LSURNAME AS MBRNAMEED
    '   FROM GMHDPF
    '   INNER JOIN CLNTPF ON GMHDPF.CLNTNUM = CLNTPF.CLNTNUM
    '   WHERE (CLNTPF.VALIDFLAG = '1')) AS D ON D.CHDRNUM = C.CHDRNUM
    'AND D.MBRNO = C.MBRNO
    'AND B.DPNTNO = D.DPNTNO
    'LEFT OUTER JOIN Tbl_Duplicate_GCLDPF AS F ON B.CLAMNUM = F.CLAMNUM
    'AND B.GCOCCNO = F.GCOCCNO
    'WHERE (B.CLAMNUM LIKE '%{2}%')
    '  AND (B.GCOCCNO LIKE '%{3}%')
    '  AND (B.CHDRNUM LIKE '%{4}%')
    '  AND (B.CLIENT_CLAIM_REF LIKE '%{5}%')
    '  AND (B.WHOPAID LIKE '%{6}%')
    '  AND (B.[STATUS GER] = {7}) 
    ');
    '", GER, Session("UserName"), Left(ClaimNumber, 8).Trim, Right(ClaimNumber, 2).Trim, PolisNo.Trim, Invoice.Trim, WhoPaid.Trim, "0")
    '                    Dim strRet As String = ""
    '                    Modul.ExecuteWithReturn(SQL & SQL1, strRet)

    '                    If (strRet = "done") Then
    '                        SQL = "UPDATE Tbl_Bucket_Pembayaran SET [STATUS GER] = 1, [Ger No 1]= '" & GER & "' " &
    '                        "WHERE  CLAMNUM LIKE '%" & Left(ClaimNumber, 8).Trim & "%' AND GCOCCNO LIKE '%" & Right(ClaimNumber, 2).Trim & "%' AND CHDRNUM LIKE '%" & PolisNo.Trim & "%' AND CLIENT_CLAIM_REF LIKE '%" & Invoice.Trim & "%' AND WHOPAID LIKE '%" & WhoPaid.Trim & "%'" ' " & _
    '                        Modul.Eksekusi(SQL)

    '                        lstRet.Add(strRet)
    '                    End If


    '                End If

    '            Next

    '            If gvSelected.Rows.Count > 0 And gvSelected.Rows.Count = lstRet.Count Then
    '                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
    '                "alert('Create GER " & GER & " Sukses'); window.location='CreateGER.aspx';", True)
    '            Else
    '                MsgBox("Create GER Gagal.")
    '            End If

    '        Catch ex As Exception
    '            MsgBox(ex.Message)
    '            Throw (ex)

    '        End Try

    '    End Sub

    '    Public Sub GENERATE_GER_TRUE()

    '        Try
    '            Dim GER As String = GenerateID()

    '            'Dim strLstGER As String = ""
    '            Dim strQuery As String = ""
    '            Dim strQueryUpdate As String = ""

    '            Dim dt_Query = New DataTable
    '            dt_Query.Columns.Add("GER")
    '            dt_Query.Columns.Add("CLAMNUM")
    '            dt_Query.Columns.Add("GCOCCNO")
    '            dt_Query.Columns.Add("CHDRNUM")
    '            dt_Query.Columns.Add("CLIENT_CLAIM_REF")
    '            dt_Query.Columns.Add("WHOPAID")
    '            dt_Query.Columns.Add("QUERY")
    '            For Each row As GridViewRow In gvSelected.Rows
    '                If row.RowType = DataControlRowType.DataRow Then

    '                    Dim ClaimNumber As String = row.Cells(0).Text
    '                    Dim PolisNo As String = row.Cells(1).Text
    '                    Dim Invoice As String = Replace(row.Cells(4).Text, "amp;amp;", "")
    '                    Dim WhoPaid As String = row.Cells(6).Text

    '                    If WhoPaid.ToUpper = "PROVIDER" Then
    '                        WhoPaid = "P"
    '                    ElseIf WhoPaid.ToUpper = "REIMBURSMENT" Then
    '                        WhoPaid = "C"
    '                    Else
    '                        WhoPaid = ""
    '                    End If


    '                    SQL = "INSERT INTO [dbo].[Tbl_GER]
    '(
    '[Transdate],[Policy No],[Claim Type],[CLNTNUM],[Provorg],[Claim No],[Who Paid],[Claim Client Ref No]
    ',[First Report Date],[Claim Form Received On],[Member No],[Member Name],[Patient No],[Patient Name],[Admission Date]
    ',[Discharge Date],[Diagnosis Code],[Procedure Code],[Limit],[Incurred],[Paid],[Cover],[Unpaid],[Excess]
    ',[Remarks],[Claim Status],[Authorization Date],[Submission Date],[Payment Date],[GER No 1],[GER No 2],[GER Date]
    ',[Date Letter AXA],[User ID],[Tick],[Payment Type],[Manual],[User Created],[Discount],[Total Amount]
    ') "
    '                    SQL1 = String.Format("
    'SELECT CONVERT(VARCHAR(10), GETDATE(), 103) AS TRANSDATE,
    '       B.CHDRNUM AS [POLIS NO],
    '       B.PRODTYP AS [CLAIM TYPE],
    '       C.CLNTNUM,
    '       B.PROVORG,
    '       B.CLAMNUM + '-' + B.GCOCCNO AS [CLAIM NO],
    '       B.WHOPAID AS [Who Paid],
    '       B.CLIENT_CLAIM_REF AS [Claim Client Ref No],
    '       CASE
    '           WHEN GCFRPDTE = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(GCFRPDTE AS VARCHAR(8))), 103)
    '       END AS [First Report Date],
    '       CASE
    '           WHEN RECVD_DATE = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(RECVD_DATE AS VARCHAR(8))), 103)
    '       END AS [Claim Form Received],
    '       B.MBRNO + '-00' AS [Member No],
    '       C.MBRNAME AS [Member Name],
    '       B.MBRNO + '-' + D.DPNTNO AS [Patient No],
    '       D.MBRNAMEED AS [Patient Name],
    '       CASE
    '           WHEN DTEVISIT = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(DTEVISIT AS VARCHAR(8))), 103)
    '       END AS [Admission Date],
    '       CASE
    '           WHEN DTEDCHRG = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(DTEDCHRG AS VARCHAR(8))), 103)
    '       END AS [Discharge Date],
    '       B.GCDIAGCD AS [Diagnosis Code],
    '       F.SRVCCODE AS [Procedure Code],
    '       0 AS LIMIT,
    '       F.INCURRED,
    '       CASE
    '           WHEN WHOPAID = 'P' THEN HMOSHARE + MBRSHARE
    '           WHEN WHOPAID = 'C' THEN HMOSHARE
    '       END AS PAID,
    '       F.HMOSHARE AS COVER,
    '       CASE
    '           WHEN WHOPAID = 'P' THEN 0
    '           WHEN WHOPAID = 'C' THEN MBRSHARE
    '       END AS UNPAID,
    '       F.MBRSHARE AS EXCESS,
    '       F.INVOICENO AS REMARKS,
    '       B.GCSTS AS [CLAIM STATUS],
    '       CASE
    '           WHEN DATEAUTH = '99999999' THEN '06/06/06'
    '           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(DATEAUTH AS VARCHAR(8))), 103)
    '       END AS [AUTHORIZATION DATE],
    '       '' AS [SUBMISSION DATE],
    '       '' AS [PAYMENT DATE],
    '       '{0}' AS [GER No 1],
    '       '' AS [GER No 2],
    '       '' AS [GER Date],
    '       '' AS [Date Letter AXA],
    '       B.GCAUTHBY AS [USER ID],
    '       '' AS TICK,
    '       '' AS [PAYMENT DATE],
    '       '' AS MANUAL,
    '       '{1}' AS [User Created],
    '       0 AS Discount,
    '       --0 AS [Total Amount]
    'CASE WHEN WHOPAID='P' THEN HMOSHARE + MBRSHARE WHEN WHOPAID='C' THEN HMOSHARE END as [Total Amount] 
    '-- CASE
    '--     WHEN B.WHOPAID = 'P' THEN ((F.INCURRED/(B.[TLMBRSHR] + B.[TLHMOSHR])) * ISNULL(DISC.DISCOUNT, 0))
    '--     WHEN B.WHOPAID = 'C' THEN ((F.INCURRED/(B.[TLHMOSHR])) * ISNULL(DISC.DISCOUNT, 0))
    '-- END AS Discount,
    '-- CASE
    '--     WHEN B.WHOPAID = 'P' THEN F.INCURRED - ((F.INCURRED/(B.[TLMBRSHR] + B.[TLHMOSHR])) * ISNULL(DISC.DISCOUNT, 0))
    '--     WHEN B.WHOPAID = 'C' THEN F.INCURRED - ((F.INCURRED/(B.[TLHMOSHR])) * ISNULL(DISC.DISCOUNT, 0))
    '-- END AS [Total Amount]
    'FROM Tbl_Bucket_Pembayaran AS B
    'INNER JOIN [Tbl_Bucket_Pembayaran_Discount] as DISC
    'ON DISC.[CLAMNUM] = B.[CLAMNUM]
    '  AND DISC.[GCOCCNO] = B.[GCOCCNO]
    '  AND DISC.[CHDRNUM] = B.[CHDRNUM]
    '  AND DISC.[MBRNO] = B.[MBRNO]
    '  AND DISC.[DPNTNO] = B.[DPNTNO]
    '  AND DISC.[PROVORG] = B.[PROVORG]
    'LEFT OUTER JOIN
    '  (SELECT GMHDPF.CHDRNUM,
    '          GMHDPF.MBRNO,
    '          CLNTPF.LSURNAME AS MBRNAME,
    '          CLNTPF.CLNTNUM
    '   FROM GMHDPF
    '   INNER JOIN CLNTPF ON GMHDPF.CLNTNUM = CLNTPF.CLNTNUM
    '   WHERE (CLNTPF.VALIDFLAG = '1')
    '     AND (GMHDPF.DPNTNO = '00')) AS C ON B.CHDRNUM = C.CHDRNUM
    'AND B.MBRNO = C.MBRNO
    'LEFT OUTER JOIN
    '  (SELECT GMHDPF.CHDRNUM,
    '          GMHDPF.DPNTNO,
    '          GMHDPF.MBRNO,
    '          CLNTPF.LSURNAME AS MBRNAMEED
    '   FROM GMHDPF
    '   INNER JOIN CLNTPF ON GMHDPF.CLNTNUM = CLNTPF.CLNTNUM
    '   WHERE (CLNTPF.VALIDFLAG = '1')) AS D ON D.CHDRNUM = C.CHDRNUM
    'AND D.MBRNO = C.MBRNO
    'AND B.DPNTNO = D.DPNTNO
    'LEFT OUTER JOIN Tbl_Duplicate_GCLDPF AS F ON B.CLAMNUM = F.CLAMNUM
    'AND B.GCOCCNO = F.GCOCCNO
    'WHERE (B.CLAMNUM LIKE '%{2}%')
    '  AND (B.GCOCCNO LIKE '%{3}%')
    '  AND (B.CHDRNUM LIKE '%{4}%')
    '  AND (ltrim(rtrim(B.CLIENT_CLAIM_REF)) LIKE '%{5}%')
    '  AND (B.WHOPAID LIKE '%{6}%')
    '  AND (B.[STATUS GER] = {7}) 
    ';
    '", GER, Session("UserName"), Left(ClaimNumber, 8).Trim, Right(ClaimNumber, 2).Trim, PolisNo.Trim, Invoice.Trim, WhoPaid.Trim, "0")
    '                    'Dim strRet As String = ""
    '                    'Modul.ExecuteWithReturn(SQL & SQL1, strRet)
    '                    strQuery = strQuery + (SQL & SQL1)
    '                    dt_Query.Rows.Add(GER, Left(ClaimNumber, 8).Trim, Right(ClaimNumber, 2).Trim, PolisNo.Trim, Invoice.Trim, WhoPaid.Trim, SQL & SQL1)

    '                    'Update Tbl_Bucket_Pembayaran
    '                    'strQueryUpdate = String.Empty
    '                    strQuery = strQuery + String.Format("
    '                    UPDATE Tbl_Bucket_Pembayaran 
    '                    SET [STATUS GER] = 1, [Ger No 1]= '{0}' 
    '                    WHERE  CLAMNUM LIKE '%{1}%' 
    '                    AND GCOCCNO LIKE '%{2}%' 
    '                    AND CHDRNUM LIKE '%{3}%' 
    '                    AND (ltrim(rtrim(CLIENT_CLAIM_REF))) LIKE '%{4}%' 
    '                    AND WHOPAID LIKE '%{5}%' ;", GER, Left(ClaimNumber, 8).Trim, Right(ClaimNumber, 2).Trim, PolisNo.Trim, Invoice.Trim, WhoPaid.Trim).TrimStart.TrimEnd
    '                    strQuery = strQuery + vbNewLine
    '                End If
    '            Next
    '            If gvSelected.Rows.Count > 0 And dt_Query.Rows.Count > 0 And gvSelected.Rows.Count = dt_Query.Rows.Count Then
    '                Try
    '                    Dim iRet As Int32 = 0
    '                    iRet = Obj_Insert.f_Execute_Text_Transaction(strQuery)
    '                    If iRet <> 0 Then
    '                        ' GET DISCOUNT
    '                        Dim dt_Disc As New System.Data.DataTable
    '                        SQL = String.Format("
    'select A.[Claim No],A.[Policy No],A.[Member No], A.[Provorg], D.DISCOUNT
    'from Tbl_GER A
    'left join [Tbl_Bucket_Pembayaran_Discount] D
    'on D.[CLAMNUM] + '-' + D.[GCOCCNO] = A.[Claim No]
    'and D.[CHDRNUM] = A.[Policy No]
    '--and D.[MBRNO] +'-'+ D.[DPNTNO] = A.[Member No]
    'and D.PROVORG = A.Provorg
    'WHERE  A.[GER No 1] = '{0}' 
    'group by A.[Claim No],A.[Policy No],A.[Member No],A.[Provorg], D.DISCOUNT
    'order by A.[Policy No],A.[Claim No] desc;
    '", GER)
    '                        dt_Disc = Modul.getAllDatainDT(SQL)
    '                        If (dt_Disc.Rows.Count > 0) Then
    '                            strQueryUpdate = String.Empty
    '                            For Each row As DataRow In dt_Disc.Rows
    '                                ' get total amount
    '                                Dim dt_Tot As New System.Data.DataTable
    '                                SQL = String.Format("
    'select top 1 [Total Amount]
    'from Tbl_GER
    'WHERE  [GER No 1] = '{0}' 
    'AND [Claim No] = '{1}'
    'AND [Policy No] = '{2}'
    'AND [Member No] = '{3}'
    'AND [Provorg] = '{4}'
    'order by [Total Amount] desc;
    '", GER, row.Item("Claim No"), row.Item("Policy No"), row.Item("Member No"), row.Item("Provorg"))
    '                                dt_Tot = Modul.getAllDatainDT(SQL)
    '                                If (dt_Tot.Rows.Count > 0) Then
    '                                    Dim Val_Disc As Double = 0, Val_Tot As Double = 0
    '                                    Val_Disc = Convert.ToDouble(row.Item("DISCOUNT"))
    '                                    Val_Tot = Convert.ToDouble(dt_Tot.Rows(0).Item("Total Amount"))
    '                                    strQueryUpdate = strQueryUpdate + String.Format("
    'UPDATE Tbl_GER 
    'SET [Discount] = '{0}', [Total Amount] = '{1}'
    'WHERE
    '[Claim No] = '{2}'
    'AND [Policy No] = '{3}'
    'AND [Member No] = '{4}'
    'AND [Provorg] = '{5}'
    'AND [Total Amount] = '{6}';
    '", Val_Disc, (Val_Tot - Val_Disc), row.Item("Claim No"), row.Item("Policy No"), row.Item("Member No"), row.Item("Provorg"), Val_Tot)
    '                                End If
    '                            Next
    '                            iRet = 0
    '                            iRet = Obj_Insert.f_Execute_Text_Transaction(strQueryUpdate)
    '                        Else
    '                            iRet = 1
    '                        End If
    '                        If iRet <> 0 Then
    '                            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
    '               "alert('Create GER : " & GER & " Sukses.'); window.location='CreateGER.aspx';", True)
    '                        Else
    '                            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "info", "alert('Create GER : " & GER & " Gagal.');", True)
    '                            Dim strQueryRollBack As String = ""
    '                            strQueryRollBack = strQueryRollBack + String.Format("delete From [dbo].[Tbl_GER] Where [GER No 1] in ({0});", GER)
    '                            strQueryRollBack = strQueryRollBack + String.Format("UPDATE [dbo].Tbl_Bucket_Pembayaran Set [STATUS GER] = 0, [Ger No 1]= '' WHERE [GER No 1] in ({0});", GER)
    '                            Obj_Insert.f_Execute_Text_Transaction(strQueryRollBack)
    '                        End If

    '                    Else
    '                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "info", "alert('Create GER : " & GER & " Gagal.');", True)
    '                        Dim strQueryRollBack As String = ""
    '                        strQueryRollBack = strQueryRollBack + String.Format("delete From [dbo].[Tbl_GER] Where [GER No 1] in ({0});", GER)
    '                        strQueryRollBack = strQueryRollBack + String.Format("UPDATE [dbo].Tbl_Bucket_Pembayaran Set [STATUS GER] = 0, [Ger No 1]= '' WHERE [GER No 1] in ({0});", GER)
    '                        Obj_Insert.f_Execute_Text_Transaction(strQueryRollBack)

    '                    End If
    '                Catch ex As Exception
    '                    Dim strQueryRollBack As String = ""
    '                    strQueryRollBack = strQueryRollBack + String.Format("delete From [dbo].[Tbl_GER] Where [GER No 1] in ({0});", GER)
    '                    strQueryRollBack = strQueryRollBack + String.Format("UPDATE [dbo].Tbl_Bucket_Pembayaran Set [STATUS GER] = 0, [Ger No 1]= '' WHERE [GER No 1] in ({0});", GER)
    '                    Obj_Insert.f_Execute_Text_Transaction(strQueryRollBack)
    '                End Try
    '            End If

    '        Catch ex As Exception
    '            MsgBox(ex.Message.ToString)
    '            'Throw (ex)
    '        End Try

    '    End Sub

    'Public Sub Bind_DDL_PROVIDER()

    '    Try
    '        Dim dt_Provider_Code As New System.Data.DataTable
    '        'SQL = "select distinct provorg FROM [dbo].[GCLHPF] order by provorg asc"
    '        SQL = "select distinct provorg FROM [dbo].[Tbl_Bucket_Pembayaran] order by provorg asc"
    '        dt_Provider_Code = Modul.getAllDatainDT(SQL)

    '        If dt_Provider_Code.Rows.Count = 0 Then
    '            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
    '            "alert('Data Provider Code Tidak Ditemukan.');", True)
    '        Else
    '            ddlProviderCode.DataSource = dt_Provider_Code
    '            ddlProviderCode.DataTextField = "provorg"
    '            ddlProviderCode.DataValueField = "provorg"
    '            ddlProviderCode.DataBind()
    '            ddlProviderCode.Items.Insert(0, New ListItem("-Select Provider-", ""))
    '            ddlProviderCode.SelectedIndex = 0


    '        End If

    '    Catch ex As Exception

    '    End Try

    'End Sub

    Public Sub GENERATE_GER_TRUE()
        Dim GER As String = GenerateID()
        Dim strQueryRollBack As String = ""
        Try
            'Dim strLstGER As String = ""
            Dim strQuery As String = ""
            Dim strQueryUpdate As String = ""
            Dim lstQuery As New List(Of String)
            'Dim dt_Query = New DataTable
            'dt_Query.Columns.Add("GER")
            'dt_Query.Columns.Add("CLAMNUM")
            'dt_Query.Columns.Add("GCOCCNO")
            'dt_Query.Columns.Add("CHDRNUM")
            'dt_Query.Columns.Add("CLIENT_CLAIM_REF")
            'dt_Query.Columns.Add("WHOPAID")
            'dt_Query.Columns.Add("QUERY")
            Dim iRowsSaved As Int64 = 1
            For Each row As GridViewRow In gvSelected.Rows
                If row.RowType = DataControlRowType.DataRow Then

                    Dim ClaimNumber As String = row.Cells(0).Text
                    Dim PolisNo As String = row.Cells(1).Text
                    Dim Invoice As String = Replace(row.Cells(4).Text, "amp;amp;", "")
                    Dim WhoPaid As String = row.Cells(6).Text

                    If WhoPaid.ToUpper = "PROVIDER" Then
                        WhoPaid = "P"
                    ElseIf WhoPaid.ToUpper = "REIMBURSMENT" Then
                        WhoPaid = "C"
                    Else
                        WhoPaid = ""
                    End If


                    SQL = "INSERT INTO [dbo].[Tbl_GER]
(
[Transdate],[Policy No],[Claim Type],[CLNTNUM],[Provorg],[Claim No],[Who Paid],[Claim Client Ref No]
,[First Report Date],[Claim Form Received On],[Member No],[Member Name],[Patient No],[Patient Name],[Admission Date]
,[Discharge Date],[Diagnosis Code],[Procedure Code],[Limit],[Incurred],[Paid],[Cover],[Unpaid],[Excess]
,[Remarks],[Claim Status],[Authorization Date],[Submission Date],[Payment Date],[GER No 1],[GER No 2],[GER Date]
,[Date Letter AXA],[User ID],[Tick],[Payment Type],[Manual],[User Created],[Discount],[Total Amount]
) "
                    SQL1 = String.Format("
SELECT CONVERT(VARCHAR(10), GETDATE(), 103) AS TRANSDATE,
       B.CHDRNUM AS [POLIS NO],
       B.PRODTYP AS [CLAIM TYPE],
       C.CLNTNUM,
       B.PROVORG,
       B.CLAMNUM + '-' + B.GCOCCNO AS [CLAIM NO],
       B.WHOPAID AS [Who Paid],
       B.CLIENT_CLAIM_REF AS [Claim Client Ref No],
       CASE
           WHEN GCFRPDTE = '99999999' THEN '06/06/06'
		   WHEN LEN(GCFRPDTE) = 8 THEN CONVERT(VARCHAR(10), CONVERT(date, CAST(GCFRPDTE AS VARCHAR(8))), 103)
           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(CONCAT(LEFT(DATEPART(year, GETDATE()),2),LEFT(GCFRPDTE,2),RIGHT(GCFRPDTE,4)) AS VARCHAR(8))), 103)
       END AS [First Report Date],
       CASE
           WHEN RECVD_DATE = '99999999' THEN '06/06/06'
           WHEN LEN(RECVD_DATE) = 8 THEN CONVERT(VARCHAR(10), CONVERT(date, CAST(RECVD_DATE AS VARCHAR(8))), 103)
           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(CONCAT(LEFT(DATEPART(year, GETDATE()),2),LEFT(RECVD_DATE,2),RIGHT(RECVD_DATE,4)) AS VARCHAR(8))), 103)
       END AS [Claim Form Received],
       B.MBRNO + '-00' AS [Member No],
       C.MBRNAME AS [Member Name],
       B.MBRNO + '-' + D.DPNTNO AS [Patient No],
       D.MBRNAMEED AS [Patient Name],
       CASE
           WHEN DTEVISIT = '99999999' THEN '06/06/06'
            WHEN LEN(DTEVISIT) = 8 THEN CONVERT(VARCHAR(10), CONVERT(date, CAST(DTEVISIT AS VARCHAR(8))), 103)
           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(CONCAT(LEFT(DATEPART(year, GETDATE()),2),LEFT(DTEVISIT,2),RIGHT(DTEVISIT,4)) AS VARCHAR(8))), 103)
       END AS [Admission Date],
       CASE
           WHEN DTEDCHRG = '99999999' THEN '06/06/06'
            WHEN LEN(DTEDCHRG) = 8 THEN CONVERT(VARCHAR(10), CONVERT(date, CAST(DTEDCHRG AS VARCHAR(8))), 103)
           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(CONCAT(LEFT(DATEPART(year, GETDATE()),2),LEFT(DTEDCHRG,2),RIGHT(DTEDCHRG,4)) AS VARCHAR(8))), 103)
       END AS [Discharge Date],
       B.GCDIAGCD AS [Diagnosis Code],
       F.SRVCCODE AS [Procedure Code],
       0 AS LIMIT,
       F.INCURRED,
       CASE
           WHEN B.WHOPAID = 'P' THEN HMOSHARE + MBRSHARE
           WHEN B.WHOPAID = 'C' THEN HMOSHARE
       END AS PAID,
       F.HMOSHARE AS COVER,
       CASE
           WHEN B.WHOPAID = 'P' THEN 0
           WHEN B.WHOPAID = 'C' THEN MBRSHARE
       END AS UNPAID,
       F.MBRSHARE AS EXCESS,
       F.INVOICENO AS REMARKS,
       B.GCSTS AS [CLAIM STATUS],
       CASE
           WHEN DATEAUTH = '99999999' THEN '06/06/06'
           ELSE CONVERT(VARCHAR(10), CONVERT(date, CAST(DATEAUTH AS VARCHAR(8))), 103)
       END AS [AUTHORIZATION DATE],
       '' AS [SUBMISSION DATE],
       '' AS [PAYMENT DATE],
       '{0}' AS [GER No 1],
       '' AS [GER No 2],
       '' AS [GER Date],
       '' AS [Date Letter AXA],
       B.GCAUTHBY AS [USER ID],
       '' AS TICK,
       '' AS [PAYMENT TYPE],
       '' AS MANUAL,
       '{1}' AS [User Created],
        ISNULL(DISC.Discount,0) as 'Discount',
       --0 AS [Total Amount]
       CASE
           WHEN B.WHOPAID = 'P' THEN (HMOSHARE + MBRSHARE - ISNULL(DISC.Discount,0))
           WHEN B.WHOPAID = 'C' THEN (HMOSHARE)
       END AS [Total Amount] 
FROM Tbl_Bucket_Pembayaran AS B
LEFT OUTER JOIN
  (SELECT GMHDPF.CHDRNUM,
          GMHDPF.MBRNO,
          CLNTPF.LSURNAME AS MBRNAME,
          CLNTPF.CLNTNUM
   FROM GMHDPF
   INNER JOIN CLNTPF ON GMHDPF.CLNTNUM = CLNTPF.CLNTNUM
   WHERE (CLNTPF.VALIDFLAG = '1')
     AND (GMHDPF.DPNTNO = '00')) AS C ON B.CHDRNUM = C.CHDRNUM
AND B.MBRNO = C.MBRNO
LEFT OUTER JOIN
  (SELECT GMHDPF.CHDRNUM,
          GMHDPF.DPNTNO,
          GMHDPF.MBRNO,
          CLNTPF.LSURNAME AS MBRNAMEED
   FROM GMHDPF
   INNER JOIN CLNTPF ON GMHDPF.CLNTNUM = CLNTPF.CLNTNUM
   WHERE (CLNTPF.VALIDFLAG = '1')) AS D ON D.CHDRNUM = C.CHDRNUM
AND D.MBRNO = C.MBRNO
AND B.DPNTNO = D.DPNTNO
LEFT OUTER JOIN GCLDPF AS F ON B.CLAMNUM = F.CLAMNUM
AND B.GCOCCNO = F.GCOCCNO
LEFT JOIN [dbo].[Tbl_Bucket_Pembayaran_Discount] DISC
  ON DISC.[CLAMNUM] = B.[CLAMNUM]
  AND DISC.[GCOCCNO] = B.[GCOCCNO]
  AND DISC.[CHDRNUM] = B.[CHDRNUM]
  AND DISC.[MBRNO] = B.[MBRNO]
  AND DISC.[DPNTNO] = B.[DPNTNO]
  AND DISC.[PROVORG] = B.[PROVORG] 
  AND DISC.[SRVCCODE] = F.[SRVCCODE]
WHERE (B.CLAMNUM LIKE '%{2}%')
  AND (B.GCOCCNO LIKE '%{3}%')
  AND (B.CHDRNUM LIKE '%{4}%')
  AND (ltrim(rtrim(B.CLIENT_CLAIM_REF)) LIKE '%{5}%')
  AND (B.WHOPAID LIKE '%{6}%')
  AND (B.[STATUS GER] = {7}) ;
", GER, Session("UserName"), Left(ClaimNumber, 8).Trim, Right(ClaimNumber, 2).Trim, PolisNo.Trim, Invoice.Trim, WhoPaid.Trim, "0")
                    'Dim strRet As String = ""
                    'Modul.ExecuteWithReturn(SQL & SQL1, strRet)
                    strQuery = strQuery + (SQL & SQL1)
                    'dt_Query.Rows.Add(GER, Left(ClaimNumber, 8).Trim, Right(ClaimNumber, 2).Trim, PolisNo.Trim, Invoice.Trim, WhoPaid.Trim, SQL & SQL1)
                    SQL = ""
                    SQL1 = ""
                    'Update Tbl_Bucket_Pembayaran
                    strQueryUpdate = strQueryUpdate + String.Format("
UPDATE Tbl_Bucket_Pembayaran 
SET [STATUS GER] = 1, [Ger No 1]= '{0}' 
WHERE  CLAMNUM LIKE '%{1}%' 
AND GCOCCNO LIKE '%{2}%' 
AND CHDRNUM LIKE '%{3}%' 
AND (ltrim(rtrim(CLIENT_CLAIM_REF))) LIKE '%{4}%' 
AND WHOPAID LIKE '%{5}%' ;
", GER, Left(ClaimNumber, 8).Trim, Right(ClaimNumber, 2).Trim, PolisNo.Trim, Invoice.Trim, WhoPaid.Trim).TrimStart.TrimEnd
                    ' dibagi per 10 row querynya, takut jadi berat saat exec
                    Dim iRowsMod As Int32 = iRowsSaved Mod 10
                    If ((iRowsMod = 0) Or (iRowsSaved = gvSelected.Rows.Count)) Then
                        lstQuery.Add(strQuery & strQueryUpdate)
                        strQuery = ""
                        strQueryUpdate = ""
                    End If
                    iRowsSaved = iRowsSaved + 1
                End If


            Next
            'If gvSelected.Rows.Count > 0 And dt_Query.Rows.Count > 0 And gvSelected.Rows.Count = dt_Query.Rows.Count Then
            If gvSelected.Rows.Count > 0 And iRowsSaved > 0 And gvSelected.Rows.Count = iRowsSaved - 1 Then
                For Each strItem As String In lstQuery
                    Dim iRet As Int32 = 0
                    iRet = Obj_Insert.f_Execute_Text_Transaction(strItem)
                    If iRet = 0 Then
                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "info", "alert('Create GER : " & GER & " Gagal.');", True)
                        strQueryRollBack = ""
                        strQueryRollBack = strQueryRollBack + String.Format("delete From [dbo].[Tbl_GER] Where [GER No 1] in ({0});", GER)
                        strQueryRollBack = strQueryRollBack + String.Format("UPDATE [dbo].Tbl_Bucket_Pembayaran Set [STATUS GER] = 0, [Ger No 1]= '' WHERE [GER No 1] in ({0});", GER)
                        Obj_Insert.f_Execute_Text_Transaction(strQueryRollBack)
                    End If
                Next
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect",
   "alert('Create GER : " & GER & " Sukses.'); window.location='CreateGER.aspx';", True)
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "info", "alert('Create GER : " & GER & " Gagal.');", True)
                strQueryRollBack = ""
                strQueryRollBack = strQueryRollBack + String.Format("delete From [dbo].[Tbl_GER] Where [GER No 1] in ({0});", GER)
                strQueryRollBack = strQueryRollBack + String.Format("UPDATE [dbo].Tbl_Bucket_Pembayaran Set [STATUS GER] = 0, [Ger No 1]= '' WHERE [GER No 1] in ({0});", GER)
                Obj_Insert.f_Execute_Text_Transaction(strQueryRollBack)
            End If


        Catch ex As Exception
        'MsgBox(ex.Message.ToString)
        'Throw (ex)
        strQueryRollBack = ""
        strQueryRollBack = strQueryRollBack + String.Format("delete From [dbo].[Tbl_GER] Where [GER No 1] in ({0});", GER)
        strQueryRollBack = strQueryRollBack + String.Format("UPDATE [dbo].Tbl_Bucket_Pembayaran Set [STATUS GER] = 0, [Ger No 1]= '' WHERE [GER No 1] in ({0});", GER)
        Obj_Insert.f_Execute_Text_Transaction(strQueryRollBack)
        End Try

    End Sub
    Private Function GenerateID()
        Dim dt As New System.Data.DataTable
        Dim mydate As Date
        Dim GERNO As Integer
        Dim numbering As String
        Dim ID As String

        mydate = Date.Now

        SQL = ""
        SQL = "SELECT MAX([GER NO 1]) FROM Tbl_GER "
        Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
        Modul.SQLAdp.Fill(dt)

        If dt.Rows.Count > 0 Then
            If dt.Rows(0).Item(0).ToString <> "" Then
                GERNO = Val(Microsoft.VisualBasic.Right(dt.Rows(0).Item(0).ToString, 4) + 1)
                numbering = Microsoft.VisualBasic.Right("0000" & GERNO, 4)
                ID = numbering

                If ID > 9999 Then
                    ID = "0001"
                End If
            Else
                ID = "0001"
            End If
        Else
            ID = "0001"
        End If

        Return ID
    End Function
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click
        'GetData()
        ''BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, ddlProviderCode.SelectedValue.Trim)
        'BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, txtProviderCode.Text.Trim)
        'SetData()
        'lblSubTotalMemberShare.Text = "0"
        'lblSubTotalHMOShare.Text = "0"
        ' tampilkan data update dan checklist
        BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, txtProviderCode.Text.Trim)
        SetData()
        GetData()

        Dim totMBRSHARE As Double
        Dim totHMOSHARE As Double
        Dim totDISCOUNT As Double

        For x As Integer = 0 To gvSelected.Rows.Count - 1
            totMBRSHARE = totMBRSHARE + gvSelected.Rows(x).Cells(7).Text
            totHMOSHARE = totHMOSHARE + gvSelected.Rows(x).Cells(8).Text
            totDISCOUNT = totDISCOUNT + gvSelected.Rows(x).Cells(10).Text
        Next

        lblTotMBRSHARE.Text = FormatNumber(totMBRSHARE, 0)
        lblTotHMOSHARE.Text = FormatNumber(totHMOSHARE, 0)

        lblTotIncurred.Text = "0"
        lblTotIncurred.Text = FormatNumber(totMBRSHARE + totHMOSHARE, 0)

        lblTotDiscount.Text = FormatNumber(totDISCOUNT, 0)

        Dim totBefDisc = 0
        totBefDisc = Convert.ToDecimal(lblTotIncurred.Text)
        Dim totDisc = 0
        totDisc = Convert.ToDecimal(lblTotDiscount.Text)

        lblTotIncurredAfterDiscount.Text = "0"
        lblTotIncurredAfterDiscount.Text = FormatNumber(totBefDisc - totDisc, 0)
    End Sub

    Protected Sub txtCLMNUM_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtCLMNUM.TextChanged

    End Sub
    Protected Sub ddl_Page_Size_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl_Page_Size.SelectedIndexChanged
        GetData()
        GridGER.PageSize = Convert.ToInt32(ddl_Page_Size.SelectedValue)
        'BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, ddlProviderCode.SelectedValue.Trim)
        BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, txtProviderCode.Text.Trim)
        SetData()
    End Sub
    Protected Sub btn_Template_Click(sender As Object, e As EventArgs) Handles btn_Template.Click
        Try
            Dim dtSelected = New DataTable()
            If ViewState("SelectedRecords") IsNot Nothing Then
                dtSelected = DirectCast(ViewState("SelectedRecords"), DataTable)
            End If
            ' query to db for each dt selected 
            Dim dtExcel As New DataTable

            dtExcel.Columns.Add("Claim Number", GetType(String))
            dtExcel.Columns.Add("Policy Number", GetType(String))
            dtExcel.Columns.Add("Nomor Peserta", GetType(String))
            'dtExcel.Columns.Add("Dependent No")
            dtExcel.Columns.Add("Provider Code", GetType(String))
            dtExcel.Columns.Add("Service Code", GetType(String))
            dtExcel.Columns.Add("Invoice Number", GetType(String))
            dtExcel.Columns.Add("Claim Type", GetType(String))
            dtExcel.Columns.Add("Amount", GetType(Decimal))
            dtExcel.Columns.Add("Discount", GetType(Decimal))
            dtExcel.AcceptChanges()

            For Each row As DataRow In dtSelected.Rows
                Dim ClaimNumber As String = row.Item(0)
                Dim PolisNo As String = row.Item(1)
                Dim NoPeserta As String = row.Item(2)
                Dim Invoice As String = Replace(row.Item(4), "amp;amp;", "")
                Dim WhoPaid As String = row.Item(6)

                If WhoPaid.ToUpper = "PROVIDER" Then
                    WhoPaid = "P"
                ElseIf WhoPaid.ToUpper = "REIMBURSMENT" Then
                    WhoPaid = "C"
                Else
                    WhoPaid = ""
                End If
                Dim strQuery As String = ""
                strQuery = String.Format("
SELECT 
--B.CLAMNUM,
--B.[GCOCCNO],
B.CLAMNUM + '-' + B.[GCOCCNO] AS 'Claim Number',
B.[CHDRNUM] AS 'Policy Number',
--B.[MBRNO] AS 'Nomor Peserta',
--B.[DPNTNO] AS 'Dependent No',
B.[MBRNO] + '-' + B.[DPNTNO] AS 'Nomor Peserta',
B.[PROVORG] AS 'Provider Code',
F.SRVCCODE AS 'Service Code',
B.CLIENT_CLAIM_REF AS 'Invoice Number',
CASE 
WHEN B.WHOPAID = 'P' THEN 'PROVIDER'
WHEN B.WHOPAID = 'C' THEN 'REIMBURSMENT'
ELSE ''
END AS 'Claim Type',
Convert(decimal(18,2),F.INCURRED) as 'Amount',
Convert(decimal(18,2),ISNULL(D.Discount,0)) as 'Discount'
FROM Tbl_Bucket_Pembayaran B 
LEFT JOIN GCLDPF F ON B.CLAMNUM=F.CLAMNUM AND B.GCOCCNO=F.GCOCCNO 
LEFT JOIN [dbo].[Tbl_Bucket_Pembayaran_Discount] D
  ON D.[CLAMNUM] = B.[CLAMNUM]
  AND D.[GCOCCNO] = B.[GCOCCNO]
  AND D.[CHDRNUM] = B.[CHDRNUM]
  AND D.[MBRNO] = B.[MBRNO]
  AND D.[DPNTNO] = B.[DPNTNO]
  AND D.[PROVORG] = B.[PROVORG] 
  AND D.[SRVCCODE] = F.[SRVCCODE]
WHERE LTRIM(RTRIM(B.CLAMNUM)) LIKE '%{0}%'
AND LTRIM(RTRIM(B.GCOCCNO))  LIKE '%{1}%'  
AND LTRIM(RTRIM(B.CHDRNUM)) LIKE '%{2}%'  
AND LTRIM(RTRIM(B.CLIENT_CLAIM_REF)) LIKE '%{3}%' 
AND B.WHOPAID LIKE '%{4}%' 
AND [STATUS GER]=0
ORDER BY B.CLIENT_CLAIM_REF,F.INCURRED DESC;
", Left(ClaimNumber, 8).Trim, Right(ClaimNumber, 2).Trim, PolisNo.Trim, Invoice.Trim, WhoPaid.Trim)
                Dim dtRet As DataTable
                dtRet = Modul.getAllDatainDT(strQuery.Trim)
                If (dtRet.Rows.Count > 0) Then
                    For Each item As DataRow In dtRet.Rows
                        dtExcel.ImportRow(item)
                    Next
                End If

            Next


            If (dtExcel.Rows.Count > 0) Then
                Response.Clear()
                Response.Charset = ""
                Response.ContentEncoding = System.Text.Encoding.UTF8
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                Dim strFileName As String = String.Format("GridCreateGER_{0}.xlsx", Now.ToString("yyyyMMdd_HHmmss"))
                Response.AddHeader("content-disposition", "attachment;filename=" & strFileName)
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial
                'Writing the excel file
                Using excelPack = New ExcelPackage()

                    'Session("GER"), Session("DATEGER"), Session("claimtype")
                    Dim ws As ExcelWorksheet = excelPack.Workbook.Worksheets.Add("Data_Detail")
                    ws.Cells("A1").LoadFromDataTable(dtExcel, True)

                    ' Assign borders
                    ws.Cells(ws.Dimension.Address).Style.Border.Top.Style = ExcelBorderStyle.Thin
                    ws.Cells(ws.Dimension.Address).Style.Border.Left.Style = ExcelBorderStyle.Thin
                    ws.Cells(ws.Dimension.Address).Style.Border.Right.Style = ExcelBorderStyle.Thin
                    ws.Cells(ws.Dimension.Address).Style.Border.Bottom.Style = ExcelBorderStyle.Thin

                    ' panduan kolom data type 
                    ' Number
                    ' 8,9
                    'Column Alligment -> Amount, Discount, Total Amount
                    For iCol As Integer = 1 To dtExcel.Columns.Count
                        Select Case iCol
                            Case 8, 9
                                ws.Column(iCol).Style.Numberformat.Format = "#,##0.00"
                                ws.Column(iCol).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                            Case Else
                                ws.Column(iCol).Style.HorizontalAlignment = ExcelHorizontalAlignment.General 'general
                        End Select

                    Next
                    'ws.Column(11).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right
                    'ws.Column(14).Style.HorizontalAlignment = ExcelHorizontalAlignment.Right

                    'Header style
                    ws.Cells(1, 1, 1, 9).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                    ws.Cells(1, 1, 1, 9).Style.Font.Bold = True

                    ws.Cells(ws.Dimension.Address).AutoFitColumns()

                    'Add Comment
                    ws.Comments.Add(ws.Cells("I1"), "Please insert this column with number only.", "System")

                    ''Lock
                    'ws.Protection.SetPassword("Ax@t0wer123")
                    'ws.Protection.IsProtected = True '--------Protect whole sheet
                    'ws.Column(8).Style.Locked = False '-------Unlock column 11
                    'ws.Column(9).Style.Locked = False '-------Unlock column 11
                    'ws.Column(11).Style.Locked = False '-------Unlock column 11


                    Dim MS As New System.IO.MemoryStream()
                    excelPack.SaveAs(MS)
                    MS.WriteTo(HttpContext.Current.Response.OutputStream)
                End Using
                Response.Flush()
                Response.End()
            Else
                Modul.UserMsgBox(Me, "Please select the data first.")
            End If
            dtSelected.Dispose()
        Catch ex As Exception
            Modul.UserMsgBox(Me, ex.Message.ToString)
            Throw (ex)
        End Try
    End Sub

    Protected Sub btnResetDiscount_Click(sender As Object, e As EventArgs) Handles btnResetDiscount.Click
        Try
            Dim iRet As Int16 = 0
            Dim strQuery As String = String.Format("Truncate Table [dbo].[Tbl_Bucket_Pembayaran_Discount];")
            iRet = Obj_Insert.f_Execute_Text_Transaction(strQuery)
            If iRet <> 0 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "alert('Reset Discount Sukses.'); window.location='CreateGER.aspx';", True)
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "info", "alert('Reset Discount Gagal.');", True)
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "info", "alert('Reset Discount Gagal." + ex.Message.ToString + "');", True)
            Throw
        End Try

    End Sub

    Protected Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='CreateGER.aspx';", True)
    End Sub

    Protected Sub btn_Upload_File_Click(sender As Object, e As EventArgs) Handles btn_Upload_File.Click
        'Checking file content length and Extension must be .xlsx  
        If (fu_Update_Discount.HasFile = True) And (System.IO.Path.GetExtension(fu_Update_Discount.FileName) = ".xlsx") Then
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial
            Using excel = New ExcelPackage(fu_Update_Discount.PostedFile.InputStream)
                Dim tbl = New DataTable()
                Dim ws = excel.Workbook.Worksheets.First()
                Dim hasHeader = True ' change it if required '
                ' create DataColumns '
                For Each firstRowCell In ws.Cells(1, 1, 1, ws.Dimension.End.Column)
                    tbl.Columns.Add(If(hasHeader,
                                       firstRowCell.Text,
                                       String.Format("Column {0}", firstRowCell.Start.Column)))
                Next
                ' add rows to DataTable '
                Dim startRow = If(hasHeader, 2, 1)
                For rowNum = startRow To ws.Dimension.End.Row
                    Dim wsRow = ws.Cells(rowNum, 1, rowNum, ws.Dimension.End.Column)
                    Dim row = tbl.NewRow()
                    For Each cell In wsRow
                        row(cell.Start.Column - 1) = cell.Text
                    Next
                    If row.Item(0).ToString.Length > 0 Then
                        tbl.Rows.Add(row)
                    End If
                Next
                Dim iColumnCheck As Integer = 0
                Dim lstColumn As New List(Of String)
                lstColumn.Add("Claim Number")
                lstColumn.Add("Policy Number")
                lstColumn.Add("Nomor Peserta")
                'lstColumn.Add("Dependent No")
                lstColumn.Add("Provider Code")
                lstColumn.Add("Service Code")
                lstColumn.Add("Invoice Number")
                lstColumn.Add("Claim Type")
                lstColumn.Add("Amount")
                lstColumn.Add("Discount")

                If (hasHeader = True And tbl.Rows.Count() > 0) Then
                    ' check column 
                    If (tbl.Columns.Count = lstColumn.Count) Then
                        Dim iColumnIndex As Integer = 0
                        For Each Column As DataColumn In tbl.Columns
                            If (lstColumn.Item(iColumnIndex) = Column.ColumnName) Then
                                iColumnCheck = iColumnCheck + 1
                            End If
                            iColumnIndex = iColumnIndex + 1
                        Next
                    End If
                End If

                If (iColumnCheck = tbl.Columns.Count) Then
                    'Update disc to GER via sp_Update_GER_Discount
                    Dim iRowsUpdate As Integer = 0
                    For Each Row As DataRow In tbl.Rows

                        Dim strCLAMNUM As String = Left(Row.Item("Claim Number").ToString().Trim, 8)
                        Dim strGCOCCNO As String = Right(Row.Item("Claim Number").ToString().Trim, 2)
                        Dim strCHDRNUM As String = Row.Item("Policy Number").ToString().Trim
                        Dim strMBRNO As String = Left(Row.Item("Nomor Peserta").ToString().Trim, 5)
                        Dim strDPNTNO As String = Right(Row.Item("Nomor Peserta").ToString().Trim, 2)
                        Dim strPROVORG As String = Row.Item("Provider Code").ToString().Trim
                        Dim strSRVCCODE As String = Row.Item("Service Code").ToString().Trim
                        Dim strCLIENT_CLAIM_REF As String = Row.Item("Invoice Number").ToString().Trim
                        Dim strWHOPAID As String = Row.Item("Claim Type").ToString().Trim
                        Dim strDisc As String = Row.Item("DISCOUNT").ToString().Trim
                        If strWHOPAID.ToUpper = "PROVIDER" Then
                            strWHOPAID = "P"
                        ElseIf strWHOPAID.ToUpper = "REIMBURSMENT" Then
                            strWHOPAID = "C"
                        Else
                            strWHOPAID = ""
                        End If
                        Dim dDisc As Decimal = 0
                        If (strDisc.Length > 0) Then
                            dDisc = Convert.ToDecimal(strDisc)
                        End If

                        Update_Bucket_Pembayaran_By_SP(strCLAMNUM, strGCOCCNO, strCHDRNUM, strMBRNO, strDPNTNO, strPROVORG, strSRVCCODE, strCLIENT_CLAIM_REF, strWHOPAID, dDisc, Session("UserName"))

                        iRowsUpdate = iRowsUpdate + 1
                    Next

                    Dim dCount As Double = 0
                    dCount = (iRowsUpdate / tbl.Rows.Count) * 100
                    Modul.UserMsgBox(Me, String.Format("Updated Complete :{0}%", dCount))
                    Dim msg = String.Format("Update successfully created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3} Tot.Update : {4}/{1}",
                                   tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count, iRowsUpdate)
                    UploadStatusLabel.Text = msg

                    'Reload data
                    GetData()
                    'Bind all data - refresh gridGER and gridSelected
                    BindGrid("", "", "", "", "Active", "")
                    'Bind by Filters
                    BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, txtProviderCode.Text.Trim)
                    If ViewState("SelectedRecords") IsNot Nothing Then
                        BindSecondaryGrid()
                        SetData()

                        Dim totMBRSHARE As Double
                        Dim totHMOSHARE As Double
                        Dim totDISCOUNT As Double

                        For x As Integer = 0 To gvSelected.Rows.Count - 1
                            totMBRSHARE = totMBRSHARE + gvSelected.Rows(x).Cells(7).Text
                            totHMOSHARE = totHMOSHARE + gvSelected.Rows(x).Cells(8).Text
                            totDISCOUNT = totDISCOUNT + gvSelected.Rows(x).Cells(10).Text
                        Next

                        lblTotMBRSHARE.Text = FormatNumber(totMBRSHARE, 0)
                        lblTotHMOSHARE.Text = FormatNumber(totHMOSHARE, 0)

                        lblTotIncurred.Text = "0"
                        lblTotIncurred.Text = FormatNumber(totMBRSHARE + totHMOSHARE, 0)

                        lblTotDiscount.Text = FormatNumber(totDISCOUNT, 0)

                        Dim totBefDisc = 0
                        totBefDisc = Convert.ToDecimal(lblTotIncurred.Text)
                        Dim totDisc = 0
                        totDisc = Convert.ToDecimal(lblTotDiscount.Text)

                        lblTotIncurredAfterDiscount.Text = "0"
                        lblTotIncurredAfterDiscount.Text = FormatNumber(totBefDisc - totDisc, 0)
                    End If

                Else
                    Modul.UserMsgBox(Me, "Updated Failed")
                    Dim msg = String.Format("Update fail created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3}",
                    tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count)
                    UploadStatusLabel.Text = msg
                End If

            End Using
            ' tampilkan data update dan checklist
            'BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, ddlClaimType.SelectedValue, ddlStatus.SelectedValue, txtProviderCode.Text.Trim)
            Dim countMBRSHARE As Double
            Dim countHMOSHARE As Double
            Dim countDISCOUNT As Double

            Dim chkAll As CheckBox = DirectCast(GridGER.HeaderRow _
                                .Cells(9).FindControl("chkAll"), CheckBox)
            For i As Integer = 0 To GridGER.Rows.Count - 1
                If chkAll.Checked Then
                    countMBRSHARE = countMBRSHARE + GridGER.Rows(i).Cells(7).Text
                    countHMOSHARE = countHMOSHARE + GridGER.Rows(i).Cells(8).Text
                    countDISCOUNT = countDISCOUNT + GridGER.Rows(i).Cells(10).Text
                Else
                    Dim chk As CheckBox = DirectCast(GridGER.Rows(i) _
                                    .Cells(9).FindControl("chk"), CheckBox)
                    If chk.Checked Then
                        countMBRSHARE = countMBRSHARE + GridGER.Rows(i).Cells(7).Text
                        countHMOSHARE = countHMOSHARE + GridGER.Rows(i).Cells(8).Text
                        countDISCOUNT = countDISCOUNT + GridGER.Rows(i).Cells(10).Text
                    End If
                End If
            Next

            lblSubTotalMemberShare.Text = "0"
            lblSubTotalMemberShare.Text = FormatNumber(countMBRSHARE, 0)

            lblSubTotalHMOShare.Text = "0"
            lblSubTotalHMOShare.Text = FormatNumber(countHMOSHARE, 0)

            lblSubTotalIncurred.Text = "0"
            lblSubTotalIncurred.Text = FormatNumber(countMBRSHARE + countHMOSHARE, 0)

            lblSubTotalDiscount.Text = "0"
            lblSubTotalDiscount.Text = FormatNumber(countDISCOUNT, 0)

            Dim totSUbBefDisc As Decimal = 0
            totSUbBefDisc = Convert.ToDecimal(lblSubTotalIncurred.Text)
            Dim totSubDisc As Decimal = 0
            totSubDisc = Convert.ToDecimal(lblSubTotalDiscount.Text)

            lblSubTotalIncurredAfterDiscount.Text = "0"
            lblSubTotalIncurredAfterDiscount.Text = FormatNumber(totSUbBefDisc - totSubDisc, 0)

        Else
            If (fu_Update_Discount.HasFile) Then
                Modul.UserMsgBox(Me, "Please Select a File Excel .xlsx only.")
                UploadStatusLabel.Text = "Not right format Excel-file."
            Else
                Modul.UserMsgBox(Me, "Please Select a File first.")
                UploadStatusLabel.Text = "None Excel-file."
            End If
        End If
    End Sub

    Private Sub Update_Bucket_Pembayaran_By_SP(strCLAMNUM As String, strGCOCCNO As String, strCHDRNUM As String,
                                               strMBRNO As String, strDPNTNO As String, strPROVORG As String, strSRVCCODE As String,
                                               strCLIENT_CLAIM_REF As String, strWHOPAID As String, DISCOUNT As Decimal, strUser As String)
        '@CLAMNUM VARCHAR(10)
        ',@GCOCCNO VARCHAR(2)
        ',@CHDRNUM VARCHAR(10) 
        ',@MBRNO VARCHAR(5)
        ',@DPNTNO VARCHAR(2) 
        ',@PROVORG VARCHAR(10)
        ',@DISCOUNT numeric(18,2) = 0
        Dim xParam(10) As SqlClient.SqlParameter

        xParam(0) = New SqlClient.SqlParameter("@CLAMNUM", SqlDbType.VarChar)
        xParam(0).Value = CType(strCLAMNUM, String)

        xParam(1) = New SqlClient.SqlParameter("@GCOCCNO", SqlDbType.VarChar)
        xParam(1).Value = CType(strGCOCCNO, String)

        xParam(2) = New SqlClient.SqlParameter("@CHDRNUM", SqlDbType.VarChar)
        xParam(2).Value = CType(strCHDRNUM, String)

        xParam(3) = New SqlClient.SqlParameter("@MBRNO", SqlDbType.VarChar)
        xParam(3).Value = CType(strMBRNO, String)

        xParam(4) = New SqlClient.SqlParameter("@DPNTNO", SqlDbType.VarChar)
        xParam(4).Value = CType(strDPNTNO, String)

        xParam(5) = New SqlClient.SqlParameter("@PROVORG", SqlDbType.VarChar)
        xParam(5).Value = CType(strPROVORG, String)

        xParam(6) = New SqlClient.SqlParameter("@SRVCCODE", SqlDbType.VarChar)
        xParam(6).Value = CType(strSRVCCODE, String)

        xParam(7) = New SqlClient.SqlParameter("@CLIENT_CLAIM_REF", SqlDbType.VarChar)
        xParam(7).Value = CType(strCLIENT_CLAIM_REF, String)

        xParam(8) = New SqlClient.SqlParameter("@WHOPAID", SqlDbType.VarChar)
        xParam(8).Value = CType(strWHOPAID, String)

        xParam(9) = New SqlClient.SqlParameter("@DISCOUNT", SqlDbType.Decimal)
        xParam(9).Value = CType(DISCOUNT, Decimal)

        xParam(10) = New SqlClient.SqlParameter("@USER", SqlDbType.VarChar)
        xParam(10).Value = CType(strUser, String)


        Try
            Dim strConn As String = ConfigurationManager.ConnectionStrings("ConSql").ConnectionString
            Modul.ExecuteNonQuery(strConn, "sp_Update_Bucket_Pembayaran_Discount", CommandType.StoredProcedure, xParam)

        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try

    End Sub

End Class