﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices


Partial Public Class AddUser
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            BindGrid()
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub
    Public Sub BindGrid()
        SQL = "SELECT dco_Name, dco_Email FROM Mst_UserApp ORDER BY dco_Name "
        Modul.SubBindGrid(SQL, DgGrid)
    End Sub
    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSave.Click
        Try
            Dim _User As String = ""
            Dim _Email As String = ""

            _User = txtUser.Text.Trim
            _Email = txtEmail.Text.Trim

            'SQL = "SELECT dco_Name, dco_Email FROM mt_vLDAPUser WHERE dco_name LIKE '%" & _User & "%' AND dco_Email LIKE '%" & _Email & "%' ORDER BY dco_Name "
            'Dt = Modul.getAllDatainDT(SQL)

            'If Dt.Rows.Count > 0 Then
            '    SQL = "INSERT INTO Mst_UserApp(dco_Name, dco_Email) VALUES('" & _User & "', '" & _Email & "') "
            '    Modul.Eksekusi(SQL)
            '    DgGrid.CurrentPageIndex = 0
            '    BindGrid()
            '    txtUser.Text = ""
            '    txtEmail.Text = ""
            'Else
            '    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            '    "alert('Invalid username or email'); window.location='AddUser.aspx';", True)
            'End If

            SQL = "INSERT INTO Mst_UserApp(dco_Name, dco_Email) VALUES('" & _User & "', '" & _Email & "') "
            Modul.Eksekusi(SQL)
            DgGrid.CurrentPageIndex = 0
            BindGrid()
            txtUser.Text = ""
            txtEmail.Text = ""

        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdRefresh.Click
        DgGrid.CurrentPageIndex = 0
        BindGrid()
    End Sub
    Private Sub DgGrid_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles DgGrid.PageIndexChanged
        DgGrid.CurrentPageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Protected Sub DgGrid_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DgGrid.SelectedIndexChanged

    End Sub
    
    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
        LoadADSIDetail()
    End Sub
    Public Sub LoadADSIDetail()
        Dim counter As Int16 = 0

        Dim searcher As New DirectorySearcher("")

        Try
            searcher.Filter = "(&(objectCategory=person)(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))"

            searcher.SearchScope = SearchScope.Subtree
            searcher.PageSize = 10000

            Dim Email, UserName As String
            'GlobalUser = ""

            Dim dtLDAP As New DataTable

            Dim dcName As DataColumn
            Dim dcEmail As DataColumn

            dcName = New DataColumn("dco_Name", System.Type.GetType("System.String"))
            dcEmail = New DataColumn("dco_Email", System.Type.GetType("System.String"))

            dtLDAP.Columns.Add(dcName)
            dtLDAP.Columns.Add(dcEmail)

            'Yensen added for LDAP 20110909
            deleteLDAP()
            'End adding

            For Each result As SearchResult In searcher.FindAll()

                Email = ""
                UserName = ""

                counter = counter + 1

                If Not (IsNothing(result)) Then
                    Dim myResultPropColl As ResultPropertyCollection
                    myResultPropColl = result.Properties

                    Dim myKey As String
                    For Each myKey In myResultPropColl.PropertyNames
                        Select Case myKey
                            Case "name"
                                Try
                                    UserName = myResultPropColl(myKey)(0)

                                Catch ex As Exception
                                    UserName = ""
                                End Try

                            Case "mail"
                                Try
                                    Email = myResultPropColl(myKey)(0)

                                Catch ex As Exception
                                    Email = ""
                                End Try
                        End Select

                        'Yensen adding for LDAP
                        If UserName <> "" And Email <> "" Then
                            AddRowdtLDAP(dtLDAP, UserName, Email)
                        End If
                        'end adding

                    Next
                End If

                'GlobalUser &= UserName & ":" & Email & ";"
            Next

            'Yensen adding for LDAP
            Dim dttmpLDAP As DataTable
            dttmpLDAP = dtLDAP.DefaultView.ToTable(True, "dco_Name", "dco_Email")

            Modul.SQLBulkCopy(dttmpLDAP, "mt_vLDAPUser")

            filterLDAP()

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            "alert('Update Active Directory Suksess'); window.location='AddUser.aspx';", True)
            'End adding
        Catch ex As Exception
            Modul.writeJava(Me, "alert('Error : " & ex.Message & "!!');document.getElementById('" & "').focus();")
            Exit Sub
        End Try
    End Sub

    Public Sub deleteLDAP()
        Dim sql As String
        sql = " delete from mt_vLDAPUser "
        Modul.Eksekusi(sql)
    End Sub

    Public Sub filterLDAP()
        Dim sql As String
        sql = " exec filter_LDAP "
        Modul.Eksekusi(sql)
    End Sub

    Public Sub AddRowdtLDAP(ByVal _dtLDAP As DataTable, ByVal _strName As String, ByVal _strEmail As String)
        Dim newRow As DataRow = _dtLDAP.NewRow()

        newRow("dco_Name") = _strName
        newRow("dco_Email") = _strEmail

        _dtLDAP.Rows.Add(newRow)
    End Sub
End Class