﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Reflection
Imports System
Imports ExcelLibrary
Imports ExcelLibrary.SpreadSheet
Imports System.Globalization

Partial Public Class ReportSummaryPremi
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Dim oSelect As New SelectBase
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub

    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click
        Try
            'ExportExcel()

        Catch ex As Exception

        End Try


    End Sub

    Sub ExportExcel()

        Dim workbook As Workbook = New Workbook()

        Dim lblproduct As New ArrayList
        lblproduct.Add("PAID")
        lblproduct.Add("OUTSTANDING")

        Dim ProdS As String
        ProdS = "PAID"
        Dim ProdF As String
        ProdF = "OUTSTANDING"

        Dim dtPAID As New DataTable
        Dim dtOUTSTANDING As New DataTable

        dtPAID = oSelect.sp_Create_Report_Premi_PAID(ddlStatus.SelectedValue.ToString, txtFromProses.Text, txtToProses.Text)
        dtOUTSTANDING = oSelect.sp_Create_Report_Premi_Outstanding(ddlStatus.SelectedValue.ToString, txtFromProses.Text, txtToProses.Text)

        For Each item In lblproduct
            Dim Column As Integer
            Column = 1

            If dtPAID.Rows.Count > 0 Then
                Dim intcol As Integer = 0
                Dim sheetCo As Integer = 1
                Dim tot1, tot2, tot3, tot4, tot5 As Double

                Dim worksheetSu As Worksheet = New Worksheet(item.ToString)

                Dim intcols As Integer = 0

                If item = "PAID" Then
                    tot1 = 0
                    tot2 = 0
                    tot3 = 0
                    tot4 = 0
                    tot5 = 0

                    For Each dc As DataColumn In dtPAID.Columns
                        'workbook.Worksheets(sheetCo).Cells(1, Column).Value = dc.ColumnName
                        worksheetSu.Cells(0, Column - 1) = New Cell(dc.ColumnName)
                        Column = Column + 1
                    Next

                    For i As Integer = 0 To dtPAID.Rows.Count - 1
                        For j As Integer = 0 To dtPAID.Columns.Count - 1
                            worksheetSu.Cells(i + 1, j + 0) = New Cell(dtPAID.Rows(i)(j).ToString())
                        Next

                        tot1 = tot1 + IIf(IsDBNull(dtPAID.Rows(i)(3)), 0, dtPAID.Rows(i)(3))
                        tot2 = tot2 + IIf(IsDBNull(dtPAID.Rows(i)(4)), 0, dtPAID.Rows(i)(4))
                        tot3 = tot3 + IIf(IsDBNull(dtPAID.Rows(i)(5)), 0, dtPAID.Rows(i)(5))
                        tot4 = tot4 + IIf(IsDBNull(dtPAID.Rows(i)(6)), 0, dtPAID.Rows(i)(6))
                        tot5 = tot5 + IIf(IsDBNull(dtPAID.Rows(i)(7)), 0, dtPAID.Rows(i)(7))
                    Next

                    worksheetSu.Cells(dtPAID.Rows.Count + 1, 1) = New Cell("Grand Total")
                    worksheetSu.Cells(dtPAID.Rows.Count + 1, 3) = New Cell(tot1.ToString("0,0.00", CultureInfo.InvariantCulture))
                    worksheetSu.Cells(dtPAID.Rows.Count + 1, 4) = New Cell(tot2.ToString("0,0.00", CultureInfo.InvariantCulture))
                    worksheetSu.Cells(dtPAID.Rows.Count + 1, 5) = New Cell(tot3.ToString("0,0.00", CultureInfo.InvariantCulture))
                    worksheetSu.Cells(dtPAID.Rows.Count + 1, 6) = New Cell(tot4.ToString("0,0.00", CultureInfo.InvariantCulture))
                    worksheetSu.Cells(dtPAID.Rows.Count + 1, 7) = New Cell(tot5.ToString("0,0.00", CultureInfo.InvariantCulture))

                ElseIf item = "OUTSTANDING" Then
                    tot1 = 0
                    tot2 = 0
                    tot3 = 0
                    tot4 = 0
                    tot5 = 0

                    For Each dc As DataColumn In dtOUTSTANDING.Columns
                        'workbook.Worksheets(sheetCo).Cells(1, Column).Value = dc.ColumnName
                        worksheetSu.Cells(0, Column - 1) = New Cell(dc.ColumnName)
                        Column = Column + 1
                    Next

                    For i As Integer = 0 To dtOUTSTANDING.Rows.Count - 1
                        For j As Integer = 0 To dtOUTSTANDING.Columns.Count - 1
                            worksheetSu.Cells(i + 1, j + 0) = New Cell(dtOUTSTANDING.Rows(i)(j).ToString())
                        Next
                        tot1 = tot1 + IIf(IsDBNull(dtOUTSTANDING.Rows(i)(3)), 0, dtOUTSTANDING.Rows(i)(3))
                        tot2 = tot2 + IIf(IsDBNull(dtOUTSTANDING.Rows(i)(4)), 0, dtOUTSTANDING.Rows(i)(4))
                        tot3 = tot3 + IIf(IsDBNull(dtOUTSTANDING.Rows(i)(5)), 0, dtOUTSTANDING.Rows(i)(5))
                        tot4 = tot4 + IIf(IsDBNull(dtOUTSTANDING.Rows(i)(6)), 0, dtOUTSTANDING.Rows(i)(6))
                        tot5 = tot5 + IIf(IsDBNull(dtOUTSTANDING.Rows(i)(7)), 0, dtOUTSTANDING.Rows(i)(7))
                    Next

                    worksheetSu.Cells(dtOUTSTANDING.Rows.Count + 1, 1) = New Cell("Grand Total")
                    worksheetSu.Cells(dtOUTSTANDING.Rows.Count + 1, 3) = New Cell(tot1.ToString("0,0.00", CultureInfo.InvariantCulture))
                    worksheetSu.Cells(dtOUTSTANDING.Rows.Count + 1, 4) = New Cell(tot2.ToString("0,0.00", CultureInfo.InvariantCulture))
                    worksheetSu.Cells(dtOUTSTANDING.Rows.Count + 1, 5) = New Cell(tot3.ToString("0,0.00", CultureInfo.InvariantCulture))
                    worksheetSu.Cells(dtOUTSTANDING.Rows.Count + 1, 6) = New Cell(tot4.ToString("0,0.00", CultureInfo.InvariantCulture))
                    worksheetSu.Cells(dtOUTSTANDING.Rows.Count + 1, 7) = New Cell(tot5.ToString("0,0.00", CultureInfo.InvariantCulture))

                End If

                sheetCo = sheetCo + 1

                worksheetSu.Cells.ColumnWidth.Item(0) = 4500
                worksheetSu.Cells.ColumnWidth.Item(1) = 16000
                worksheetSu.Cells.ColumnWidth.Item(3) = 4500
                worksheetSu.Cells.ColumnWidth.Item(4) = 4500
                worksheetSu.Cells.ColumnWidth.Item(5) = 4500
                worksheetSu.Cells.ColumnWidth.Item(6) = 4500
                worksheetSu.Cells.ColumnWidth.Item(7) = 5000

                workbook.Worksheets.Add(worksheetSu)
            Else
                'oXL.Worksheets.Add(item.ToString).Cells("A1").Value = "NO DATA"
                Dim worksheetSu As Worksheet = New Worksheet(item.ToString)
                worksheetSu.Cells(0, 0) = New Cell("NO DATA")
                'workbook.Worksheets(1).Cells(1, 1).Value = "NO DATA"
                'oXL.Workbooks(1).Worksheets(1).Cells(1, 1).Value = "NO DATA"
                workbook.Worksheets.Add(worksheetSu)
            End If
        Next


        Dim filename As String = "Report Summary Premi " & Strings.Right(DateTime.Now.Year.ToString, 4).PadLeft(4, "0") & DateTime.Now.Month.ToString.PadLeft(2, "0") & DateTime.Now.Day.ToString.PadLeft(2, "0") & ".xls"

        Dim report As String = Server.MapPath("Report\")
        If Not System.IO.Directory.Exists(report) Then
            System.IO.Directory.CreateDirectory(report)
        End If

        Dim reportName As String = Server.MapPath("Report\" + filename)
        If System.IO.File.Exists(reportName) Then
            System.IO.File.Delete(reportName)
        End If

        Dim sAppPath As String = Server.MapPath("Report\" + filename)
        Dim sPath As String = Request.ApplicationPath + "\Report\" + filename

        workbook.Save(sAppPath)

        Dim TheFile As System.IO.FileInfo = New System.IO.FileInfo(sAppPath)
        If (TheFile.Exists) Then

            Response.ContentType = "application/vnd.ms-excel"
            Response.AddHeader("Content-Disposition", "inline; filename=" + filename)
            Response.AddHeader("X-Download-Options", "noopen")

            'Remove the charset from the Content-Type header.
            Response.Charset = ""
            Response.WriteFile(TheFile.FullName)
            Response.End()
        End If

    End Sub
End Class