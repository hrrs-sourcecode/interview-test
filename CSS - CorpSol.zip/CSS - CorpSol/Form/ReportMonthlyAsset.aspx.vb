﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Reflection

Partial Public Class ReportMonthlyAsset
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Dim dr As SqlDataReader
    Dim oSelect As New SelectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            DropFill_FundType()
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub
    Public Sub DropFill_FundType()
        Dim ListTemp As ListItem

        ddlFundType.Items.Clear()
        ListTemp = New ListItem("All", "All")
        ddlFundType.Items.Add(ListTemp)

        SQL = "SELECT DISTINCT DESCPF_TR93U_LONGDESC,ACTRPF_INVFCDE FROM IDAS_CORPSOL_TRANSACTION WHERE ACTRPF_INVFCDE NOT IN ('IN','UH') " & _
              "ORDER BY ACTRPF_INVFCDE"

        dr = Modul.getAllDatainDR(SQL)

        While dr.Read
            ListTemp = New ListItem(dr(1), dr(0))
            ddlFundType.Items.Add(ListTemp)
        End While

        dr.Close()
        Modul.SQLCn.Close()

    End Sub
    Protected Sub ddlFundType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFundType.SelectedIndexChanged
        txtLongDesc.Text = ddlFundType.SelectedValue.ToString
    End Sub
    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click

        Try
            Dim dt_report As New System.Data.DataTable
            Dim dt_report_groping As New System.Data.DataTable
            Dim Unit, Rupiah As Double
            Dim sFileName As String = ""

            If txtFrom.Text.Trim = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Tidak Boleh Kosong.'); window.location='ReportMonthlyAsset.aspx';", True)
                Exit Sub
            ElseIf txtPolis.Text = "" And chkPolis.Checked = False Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Police Number Tidak Boleh Kosong. Harap ceklis all polis jika ingin menampilkan data all polis.'); window.location='ReportMonthlyAsset.aspx';", True)
                Exit Sub
            End If


            sFileName = "Saving Management Report " & txtPolis.Text & ".xls"

            dt_report = oSelect.sp_Monthly_Asset(txtFrom.Text, txtFrom.Text, txtPolis.Text, IIf(ddlFundType.SelectedItem.Text = "All", "", ddlFundType.SelectedItem.Text))

            Dim exceltable As New StringBuilder()

            exceltable.Append("<HTML><BODY><table style=table-layout: fixed>" & _
                              "<tr><td colspan=3 align=left><font size=small face=Calibri><b>LAPORAN ASET PROGRAM CORPORATE SAVINGS</b></font></td>" & _
                              "</tr><tr><td colspan=3 align=left><font size=small face=Calibri><b>" & txtFrom.Text & "</b></font></td>" & _
                              "</tr><tr><td colspan=3 align=left><font size=small face=Calibri><b></b></font></td>" & _
                              "</tr></table><br /><TABLE Border=1 style=table-layout: fixed>")

            exceltable.AppendFormat("<TR>")
            exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Lightgreen>NAMA PERUSAHAAN</TH>"))
            exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Lightgreen>TIPE / JENIS FUND</TH>"))
            exceltable.AppendFormat(String.Concat("<TD colspan=3 align=center bgcolor=Lightgreen><b>ASET</b></TD>"))
            exceltable.AppendFormat("</TR>")

            exceltable.Append("<TR>")
            exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Lightgreen><b>NAV</b></TD>"))
            exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Lightgreen><b>Unit</b></TD>"))
            exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Lightgreen><b>RUPIAH</b></TD>"))
            exceltable.AppendFormat("</TR>")

            For Each row As DataRow In dt_report.Rows
                exceltable.AppendFormat("<TR>")

                exceltable.AppendFormat(String.Concat("<TD>", row("NAMA PERUSAHAAN").ToString(), "</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>", row("Tipe Fund").ToString(), "</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>", row("NAV").ToString(), "</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>", row("UNIT").ToString(), "</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>", row("RUPIAH").ToString(), "</TD>"))

                Unit += row("UNIT")
                Rupiah += row("RUPIAH")

                exceltable.AppendFormat("</TR>")
            Next

            dt_report_groping = oSelect.sp_Monthly_Asset_Grouping(txtFrom.Text, txtFrom.Text, txtPolis.Text, IIf(ddlFundType.SelectedItem.Text = "All", "", ddlFundType.SelectedItem.Text))

            For Each row As DataRow In dt_report_groping.Rows
                exceltable.AppendFormat("<TR>")

                exceltable.AppendFormat(String.Concat("<TD colspan=2>", row("Tipe Fund").ToString(), "</TD>"))
                exceltable.AppendFormat(String.Concat("<TD></TD>"))
                exceltable.AppendFormat(String.Concat("<TD>", row("TOTAL UNIT").ToString(), "</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>", row("TOTAL RUPIAH").ToString(), "</TD>"))

                exceltable.AppendFormat("</TR>")
            Next

            exceltable.Append("</TABLE></td></tr></table></BODY></HTML>")

            Response.Clear()
            Response.Buffer = True
            Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
            Response.Charset = ""
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Me.EnableViewState = False
            Response.ContentType = "application/vnd.ms-excel"

            Response.AddHeader("X-Download-Options", "noopen")

            'Remove the charset from the Content-Type header.
            Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
            Response.Write(style)

            Response.Write(exceltable.ToString())

            Response.End()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtPolis_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtPolis.TextChanged
        Dim dt_Polis As New System.Data.DataTable
        Dim ListTemp As ListItem

        If Len(txtPolis.Text) = 8 Then
            dt_Polis = oSelect.sp_Get_Type_Polis(txtPolis.Text)

            'If dt_Polis.Rows.Count = 0 Then
            '    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            '    "alert('Data Tidak Ditemukan'); window.location='ReportMonthlyAsset.aspx';", True)
            '    Exit Sub
            'End If

            ddlFundType.Items.Clear()
            ListTemp = New ListItem("All", "All")
            ddlFundType.Items.Add(ListTemp)

            For x = 0 To dt_Polis.Rows.Count - 1
                ListTemp = New ListItem(dt_Polis.Rows(x)("Fund"), dt_Polis.Rows(x)("Description"))
                ddlFundType.Items.Add(ListTemp)
            Next

            txtLongDesc.Text = ddlFundType.SelectedValue.ToString

        End If
    End Sub

    Protected Sub chkPolis_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles chkPolis.CheckedChanged
        If chkPolis.Checked = True Then
            txtPolis.Enabled = False
            txtPolis.BackColor = Drawing.Color.Silver
            txtPolis.Text = ""
        Else
            txtPolis.Enabled = True
            txtPolis.BackColor = Drawing.Color.White
        End If
    End Sub
End Class