﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Web

Partial Public Class ReportRefundClaim
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim CrystalReportViewer1 As New CrystalReportViewer
    Dim oSelect As New SelectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
			
			'Response.Write("Hello")
			'Response.End
			
            BindGrid("")
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
			
			'Response.Write("World")
			'Response.End
			
            BindGrid(txtCLMNUM.Text)
        End If

    End Sub

    Public Sub BindGrid(ByVal CLAMNUM As String)
        SQL = "SELECT DISTINCT CLAMNUM + '-' + GCOCCNO as [CLAIM],CHDRNUM as [POLIS NO],MBRNO + '-' + DPNTNO as [NO PESERTA],CLNTNUM as [NO CLIENT]," & _
              "GCSTS as [STATUS G400],PRODTYP as PRODUCT,CONVERT(VARCHAR,CONVERT(DATETIME,CAST(DTEVISIT as VARCHAR)),103) as [DATE VISIT],D.LONGDESC as DIAGNOSA," & _
              "PLANNO as [NO PLAN],PROVORG as [NO PROVIDER],P.CLIENT_CLAIM_REF,P.WHOPAID,CONVERT(varchar, CAST(TLMBRSHR AS money), 1) as [MEMBER SHARE],CONVERT(varchar, CAST(TLHMOSHR AS money), 1) as [HMOSHARE]," & _
              "P.USER_PROFILE as [USER PROFILE] FROM GCLHPF P WITH (NOLOCK) LEFT JOIN DESCPF D WITH (NOLOCK) ON 'E' + P.GCDIAGCD=D.DESCITEM " & _
              "WHERE CLAMNUM LIKE '%" & CLAMNUM & "%' AND D.LONGDESC <>'NA' AND D.LONGDESC <>'N/A' AND P.GCSTS='CR' AND P.WHOPAID='C' AND D.DESCPFX = 'IT' " & _
              "UNION " & _
              "SELECT DISTINCT CLAMNUM + '-' + GCOCCNO as [CLAIM],CHDRNUM as [POLIS NO],MBRNO + '-' + DPNTNO as [NO PESERTA],CLNTNUM as [NO CLIENT]," & _
              "GCSTS as [STATUS G400],PRODTYP as PRODUCT,CONVERT(VARCHAR,CONVERT(DATETIME,CAST(DTEVISIT as VARCHAR)),103) as [DATE VISIT],D.LONGDESC as DIAGNOSA," & _
              "PLANNO as [NO PLAN],PROVORG as [NO PROVIDER],P.CLIENT_CLAIM_REF,P.WHOPAID,CONVERT(varchar, CAST(TLMBRSHR AS money), 1) as [MEMBER SHARE],CONVERT(varchar, CAST(TLHMOSHR AS money), 1) as [HMOSHARE]," & _
              "P.USER_PROFILE as [USER PROFILE] FROM TRN_HDR_SPECIAL_CASE P WITH (NOLOCK) LEFT JOIN DESCPF D WITH (NOLOCK) ON  'E' + P.GCDIAGCD=D.DESCITEM " & _
              "WHERE CLAMNUM LIKE '%" & CLAMNUM & "%' AND D.LONGDESC <>'NA' AND D.LONGDESC <>'N/A' AND P.GCSTS='CR' AND P.WHOPAID='C' AND D.DESCPFX = 'IT' ORDER BY [CHDRNUM]"

        'Response.Write(SQL)

        Modul.SubBindGridView(SQL, GridHeader)

        Dim dt_Count As New System.Data.DataTable
        SQL = "SELECT SUM(TOTAL) as TOTAL FROM (SELECT COUNT(0) As TOTAL FROM GCLHPF WHERE CLAMNUM LIKE '%" & CLAMNUM & "%' " & _
              "AND GCSTS='CR' AND WHOPAID='C' UNION SELECT COUNT(0) AS TOTAL FROM TRN_HDR_SPECIAL_CASE WHERE CLAMNUM LIKE '%" & CLAMNUM & "%' AND GCSTS='CR' AND WHOPAID='C') a"
        dt_Count = Modul.getAllDatainDT(SQL)

        lblTotRow.Text = "Total Data : " & dt_Count.Rows(0)(0).ToString().Trim & " Data "

    End Sub

    Private Sub GridHeader_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridHeader.PageIndexChanging
        GridHeader.PageIndex = e.NewPageIndex
        Me.BindGrid(txtCLMNUM.Text)
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click

    End Sub

    Private Sub GridHeader_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridHeader.RowCommand
        If e.CommandName = "Download" Then
            Try

                Dim dtRefund As New DataTable
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = GridHeader.Rows(index)
                Dim crystalReport As New ReportDocument()
                Dim NoSurat As String

                Session("ClaimNumber") = Left(selectedRow.Cells(0).Text, 8)
                Session("GCOCCNO") = Right(selectedRow.Cells(0).Text, 2)

                NoSurat = GenerateNoSurat()

                crystalReport.Load(Server.MapPath("~/Report/claim_kembali.rpt"))

                dtRefund = oSelect.LetterRefundClaim(selectedRow.Cells(0).Text, NoSurat)

                crystalReport.SetParameterValue(0, selectedRow.Cells(0).Text)
                crystalReport.SetParameterValue(1, NoSurat)

                crystalReport.SetDataSource(dtRefund)
                CrystalReportViewer1.HasExportButton = "True"
                CrystalReportViewer1.ReportSourceID = "CrystalReportSource1"
                CrystalReportViewer1.ReportSource = crystalReport

                Dim formatType As ExportFormatType = ExportFormatType.NoFormat
                formatType = ExportFormatType.WordForWindows

                Response.AddHeader("X-Download-Options", "noopen")

                crystalReport.ExportToHttpResponse(formatType, Response, True, "Letter Return Claim Number " & selectedRow.Cells(0).Text)

                Response.[End]()

            Catch ex As Exception
                'MsgBox(ex.Message)
                'Throw (ex)
            End Try
        End If
    End Sub
    Public Function GenerateNoSurat()
        Dim dt As New System.Data.DataTable
        Dim dt_NoSurat As New System.Data.DataTable
        Dim NoSurat As Integer
        Dim numbering As String
        Dim ID As String = ""

        'SQL = "DELETE FROM Tbl_NoSurat_Refund WHERE YEAR=" & Year(Date.Now) - 1 & " "
        'Modul.Eksekusi(SQL)

        SQL = "SELECT * FROM Tbl_NoSurat_Refund WHERE YEAR=" & Year(Date.Now) & " AND CLAIMNO='" & Session("ClaimNumber") & "' AND GCOCCNO='" & Session("GCOCCNO") & "' "
        Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
        Modul.SQLAdp.Fill(dt_NoSurat)

        If dt_NoSurat.Rows.Count > 0 Then
            If dt_NoSurat.Rows(0).Item(0).ToString <> "" Then
                NoSurat = Val(dt_NoSurat.Rows(0).Item(0).ToString)
                numbering = Microsoft.VisualBasic.Right("0000000" & NoSurat, 7)
                ID = numbering
            Else
                SQL = "SELECT TOP 1 NUMBER FROM Tbl_NoSurat_Refund WHERE YEAR=" & Year(Date.Now) & " ORDER BY NUMBER DESC"
                Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
                Modul.SQLAdp.Fill(dt)

                If dt.Rows.Count > 0 Then
                    If dt.Rows(0).Item(0).ToString <> "" Then
                        NoSurat = Val(dt.Rows(0).Item(0).ToString) + 1
                        numbering = Microsoft.VisualBasic.Right("0000000" & NoSurat, 7)
                        ID = numbering
                    End If
                Else
                    ID = "0000001"
                End If

                SQL = "INSERT INTO Tbl_NoSurat_Refund VALUES (" & ID & "," & Year(Date.Now) & ",'" & Session("ClaimNumber") & "','" & Session("GCOCCNO") & "','" & Session("UserName") & "','" & Date.Now.ToString("yyyy/MM/dd HH:mm:ss") & "') "
                Modul.Eksekusi(SQL)
            End If
        Else
            SQL = "SELECT TOP 1 NUMBER FROM Tbl_NoSurat_Refund WHERE YEAR=" & Year(Date.Now) & " ORDER BY NUMBER DESC"
            Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
            Modul.SQLAdp.Fill(dt)

            If dt.Rows.Count > 0 Then
                If dt.Rows(0).Item(0).ToString <> "" Then
                    NoSurat = Val(dt.Rows(0).Item(0).ToString) + 1
                    numbering = Microsoft.VisualBasic.Right("0000000" & NoSurat, 7)
                    ID = numbering
                End If
            Else
                ID = "0000001"
            End If

            SQL = "INSERT INTO Tbl_NoSurat_Refund VALUES (" & ID & "," & Year(Date.Now) & ",'" & Session("ClaimNumber") & "','" & Session("GCOCCNO") & "','" & Session("UserName") & "','" & Date.Now.ToString("yyyy/MM/dd HH:mm:ss") & "') "
            Modul.Eksekusi(SQL)
        End If

        Return ID

    End Function

 
End Class