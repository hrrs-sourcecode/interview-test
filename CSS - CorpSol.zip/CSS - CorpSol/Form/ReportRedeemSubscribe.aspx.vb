﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Reflection
Imports System
Imports System.IO
Imports Ionic.Zip
Partial Public Class ReportRedeemSubscribe
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim oSelect As New SelectBase
    Dim Dt As New System.Data.DataTable
    Dim dr As SqlDataReader
    Dim dt_mbrNo As New System.Data.DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            DropFill_FundType()
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub
    Public Sub DropFill_FundType()
        Dim ListTemp As ListItem

        ddlFundType.Items.Clear()
        ListTemp = New ListItem("Choose", "")
        ddlFundType.Items.Add(ListTemp)

        SQL = "SELECT DISTINCT DESCPF_TR93U_LONGDESC,ACTRPF_INVFCDE FROM IDAS_CORPSOL_TRANSACTION WHERE ACTRPF_INVFCDE NOT IN ('IN','UH') " & _
              "ORDER BY ACTRPF_INVFCDE"


        dr = Modul.getAllDatainDR(SQL)

        While dr.Read
            ListTemp = New ListItem(dr(1), dr(0))
            ddlFundType.Items.Add(ListTemp)
        End While

        dr.Close()
        Modul.SQLCn.Close()

    End Sub
    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click
        Try
            Dim dateFrom As DateTime
            Dim dateTo As DateTime
            Dim sFileName As String = ""

            dateFrom = CDate(Right(txtFrom.Text, 4) & "-" & Mid(txtFrom.Text, 4, 2) & "-" & Left(txtFrom.Text, 2))
            dateTo = CDate(Right(txtTo.Text, 4) & "-" & Mid(txtTo.Text, 4, 2) & "-" & Left(txtTo.Text, 2))

            If txtFrom.Text.Trim = "" Or txtTo.Text.Trim = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Tidak Boleh Kosong.'); window.location='ReportRedeemSubscribe.aspx';", True)
                Exit Sub
            ElseIf dateTo > dateFrom.AddMonths(1) Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Melebihi Periode Yang Ditentukan.'); window.location='ReportRedeemSubscribe.aspx';", True)
                Exit Sub
            ElseIf txtPolis.Text = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Police Number Tidak Boleh Kosong.'); window.location='ReportRedeemSubscribe.aspx';", True)
                Exit Sub
            End If

            If ddlReportLevel.SelectedValue.ToString = "Policy Level" Then
                Report_Policy_Level()
            ElseIf ddlReportLevel.SelectedValue.ToString = "Member Level" Then
                Report_Member_Level()

                dt_mbrNo.Clear()
                dt_mbrNo = oSelect.sp_Get_MemberNo(txtFrom.Text, txtTo.Text, txtPolis.Text, txtMemberName.Text, ddlFundType.SelectedItem.Text)

                Using zip As New ZipFile()
                    zip.AlternateEncodingUsage = ZipOption.AsNecessary
                    zip.AddDirectoryByName("RedeemSubscribe")

                    For x = 0 To dt_mbrNo.Rows.Count - 1

                        sFileName = "Report Redeem and Subscribe " & txtPolis.Text & " - " & dt_mbrNo.Rows(x)("MBRNO") & ".xls"
                        Dim spath As String = Server.MapPath("~/File/" & sFileName)

                        zip.AddFile(spath, "RedeemSubscribe")
                    Next

                    Response.Clear()
                    Response.Buffer = True
                    Response.AddHeader("Content-Disposition", "inline; filename=" + "RedeemSubscribe.Zip")
                    Response.Charset = ""
                    Response.Cache.SetCacheability(HttpCacheability.NoCache)
                    Me.EnableViewState = False
                    Response.ContentType = "application/zip"

                    Response.AddHeader("X-Download-Options", "noopen")

                    'Remove the charset from the Content-Type header.
                    Dim style As String = "<style> .text { mso-number-format:\@; } </style> "

                    zip.Save(Response.OutputStream)

                    Dim filePaths() As String = Directory.GetFiles(Server.MapPath("~/File/"))

                    For Each filePath As String In filePaths
                        File.Delete(filePath)
                    Next

                    Response.End()

                End Using

            End If


        Catch ex As Exception

        End Try

    End Sub

    Protected Sub ddlFundType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFundType.SelectedIndexChanged
        txtLongDesc.Text = ddlFundType.SelectedValue.ToString
    End Sub
    Public Sub Report_Policy_Level()
        Try
            Dim dt_report As New System.Data.DataTable

            Dim sFileName As String = ""
            Dim tot_RedUnit, tot_RedAmount, tot_SubUnit, tot_SubAmount As Double
            dt_report = oSelect.sp_Redeem_And_Subscribe(txtFrom.Text, txtTo.Text, txtPolis.Text, ddlReportLevel.SelectedValue.ToString, ddlFundType.SelectedItem.Text, txtMemberName.Text, "")

            If dt_report.Rows.Count > 0 Then
                sFileName = "Report Redeem and Subscribe " & txtPolis.Text & ".xls"

                Dim exceltable As New StringBuilder()

                exceltable.Append("<HTML><BODY><table style=table-layout: fixed>" & _
                                  "<tr><td colspan=3><font size=small face=Calibri><b>LAPORAN REDEEM DAN SUBSCRIBE</b></font></td>" & _
                                  "</tr><tr><td colspan=3><font size=small face=Calibri><b>PRODUK MANDIRI CORPORATE SAVINGS</b></font></td>" & _
                                  "</tr></table><br /><TABLE Border=1 style=table-layout: fixed>")

                exceltable.AppendFormat("<TR>")
                exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Silver>TGL TRANSAKSI</TH>"))
                exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Silver>Nama Nasabah</TH>"))
                exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Silver>Jenis Transaksi</TH>"))
                exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Silver>Tipe Fund</TH>"))
                exceltable.AppendFormat(String.Concat("<TD colspan=2 align=center bgcolor=Silver><b>REDEEM</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD colspan=2 align=center bgcolor=Silver><b>SUBSCRIBE</b></TD>"))
                exceltable.AppendFormat("</TR>")

                exceltable.Append("<TR>")
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Unit</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Amount</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Unit</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Amount</b></TD>"))
                exceltable.AppendFormat("</TR>")

                For Each row As DataRow In dt_report.Rows
                    exceltable.AppendFormat("<TR>")

                    exceltable.AppendFormat(String.Concat("<TD>", row("TGL TRANSAKSI").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("NAMA NASABAH").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("JENIS TRANSAKSI").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Tipe Fund").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("REDEEM UNIT").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("REDEEM AMOUNT").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("SUBSCRIBE UNIT").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("SUBSCRIBE AMOUNT").ToString(), "</TD>"))

                    exceltable.AppendFormat("</TR>")

                    tot_RedUnit += row("REDEEM UNIT")
                    tot_RedAmount += row("REDEEM AMOUNT")
                    tot_SubUnit += row("SUBSCRIBE UNIT")
                    tot_SubAmount += row("SUBSCRIBE AMOUNT")

                Next

                exceltable.Append("<TR><TD style=font-size: small; font-family: Calibri; colspan=4><b>Total</b>" & _
                                  "</TD><TD>" & tot_RedUnit & "</TD><TD>" & tot_RedAmount & "</TD><TD>" & tot_SubUnit & "</TD><TD>" & tot_SubAmount & "</TD></TR>" & _
                                  "</TABLE></td></tr></table></BODY></HTML>")
                Response.Clear()
                Response.Buffer = True
                Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                Response.Charset = ""
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Me.EnableViewState = False
                Response.ContentType = "application/vnd.ms-excel"

                Response.AddHeader("X-Download-Options", "noopen")

                'Remove the charset from the Content-Type header.
                Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                Response.Write(style)

                Response.Write(exceltable.ToString())

                Response.End()
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan.'); window.location='ReportRedeemSubscribe.aspx';", True)
            End If

        Catch ex As Exception

        End Try
    End Sub
    Public Sub Report_Member_Level()
        Try
            Dim dt_report As New System.Data.DataTable

            Dim sFileName As String = ""
            Dim tot_RedUnit, tot_RedAmount, tot_SubUnit, tot_SubAmount As Double

            dt_mbrNo = oSelect.sp_Get_MemberNo(txtFrom.Text, txtTo.Text, txtPolis.Text, txtMemberName.Text, ddlFundType.SelectedItem.Text)

            If dt_mbrNo.Rows.Count > 0 Then

                For z = 0 To dt_mbrNo.Rows.Count - 1

                    dt_report.Clear()
                    dt_report = oSelect.sp_Redeem_And_Subscribe(txtFrom.Text, txtTo.Text, txtPolis.Text, ddlReportLevel.SelectedValue.ToString, ddlFundType.SelectedItem.Text, txtMemberName.Text, dt_mbrNo.Rows(z)("MBRNO"))

                    sFileName = "Report Redeem and Subscribe " & txtPolis.Text & " - " & dt_mbrNo.Rows(z)("MBRNO") & ".xls"

                    Dim exceltable As New StringBuilder()

                    exceltable.Append("<HTML><BODY><table style=table-layout: fixed>" & _
                                      "<tr><td colspan=3><font size=small face=Calibri><b>LAPORAN REDEEM DAN SUBSCRIBE</b></font></td>" & _
                                      "</tr><tr><td colspan=3><font size=small face=Calibri><b>PRODUK MANDIRI CORPORATE SAVINGS</b></font></td>" & _
                                      "</tr></table><br /><TABLE Border=1 style=table-layout: fixed>")

                    exceltable.AppendFormat("<TR>")
                    exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Silver>TGL TRANSAKSI</TH>"))
                    exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Silver>Nama Nasabah</TH>"))
                    exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Silver>Jenis Transaksi</TH>"))
                    exceltable.AppendFormat(String.Concat("<TH rowspan=2 bgcolor=Silver>Tipe Fund</TH>"))
                    exceltable.AppendFormat(String.Concat("<TD colspan=2 align=center bgcolor=Silver><b>REDEEM</b></TD>"))
                    exceltable.AppendFormat(String.Concat("<TD colspan=2 align=center bgcolor=Silver><b>SUBSCRIBE</b></TD>"))
                    exceltable.AppendFormat("</TR>")

                    exceltable.Append("<TR>")
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Unit</b></TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Amount</b></TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Unit</b></TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>Amount</b></TD>"))
                    exceltable.AppendFormat("</TR>")

                    For Each row As DataRow In dt_report.Rows
                        exceltable.AppendFormat("<TR>")

                        exceltable.AppendFormat(String.Concat("<TD>", row("TGL TRANSAKSI").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("NAMA NASABAH").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("JENIS TRANSAKSI").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("Tipe Fund").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("REDEEM UNIT").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("REDEEM AMOUNT").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("SUBSCRIBE UNIT").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("SUBSCRIBE AMOUNT").ToString(), "</TD>"))

                        exceltable.AppendFormat("</TR>")

                        tot_RedUnit += row("REDEEM UNIT")
                        tot_RedAmount += row("REDEEM AMOUNT")
                        tot_SubUnit += row("SUBSCRIBE UNIT")
                        tot_SubAmount += row("SUBSCRIBE AMOUNT")
                    Next

                    exceltable.Append("<TR><TD style=font-size: small; font-family: Calibri; colspan=4><b>Total</b>" & _
                                 "</TD><TD>" & tot_RedUnit & "</TD><TD>" & tot_RedAmount & "</TD><TD>" & tot_SubUnit & "</TD><TD>" & tot_SubAmount & "</TD></TR>" & _
                                 "</TABLE></td></tr></table></BODY></HTML>")

                    Dim file As System.IO.StreamWriter = New System.IO.StreamWriter(Server.MapPath("~/File/" & sFileName))
                    file.WriteLine(exceltable.ToString)
                    file.Close()
                Next

            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan.'); window.location='ReportRedeemSubscribe.aspx';", True)

            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub ddlReportLevel_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlReportLevel.SelectedIndexChanged
        If ddlReportLevel.SelectedValue.ToString = "Member Level" Then
            lblMember.Visible = True
            txtMemberName.Visible = True
        Else
            lblMember.Visible = False
            txtMemberName.Visible = False
        End If
    End Sub
    Protected Sub txtPolis_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtPolis.TextChanged
        Dim dt_Polis As New System.Data.DataTable
        Dim ListTemp As ListItem

        If Len(txtPolis.Text) = 8 Then
            dt_Polis = oSelect.sp_Get_Type_Polis(txtPolis.Text)

            If dt_Polis.Rows.Count = 0 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportRedeemSubscribe.aspx';", True)
                Exit Sub
            End If
            Session("Type") = dt_Polis.Rows(0)("Type").ToString

            If Session("Type") = "DCI" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
                ddlReportLevel.Items.Add("Member Level")
            ElseIf Session("Type") = "DBE" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportRedeemSubscribe.aspx';", True)
            End If

            ddlFundType.Items.Clear()

            For x = 0 To dt_Polis.Rows.Count - 1
                ListTemp = New ListItem(dt_Polis.Rows(x)("Fund"), dt_Polis.Rows(x)("Description"))
                ddlFundType.Items.Add(ListTemp)
            Next

            txtLongDesc.Text = ddlFundType.SelectedValue.ToString

        End If
    End Sub
End Class