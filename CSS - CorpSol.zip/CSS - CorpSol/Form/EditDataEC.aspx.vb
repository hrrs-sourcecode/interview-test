﻿Imports System.Data
Imports System.Data.SqlClient

Partial Public Class EditDataEC
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim dr As SqlDataReader
    Dim oSelect As New SelectBase
    Dim oUpdate As New UpdateBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            BindGrid("", "", "", "", "UNPAID")
            trInfoDetail.Visible = False
            trDetail.Visible = False
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            BindGrid(txtCLAIMNO.Text, txtPolis.Text, txtMEMBERNAME.Text, txtAMOUNT.Text, ddl_STATUS.SelectedValue.Trim)
            trInfoDetail.Visible = False
            trDetail.Visible = False
        End If

    End Sub
    Public Sub BindGrid(ByVal CLAIMNO As String, ByVal POLIS As String, ByVal MEMBERNAME As String, ByVal AMOUNT As String, ByVal STATUS As String)
        Try
            SQL = "SELECT CLAIM_NO,POLICY_NO,CONVERT(VARCHAR, CAST(PAID AS MONEY), 1) AS PAID,CONVERT(VARCHAR, CAST((ISNULL(BIAYA_PERAWATAN,0) - ISNULL(YANG_DITANGGUNG,0)) AS MONEY), 1) AS OUTSTANDING,MEMBER_NAME,STATUS,SEQ,CONVERT(VARCHAR(10),TGL_UPLOAD,111) as TGL_UPLOAD," & _
                  "CONVERT(VARCHAR(10),TGL_BAYAR,111) as TGL_BAYAR, CONVERT(VARCHAR(10),TGL_PENAGIHAN_EXCESS,111) as TGL_PENAGIHAN_EXCESS, CONVERT(VARCHAR(10),TGL_PENAGIHAN_EXCESS2,111) as TGL_PENAGIHAN_EXCESS2, " & _
                  "CONVERT(VARCHAR(10),TGL_PENAGIHAN_EXCESS3,111) as TGL_PENAGIHAN_EXCESS3 FROM tbl_EC WHERE CLAIM_NO LIKE '%" & CLAIMNO & "%' AND POLICY_NO LIKE '%" & POLIS & "%' " & _
                  "AND MEMBER_NAME LIKE '%" & MEMBERNAME & "%' AND CONVERT(BIGINT,TOTAL_EXCESS) LIKE '%" & Replace(AMOUNT, ",", "") & "%'" & _
                  "AND STATUS = '" & STATUS & "' Order by TGL_UPLOAD DESC"
            Modul.SubBindGridView(SQL, GridEC)

           

            If GridEC.Rows.Count = 0 Then
                trInfoDetail.Visible = False
                trDetail.Visible = False

                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
               "alert('Data Tidak Ditemukan.');;", True)
            Else
                ViewState("varStatus") = STATUS
                ShowHideColumns()
            End If

            Dim dt_Count As New System.Data.DataTable
            SQL = "SELECT COUNT(*) FROM tbl_EC WHERE CLAIM_NO LIKE '%" & CLAIMNO & "%' AND POLICY_NO LIKE '%" & POLIS & "%' " & _
                  "AND MEMBER_NAME LIKE '%" & MEMBERNAME & "%' AND CONVERT(BIGINT,TOTAL_EXCESS) LIKE '%" & Replace(AMOUNT, ",", "") & "%'" & _
                  "AND STATUS = '" & STATUS & "'"
            dt_Count = Modul.getAllDatainDT(SQL)

            lblTotalData.Text = "Total Data = " & dt_Count.Rows(0)(0).ToString().Trim & " data"

        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub

    Private Sub GridEC_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridEC.PageIndexChanging
        GridEC.PageIndex = e.NewPageIndex
        BindGrid(txtCLAIMNO.Text, txtPolis.Text, txtMEMBERNAME.Text, txtAMOUNT.Text, ddl_STATUS.SelectedValue.Trim)
        ShowHideColumns()
    End Sub
    Private Sub ShowHideColumns()

        'Dim totalPaid As String = "0"
        'Dim totalOutstanding As String = "0"

        'totalPaid = ViewState("totalPaid").ToString()
        'totalOutstanding = ViewState("totalOutstanding").ToString()

        If (ViewState("varStatus") IsNot Nothing) Then

            Dim status As String = ViewState("varStatus").ToString()

            If status = "PAID" Then

                'If totalPaid > 0 Then
                '    GridEC.Columns(2).Visible = True
                'Else
                '    GridEC.HeaderRow.Cells(2).Visible = False

                '    For Each gvr As GridViewRow In GridEC.Rows
                '        gvr.Cells(2).Visible = False
                '    Next

                'End If

                GridEC.HeaderRow.Cells(3).Visible = False

                For Each gvr As GridViewRow In GridEC.Rows
                    gvr.Cells(3).Visible = False
                Next

            Else

                'If totalOutstanding > 0 Then
                '    GridEC.Columns(3).Visible = True
                'Else
                '    GridEC.HeaderRow.Cells(3).Visible = False

                '    For Each gvr As GridViewRow In GridEC.Rows
                '        gvr.Cells(3).Visible = False
                '    Next

                'End If

                GridEC.HeaderRow.Cells(2).Visible = False

                For Each gvr As GridViewRow In GridEC.Rows
                    gvr.Cells(2).Visible = False
                Next

            End If

        End If


    End Sub
    Private Sub GridPremi_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridEC.RowCommand
        Try
            If e.CommandName = "SelectHeader" Then

                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = GridEC.Rows(index)
                Dim myLinkButton As LinkButton
                myLinkButton = selectedRow.Cells(0).Controls(0)

                Dt = oSelect.sp_get_detail_EC(myLinkButton.Text)

                If Dt.Rows.Count > 0 Then

                    txtClaimNoDetail.Text = Dt.Rows(0)("CLAIM_NO").ToString
                    txtClaimClientReffNo.Text = Dt.Rows(0)("CLAIM_CLIENT_REF_NO").ToString
                    txtPOLICYNODetail.Text = Dt.Rows(0)("POLICY_NO").ToString
                    txtComPanyName.Text = Dt.Rows(0)("ComPany_Name").ToString
                    txtPICName.Text = Dt.Rows(0)("PIC_Name").ToString
                    txtPhoneNumber.Text = Dt.Rows(0)("NO_PHONE/HP").ToString
                    txtEmailAddress.Text = Dt.Rows(0)("EMAIL").ToString
                    txtCorrespondence.Text = Dt.Rows(0)("ADDRESS").ToString
                    txtReceivedDate.Text = Dt.Rows(0)("Received_Date2").ToString
                    txtClaimType.Text = Dt.Rows(0)("Claim_Type").ToString
                    txtMemberNo.Text = Dt.Rows(0)("Member_No").ToString
                    txtMemberNameDetail.Text = Dt.Rows(0)("MEMBER_NAME").ToString
                    txtPatientNo.Text = Dt.Rows(0)("PETIRNT_NO").ToString
                    txtPatientName.Text = Dt.Rows(0)("Patient_Name").ToString
                    ddl_Status_Detail.Text = Dt.Rows(0)("STATUS").ToString
                    txtProvider.Text = Dt.Rows(0)("Provider").ToString
                    txtAdmissionDate.Text = Dt.Rows(0)("Admission_Date2").ToString
                    txtDischargeDate.Text = Dt.Rows(0)("Discharge_Date2").ToString
                    txtBiayaPerawatan.Text = Convert.ToDecimal(Dt.Rows(0)("Biaya_Perawatan")).ToString("#,##0.")
                    txtYangDitanggung.Text = Convert.ToDecimal(Dt.Rows(0)("Yang_Ditanggung")).ToString("#,##0.")
                    txtTotalExcess.Text = Convert.ToDecimal(Dt.Rows(0)("Total_Excess")).ToString("#,##0.")
                    txtTanggalPenagihan.Text = Dt.Rows(0)("TGL_PENAGIHAN_EXCESS2").ToString
                    txtTanggalPenagihan2.Text = Dt.Rows(0)("TGL_PENAGIHAN_EXCESS22").ToString
                    txtTanggalPenagihan3.Text = Dt.Rows(0)("TGL_PENAGIHAN_EXCESS32").ToString
                    txtTanggalUpload.Text = Dt.Rows(0)("TGL_UPLOAD2").ToString
                    txtTanggalBayar.Text = Dt.Rows(0)("TGL_BAYAR").ToString
                    txtTanggalBayar2.Text = Dt.Rows(0)("TGL_BAYAR2").ToString
                    txtTanggalBayar3.Text = Dt.Rows(0)("TGL_BAYAR3").ToString
                    txtTanggalProses.Text = Dt.Rows(0)("TGL_PROSES2").ToString
                    ddl_Reason.Text = Dt.Rows(0)("Reason").ToString
                    txtPaid.Text = Convert.ToDecimal(Dt.Rows(0)("PAID")).ToString("#,##0.")
                    txtRemarkCollection.Text = Dt.Rows(0)("REMARK_COLLECTION").ToString
                    txtOutstanding.Text = Convert.ToDecimal(Dt.Rows(0)("OUTSTANDING")).ToString("#,##0.")
                    txtNoRCL.Text = Dt.Rows(0)("NO_RCL").ToString
                    txtInvoice.Text = Dt.Rows(0)("NO_INVOICE").ToString
                    txtUser.Text = Dt.Rows(0)("User").ToString
                    txtReceipt_Detail.Text = Dt.Rows(0)("SEQ").ToString

                    ' NEW 2020/12/23 - INVOICE_DATE, PREMI_TAHUNAN
                    txtInvoiceDate.Text = Dt.Rows(0)("INVOICE_DATE").ToString
                    txtPremiTahunan.Text = Convert.ToDecimal(Dt.Rows(0)("PREMI_TAHUNAN")).ToString("#,##0.")

                    trInfoDetail.Visible = True
                    trDetail.Visible = True

                    ' Show Hide Column
                    ShowHideColumns()
                End If
            End If
        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            Throw (ex)
        End Try

    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click
        
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSave.Click
        Dim vCLAIM_NO As String
        Dim vCLAIM_CLIENT_REF_NO As String
        Dim vPOLICY_NO As String
        Dim vComPany_Name As String
        Dim vPIC_Name As String
        Dim vNO_PHONE As String
        Dim vEMAIL As String
        Dim vADDRESS As String
        Dim vReceived_Date As String
        Dim vClaim_Type As String
        Dim vMember_No As String
        Dim vMEMBER_NAME As String
        Dim vPETIRNT_NO As String
        Dim vPatient_Name As String
        Dim vSTATUS As String
        Dim vProvider As String
        Dim vAdmission_Date As String
        Dim vDischarge_Date As String
        Dim vBiaya_Perawatan As String
        Dim vYang_Ditanggung As String
        Dim vTotal_Excess As String
        Dim vTGL_PENAGIHAN_EXCESS As String
        Dim vTGL_PENAGIHAN_EXCESS2 As String
        Dim vTGL_PENAGIHAN_EXCESS3 As String
        Dim vTGL_BAYAR As String
        Dim vTGL_BAYAR2 As String
        Dim vTGL_BAYAR3 As String
        Dim vTGL_PROSES As String
        Dim vReason As String
        Dim vPAID As String
        Dim vREMARK_COLLECTION As String
        Dim vOUTSTANDING As String
        Dim vSEQ As String
        Dim vNO_RCL As String
        Dim vNO_INVOICE As String
        Dim vUSER As String
        Dim query As String = ""
        Dim vINVOICE_DATE As String

        Try
            vCLAIM_NO = txtClaimNoDetail.Text
            vCLAIM_CLIENT_REF_NO = txtClaimClientReffNo.Text
            vPOLICY_NO = txtPOLICYNODetail.Text
            vComPany_Name = txtComPanyName.Text
            vPIC_Name = txtPICName.Text
            vNO_PHONE = txtPhoneNumber.Text
            vEMAIL = txtEmailAddress.Text
            vADDRESS = txtCorrespondence.Text
            vReceived_Date = txtReceivedDate.Text
            vClaim_Type = txtClaimType.Text
            vMember_No = txtMemberNo.Text
            vMEMBER_NAME = txtMemberNameDetail.Text
            vPETIRNT_NO = txtPatientNo.Text
            vPatient_Name = txtPatientName.Text
            vSTATUS = ddl_Status_Detail.Text
            vProvider = txtProvider.Text
            vAdmission_Date = txtAdmissionDate.Text
            vDischarge_Date = txtDischargeDate.Text
            vBiaya_Perawatan = Replace(txtBiayaPerawatan.Text, ",", "")
            vYang_Ditanggung = Replace(txtYangDitanggung.Text, ",", "")
            vTotal_Excess = Replace(txtBiayaPerawatan.Text, ",", "") - Replace(txtYangDitanggung.Text, ",", "")
            vTGL_PENAGIHAN_EXCESS = txtTanggalPenagihan.Text
            vTGL_PENAGIHAN_EXCESS2 = txtTanggalPenagihan2.Text
            vTGL_PENAGIHAN_EXCESS3 = txtTanggalPenagihan3.Text
            vTGL_BAYAR = txtTanggalBayar.Text
            vTGL_BAYAR2 = txtTanggalBayar2.Text
            vTGL_BAYAR3 = txtTanggalBayar3.Text
            vTGL_PROSES = txtTanggalProses.Text
            vReason = ddl_Reason.Text
            vPAID = Replace(txtPaid.Text, ",", "")
            vREMARK_COLLECTION = txtRemarkCollection.Text
            vOUTSTANDING = Val(Replace(vTotal_Excess, ",", "")) - Val(Replace(vPAID, ",", ""))
            vSEQ = txtReceipt_Detail.Text
            vNO_RCL = txtNoRCL.Text
            vNO_INVOICE = txtInvoice.Text
            vUSER = UCase(txtUser.Text)

            ' NEW 2020/12/23 - INVOICE_DATE
            vINVOICE_DATE = IIf(txtInvoiceDate.Text.Trim.Length = 0, "", txtInvoiceDate.Text.Trim)

            oUpdate.f_Update_Data_EC(vPOLICY_NO, vComPany_Name, vPIC_Name, vNO_PHONE, vEMAIL, vADDRESS, vClaim_Type, vCLAIM_NO,
                                     vCLAIM_CLIENT_REF_NO, vMember_No, vMEMBER_NAME, vPETIRNT_NO, vPatient_Name, vReceived_Date, vProvider,
                                     vAdmission_Date, vDischarge_Date, vBiaya_Perawatan, vYang_Ditanggung, vTotal_Excess, vTGL_PENAGIHAN_EXCESS,
                                     vTGL_PENAGIHAN_EXCESS2, vTGL_PENAGIHAN_EXCESS3, vTGL_BAYAR, vSEQ, vREMARK_COLLECTION, vPAID, vOUTSTANDING,
                                     vReason, vSTATUS, vTGL_PROSES, vNO_RCL, vTGL_BAYAR2, vTGL_BAYAR3, vNO_INVOICE, vUSER, vINVOICE_DATE)

            'query = "'" & vTGL_UPLOAD & "','" & vPOLICY_NO & "','" & vComPany_Name & "','" & vPIC_Name & "','" & vNO_PHONE & "','" & vEMAIL & "','" & vADDRESS & "','" & vClaim_Type & "','" & vCLAIM_NO & "','" & _
            '        vCLAIM_CLIENT_REF_NO & "','" & vMember_No & "','" & vMEMBER_NAME & "','" & vPETIRNT_NO & "','" & vPatient_Name & "','" & vReceived_Date & "','" & vProvider & "','" & _
            '        vAdmission_Date & "','" & vDischarge_Date & "','" & vBiaya_Perawatan & "','" & vYang_Ditanggung & "','" & vTotal_Excess & "','" & vTGL_PENAGIHAN_EXCESS & "','" & _
            '        vTGL_PENAGIHAN_EXCESS2 & "','" & vTGL_PENAGIHAN_EXCESS3 & "','" & vTGL_BAYAR & "','" & vSEQ & "','" & vREMARK_COLLECTION & "','" & vPAID & "','" & vOUTSTANDING & "','" & _
            '        vReason & "','" & vSTATUS & "','" & vTGL_PROSES & "','" & vNO_RCL & "'"

            Modul.UserMsgBox(Me, "Save Completed !!")

        Catch ex As Exception
            'Response.Redirect("~/Form/PageUnavailable.aspx", False)
            Throw (ex)
        End Try
    End Sub

    Protected Sub GridEC_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridEC.SelectedIndexChanged

    End Sub
End Class