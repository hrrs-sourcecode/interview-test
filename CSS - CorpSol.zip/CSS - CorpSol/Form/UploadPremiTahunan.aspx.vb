﻿Imports System.Data.OleDb
Imports System.IO
Imports OfficeOpenXml
Imports OfficeOpenXml.Style
''' <summary>
''' This is from reza source code
''' 202012228
''' </summary>
Public Class UploadPremiTahunan
    Inherits System.Web.UI.Page
    Dim Modul As New ClassModul
    Dim DT As New DataTable
    Dim dt_Result As New DataTable
    Dim Obj_Insert As New InsertBase
    Dim Obj_Select As New SelectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not Page.IsPostBack Then
                If Session("username") = "" Or Session("username") Is Nothing Then
                    Response.Redirect("~/Login.aspx", False)
                    Exit Sub
                End If
            End If
        Catch ex As Exception
            ex.Message.ToString()
            Throw
        Finally

        End Try
    End Sub

    Protected Sub Btn_Save_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Btn_Save.Click
        Try
            'Insert_Data_Premi_Tahunan()
            Upload_Data_Premi_Tahunan()
        Catch ex As Exception
            ex.Message.ToString()
            Throw
        Finally

        End Try
    End Sub

    Protected Sub Insert_Data_Premi_Tahunan()
        If Not txtUpload.HasFile Then
            ' Handle file
            Modul.UserMsgBox(Me, "File Can't Empty !!")
            Exit Sub
        End If
        'txtUpload.FileBytes.Length > 1024 => 1kb [5 Mb = 5 * 1024 * 1024]
        If txtUpload.HasFile And txtUpload.FileBytes.Length > 5242880 Then
            ' Handle file
            Modul.UserMsgBox(Me, "Max.File Size is 5 Mb !!")
            Exit Sub
        End If

        Dim Excel_Path As String = Server.MapPath("~/Form/") + Path.GetFileName(txtUpload.PostedFile.FileName)
        Dim File_Extention As String = Path.GetExtension(txtUpload.PostedFile.FileName)
        txtUpload.SaveAs(Excel_Path)

        Dim OLEDB_Connection As OleDbConnection
        Dim OLEDB_DA_Upload As OleDbDataAdapter

        Dim DT_Read_File_Excel_Premi_Tahunan As New DataTable
        Dim DT_Bind_Upload_Excel_Premi_Tahunan As New DataTable

        Dim Success_Insert As Integer = 0

        Try

            OLEDB_Connection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; " & "Data Source='" & Excel_Path & " '; " & "Extended Properties=Excel 12.0;")
            OLEDB_Connection.Open()

            Dim dbSchema As DataTable = OLEDB_Connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
            Dim firstSheetName As String = dbSchema.Rows(0)("TABLE_NAME").ToString()

            OLEDB_DA_Upload = New OleDbDataAdapter("SELECT * FROM [" & firstSheetName & "] WHERE [POLIS] IS NOT NULL", OLEDB_Connection)
            OLEDB_DA_Upload.Fill(DT_Read_File_Excel_Premi_Tahunan)
            OLEDB_DA_Upload.Dispose()
            OLEDB_Connection.Close()

            'MyCommand = New OleDbDataAdapter("SELECT [POLIS], [PREMI_TAHUNAN]  FROM [" & firstSheetName & "] WHERE [POLIS] IS NOT NULL", MyConnection)
            OLEDB_DA_Upload = New OleDbDataAdapter("SELECT [POLIS], [PREMI TAHUNAN] FROM [" & firstSheetName & "] WHERE [POLIS] IS NOT NULL ", OLEDB_Connection)
            OLEDB_DA_Upload.Fill(DT_Bind_Upload_Excel_Premi_Tahunan)
            OLEDB_DA_Upload.Dispose()
            OLEDB_Connection.Close()


            For i = 0 To DT_Read_File_Excel_Premi_Tahunan.Rows.Count
                Try
                    If i = DT_Read_File_Excel_Premi_Tahunan.Rows.Count Then
                        Exit For
                    End If

                    Dim POLICY_NUMBER As Integer = IIf(IsDBNull(DT_Read_File_Excel_Premi_Tahunan.Rows(i).Item("POLIS")), 0, DT_Read_File_Excel_Premi_Tahunan.Rows(i).Item("POLIS"))
                    Dim PREMI_TAHUNAN As Double = IIf(IsDBNull(DT_Read_File_Excel_Premi_Tahunan.Rows(i).Item("PREMI TAHUNAN")), 0, DT_Read_File_Excel_Premi_Tahunan.Rows(i).Item("PREMI TAHUNAN"))

                    DT = Obj_Select.sp_get_detail_premi_tahunan(POLICY_NUMBER)

                    If DT.Rows.Count > 0 Then

                        Success_Insert += 1

                        Obj_Insert.f_Insert_Data_Premi_Tahunan(POLICY_NUMBER, PREMI_TAHUNAN)
                        LblSukses.Text = "Status Information Upload"
                        LblGagal.Text = "Data premi tahunan untuk nomor polis : " & POLICY_NUMBER & " berhasil diupdate"

                        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "alert('Data premi tahunan berhasil diupdate !');", True)

                        'GridView_Data_Premi_Tahunan.DataSource = DT_Bind_Upload_Excel_Premi_Tahunan
                        'GridView_Data_Premi_Tahunan.DataBind()
                    End If

                Catch ex As Exception
                    ex.Message.ToString()
                    Throw
                    'Exit Sub
                End Try
            Next

            File.Delete(Excel_Path)

        Catch ex As Exception
            ex.Message.ToString()
            Throw
            Exit Sub
        End Try
    End Sub

    Protected Sub Upload_Data_Premi_Tahunan()
        btn_result.Visible = False
        If Not txtUpload.HasFile Then
            ' Handle file
            Modul.UserMsgBox(Me, "File Can't Empty !!")
            Exit Sub
        End If

        Dim Excel_Path As String = Server.MapPath("~/Form/") + Path.GetFileName(txtUpload.PostedFile.FileName)
        Dim File_Extention As String = Path.GetExtension(txtUpload.PostedFile.FileName)
        txtUpload.SaveAs(Excel_Path)


        'Upload_File_Excel(file_excel)
        If (txtUpload.HasFile AndAlso IO.Path.GetExtension(txtUpload.FileName) = ".xlsx") Then
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial
            Using excel = New ExcelPackage(txtUpload.PostedFile.InputStream)
                'POLICY_NO	PREMI_TAHUNAN
                dt_Result = New DataTable
                dt_Result.Columns.Add("POLICY_NO")
                dt_Result.Columns.Add("PREMI_TAHUNAN")
                dt_Result.Columns.Add("Status")
                dt_Result.Columns.Add("Error_Message")
                Dim nSukses As Integer = 0
                Dim nGagal As Integer = 0
                Dim tbl = New DataTable()
                Dim ws = excel.Workbook.Worksheets.First()
                Dim hasHeader = True ' change it if required '
                ' create DataColumns '
                For Each firstRowCell In ws.Cells(1, 1, 1, ws.Dimension.End.Column)
                    tbl.Columns.Add(If(hasHeader,
                                       firstRowCell.Text,
                                       String.Format("Column {0}", firstRowCell.Start.Column)))
                Next
                ' add rows to DataTable '
                Dim startRow = If(hasHeader, 2, 1)
                For rowNum = startRow To ws.Dimension.End.Row
                    Dim wsRow = ws.Cells(rowNum, 1, rowNum, ws.Dimension.End.Column)
                    Dim row = tbl.NewRow()
                    For Each cell In wsRow
                        row(cell.Start.Column - 1) = cell.Text
                    Next
                    tbl.Rows.Add(row)
                Next
                'No Polis	Tanggal Tagihan	Remark

                Dim lstColumn As New List(Of String)
                lstColumn.Add("POLICY_NO")
                lstColumn.Add("PREMI_TAHUNAN")

                Dim iColumnCheck As Integer = 0
                If (hasHeader = True And tbl.Rows.Count() > 0) Then
                    ' check column 
                    If (tbl.Columns.Count = lstColumn.Count) Then

                        Dim iColumnIndex As Integer = 0
                        For Each Column As DataColumn In tbl.Columns
                            Dim strTblColumnName As String = Column.ColumnName.Trim.ToLower
                            Dim strLstColumnName As String = lstColumn.Item(iColumnIndex).Trim.ToLower
                            If (strTblColumnName.Equals(strLstColumnName)) Then
                                iColumnCheck = iColumnCheck + 1
                            End If
                            iColumnIndex = iColumnIndex + 1
                        Next
                    End If
                End If
                Dim hasError As Boolean = False
                If (iColumnCheck = tbl.Columns.Count) Then
                    Dim iRowsUpdate As Integer = 0

                    For Each Row As DataRow In tbl.Rows
                        Try
                            Dim POLICY_NUMBER As Integer = IIf(IsDBNull(Row.Item("POLICY_NO")), 0, IIf(Row.Item("POLICY_NO").ToString.Length = 0, 0, Row.Item("POLICY_NO")))
                            Dim PREMI_TAHUNAN As Double = IIf(IsDBNull(Row.Item("PREMI_TAHUNAN")), 0, IIf(Row.Item("PREMI_TAHUNAN").ToString.Length = 0, 0, Row.Item("PREMI_TAHUNAN")))
                            Dim iRet As Integer = 0
                            iRet = Obj_Insert.f_Insert_Data_Premi_Tahunan(POLICY_NUMBER, PREMI_TAHUNAN)
                            If (iRet > 0) Then
                                nSukses += 1
                                'add into dt_Result as sukses
                                dt_Result.Rows.Add(POLICY_NUMBER, PREMI_TAHUNAN, "Sukses", "")
                            Else
                                nGagal += 1
                                'add into dt_Result as gagal
                                dt_Result.Rows.Add(POLICY_NUMBER, PREMI_TAHUNAN, "Gagal", "Tidak ada data di [Tbl_Premi] dan [Tbl_EC] dengan [POLICY_NUMBER]/[POLICY_NO] ini.")
                            End If
                        Catch ex As Exception
                            'add into dt_Result as gagal
                            dt_Result.Rows.Add(IIf(IsDBNull(Row.Item("POLICY_NO")), 0, IIf(Row.Item("POLICY_NO").ToString.Length = 0, 0, Row.Item("POLICY_NO"))),
                                                 IIf(IsDBNull(Row.Item("PREMI_TAHUNAN")), 0, IIf(Row.Item("PREMI_TAHUNAN").ToString.Length = 0, 0, Row.Item("PREMI_TAHUNAN"))),
                                               "Gagal", ex.Message.ToString)
                        End Try
                        iRowsUpdate = iRowsUpdate + 1
                    Next

                Else
                    Modul.UserMsgBox(Me, "File Excel Columns not match.")
                    'Dim msg = String.Format("Update fail created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3}",
                    'tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count)
                    'UploadStatusLabel.Text = msg
                End If
                nGagal = tbl.Rows.Count - nSukses
                'Label_Status.Text = "Status Information Upload"
                LblSukses.Text = nSukses.ToString & " Record"
                LblGagal.Text = nGagal.ToString & " Record"
                If IsDBNull(dt_Result) = False Then

                    If dt_Result.Rows.Count > 1 Then
                        Session.Add("dt_Result_premi_tahunan", dt_Result)
                        btn_result.Visible = True
                    End If

                End If

                tbl = Nothing
            End Using

        Else
            If (txtUpload.HasFile) Then
                ' Handle file
                Modul.UserMsgBox(Me, "File Excel must with extension .xlsx only !!")
                Exit Sub
            Else
                ' Handle file
                Modul.UserMsgBox(Me, "File Upload Can't Empty !!")
                Exit Sub
            End If
        End If

        File.Delete(Excel_Path)


    End Sub

    Protected Sub Btn_Cancel_Save_Click(sender As Object, e As EventArgs)
        Try
            'Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "alert('Batal upload !');", True)
            Response.Redirect("~/Form/UploadPremiTahunan.aspx", False)
        Catch ex As Exception
            ex.Message.ToString()
            Throw
        Finally

        End Try
    End Sub

    Protected Sub Btn_Template_Click(sender As Object, e As EventArgs) Handles Btn_Template.Click
        Try
            Dim sPath As String = Server.MapPath("~\TemplateFiles\")
            Response.Clear()
            Response.Charset = ""
            Response.ContentEncoding = System.Text.Encoding.UTF8
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;filename=Template_Premi_Tahunan_" + Now.ToString("yyyyMMdd_HHmmss") + ".xlsx")
            'Response.AppendHeader("Content-Disposition", "attachment;filename=Template_Premi_Tahunan.xlsx")
            Response.TransmitFile(sPath & "Template_Premi_Tahunan.xlsx")
            Response.Flush()
            Response.End()

        Catch ex As Exception
        End Try
    End Sub

    Protected Sub btn_result_Click(sender As Object, e As EventArgs) Handles btn_result.Click
        Try
            Dim dt_Result = New DataTable
            dt_Result = TryCast(Session("dt_Result_premi_tahunan"), DataTable)
            If IsDBNull(dt_Result) = False Then

                If dt_Result.Rows.Count > 1 Then

                    Response.Clear()
                    Response.Charset = ""
                    Response.ContentEncoding = System.Text.Encoding.UTF8
                    Response.Cache.SetCacheability(HttpCacheability.NoCache)
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    Response.AddHeader("content-disposition", "attachment;filename=Upload_Premi_Tahunan_Result_" + Now.ToString("yyyy_MM_dd") + ".xlsx")

                    Using package = New ExcelPackage()
                        Dim ws As ExcelWorksheet =
                        package.Workbook.Worksheets.Add("Upload_Premi_Tahunan_Result")
                        ws.Cells("A1").LoadFromDataTable(dt_Result, True)
                        'Adding style to the header
                        ws.Row(1).Height = 20
                        Dim headerRowStyle = ws.Row(1).Style
                        headerRowStyle.Font.Bold = True
                        headerRowStyle.Font.Color.SetColor(System.Drawing.Color.Black)
                        ws.Row(1).Style.ShrinkToFit = False
                        ws.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws.Cells(ws.Dimension.Address).AutoFitColumns()

                        Using MS As New System.IO.MemoryStream()
                            package.SaveAs(MS)
                            MS.WriteTo(Response.OutputStream)
                        End Using
                    End Using
                    Response.Flush()
                    Response.End()

                End If

            End If
        Catch ex As Exception

        End Try
    End Sub
End Class