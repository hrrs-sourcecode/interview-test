﻿Imports System.Data.SqlClient
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Web
Imports System.IO

Partial Public Class ReturnPaymentReport
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim ClaimNum As String = Request.QueryString("code")
                Response.ClearContent()
                Response.ContentType = "application/pdf"
                Response.AddHeader("Content-Disposition", "inline; filename=" + "xyz")
                Response.BinaryWrite(ToByteArray(GenerateWordDoc(ClaimNum)))
                Response.End()
            Catch ex As Exception
                DebugLogger.WriteLogStamp(ex.Message)
                DebugLogger.WriteLogStamp(ex.StackTrace)
            End Try
        End If
    End Sub

    Private Function ToByteArray(ByVal stream As Stream) As Byte()
        stream.Position = 0
        Dim buffer(stream.Length) As Byte
        For totalBytesCopied As Integer = 0 To stream.Length - 1
            totalBytesCopied += stream.Read(buffer, totalBytesCopied, stream.Length - totalBytesCopied)
        Next

        Return buffer
    End Function
    Private Function GenerateWordDoc(ByVal CLAIMNUM As String) As Stream
        Dim crystalReport As New ReportDocument()
        Dim result As Stream
        Dim username As String = ConfigurationManager.AppSettings("username").ToString
        Dim password As String = ConfigurationManager.AppSettings("password").ToString

        crystalReport.Load(Server.MapPath("~/Report/return_payment.rpt"))
        crystalReport.SetParameterValue(0, CLAIMNUM)
        crystalReport.SetDatabaseLogon(username, password)
        result = crystalReport.ExportToStream(ExportFormatType.PortableDocFormat)

        Return result

    End Function

End Class