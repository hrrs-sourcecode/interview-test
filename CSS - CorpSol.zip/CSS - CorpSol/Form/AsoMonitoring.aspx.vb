﻿Imports System.IO
Imports System.Net.Mail
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports iTextSharp.text.pdf

Partial Public Class AsoMonitoring
    Inherits System.Web.UI.Page

    Dim SQL, SQL1, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Dim Dt_GridGER As New System.Data.DataTable
    Dim Obj_Insert As New InsertBase
    'Dim CrystalReportViewer1 As New CrystalReportViewer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If

            BindGrid(txtAccNo.Text.Trim, txtAccName.Text.Trim, txtPolisNo.Text.Trim, txtCompanyNo.Text.Trim, txtCompanyName.Text.Trim)
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If

        End If

    End Sub

    Protected Sub OnPaging(ByVal sender As Object, ByVal e As GridViewPageEventArgs) Handles GridGER.PageIndexChanging
        GridGER.PageIndex = e.NewPageIndex
        BindGrid(txtAccNo.Text.Trim, txtAccName.Text.Trim, txtPolisNo.Text.Trim, txtCompanyNo.Text.Trim, txtCompanyName.Text.Trim)
    End Sub

    Public Sub BindGrid(ByVal AccNo As String, ByVal AccName As String, ByVal PolicyNo As String, ByVal CompanyNo As String, ByVal CompanyName As String)
        Try
            Dim dt_Grid_GER As New DataTable

			SQL = String.Format("[sp_GetAsoMonitoringHeader] '{0}','{1}','{2}','{3}','{4}'", PolicyNo, CompanyNo, CompanyName, AccNo, AccName)

			dt_Grid_GER = Modul.getAllDatainDT(SQL)

            GridGER.DataSource = dt_Grid_GER
            GridGER.DataBind()

            lblTotRow.Text = dt_Grid_GER.Rows.Count.ToString()


        Catch ex As Exception
            DebugLogger.WriteLogStamp(ex.Message)
            DebugLogger.WriteLogStamp(ex.StackTrace)
            Modul.UserMsgBox(Me, ex.Message.ToString)
        End Try
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click
        BindGrid(txtAccNo.Text.Trim, txtAccName.Text.Trim, txtPolisNo.Text.Trim, txtCompanyNo.Text.Trim, txtCompanyName.Text.Trim)
    End Sub

    Protected Sub ddl_Page_Size_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl_Page_Size.SelectedIndexChanged
        GridGER.PageSize = Convert.ToInt32(ddl_Page_Size.SelectedValue)
        BindGrid(txtAccNo.Text.Trim, txtAccName.Text.Trim, txtPolisNo.Text.Trim, txtCompanyNo.Text.Trim, txtCompanyName.Text.Trim)
    End Sub

End Class