﻿Imports System.IO
Imports System.Windows.Forms
Imports ClosedXML.Excel

Partial Public Class AsoMonitoringDetail
    Inherits System.Web.UI.Page

    Dim SQL, SQL1 As String

    Dim Modul As New ClassModul
    Dim dt As New System.Data.DataTable


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim AccNo As String = Request.QueryString("code")
                BindInfo(AccNo)
            Catch ex As Exception
                DebugLogger.WriteLogStamp(ex.Message)
                DebugLogger.WriteLogStamp(ex.StackTrace)
            End Try
        End If

    End Sub

    Public Sub BindInfo(ByVal AccNo As String)
        Dim dtTbl As New DataTable
        Dim dtDdl As New DataTable
        Dim benefit As String = ""

        SQL = "select 
	                aa.ACCOUNT_NO AccNo,
                    aa.POLICY_NUMBER PolicyNo,
	                aa.ACCOUNT_NAME AccName,
	                case 
		                when aa.CompanyNo is null then aa.ACCOUNT_NO
		                else aa.ACCOUNT_NO
	                end CompanyNo,
	                case 
		                when aa.CompanyName is null then aa.ACCOUNT_NAME
		                else aa.ACCOUNT_NAME
	                end CompanyName,
	                bnf.Benefit
                from 
	                 (select 
	                 ROW_NUMBER() over (partition by xx.ACCOUNT_NO order by xx.ct desc) rn, 
	                 xx.*
	                 from
		                (select 
			                count(*) ct, ACCOUNT_NAME, ACCOUNT_NO, POLICY_NUMBER, ASO.COWNNUM CompanyNo, ASO.COWNNAME CompanyName
		                 from 
			                Tbl_Premi pr left join 
			                (select distinct COWNNUM, COWNNAME, CHDRNUM, SUBSCODE, SUBSNAME from ASO) aso on pr.ACCOUNT_NO = aso.SUBSCODE 		
		                 where pr.ACCOUNT_NO is not null group by ACCOUNT_NAME, ACCOUNT_NO, POLICY_NUMBER, COWNNUM, COWNNAME) xx) aa left join AsoAccountBenefit bnf on (bnf.AccNo = aa.ACCOUNT_NO)
	                 where aa.rn = 1"

        If Not String.IsNullOrEmpty(AccNo) Then
            SQL += String.Format(" and aa.ACCOUNT_NO = '{0}'", AccNo)
        End If

        dtTbl = Modul.getAllDatainDT(SQL)

        hdAccNo.Value = dtTbl.Rows(0).Item("AccNo")
        hdAccName.Value = dtTbl.Rows(0).Item("AccName")
        txtAccNo.Text = dtTbl.Rows(0).Item("AccNo")
        txtAccName.Text = dtTbl.Rows(0).Item("AccName")
        txtPolicyNo.Text = dtTbl.Rows(0).Item("PolicyNo")
        txtCompanyNo.Text = dtTbl.Rows(0).Item("CompanyNo")
        txtCompanyName.Text = dtTbl.Rows(0).Item("CompanyName")
        benefit = dtTbl.Rows(0).Item("Benefit").ToString()

        If (Not String.IsNullOrEmpty(benefit)) Then
            For Each item In benefit.Split(",")
                If item = "DEN1" Then
                    cbDEN1.Checked = True
                End If

                If item = "MAT1" Then
                    cbMAT1.Checked = True
                End If

                If item = "MCU1" Then
                    cbMCU1.Checked = True
                End If

                If item = "OPD1" Then
                    cbOPD1.Checked = True
                End If

                If item = "OTD1" Then
                    cbOTD1.Checked = True
                End If
            Next
        End If

        SQL = String.Format(
         "select 
	        distinct
	        case 
		        when POLPERIOD is null then FORMAT (effdt, 'dd/MM/yyyy ') + ' - ' + FORMAT (DATEADD( DAY, -1,DATEADD(year,1,effdt)), 'dd/MM/yyyy')  
		        else POLPERIOD
	        end POLPERIOD,
	        ACCOUNT_NO 
        from 
	        ((select distinct POLICY_EFFECTIVE_DATE effdt, ACCOUNT_NO from Tbl_Premi where ACCOUNT_NO is not null and ASO > 0) pr
	        left join (SELECT DISTINCT POLPERIOD, SUBSCODE FROM ASO) aso on pr.ACCOUNT_NO = aso.SUBSCODE)
        where ACCOUNT_NO = '{0}'
        order by POLPERIOD desc ", AccNo)

        dtDdl = Modul.getAllDatainDT(SQL)

        ddlPolPeriod.DataSource = dtDdl
        ddlPolPeriod.DataTextField = "POLPERIOD"
        ddlPolPeriod.DataValueField = "POLPERIOD"

        ddlPolPeriod.DataBind()

    End Sub

    Protected Sub btnGenerate_Click(sender As Object, e As EventArgs)

        Dim path As String = CreateExcelReport(hdAccNo.Value.ToString())
        Dim content = File.ReadAllBytes(path)
        Dim polPeriod As String = ddlPolPeriod.SelectedValue.Replace(" - ", "_to_").Replace("/", "-")

        If (Not String.IsNullOrEmpty(txtDateFrom.Text) And Not String.IsNullOrEmpty(txtDateTo.Text)) Then
            polPeriod = CDate(txtDateFrom.Text).ToString("dd-MM-yyyy") + "_to_" + CDate(txtDateTo.Text).ToString("dd-MM-yyyy")
        End If

        Response.ClearContent()
        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        Response.AddHeader("Content-Disposition", String.Format("inline; filename=ASOMonitoringReport_{0}_{1}.xlsx", hdAccNo.Value.ToString(), polPeriod))

        Using ms As MemoryStream = New MemoryStream()
            Response.OutputStream.Write(content, 0, content.Length)
            ms.WriteTo(Response.OutputStream)
            Response.Flush()
        End Using

        If File.Exists(path) Then
            File.Delete(path)
        End If

        Response.End()
    End Sub

    Private Function CreateExcelReport(ByVal AccNo As String) As String
        Dim dateFrom As String = txtDateFrom.Text
        Dim dateTo As String = txtDateTo.Text
        Dim polPeriod As String = ddlPolPeriod.SelectedValue
        Dim accName As String = hdAccName.Value

        Dim startPeriod As String = polPeriod.Split("-")(0).Trim().Split("/")(1) + "/" + polPeriod.Split("-")(0).Trim().Split("/")(0) + "/" + polPeriod.Split("-")(0).Trim().Split("/")(2)
        Dim endPeriod As String = polPeriod.Split("-")(1).Trim().Split("/")(1) + "/" + polPeriod.Split("-")(1).Trim().Split("/")(0) + "/" + polPeriod.Split("-")(1).Trim().Split("/")(2)

        dateFrom = startPeriod
        dateTo = (If(String.IsNullOrEmpty(dateTo), "", dateTo))

        Dim dtAso As DataTable = PopulateDataAso(AccNo, accName, dateFrom, dateTo, polPeriod)

        Dim dtTopUp As New DataTable()
        dtTopUp = PopulateDataTopUp(AccNo, startPeriod, endPeriod)

        Dim folderPath As String = System.Web.Hosting.HostingEnvironment.MapPath("~/TempFile")
        Dim pathLoc As String = String.Format("{0}\Excel-ASOMonitoring-{1}.xlsx", folderPath, Guid.NewGuid().ToString())
        Dim fileInfo As FileInfo = New FileInfo(pathLoc)
        fileInfo.Directory.Create()

        Using wb As XLWorkbook = New XLWorkbook()
            Dim dtRptMin As DateTime = dtAso.AsEnumerable().Select(Function(f) f.Field(Of DateTime)("APPROVDTE")).OrderBy(Function(x) x.Ticks).FirstOrDefault()
            Dim dtRptMax As DateTime = dtAso.AsEnumerable().Select(Function(f) f.Field(Of DateTime)("APPROVDTE")).OrderByDescending(Function(x) x.Ticks).FirstOrDefault()
            Dim dtInitPrem As Decimal = (If(dtTopUp.Rows.Count = 0, 0, CDec(dtTopUp.AsEnumerable().Select(Function(f) f.Field(Of Double)("TopUpAmt")).First())))
            Dim dtInitPremDate As String = (If(dtTopUp.Rows.Count = 0, "", dtTopUp.AsEnumerable().Select(Function(f) f.Field(Of DateTime)("TransDate")).First().ToString("dd-MM-yyyy")))

            If (dtTopUp.Rows.Count > 0) Then
                Dim cloneDt As DataTable = dtTopUp.Clone()
                cloneDt.ImportRow(dtTopUp(0))
                Dim rowInitPrem As DataRow = cloneDt.Rows(0)

                dtTopUp.Rows.RemoveAt(0)
            End If

            Dim ws = wb.Worksheets.Add(dtAso, "Summary")
            AddCalculation(ws, "Summary", "", dtTopUp, dtInitPrem, dtInitPremDate)

            Dim prevAddrOutstanding As String = ""

            Dim i As Integer = 0
            If dtAso.Rows.Count > 0 Then
                While (CDate(dtRptMax.AddMonths(1).ToString("MM-01-yyyy")) > CDate(dtRptMin.AddMonths(i).ToString("MM-01-yyyy")))
                    Dim wsTitle As String = dtRptMin.AddMonths(i).ToString("MMM_yyyy")
                    Dim dtAsoSplit As DataTable = dtAso.Clone()
                    For Each rw In dtAso.AsEnumerable().Where(Function(f) f.Field(Of DateTime)("APPROVDTE").ToString("MMM_yyyy") = wsTitle)
                        dtAsoSplit.ImportRow(rw)
                    Next

                    Dim dtTopUpSplit As DataTable = dtTopUp.Clone()
                    For Each rw In dtTopUp.AsEnumerable().Where(Function(f) f.Field(Of DateTime)("TransDate").ToString("MMM_yyyy") = wsTitle)
                        dtTopUpSplit.ImportRow(rw)
                    Next

                    ws = wb.Worksheets.Add(dtAsoSplit, wsTitle)
                    ws.Position = 2
                    prevAddrOutstanding = AddCalculation(ws, wsTitle, prevAddrOutstanding, dtTopUpSplit, dtInitPrem, dtInitPremDate)
                    i = i + 1
                End While
            End If

            wb.SaveAs(pathLoc)
        End Using

        Return pathLoc
    End Function

    Private Function AddCalculation(ws As IXLWorksheet,
                                    ByVal sheetName As String,
                                    ByVal prevaddrOutstanding As String,
                                    ByVal dtTopUp As DataTable,
                                    ByVal dtInitPrem As Decimal,
                                    ByVal dtInitPremDate As String) As String
        Dim addrCover As String = ""
        Dim addrTtlDepo As String = ""
        Dim addrInitial As String = ""
        Dim addrAfterInitial As String = ""
        Dim addrOutstanding As String = ""
        Dim addrPrevOutstanding As String = ""
        Dim addrKuota As String = ""
        Dim rowNum As Int16 = 0

        ws.Column("J").Style.NumberFormat.Format = " #,##0.00"
        ws.Column("K").Style.NumberFormat.Format = " #,##0.00"
        ws.Column("L").Style.NumberFormat.Format = " #,##0.00"

        Dim row As IXLRow = ws.LastRowUsed().RowBelow(2)
        row.Cell("I").Value = "Total Claim : "
        row.Cell("J").SetFormulaR1C1(String.Format("=SUM({0}[Incurred])", sheetName))
        row.Cell("K").SetFormulaR1C1(String.Format("=SUM({0}[Cover])", sheetName))
        row.Cell("L").SetFormulaR1C1(String.Format("=SUM({0}[Unpaid])", sheetName))
        'row.Cell("K").SetFormulaR1C1("=SUM(Summary[Cover])")

        'row.Cell("L").SetFormulaR1C1("=SUM(Summary[Unpaid])")
        row.Cells("10:12").Style.Border.BottomBorder = XLBorderStyleValues.Double
        addrCover = "K" + row.RowNumber.ToString()
        StylingExcelRow(row)

        row = ws.LastRowUsed().RowBelow(2)
        row.Cell("I").Value = "Update per Tanggal : "
        row.Cell("J").Value = "'" + DateTime.Now.ToString("dd-MMM-yy")
        StylingExcelRow(row)

        row = ws.LastRowUsed().RowBelow(2)
        row.Cell("I").Value = String.Format("PREMI INITIAL ({0}) : ", dtInitPremDate)
        row.Cell("J").Value = dtInitPrem
        row.Cell("J").Style.NumberFormat.Format = " #,##0.00"
        addrInitial = "J" + row.RowNumber.ToString()
        addrPrevOutstanding = "J" + row.RowNumber.ToString()
        addrAfterInitial = "J" + (row.RowNumber + 1).ToString()
        StylingExcelRow(row)

        For Each rw In dtTopUp.Rows
            row = ws.LastRowUsed().RowBelow(1)
            row.Cell("I").Value = String.Format("Penambahan Deposit ({0}) : ", CDate(rw("TransDate")).ToString("dd-MM-yyyy"))
            row.Cell("J").Value = rw("TopUpAmt")
            row.Cell("J").Style.NumberFormat.Format = " #,##0.00"
            StylingExcelRow(row)
        Next

        If (Not String.IsNullOrEmpty(prevaddrOutstanding)) Then
            row = ws.LastRowUsed().RowBelow(1)
            row.Cell("H").Value = "Total Sisa Deposit Setelah Tagihan Sebelumnya : "
            ws.Range(String.Format("H{0}:I{0}", row.RowNumber.ToString())).Merge()

            row.Cell("J").SetFormulaR1C1(String.Format("={0}", prevaddrOutstanding))
            addrPrevOutstanding = "J" + row.RowNumber.ToString()
            StylingExcelRow(row)
        End If

        row = ws.LastRowUsed().RowBelow(2)
        row.Cell("I").Value = "Total Deposit : "

        'Sum deposit + prevOutstanding 
        row.Cell("K").SetFormulaR1C1(String.Format("=SUM({0}:{1})", addrPrevOutstanding, addrAfterInitial))
        row.Cell("K").Style.Border.BottomBorder = XLBorderStyleValues.Double
        addrTtlDepo = "K" + row.RowNumber.ToString()
        StylingExcelRow(row)

        row = ws.LastRowUsed().RowBelow(2)
        row.Cell("I").Value = "Sisa Deposit : "
        row.Cell("K").SetFormulaR1C1(String.Format("={0}-{1}", addrTtlDepo, addrCover))
        row.Cell("K").Style.Font.SetUnderline()
        row.Cell("K").Style.Fill.BackgroundColor = XLColor.Yellow
        row.Cell("K").Style.Font.FontColor = XLColor.Red
        addrOutstanding = "K" + ws.LastRowUsed().RowNumber.ToString()
        StylingExcelRow(row)

        row = ws.LastRowUsed().RowBelow(2)
        row.Cell("I").Value = "Maks. Quota Sisa Penagihan 60% : "
        row.Cell("J").SetFormulaR1C1(String.Format("={0}*60%", addrInitial))
        addrKuota = "J" + row.RowNumber.ToString()
        StylingExcelRow(row)

        ws.LastRowUsed().Cell("K").Value = "(Ditagihkan jika Deposit EC sudah sampai sejumlah disamping)"
        ws.Range(String.Format("K{0}:O{0}", row.RowNumber.ToString())).Merge().Style().Alignment.Horizontal = XLAlignmentHorizontalValues.Center

        row = ws.LastRowUsed().RowBelow(2)
        row.Cell("I").Value = "NB : "
        rowNum = row.RowNumber
        StylingExcelRow(row)

        ws.Range(String.Format("I{0}:I{1}", rowNum.ToString(), rowNum + 1.ToString())).Merge().Style().Alignment.Vertical = XLAlignmentVerticalValues.Center
        ws.LastRowUsed().Cell("J").SetFormulaR1C1(String.Format("=IF({0}>={1},""Belum Mencapai Limit Tagih"",""Sudah Mencapai Limit Tagih"")", addrOutstanding, addrKuota))
        ws.Range(String.Format("J{0}:K{1}", rowNum.ToString(), rowNum + 1.ToString())).Merge().Style().Alignment.Vertical = XLAlignmentVerticalValues.Center
        ws.LastRowUsed().Cell("J").Style.Fill.BackgroundColor = XLColor.Red
        ws.LastRowUsed().Cell("J").Style.Font.FontColor = XLColor.White
        ws.LastRowUsed().Cell("J").Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center
        ws.Columns().AdjustToContents()

        'Dim x As Int32 = CInt(ws.Cell(addrOutstanding).GetString())
        Return String.Format("={0}!{1}", sheetName, addrOutstanding)
    End Function

    Private Sub StylingExcelRow(er As IXLRow)
        er.Style.Font.Bold = True
        er.Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Right)
    End Sub

    Private Function PopulateDataAso(ByVal AccNo As String, ByVal AccName As String, ByVal DateFr As String, ByVal DateTo As String, ByVal PolPeriod As String) As DataTable
        Dim dtTbl As New DataTable()

        Dim param As String = ""

        SQL = String.Format("[sp_GetAsoMonitoringDetail] '{0}','{1}','{2}','{3}'", AccNo, PolPeriod, DateFr, DateTo)

        dtTbl = Modul.getAllDatainDT(SQL)

        Return dtTbl
    End Function

    Protected Sub btnUpdateBenefit_Click(sender As Object, e As EventArgs)
        Dim accNo As String = hdAccNo.Value
        Dim accName As String = hdAccName.Value
        Dim benefit As String = ""
        Dim userName As String = Session("UserName")

        If cbDEN1.Checked Then
            benefit += "DEN1"
        End If

        If cbMAT1.Checked Then
            If Not String.IsNullOrEmpty(benefit) Then
                benefit += ","
            End If
            benefit += "MAT1"
        End If

        If cbMCU1.Checked Then
            If Not String.IsNullOrEmpty(benefit) Then
                benefit += ","
            End If
            benefit += "MCU1"
        End If

        If cbOPD1.Checked Then
            If Not String.IsNullOrEmpty(benefit) Then
                benefit += ","
            End If
            benefit += "OPD1"
        End If

        If cbOTD1.Checked Then
            If Not String.IsNullOrEmpty(benefit) Then
                benefit += ","
            End If
            benefit += "OTD1"
        End If

        Dim dt As DataTable = Modul.getAllDatainDT(String.Format("select top(1) Id from AsoAccountBenefit where AccNo = '{0}'", accNo))

        If (dt.Rows.Count = 0) Then
            If Not String.IsNullOrEmpty(benefit) Then
                Modul.Eksekusi(String.Format("insert into AsoAccountBenefit values ('{0}','{1}','{2}','{3}',GETDATE(),'',NULL )", accNo, accName, benefit, userName))
            End If
        Else
            If Not String.IsNullOrEmpty(benefit) Then
                Modul.Eksekusi(String.Format("update AsoAccountBenefit set Benefit = '{0}', ModifiedBy = '{1}', ModifiedDate = GETDATE()  where AccNo = '{2}' ", benefit, userName, accNo, accName))
            Else
                Modul.Eksekusi(String.Format("delete from AsoAccountBenefit where AccNo = '{0}' ", accNo))
            End If
        End If

    End Sub

    Private Function PopulateDataTopUp(ByVal AccNo As String, ByVal DateFrom As String, ByVal DateTo As String) As DataTable
        Dim dtTbl As New DataTable()
        'SQL = String.Format("
        '            select 
        '             pr.TGL_BAYAR TransDate,	
        '             pr.ACCOUNT_NAME,
        '             pr.POLICY_NUMBER,
        '             pr.ASO TopUpAmt
        '            from 
        '             Tbl_Premi pr,
        '             (select 
        '              distinct
        '              case 
        '               when GETDATE() > POLICY_EFFECTIVE_DATE then DATEADD(YEAR, DATEDIFF(year,POLICY_EFFECTIVE_DATE,GETDATE())  ,POLICY_EFFECTIVE_DATE)
        '               else POLICY_EFFECTIVE_DATE
        '              end effdt, 
        '              POLICY_NUMBER
        '             from Tbl_Premi 
        '             where 
        '              ASO > 0 and 
        '              PAID > 0) xx
        '            where 
        '             ACCOUNT_NAME ='{0}' 
        '                and xx.POLICY_NUMBER = pr.POLICY_NUMBER 
        '                and pr.TGL_BAYAR >= xx.effdt 
        '                and ASO > 0 
        '                and PAID > 0 
        '            order by ID_Premi asc", AccNo)

        SQL = String.Format("
                    select 
	                    case 
		                    when (FORMAT(DATEADD(DAY, -1, POLICY_EFFECTIVE_DATE), 'dd-MM')  = FORMAT(TGL_BAYAR,'dd-MM') and TGL_BAYAR3 is not null) then TGL_BAYAR3
		                    else TGL_BAYAR
	                    end TransDate,		
	                    pr.ACCOUNT_NAME,
	                    pr.POLICY_NUMBER,
	                    pr.ASO TopUpAmt
                    from 
	                    Tbl_Premi pr
                    where 
	                    ACCOUNT_NO ='{0}'
                        and pr.TGL_BAYAR between CONVERT(datetime, '{1}') and CONVERT(datetime, '{2}')
                        and ASO > 0 
                        and PAID > 0 
                    order by ID_Premi asc", AccNo, DateFrom, DateTo)

        dtTbl = Modul.getAllDatainDT(SQL)

        Return dtTbl
    End Function

End Class