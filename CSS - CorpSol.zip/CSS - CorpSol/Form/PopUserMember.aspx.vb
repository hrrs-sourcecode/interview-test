﻿Imports System.Data.SqlClient
Partial Public Class PopUserMember
    Inherits System.Web.UI.Page

    Dim Dt As New DataTable
    Dim SQL, x1v9oText As String
    Dim strValue() As String
    Dim Modul As New ClassModul
    Dim submitter As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            x1v9o.Text = Request.QueryString("x1v9o")
            txtPhase.Text = "1"

            If Not Request.QueryString("Phase") Is Nothing Then
                txtPhase.Text = Request.QueryString("Phase")
            End If

            cmdFind_Click(cmdFind, e)
            Me.Focus()
        End If
    End Sub

    Protected Sub cmdFind_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdFind.Click
        SQL = "SELECT dco_Name, dco_Email " & _
              "FROM Mst_UserApp " & _
              "WHERE dco_Name LIKE '%" & txtName.Text & "%' "

        SQL &= "ORDER BY " & hiddenSort.Value
        Modul.SubBindGrid(SQL, DgGrid)
    End Sub
    Private Sub DgGrid_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DgGrid.ItemCommand
        If e.CommandName = "cmdSelect" Then
            Response.Write("<script type='text/javascript'>")
            Response.Write("window.opener.location='UserAccess.aspx?x1v9o=" + Modul.base64Encode(x1v9o.Text) + "';" & vbCrLf)
            'Response.Write("window.opener.location='UserRequest.aspx;" & vbCrLf)
            Response.Write("window.close();")
            Response.Write("</script>")
            Session("txtuser") = DgGrid.Items(e.Item.ItemIndex).Cells(1).Text
        End If
    End Sub
    Private Sub DgGrid_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles DgGrid.PageIndexChanged
        DgGrid.CurrentPageIndex = e.NewPageIndex
        cmdFind_Click(cmdFind, e)
    End Sub
End Class