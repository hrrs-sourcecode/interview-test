﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices
Imports System.Data.OleDb
Imports Microsoft.Office.Interop
Imports System.IO
Partial Public Class ReportECDetail
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim oSelect As New SelectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If
            BindGrid("", "", "", "", "")
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If

            BindGrid(txtPolicyNo.Text.Trim, txtTGLUploadFrom.Text.Trim, txtTGLUploadTo.Text, ddlReason.SelectedValue.ToString, ddlStatus.SelectedValue.ToString)

        End If
    End Sub
    Public Sub BindGrid(ByVal POLICY_NO As String, ByVal TGLUPLOADFROM As String, ByVal TGLUPLOADTO As String, ByVal REASON As String, ByVal STATUS As String)
        Dt = oSelect.sp_Bind_Report_EC_Detail(POLICY_NO, TGLUPLOADFROM, TGLUPLOADTO, REASON, STATUS)
        GridECDetail.DataSource = Dt
        GridECDetail.DataBind()
        lblTotal.Text = Dt.Rows.Count & " Data"
    End Sub

    Protected Sub btnReport_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReport.Click
        Try
            Dim dt_report As New DataTable

            dt_report = oSelect.sp_Create_Report_EC_Detail(txtPolicyNo.Text, txtTGLUploadFrom.Text, txtTGLUploadTo.Text, ddlReason.SelectedValue.ToString, ddlStatus.SelectedValue.ToString)

            If dt_report.Rows.Count > 0 Then
                Dim sFileName As String = ""

                Dim sysdate As Date = Date.Now.Date

                sFileName = "REPORT EC " & Replace(sysdate.ToString("dd/MM/yyyy"), "/", "") & ".xls"

                Dim GridView1 As New GridView()
                GridView1.AllowPaging = False
                GridView1.AllowSorting = False
                GridView1.DataSource = dt_report
                GridView1.DataBind()

                Response.Clear()
                Response.Buffer = True
                Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                Response.Charset = ""
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Me.EnableViewState = False
                Response.ContentType = "application/vnd.ms-excel"
                Dim StringWrite As New System.IO.StringWriter
                Dim HtmlWrite As New System.Web.UI.HtmlTextWriter(StringWrite)

                For Each r As GridViewRow In GridView1.Rows
                    If r.RowType = DataControlRowType.DataRow Then
                        For columnIndex As Integer = 0 To r.Cells.Count - 1
                            r.Cells(columnIndex).Attributes.Add("class", "text")
                        Next
                    End If
                Next

                GridView1.RenderControl(HtmlWrite)

                Response.AddHeader("X-Download-Options", "noopen")

                'Remove the charset from the Content-Type header.
                Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                Response.Write(style)

                Response.Write(StringWrite.ToString())
                Response.End()
            End If

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
    End Sub

    Private Sub GridECDetail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridECDetail.PageIndexChanging
        GridECDetail.PageIndex = e.NewPageIndex
        BindGrid(txtPolicyNo.Text.Trim, txtTGLUploadFrom.Text.Trim, txtTGLUploadTo.Text, ddlReason.SelectedValue.ToString, ddlStatus.SelectedValue.ToString)
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click

    End Sub

    Protected Sub btnReportSummary_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReportSummary.Click
        'GeDataPremiSummary()
        GetDataExcessClaimSummary()
    End Sub
    Private Sub GetDataExcessClaimSummary()

        Try
            Dt = oSelect.sp_Create_Report_Summary_EC_Pivot

            Dim initialCatalogOleDB As String = ConfigurationManager.AppSettings("initialCatalogOleDB").ToString()
            Dim dataSourceOleDB As String = ConfigurationManager.AppSettings("dataSourceOleDB").ToString()
            Dim userIdOleDB As String = ConfigurationManager.AppSettings("userIdOleDB").ToString()
            Dim passOleDB As String = ConfigurationManager.AppSettings("passOleDB").ToString()


            Dim connection As String = "OLEDB;Provider=SQLOLEDB.1;Password=" + passOleDB + _
                                   ";Persist Security Info=True;User ID=" + userIdOleDB + _
                                   ";Initial Catalog=" + initialCatalogOleDB + _
                                   ";Data Source=" + dataSourceOleDB

            Dim command As String = Dt.Rows(0).Item(0).ToString
            Dim app As Excel.Application = New Microsoft.Office.Interop.Excel.Application()
            Dim workbook As Excel.Workbook = CType(app.Workbooks.Add(Type.Missing), Microsoft.Office.Interop.Excel.Workbook)
            Dim sheet As Excel.Worksheet = CType(workbook.ActiveSheet, Microsoft.Office.Interop.Excel.Worksheet)
            Dim range As Excel.Range
            Dim dt_detail As New DataTable

            dt_detail = oSelect.sp_Create_Report_Detail_EC_Pivot()

            range = sheet.Range("B1:B" & dt_detail.Rows.Count + 1)
            range.NumberFormat = "@"



            ' create textfile detail premi
            Dim sb As StringBuilder = New StringBuilder()
            Dim strDelimiter As String = ", "


            ' CREATE HEADER 
            sb.Append("ID_Excess")
            sb.Append(strDelimiter)
            sb.Append("TGL_UPLOAD")
            sb.Append(strDelimiter)
            sb.Append("POLICY_NO")
            sb.Append(strDelimiter)
            sb.Append("COMPANY_NAME")
            sb.Append(strDelimiter)
            sb.Append("PIC_NAME")
            sb.Append(strDelimiter)
            sb.Append("NO_PHONE/HP")
            sb.Append(strDelimiter)
            sb.Append("EMAIL")
            sb.Append(strDelimiter)
            sb.Append("ADDRESS")
            sb.Append(strDelimiter)
            sb.Append("CLAIM_TYPE")
            sb.Append(strDelimiter)
            sb.Append("CLAIM_NO")
            sb.Append(strDelimiter)
            sb.Append("CLAIM_CLIENT_REF_NO")
            sb.Append(strDelimiter)
            sb.Append("MEMBER_NO")
            sb.Append(strDelimiter)
            sb.Append("MEMBER_NAME")
            sb.Append(strDelimiter)
            sb.Append("PETIRNT_NO")
            sb.Append(strDelimiter)
            sb.Append("PATIENT_NAME")
            sb.Append(strDelimiter)
            sb.Append("RECEIVED_DATE")
            sb.Append(strDelimiter)
            sb.Append("Provider")
            sb.Append(strDelimiter)
            sb.Append("ADMISSION_DATE")
            sb.Append(strDelimiter)
            sb.Append("DISCHARGE_DATE")
            sb.Append(strDelimiter)
            sb.Append("BIAYA_PERAWATAN")
            sb.Append(strDelimiter)
            sb.Append("YANG_DITANGGUNG")
            sb.Append(strDelimiter)
            sb.Append("TOTAL_EXCESS")
            sb.Append(strDelimiter)
            sb.Append("TGL_PENAGIHAN_EXCESS")
            sb.Append(strDelimiter)
            sb.Append("TGL_PENAGIHAN_EXCESS2")
            sb.Append(strDelimiter)
            sb.Append("TGL_PENAGIHAN_EXCESS3")
            sb.Append(strDelimiter)
            sb.Append("TGL_BAYAR")
            sb.Append(strDelimiter)
            sb.Append("TGL_BAYAR2")
            sb.Append(strDelimiter)
            sb.Append("TGL_BAYAR3")
            sb.Append(strDelimiter)
            sb.Append("SEQ")
            sb.Append(strDelimiter)
            sb.Append("REMARK_COLLECTION")
            sb.Append(strDelimiter)
            sb.Append("Paid")
            sb.Append(strDelimiter)
            sb.Append("Outstanding")
            sb.Append(strDelimiter)
            sb.Append("Reason")
            sb.Append(strDelimiter)
            sb.Append("Status")
            sb.Append(strDelimiter)
            sb.Append("TGL_PROSES")
            sb.Append(strDelimiter)
            sb.Append("NO_RCL")
            sb.Append(strDelimiter)
            sb.Append("TGL_PENGIRIMAN_HARDCOPY")
            sb.Append(strDelimiter)
            sb.Append("NO_INVOICE")
            sb.Append(strDelimiter)
            sb.Append("STATUS_CLAIM")
            sb.Append(strDelimiter)
            sb.Append("RECEIPT_NO1")
            sb.Append(strDelimiter)
            sb.Append("RECEIPT_NO2")
            sb.Append(strDelimiter)
            sb.Append("RECEIPT_NO3")
            sb.Append(strDelimiter)
            sb.Append("STATUS_POLIS")
            sb.Append(strDelimiter)
            sb.Append("GROUP_NAME")
            sb.Append(strDelimiter)
            sb.Append("Aging_OS")
            sb.Append(strDelimiter)
            sb.Append("Aging Code_OS")
            sb.Append(strDelimiter)
            sb.Append("Aging_Paid")
            sb.Append(strDelimiter)
            sb.Append("Aging Code_Paid")
            sb.Append(strDelimiter)
            sb.Append("TGL_CUT_OFF" + System.Environment.NewLine)


            If dt_detail.Rows.Count > 0 Then

                For Each dr As DataRow In dt_detail.Rows

                    sb.Append(dr("ID_Excess").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_UPLOAD").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("POLICY_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("COMPANY_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("PIC_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("NO_PHONE/HP").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("EMAIL").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("ADDRESS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("CLAIM_TYPE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("CLAIM_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("CLAIM_CLIENT_REF_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("MEMBER_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("MEMBER_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("PETIRNT_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("PATIENT_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("RECEIVED_DATE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Provider").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("ADMISSION_DATE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("DISCHARGE_DATE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("BIAYA_PERAWATAN").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("YANG_DITANGGUNG").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TOTAL_EXCESS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PENAGIHAN_EXCESS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PENAGIHAN_EXCESS2").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PENAGIHAN_EXCESS3").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_BAYAR").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_BAYAR2").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_BAYAR3").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("SEQ").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("REMARK_COLLECTION").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Paid").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Outstanding").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Reason").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Status").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PROSES").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("NO_RCL").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PENGIRIMAN_HARDCOPY").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("NO_INVOICE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("STATUS_CLAIM").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("RECEIPT_NO1").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("RECEIPT_NO2").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("RECEIPT_NO3").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("STATUS_POLIS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("GROUP_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging_OS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging Code_OS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging_Paid").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging Code_Paid").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(DateTime.Now.ToString() + System.Environment.NewLine)

                Next

            End If

            Dim textfileName As String = "datadetailec.txt"
            Dim path = Server.MapPath("~/Report/")

            Dim csvFilename As String = "Report Summary Excess Claim " & Strings.Right(DateTime.Now.Year.ToString, 4).PadLeft(4, "0") & DateTime.Now.Month.ToString.PadLeft(2, "0") & DateTime.Now.Day.ToString.PadLeft(2, "0") & ".csv"
            Dim sAppPath As String = Server.MapPath("~/Report/" + csvFilename)

            'Rename File
            ' IF exist delete excel file
            Dim excelFilename = csvFilename.Replace("csv", "xlsx")


            ' IF exist delete excel detail
            If File.Exists(path + excelFilename) Then
                File.Delete(path + excelFilename)
            End If

            ' IF exist delete csv detail
            If File.Exists(path + csvFilename) Then
                File.Delete(path + csvFilename)
            End If

            ' IF exist delete textfile
            If File.Exists(path + textfileName) Then
                File.Delete(path + textfileName)
            End If


            File.WriteAllText(path + textfileName, sb.ToString())


            range = sheet.Range(sheet.Cells(1, 1), sheet.Cells(dt_detail.Rows.Count + 1, dt_detail.Columns.Count))
            range.EntireColumn.AutoFit()

            Dim border As Microsoft.Office.Interop.Excel.Borders = range.Borders
            border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous


            workbook.SaveAs(sAppPath)
            workbook.Close()
            app.Quit()


            releaseObject(sheet)
            releaseObject(workbook)
            releaseObject(app)


            ' import textfile to sheet excel
            Dim ConnectionString As String

            ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" & _
                               "Data Source=" & sAppPath & ";Extended Properties=""Excel 12.0;HDR=Yes;Format=CSVDelimited"""

            Dim ExcelConnection As New System.Data.OleDb.OleDbConnection(ConnectionString)


            'CREATE SHEET DETAIL
            ExcelConnection.Open()

            Dim SQLString1 As String = "Select * INTO [Detail] FROM [Text;DATABASE=" & path & "].[" & textfileName & "]"

            Dim ExcelCommand1 As New System.Data.OleDb.OleDbCommand(SQLString1, ExcelConnection)
            ExcelCommand1.ExecuteNonQuery()
            ExcelConnection.Close()


            File.Copy(path + csvFilename, path + excelFilename)


            ' IF exist delete csv detail
            If File.Exists(path + csvFilename) Then
                File.Delete(path + csvFilename)
            End If

            ' IF exist delete textfile
            If File.Exists(path + textfileName) Then
                File.Delete(path + textfileName)
            End If


            ' Active Sheet 
            ActiveSheet(path, excelFilename)


            ' Create Pivot Table Paid
            CreatePivotTablePaid(path, excelFilename)


            ' Create Pivot Table Outstanding
            CreatePivotTableOutstanding(path, excelFilename)


            Dim TheFile As System.IO.FileInfo = New System.IO.FileInfo(path + excelFilename)

            Response.ContentType = "application/vnd.ms-excel"
            Response.AddHeader("Content-Disposition", "inline; filename=" + excelFilename)
            Response.AddHeader("X-Download-Options", "noopen")

            'Remove the charset from the Content-Type header.
            Response.Charset = ""
            Response.WriteFile(TheFile.FullName)

            Response.End()


        Catch ex As Exception
            'Throw ex
            Modul.UserMsgBox(Me, ex.Message)
        End Try
    End Sub
    Private Sub CreatePivotTablePaid(ByVal path As String, ByVal excelFilename As String)

        Dim appNew As Excel.Application = New Excel.Application
        Dim xlWorkbook As Excel.Workbook = appNew.Workbooks.Open(path + excelFilename)

        Dim xlWorksheet = CType(xlWorkbook.Sheets("Detail"), Excel.Worksheet)
        xlWorksheet.Activate()


        Dim xlSheet = CType(xlWorkbook.Sheets("Paid"), Excel.Worksheet)

        Dim range As Excel.Range = xlWorkbook.Worksheets("Detail").Range("A1:AW1048576")
        xlWorkbook.Names.Add("Range1", range)
        Dim pc As Excel.PivotCache = xlWorkbook.PivotCaches().Add(Excel.XlPivotTableSourceType.xlDatabase, "Range1")

        Dim pivotTable As Excel.PivotTable = pc.CreatePivotTable(xlSheet.Range("A1"), "Paid")

        pivotTable.MergeLabels = True
        pivotTable.ErrorString = ""
        pivotTable.DisplayErrorString = True
        pivotTable.NullString = "-"
        pivotTable.LayoutRowDefault = Excel.XlLayoutRowType.xlOutlineRow

        'To be professional or merely resuable, the name could be passed as parameter
        With pivotTable.PivotFields("STATUS")
            .Orientation = Excel.XlPivotFieldOrientation.xlPageField
            .Position = 1
        End With

        With pivotTable.PivotFields("TGL_PROSES")
            .Orientation = Excel.XlPivotFieldOrientation.xlPageField
            .Position = 1
        End With

        With pivotTable.PivotFields("POLICY_NO")
            .Orientation = Excel.XlPivotFieldOrientation.xlRowField
            .Position = 1
        End With

        With pivotTable.PivotFields("GROUP_NAME")
            .Orientation = Excel.XlPivotFieldOrientation.xlRowField
            .Position = 1
        End With

        With pivotTable.PivotFields("Aging Code_Paid")
            .Orientation = Excel.XlPivotFieldOrientation.xlColumnField
            .Position = 1
        End With

        With pivotTable.PivotFields("PAID")
            .Orientation = Excel.XlPivotFieldOrientation.xlDataField
            .Function = Excel.XlConsolidationFunction.xlSum
            .NumberFormat = "#,##0.00"
            .Position = 1
        End With

        pivotTable.CompactLayoutRowHeader = "GROUP NAME AND POLICY NUMBER"


        xlWorkbook.Save()
        xlWorkbook.Close()
        appNew.Quit()

        releaseObject(xlWorksheet)
        releaseObject(xlWorkbook)
        releaseObject(appNew)

    End Sub

    Public Sub CreatePivotTableOutstanding(ByVal path As String, ByVal excelFilename As String)

        Dim appNew As Excel.Application = New Excel.Application
        Dim xlWorkbook As Excel.Workbook = appNew.Workbooks.Open(path + excelFilename)

        Dim xlWorksheet = CType(xlWorkbook.Sheets("Detail"), Excel.Worksheet)
        xlWorksheet.Activate()


        Dim xlSheet = CType(xlWorkbook.Sheets("Outstanding"), Excel.Worksheet)

        Dim range As Excel.Range = xlWorkbook.Worksheets("Detail").Range("A1:AW1048576")
        xlWorkbook.Names.Add("Range1", range)
        Dim pc As Excel.PivotCache = xlWorkbook.PivotCaches().Add(Excel.XlPivotTableSourceType.xlDatabase, "Range1")

        Dim pivotTable As Excel.PivotTable = pc.CreatePivotTable(xlSheet.Range("A1"), "Outstanding")

        pivotTable.MergeLabels = True
        pivotTable.ErrorString = ""
        pivotTable.DisplayErrorString = True
        pivotTable.NullString = "-"
        pivotTable.LayoutRowDefault = Excel.XlLayoutRowType.xlOutlineRow

        'To be professional or merely resuable, the name could be passed as parameter
        With pivotTable.PivotFields("STATUS")
            .Orientation = Excel.XlPivotFieldOrientation.xlPageField
            .Position = 1
        End With

        With pivotTable.PivotFields("CLAIM_TYPE")
            .Orientation = Excel.XlPivotFieldOrientation.xlPageField
            .Position = 1
        End With

        With pivotTable.PivotFields("POLICY_NO")
            .Orientation = Excel.XlPivotFieldOrientation.xlRowField
            .Position = 1
        End With

        With pivotTable.PivotFields("GROUP_NAME")
            .Orientation = Excel.XlPivotFieldOrientation.xlRowField
            .Position = 1
        End With

        With pivotTable.PivotFields("Aging Code_OS")
            .Orientation = Excel.XlPivotFieldOrientation.xlColumnField
            .Position = 1
        End With

        With pivotTable.PivotFields("OUTSTANDING")
            .Orientation = Excel.XlPivotFieldOrientation.xlDataField
            .Function = Excel.XlConsolidationFunction.xlSum
            .NumberFormat = "#,##0.00"
            .Position = 1
        End With

        pivotTable.CompactLayoutRowHeader = "GROUP NAME AND POLICY NUMBER"


        xlWorkbook.Save()
        xlWorkbook.Close()
        appNew.Quit()

        releaseObject(xlWorksheet)
        releaseObject(xlWorkbook)
        releaseObject(appNew)

    End Sub

    Public Sub ActiveSheet(ByVal path As String, ByVal excelFilename As String)

        Dim appNew As Microsoft.Office.Interop.Excel.Application = New Microsoft.Office.Interop.Excel.Application()
        Dim xlWorkbook As Microsoft.Office.Interop.Excel.Workbook = appNew.Workbooks.Open(path + excelFilename)


        ' Sheet Report Data
        Dim xlWorksheet = CType(xlWorkbook.Sheets("Detail"), Excel.Worksheet)
        xlWorksheet.Activate()
        xlWorksheet.Cells.EntireColumn.AutoFit()


        Dim xlSheet3 = CType(xlWorkbook.Sheets.Add(After:=xlWorkbook.Worksheets(2)), Excel.Worksheet)
        xlSheet3.Name = "Paid"

        Dim xlSheet6 = CType(xlWorkbook.Sheets.Add(After:=xlWorkbook.Worksheets(3)), Excel.Worksheet)
        xlSheet6.Name = "Outstanding"


        ' DELETE WORKSHEET Report Data
        xlWorkbook.Application.DisplayAlerts = False
        xlWorkbook.Sheets("Sheet1").Delete()
        xlWorkbook.Application.DisplayAlerts = True

        xlWorkbook.Save()
        xlWorkbook.Close()
        appNew.Quit()

        releaseObject(xlWorksheet)
        releaseObject(xlWorkbook)
        releaseObject(appNew)

    End Sub

    Private Sub releaseObject(ByVal obj As Object)

        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try

    End Sub
    'Private Sub GeDataPremiSummary()
    '    Try
    '        Dt = oSelect.sp_Create_Report_Summary_EC_Pivot

    '        Dim connection As String = "OLEDB;Provider=SQLOLEDB.1;Password=P@ssw0rd;Persist Security Info=True;User ID=corpsoladmin;Initial Catalog=CorpSol;Data Source=WRBSQL01"
    '        'Dim connection As String = "OLEDB;Provider=SQLOLEDB.1;Password=P@ssw0rd;Persist Security Info=True;User ID=CorpSol_User;Initial Catalog=CorpSol;Data Source=WRGCRDB01"
    '        Dim command As String = Dt.Rows(0).Item(0).ToString
    '        Dim app As Excel.Application = New Microsoft.Office.Interop.Excel.Application()
    '        Dim workbook As Excel.Workbook = CType(app.Workbooks.Add(Type.Missing), Microsoft.Office.Interop.Excel.Workbook)
    '        Dim sheet As Excel.Worksheet = CType(workbook.ActiveSheet, Microsoft.Office.Interop.Excel.Worksheet)
    '        Dim range As Excel.Range
    '        Dim dt_detail As New DataTable

    '        If app.Application.Sheets.Count() < 1 Then
    '            sheet = CType(workbook.Worksheets.Add(), Excel.Worksheet)
    '        Else
    '            sheet = app.Worksheets(1)
    '        End If

    '        sheet.Name = "Detail"

    '        dt_detail = oSelect.sp_Create_Report_Detail_EC_Pivot()

    '        If dt_detail.Rows.Count > 0 Then

    '            Dim i = 0

    '            Do While (i < dt_detail.Columns.Count)
    '                sheet.Cells(1, (i + 1)) = dt_detail.Columns(i).ColumnName
    '                i = (i + 1)
    '            Loop

    '            ' rows
    '            i = 0
    '            Do While (i < dt_detail.Rows.Count)
    '                ' to do: format datetime values before printing
    '                Dim j = 0
    '                Do While (j < dt_detail.Columns.Count)
    '                    sheet.Cells((i + 2), (j + 1)) = dt_detail.Rows(i)(j)
    '                    j = (j + 1)
    '                Loop

    '                i = (i + 1)
    '            Loop

    '        End If

    '        range = sheet.Range(sheet.Cells(1, 1), sheet.Cells(dt_detail.Rows.Count + 1, dt_detail.Columns.Count))
    '        range.EntireColumn.AutoFit()

    '        Dim border As Microsoft.Office.Interop.Excel.Borders = range.Borders
    '        border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous

    '        'range = sheet.Range("B1:B" & dt_detail.Rows.Count + 1)
    '        'range.NumberFormat = "@"

    '        ' second
    '        If app.Application.Sheets.Count() < 2 Then
    '            sheet = CType(workbook.Worksheets.Add(), Excel.Worksheet)
    '        Else
    '            sheet = app.Worksheets(2)
    '        End If

    '        sheet.Name = "Paid"

    '        Dim pivotCache As Excel.PivotCache = app.ActiveWorkbook.PivotCaches().Add(Excel.XlPivotTableSourceType.xlExternal, Type.Missing)

    '        pivotCache.Connection = connection
    '        pivotCache.MaintainConnection = True
    '        pivotCache.CommandText = command
    '        pivotCache.CommandType = Excel.XlCmdType.xlCmdSql

    '        Dim pivotTables As Excel.PivotTables = CType(sheet.PivotTables(Type.Missing), Excel.PivotTables)

    '        Dim pivotTable As Excel.PivotTable = pivotTables.Add(pivotCache, app.ActiveCell, "PivotTable1", Type.Missing, Type.Missing)

    '        pivotTable.SmallGrid = False
    '        pivotTable.ShowTableStyleRowStripes = True
    '        pivotTable.TableStyle2 = "PivotStyleLight1"

    '        Dim pageField As Excel.PivotField = CType(pivotTable.PivotFields("TGL_PROSES"), Excel.PivotField)
    '        pageField.Orientation = Excel.XlPivotFieldOrientation.xlPageField

    '        Dim pageField2 As Excel.PivotField = CType(pivotTable.PivotFields("STATUS"), Excel.PivotField)
    '        pageField2.Orientation = Excel.XlPivotFieldOrientation.xlPageField

    '        Dim rowField As Excel.PivotField = CType(pivotTable.PivotFields("GROUP_NAME"), Excel.PivotField)
    '        rowField.Orientation = Excel.XlPivotFieldOrientation.xlRowField

    '        Dim rowField2 As Excel.PivotField = CType(pivotTable.PivotFields("POLICY_NO"), Excel.PivotField)
    '        rowField2.Orientation = Excel.XlPivotFieldOrientation.xlRowField

    '        Dim colField As Excel.PivotField = CType(pivotTable.PivotFields("Aging Code_Paid"), Excel.PivotField)
    '        colField.Orientation = Excel.XlPivotFieldOrientation.xlColumnField

    '        pivotTable.AddDataField(pivotTable.PivotFields("PAID"), "Sum of PAID", Excel.XlConsolidationFunction.xlSum)

    '        ' second
    '        If app.Application.Sheets.Count() < 3 Then
    '            sheet = CType(workbook.Worksheets.Add(), Excel.Worksheet)
    '        Else
    '            sheet = app.Worksheets(3)
    '        End If

    '        sheet.Name = "Outstanding"

    '        Dim pivotCacheSheet2 As Excel.PivotCache = app.ActiveWorkbook.PivotCaches().Add(Excel.XlPivotTableSourceType.xlExternal, Type.Missing)

    '        pivotCacheSheet2.Connection = connection
    '        pivotCacheSheet2.MaintainConnection = True
    '        pivotCacheSheet2.CommandText = command
    '        pivotCacheSheet2.CommandType = Excel.XlCmdType.xlCmdSql

    '        Dim pivotTablesSheet2 As Excel.PivotTables = CType(sheet.PivotTables(Type.Missing), Excel.PivotTables)

    '        Dim pivotTableSheet2 As Excel.PivotTable = pivotTablesSheet2.Add(pivotCacheSheet2, app.ActiveCell, "PivotTable2", Type.Missing, Type.Missing)

    '        pivotTableSheet2.SmallGrid = False
    '        pivotTableSheet2.ShowTableStyleRowStripes = True
    '        pivotTableSheet2.TableStyle2 = "PivotStyleLight1"

    '        Dim pageFieldSheet As Excel.PivotField = CType(pivotTableSheet2.PivotFields("STATUS_CLAIM"), Excel.PivotField)
    '        pageFieldSheet.Orientation = Excel.XlPivotFieldOrientation.xlPageField

    '        Dim pageFieldSheet2 As Excel.PivotField = CType(pivotTableSheet2.PivotFields("CLAIM_TYPE"), Excel.PivotField)
    '        pageFieldSheet2.Orientation = Excel.XlPivotFieldOrientation.xlPageField

    '        Dim pageFieldSheet3 As Excel.PivotField = CType(pivotTableSheet2.PivotFields("STATUS"), Excel.PivotField)
    '        pageFieldSheet3.Orientation = Excel.XlPivotFieldOrientation.xlPageField

    '        Dim rowFieldSheet2 As Excel.PivotField = CType(pivotTableSheet2.PivotFields("GROUP_NAME"), Excel.PivotField)
    '        rowFieldSheet2.Orientation = Excel.XlPivotFieldOrientation.xlRowField

    '        Dim rowField2Sheet2 As Excel.PivotField = CType(pivotTableSheet2.PivotFields("POLICY_NO"), Excel.PivotField)
    '        rowField2Sheet2.Orientation = Excel.XlPivotFieldOrientation.xlRowField

    '        Dim colFieldSheet2 As Excel.PivotField = CType(pivotTableSheet2.PivotFields("Aging Code_OS"), Excel.PivotField)
    '        colFieldSheet2.Orientation = Excel.XlPivotFieldOrientation.xlColumnField

    '        pivotTableSheet2.AddDataField(pivotTableSheet2.PivotFields("OUTSTANDING"), "Sum of OUTSTANDING", Excel.XlConsolidationFunction.xlSum)

    '        Dim filename As String = "Report Summary EC " & Strings.Right(DateTime.Now.Year.ToString, 4).PadLeft(4, "0") & DateTime.Now.Month.ToString.PadLeft(2, "0") & DateTime.Now.Day.ToString.PadLeft(2, "0") & ".xls"

    '        Dim sAppPath As String = Server.MapPath("Report\" + filename)
    '        Dim sPath As String = Request.ApplicationPath + "\Report\" + filename

    '        Dim TheFile As System.IO.FileInfo = New System.IO.FileInfo(sAppPath)
    '        If (TheFile.Exists) Then

    '            System.IO.File.Delete(sAppPath)

    '        End If

    '        workbook.SaveAs(sAppPath)
    '        workbook.Close()
    '        app.Quit()

    '        Response.ContentType = "application/vnd.ms-excel"
    '        Response.AddHeader("Content-Disposition", "inline; filename=" + filename)
    '        Response.AddHeader("X-Download-Options", "noopen")

    '        'Remove the charset from the Content-Type header.
    '        Response.Charset = ""
    '        Response.WriteFile(TheFile.FullName)

    '        Response.End()

    '    Catch ex As Exception
    '        'Throw ex
    '        Modul.UserMsgBox(Me, ex.Message)
    '    End Try
    'End Sub
End Class