﻿Public Class PopAddDataReportGER
    Inherits System.Web.UI.Page
    Dim Modul As New ClassModul
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim strGerNo As String = Request.QueryString("GER_NO")
        Dim strGER_Created_Date As String = Request.QueryString("GER_Created_Date")
        Dim strGER_Claim_Type As String = Request.QueryString("GER_Claim_Type")


        txtGerNumber.Text = strGerNo
        txtTransDate.Text = strGER_Created_Date
        txtCaimType.Text = strGER_Claim_Type
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If
            Me.Focus()
            txtPolNumber.Focus()
        Else
            If Session("username") = "" Then
                'Response.Redirect("~/Login.aspx", False)
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "close", "window.close();", True)
                Exit Sub
            End If

        End If
    End Sub

    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'BindGridDetail(txtGerNumber.Text.TrimEnd(), txtPolNumber.Text.TrimEnd(), txtInvoiceNumber.Text.TrimEnd(), txtClaimNumber.Text.TrimEnd(), txtMemberNumber.Text.TrimEnd(), txtDeptNumber.Text.TrimEnd(), ddlClaimType.SelectedValue.ToString, Session("username"), "INSERT", txtTransDate.Text.TrimEnd)

        'Kalo pakai checklist
        'If (txtPolNumber.Text.TrimEnd() <> "" And txtInvoiceNumber.Text.TrimEnd() <> "") Or (txtPolNumber.Text.TrimEnd() <> "" And txtClaimNumber.Text.TrimEnd() <> "") Or (txtInvoiceNumber.Text.TrimEnd() <> "" And txtClaimNumber.Text.TrimEnd() <> "") Then
        '    If (lbl_check.Text.TrimEnd.Length > 0) Then
        '        'BindGridDetail(txtGerNumber.Text.TrimEnd(), txtPolNumber.Text.TrimEnd(), txtInvoiceNumber.Text.TrimEnd(), txtClaimNumber.Text.TrimEnd(), txtMemberNumber.Text.TrimEnd(), txtDeptNumber.Text.TrimEnd(), txtCaimType.Text.TrimEnd, Session("username"), "INSERT", txtTransDate.Text.TrimEnd, lbl_check.Text.TrimEnd.Remove(lbl_check.Text.Length - 1, 1))
        '        BindGridDetail(txtGerNumber.Text.TrimEnd(), txtPolNumber.Text.TrimEnd(), txtInvoiceNumber.Text.TrimEnd(), txtClaimNumber.Text.TrimEnd(), txtMemberNumber.Text.TrimEnd(), txtDeptNumber.Text.TrimEnd(), txtCaimType.Text.TrimEnd, Session("username"), "INSERT", txtTransDate.Text.TrimEnd, lbl_check.Text.TrimEnd)
        '        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "close", "alert('Save Success.Please Refresh page ReportGER to show this changed.');window.close();", True)
        '    Else
        '        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Alert", "alert('Please Select Min.1 from the Checklist!');", True)
        '    End If

        'Else
        '    ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Alert", "alert('Min. Input Required yang harus di isi 2!');", True)
        'End If

        'Tanpa Checklist
        If (txtPolNumber.Text.TrimEnd() <> "" And txtInvoiceNumber.Text.TrimEnd() <> "") Or (txtPolNumber.Text.TrimEnd() <> "" And txtClaimNumber.Text.TrimEnd() <> "") Or (txtInvoiceNumber.Text.TrimEnd() <> "" And txtClaimNumber.Text.TrimEnd() <> "") Then
            BindGridDetail(txtGerNumber.Text.TrimEnd(), txtPolNumber.Text.TrimEnd(), txtInvoiceNumber.Text.TrimEnd(), txtClaimNumber.Text.TrimEnd(), txtMemberNumber.Text.TrimEnd(), txtDeptNumber.Text.TrimEnd(), txtCaimType.Text.TrimEnd, Session("username"), "INSERT", txtTransDate.Text.TrimEnd, "")
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "close", "alert('Save Success.Please Refresh page ReportGER to show this changed.');window.close();", True)

        Else
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Alert", "alert('Min. Input Required yang harus di isi 2!');", True)
        End If
    End Sub

    Protected Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        'If (txtPolNumber.Text.TrimEnd() <> "" And txtInvoiceNumber.Text.TrimEnd() <> "" And txtClaimNumber.Text.TrimEnd() <> "" And txtMemberNumber.Text.TrimEnd() <> "" And txtDeptNumber.Text.TrimEnd() <> "") Then
        If (txtPolNumber.Text.TrimEnd() <> "" And txtInvoiceNumber.Text.TrimEnd() <> "") Or (txtPolNumber.Text.TrimEnd() <> "" And txtClaimNumber.Text.TrimEnd() <> "") Or (txtInvoiceNumber.Text.TrimEnd() <> "" And txtClaimNumber.Text.TrimEnd() <> "") Then
            BindGridDetail(txtGerNumber.Text.TrimEnd(), txtPolNumber.Text.TrimEnd(), txtInvoiceNumber.Text.TrimEnd(), txtClaimNumber.Text.TrimEnd(), txtMemberNumber.Text.TrimEnd(), txtDeptNumber.Text.TrimEnd(), txtCaimType.Text.TrimEnd, Session("username"), "SELECT", txtTransDate.Text.TrimEnd, "")
        Else
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Alert", "alert('Min. Input Required yang harus di isi 2!');", True)
        End If
    End Sub
    Public Sub BindGridDetail(ByVal GER_NO As String, ByVal CHDRNUM As String, ByVal CLIENT_CLAIM_REF As String, ByVal CLAIM_NO As String, ByVal MBR_NO As String, ByVal DPNT_NO As String _
                              , ByVal WPAID As String, ByVal USER_NAME As String, ByVal PROCESS_TYPE As String, ByVal TRANS_DATE As String, ByVal CHECK_LIST As String)

        Dim xParam(10) As SqlClient.SqlParameter

        xParam(0) = New SqlClient.SqlParameter("@GER_NO", SqlDbType.VarChar)
        xParam(0).Value = CType(GER_NO, String)
        xParam(1) = New SqlClient.SqlParameter("@CHDRNUM", SqlDbType.VarChar)
        xParam(1).Value = CType(CHDRNUM, String)
        xParam(2) = New SqlClient.SqlParameter("@CLIENT_CLAIM_REF", SqlDbType.VarChar)
        xParam(2).Value = CType(CLIENT_CLAIM_REF, String)
        xParam(3) = New SqlClient.SqlParameter("@CLAIM_NO", SqlDbType.VarChar)
        xParam(3).Value = CType(CLAIM_NO, String)
        xParam(4) = New SqlClient.SqlParameter("@MBR_NO", SqlDbType.VarChar)
        xParam(4).Value = CType(MBR_NO, String)
        xParam(5) = New SqlClient.SqlParameter("@DPNT_NO", SqlDbType.VarChar)
        xParam(5).Value = CType(DPNT_NO, String)
        xParam(6) = New SqlClient.SqlParameter("@WPAID", SqlDbType.VarChar)
        xParam(6).Value = CType(WPAID, String)
        xParam(7) = New SqlClient.SqlParameter("@USER_NAME", SqlDbType.VarChar)
        xParam(7).Value = CType(USER_NAME, String)
        xParam(8) = New SqlClient.SqlParameter("@PROCESS_TYPE", SqlDbType.VarChar)
        xParam(8).Value = CType(PROCESS_TYPE, String) 'value = 'SELECT','INSERT'
        xParam(9) = New SqlClient.SqlParameter("@TRANS_DATE", SqlDbType.VarChar)
        xParam(9).Value = CType(TRANS_DATE, String) 'value = 'SELECT','INSERT'
        xParam(10) = New SqlClient.SqlParameter("@CHECK_LIST", SqlDbType.VarChar)
        xParam(10).Value = CType(CHECK_LIST, String) 'value = '1,2,3' or ''

        Dim dtRet As New DataTable
        Try
            Dim strConn As String = ConfigurationManager.ConnectionStrings("ConSql").ConnectionString
            dtRet = Modul.FillDataset("sp_Insert_Ger_By_GER_NO", CommandType.StoredProcedure, xParam)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        If (dtRet.Rows.Count > 0) And (PROCESS_TYPE.TrimEnd = "SELECT") Then
            gridDetail.DataSource = dtRet
            gridDetail.DataBind()
            'lblAmount.Text = IIf(IsDBNull(dtRet.Compute("SUM(Total Amount)", "")), "0", dtRet.Compute("SUM(Total Amount)", ""))

            lblAmount.Text = dtRet.Compute("Sum([Total Amount])", "").ToString()
            hidden_div.Visible = True
            'Session.Add("DataDetails", dtRet)


        ElseIf (dtRet.Rows.Count = 0) And (PROCESS_TYPE.TrimEnd = "SELECT") Then
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "Alert", "alert('Tidak ada data berdasarkan pencarian ini.');", True)
            hidden_div.Visible = False
        Else
            hidden_div.Visible = False
        End If


    End Sub
    'Protected Sub CheckBox_CheckChanged(ByVal sender As Object, ByVal e As EventArgs)
    '    Dim chkAll As CheckBox = DirectCast(gridDetail.HeaderRow _
    '                            .Cells(14).FindControl("chkAll"), CheckBox)
    '    Dim strTemp As String
    '    lbl_check.Text = ""
    '    For i As Integer = 0 To gridDetail.Rows.Count - 1
    '        If chkAll.Checked Then
    '            strTemp = lbl_check.Text
    '            lbl_check.Text = strTemp + (i + 1).ToString + ","
    '        Else

    '            Dim chk As CheckBox = DirectCast(gridDetail.Rows(i) _
    '                            .Cells(14).FindControl("chk"), CheckBox)
    '            If chk.Checked Then
    '                strTemp = lbl_check.Text
    '                lbl_check.Text = strTemp + (i + 1).ToString + ","
    '            Else
    '                strTemp = lbl_check.Text
    '                lbl_check.Text = strTemp.Replace((i + 1).ToString + ",", "")
    '                'dt = RemoveRow(GridGER.Rows(i), dt)
    '            End If
    '        End If
    '    Next
    'End Sub

End Class