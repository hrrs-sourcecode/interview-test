﻿Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.Office.Interop
Imports Microsoft.Office.Interop.Excel
Imports System.Reflection
Imports System
Partial Public Class ReportPaymentReimbursement
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub

    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click
        Try
            Dim dt_report As New System.Data.DataTable
            Dim dt_polis As New System.Data.DataTable

            SQL = "SELECT CASE WHEN [Claim Type]='GHC1' THEN 'Inpatient' WHEN [Claim Type]='OPD1' THEN 'Outpatient' WHEN [Claim Type]='MAT1' THEN 'Maternity' WHEN [Claim Type]='DEN1' THEN 'Dental' WHEN [Claim Type]='OTD1' THEN 'Optical' " & _
                  "WHEN [Claim Type]='MCU1' THEN 'MCU' END as [Claim Type],[Claim No],[Claim Client Ref No],[Member No],[Member Name],[Patient No],[Patient Name],[Admission Date],[Discharge Date]," & _
                  "SUM(Incurred) as Incurred,SUM([Total Amount]) as Paid,SUM(Unpaid) as Unpaid,[Payment Date] FROM Tbl_GER WHERE [Payment Date] >= '" & txtFromPayment.Text.Trim & "' AND [Payment Date] <= '" & txtToPayment.Text.Trim & "' " & _
                  "AND [Who Paid]='C' AND [Policy No] LIKE '%" & txtPolis.Text.Trim & "%' AND [Claim No] LIKE '%" & txtClaim.Text & "%' AND [Member Name] LIKE '%" & txtMember.Text & "%' AND [Patient Name] LIKE '%" & txtPatient.Text & "%' " & _
                  "GROUP BY [Claim Type] ,[Claim No],[Claim Client Ref No],[Member No],[Member Name],[Patient No],[Patient Name],[Admission Date],[Discharge Date],[Payment Date] "
            
            dt_report = Modul.getAllDatainDT(SQL)

            Dim sql_polis As String
            Dim polisName As String = ""
            Dim reader_polis As SqlDataReader

            sql_polis = "SELECT CHDRPF.CHDRNUM,clntpf.LSURNAME as COWNNAME FROM CHDRPF INNER JOIN CLNTPF ON CHDRPF.COWNNUM = Clntpf.CLNTNUM " & _
                        "WHERE CLNTPF.VALIDFLAG = '1' AND CHDRPF.CHDRNUM='" & txtPolis.Text.Trim & "' ORDER BY CHDRPF.CHDRNUM"
            reader_polis = Modul.getAllDatainDR(sql_polis)

            If reader_polis.HasRows Then
                reader_polis.Read()
                polisName = reader_polis.GetValue(1)
            End If
            


            If dt_report.Rows.Count > 0 Then
                Dim sFileName As String = ""

                sFileName = "REPORT PEMBAYARAN KLAIM POLIS " & txtPolis.Text.Trim & ".xls"


                Dim exceltable As New StringBuilder()

                exceltable.Append("<HTML><BODY><table style=table-layout: fixed><tr><td><font size=1 face=Tahoma>Printed Date : " & Date.Now.ToString("dd MMM yyyy") & " </font></td>" & _
                                  "</tr><tr><td><font size=3 face=Tahoma><b>REPORT PEMBAYARAN KLAIM REIMBURSEMENT </b></font></td>" & _
                                  "</tr><tr><td><font size=3 face=Tahoma><b>" & polisName & " - " & txtPolis.Text.Trim & " </b></font></td></tr></table><br />" & _
                                 "<table><tr><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>" & _
                                 "<TABLE Border=1>")
                exceltable.AppendFormat("<TR>")

                exceltable.AppendFormat(String.Concat("<TD>Claim Type</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Claim No</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Claim Client Ref No</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Member No</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Member Name</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Patient No</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Patient Name</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Admission Date</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Discharge Date</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Incurred</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Paid</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Unpaid</TD>"))
                exceltable.AppendFormat(String.Concat("<TD>Payment Date</TD>"))

                exceltable.AppendFormat("</TR>")

                For Each row As DataRow In dt_report.Rows
                    exceltable.AppendFormat("<TR>")

                    exceltable.AppendFormat(String.Concat("<TD>", row("Claim Type").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Claim No").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Claim Client Ref No").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Member No").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Member Name").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Patient No").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Patient Name").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Admission Date").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Discharge Date").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Incurred").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Paid").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Unpaid").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("Payment Date").ToString(), "</TD>"))

                    exceltable.AppendFormat("</TR>")
                Next

                exceltable.Append("</TABLE><br /><p><font size=2 face=Tahoma><b>NB: JIKA DALAM WAKTU 2-3 HARI KERJA DANA BELUM MASUK KE REKENING MOHON UNTUK DIKONFIRMASIKAN KEMBALI</b> </font></p></BODY></HTML>")

                Response.Clear()
                Response.Buffer = True
                Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                Response.Charset = ""
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Me.EnableViewState = False
                Response.ContentType = "application/vnd.ms-excel"

                Response.AddHeader("X-Download-Options", "noopen")

                'Remove the charset from the Content-Type header.
                Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                Response.Write(style)

                Response.Write(exceltable.ToString())

                Response.End()
                reader_polis.Close()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Public Sub ExportExcel(ByVal sfilename As String, ByVal dt_report As System.Data.DataTable)
        Dim newFilePath As String = Server.MapPath("Report\") + sfilename
        Dim objExcel As ApplicationClass = Nothing
        Dim objBooks As Workbooks = Nothing
        Dim objBook As _Workbook = Nothing
        Dim objSheets As Sheets = Nothing
        Dim objSheet As _Worksheet = Nothing
        Dim objRange As Range = Nothing
        Dim row As Integer = 6, col As Integer = 2
        Dim Mydate As Date

        objExcel = New ApplicationClass()
        objBooks = objExcel.Workbooks
        objBook = objBooks.Add(XlWBATemplate.xlWBATWorksheet)

        'Print column heading in the excel sheet
        Dim j As Integer = col

        For Each column As DataColumn In dt_report.Columns
            objSheets = objBook.Worksheets
            objSheet = DirectCast(objSheets.Item(1), _Worksheet)
            objRange = DirectCast(objSheet.Cells(row, j), Range)
            objRange.Value2 = column.ColumnName
            objRange.Columns.WrapText = True
            objRange.Font.Bold = True
            objRange.Font.Name = "Tahoma"
            objRange.Font.Size = 10
            'objRange.HorizontalAlignment = "Center"
            'objRange.VerticalAlignment = "Center"
            objRange.BorderAround()
            objRange.Columns.AutoFit()
            j += 1
        Next
        row += 1

        Dim count As Integer = dt_report.Columns.Count

        For Each dataRow As DataRow In dt_report.Rows
            Dim k As Integer = col
            For i As Integer = 0 To count - 1
                objRange = DirectCast(objSheet.Cells(row, k), Range)
                objRange.Value2 = dataRow(i).ToString()
                objRange.Font.Name = "Tahoma"
                objRange.Font.Size = 10
                'objRange.VerticalAlignment = "Center"
                objRange.BorderAround()
                objRange.Rows.AutoFit()
                k += 1
            Next
            row += 1
        Next


        objRange = DirectCast(objSheet.Cells(2, 2), Range)
        objRange.Font.Bold = True
        objRange.Font.Name = "Tahoma"
        objRange.Value2 = "Claim Payment Report (GER)"

        objRange = DirectCast(objSheet.Cells(3, 2), Range)
        objRange.Value2 = "Periode"

        objRange = DirectCast(objSheet.Cells(4, 2), Range)
        objRange.Value2 = "Report date"

        objRange = DirectCast(objSheet.Cells(3, 3), Range)
        objRange.Value2 = txtFromPayment.Text.Trim & " s/d " & txtFromPayment.Text.Trim

        objRange = DirectCast(objSheet.Cells(4, 3), Range)
        objRange.Value2 = Mydate.ToString("dd/MM/yyyy")


        'Save Excel document
        objSheet.Name = "Sheet1"

        Dim report As String = Server.MapPath("Report\")
        If Not System.IO.Directory.Exists(report) Then
            System.IO.Directory.CreateDirectory(report)
        End If
        Dim reportName As String = Server.MapPath("Report\" + sfilename)
        If System.IO.File.Exists(reportName) Then
            System.IO.File.Delete(reportName)
        End If

        Dim sAppPath As String = Server.MapPath("Report\" + sfilename)
        Dim sPath As String = Request.ApplicationPath + "\Report\" + sfilename

        Dim objOpt As Object = Missing.Value
        objBook.SaveAs(newFilePath, objOpt, objOpt, objOpt, objOpt, objOpt, _
         XlSaveAsAccessMode.xlNoChange, objOpt, objOpt, objOpt, objOpt, objOpt)
        objBook.Close(False, objOpt, objOpt)

        Dim TheFile As System.IO.FileInfo = New System.IO.FileInfo(sAppPath)
        If (TheFile.Exists) Then

            Response.ContentType = "application/vnd.ms-excel"
            Response.AddHeader("Content-Disposition", "inline; filename=" + sfilename)

            Response.AddHeader("X-Download-Options", "noopen")

            'Remove the charset from the Content-Type header.
            Response.Charset = ""
            Response.WriteFile(TheFile.FullName)
            Response.End()

            'Response.Redirect(sPath)
        End If

        objExcel = Nothing
        objBooks = Nothing
        objBook = Nothing
        objSheets = Nothing
        objSheet = Nothing
        objRange = Nothing
        ReleaseComObject(objExcel)
        ReleaseComObject(objBooks)
        ReleaseComObject(objBook)
        ReleaseComObject(objSheets)
        ReleaseComObject(objSheet)
        ReleaseComObject(objRange)
    End Sub

    Public Sub ReleaseComObject(ByVal reference As Object)
        Try
            While System.Runtime.InteropServices.Marshal.ReleaseComObject(reference) <= 0
            End While
        Catch
        End Try
    End Sub
End Class