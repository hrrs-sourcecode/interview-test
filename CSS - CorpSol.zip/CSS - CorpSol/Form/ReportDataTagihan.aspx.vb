﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices
Imports System.Data.OleDb

Imports Microsoft.Office.Interop
Imports System.IO
Imports System.Drawing

Partial Public Class ReportDataTagihan
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul

    Dim dtPremi As New DataTable
    Dim dtExcessClaim As New DataTable
    Dim dtSummary As New DataTable

    Dim oSelect As New SelectBase

    Dim shareFolderTagihan As String = ConfigurationManager.AppSettings("ShareFolderTagihan").ToString

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If
        End If

    End Sub

    Protected Sub btnReportTagihan_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReportTagihan.Click

        Try

            GetDataTagihan()

        Catch ex As Exception

            Modul.UserMsgBox(Me, ex.Message)

        End Try


    End Sub

    Private Sub GetDataTagihan()

        Try

            Dim app As Excel.Application = New Microsoft.Office.Interop.Excel.Application()
            Dim workbook As Excel.Workbook = CType(app.Workbooks.Add(Type.Missing), Microsoft.Office.Interop.Excel.Workbook)
            Dim sheet As Excel.Worksheet = CType(workbook.ActiveSheet, Microsoft.Office.Interop.Excel.Worksheet)

            Dim path = shareFolderTagihan

            Dim listCompanyPremi As List(Of String) = New List(Of String)()

            dtPremi = oSelect.sp_Create_Report_Tagihan("PREMI")

            Dim billNo As String = ""

            For Each row As DataRow In dtPremi.Rows

                billNo = row("BILL_NO").ToString()

                If (Not String.IsNullOrEmpty(billNo)) Then

                    listCompanyPremi.Add(row("POLICY_NUMBER").ToString())

                End If

            Next

            listCompanyPremi = listCompanyPremi.Distinct.GroupBy(Function(x) x.ToString()).Select(Function(d) d.First()).ToList()

            For Each policyNumber As String In listCompanyPremi.OrderBy(Function(x) Convert.ToInt32(x))

                'Generate Data Premi
                GenerateDataPremi(path, app, workbook, sheet, policyNumber)


                'Exit For

            Next

            Modul.UserMsgBox(Me, "Generated Summary Tagihan has been successfully !!")

        Catch ex As Exception
            'Throw ex
            Modul.UserMsgBox(Me, ex.Message)
        End Try
    End Sub


    Public Sub GenerateDataPremi(path As String, app As Excel.Application,
                                 workbook As Excel.Workbook, sheet As Excel.Worksheet,
                                 policyNumber As String)


        Dim csvFilename As String = ""
        Dim excelFilename As String = ""


        dtPremi = oSelect.sp_Create_Report_Tagihan("PREMI")


        Dim initialCatalogOleDB As String = ConfigurationManager.AppSettings("initialCatalogOleDB").ToString()
        Dim dataSourceOleDB As String = ConfigurationManager.AppSettings("dataSourceOleDB").ToString()
        Dim userIdOleDB As String = ConfigurationManager.AppSettings("userIdOleDB").ToString()
        Dim passOleDB As String = ConfigurationManager.AppSettings("passOleDB").ToString()


        Dim connection As String = "OLEDB;Provider=SQLOLEDB.1;Password=" + passOleDB +
                                   ";Persist Security Info=True;User ID=" + userIdOleDB +
                                   ";Initial Catalog=" + initialCatalogOleDB +
                                   ";Data Source=" + dataSourceOleDB

        Dim command As String = dtPremi.Rows(0).Item(0).ToString()


        ' create textfile detail premi
        Dim sb As StringBuilder = New StringBuilder()
        Dim strDelimiter As String = ", "

        Dim textfileName As String = ""
        Dim policyNumberPremi As String = ""
        Dim accountName As String = ""



        ' CREATE HEADER 
        sb.Append("Bill Number")
        sb.Append(strDelimiter)
        sb.Append("No. Bill Manual")
        sb.Append(strDelimiter)
        sb.Append("Payment Mode")
        sb.Append(strDelimiter)
        sb.Append("Policy Number")
        sb.Append(strDelimiter)
        sb.Append("Account Name")
        sb.Append(strDelimiter)
        sb.Append("Policy Effective Date")
        sb.Append(strDelimiter)
        sb.Append("Product")
        sb.Append(strDelimiter)
        sb.Append("Number of Members (Total)")
        sb.Append(strDelimiter)
        sb.Append("Premium Amount")
        sb.Append(strDelimiter)
        sb.Append("By Kartu")
        sb.Append(strDelimiter)
        sb.Append("Outstanding")
        sb.Append(strDelimiter)
        sb.Append("Issue date (system)")
        sb.Append(strDelimiter)
        sb.Append("Type of Endorsment")
        sb.Append(strDelimiter)
        sb.Append("Tanggal Penagihan")
        sb.Append(strDelimiter)
        sb.Append("Aging OS")
        sb.Append(strDelimiter)
        sb.Append("Aging Code OS" + System.Environment.NewLine)


        Dim billNo As String = ""

        If dtPremi.Rows.Count > 0 Then

            For Each dr In dtPremi.Rows

                policyNumberPremi = dr("POLICY_NUMBER").ToString()
                billNo = dr("BILL_NO").ToString()

                If Not String.IsNullOrEmpty(billNo) Then

                    If (policyNumberPremi <> policyNumber) Then
                        Continue For
                    End If


                    If (policyNumberPremi = policyNumber) Then

                        accountName = dr("ACCOUNT_NAME").ToString()

                        sb.Append(dr("BILL_NO").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("NO_BILL_MANUAL").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("PAYMENT_MODE").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("POLICY_NUMBER").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("ACCOUNT_NAME").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("POLICY_EFFECTIVE_DATE").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("PRODUCT").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("TOTAL_MEMBER").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("PREMIUM_AMOUNT").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("BY_KARTU").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("OUTSTANDING").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("ISSUE_DATE (SYSTEM)").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("TYPE_OF_ENDORSMENT").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("TGL_PENAGIHAN_PREMI").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("Aging_OS").ToString())
                        sb.Append(strDelimiter)
                        sb.Append(dr("Aging Code_OS").ToString() + System.Environment.NewLine)

                        ViewState("varPremiCount") += 1
                        ViewState("varPremiOutstanding") += Convert.ToDecimal(dr("OUTSTANDING"))

                    End If

                End If

            Next


            textfileName = "datapremi.txt"
            File.WriteAllText(path + textfileName, sb.ToString())

        End If


        csvFilename = accountName.Replace("PT.", "").Replace("PT .", "") + ".csv"

        Dim sAppPath As String = shareFolderTagihan + csvFilename

        app = New Microsoft.Office.Interop.Excel.Application()
        workbook = CType(app.Workbooks.Add(Type.Missing), Microsoft.Office.Interop.Excel.Workbook)
        sheet = CType(workbook.ActiveSheet, Microsoft.Office.Interop.Excel.Worksheet)


        'workbook.SaveAs(sAppPath,,,,,, Excel.XlSaveAsAccessMode.xlExclusive)

        workbook.SaveAs(sAppPath)
        workbook.Close()
        app.Quit()


        releaseObject(sheet)
        releaseObject(workbook)
        releaseObject(app)


        ' import textfile to sheet excel
        Dim ConnectionString As String

        ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" &
                           "Data Source=" & sAppPath & ";Extended Properties=""Excel 12.0;HDR=Yes;Format=CSVDelimited"""

        Dim ExcelConnection As New System.Data.OleDb.OleDbConnection(ConnectionString)


        'CREATE SHEET DETAIL
        ExcelConnection.Open()

        Dim SQLString1 As String = "Select * INTO [Premi] FROM [Text;DATABASE=" & path & "].[" & textfileName & "]"

        Dim ExcelCommand1 As New System.Data.OleDb.OleDbCommand(SQLString1, ExcelConnection)
        ExcelCommand1.ExecuteNonQuery()
        ExcelConnection.Close()


        ' IF exist delete textfile
        If File.Exists(path + textfileName) Then
            File.Delete(path + textfileName)
        End If


        'Generate Data Excess Claim
        GenerateDataExcessClaim(path, app, workbook, sheet, policyNumber, csvFilename)

        'Generate Data Summary
        GenerateDataSummary(path, app, workbook, sheet, policyNumber, csvFilename)


        excelFilename = csvFilename.Replace("csv", "xlsx")

        ' IF exist delete excel file
        If File.Exists(path + excelFilename) Then
            File.Delete(path + excelFilename)
        End If


        File.Copy(path + csvFilename, path + excelFilename)


        ' Active Sheet 
        ActiveSheet(path, excelFilename)

        'IF exist delete csv file
        If File.Exists(path + csvFilename) Then
            File.Delete(path + csvFilename)
        End If


    End Sub

    Public Sub GenerateDataExcessClaim(path As String, app As Excel.Application,
                                       workbook As Excel.Workbook, sheet As Excel.Worksheet,
                                       policyNumber As String, csvFilename As String)


        dtExcessClaim = oSelect.sp_Create_Report_Tagihan("EC")


        Dim initialCatalogOleDB As String = ConfigurationManager.AppSettings("initialCatalogOleDB").ToString()
        Dim dataSourceOleDB As String = ConfigurationManager.AppSettings("dataSourceOleDB").ToString()
        Dim userIdOleDB As String = ConfigurationManager.AppSettings("userIdOleDB").ToString()
        Dim passOleDB As String = ConfigurationManager.AppSettings("passOleDB").ToString()


        Dim connection As String = "OLEDB;Provider=SQLOLEDB.1;Password=" + passOleDB +
                                   ";Persist Security Info=True;User ID=" + userIdOleDB +
                                   ";Initial Catalog=" + initialCatalogOleDB +
                                   ";Data Source=" + dataSourceOleDB

        Dim command As String = dtExcessClaim.Rows(0).Item(0).ToString


        ' create textfile detail premi
        Dim sb As StringBuilder = New StringBuilder()
        Dim strDelimiter As String = ", "

        Dim textfileName As String = ""
        Dim policyNumberPremi As String = ""
        Dim accountName As String = ""


        ' CREATE HEADER 
        sb.Append("Policy No")
        sb.Append(strDelimiter)
        sb.Append("Company Name")
        sb.Append(strDelimiter)
        sb.Append("Claim Type")
        sb.Append(strDelimiter)
        sb.Append("Claim No")
        sb.Append(strDelimiter)
        sb.Append("Claim Client Ref No")
        sb.Append(strDelimiter)
        sb.Append("Member No")
        sb.Append(strDelimiter)
        sb.Append("Member Name")
        sb.Append(strDelimiter)
        sb.Append("Patient No")
        sb.Append(strDelimiter)
        sb.Append("Patient Name")
        sb.Append(strDelimiter)
        sb.Append("Received Date")
        sb.Append(strDelimiter)
        sb.Append("Provider")
        sb.Append(strDelimiter)
        sb.Append("Admission Date")
        sb.Append(strDelimiter)
        sb.Append("Discharge Date")
        sb.Append(strDelimiter)
        sb.Append("Biaya Perawatan")
        sb.Append(strDelimiter)
        sb.Append("Yang ditanggung")
        sb.Append(strDelimiter)
        sb.Append("Total Excess")
        sb.Append(strDelimiter)
        sb.Append("Tanggal Penagihan")
        sb.Append(strDelimiter)
        sb.Append("Aging")
        sb.Append(strDelimiter)
        sb.Append("Aging Code")
        sb.Append(strDelimiter)
        sb.Append("TGL KIRIM HARDCOPY" + System.Environment.NewLine)


        If dtExcessClaim.Rows.Count > 0 Then

            For Each dr In dtExcessClaim.Rows

                policyNumberPremi = dr("POLICY_NO").ToString()

                If (policyNumberPremi <> policyNumber) Then
                    Continue For
                End If


                If (policyNumberPremi = policyNumber) Then

                    sb.Append(dr("POLICY_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("COMPANY_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("CLAIM_TYPE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("CLAIM_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("CLAIM_CLIENT_REF_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("MEMBER_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("MEMBER_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("PETIRNT_NO").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("PATIENT_NAME").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("RECEIVED_DATE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Provider").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("ADMISSION_DATE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("DISCHARGE_DATE").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("BIAYA_PERAWATAN").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("YANG_DITANGGUNG").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TOTAL_EXCESS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PENAGIHAN_EXCESS").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging_Paid").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("Aging Code_Paid").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TGL_PENGIRIMAN_HARDCOPY").ToString() + System.Environment.NewLine)

                    ViewState("varECCount") += 1
                    ViewState("varECOutstanding") += Convert.ToDecimal(dr("TOTAL_EXCESS"))

                End If

            Next


            textfileName = "dataexcessclaim.txt"
            File.WriteAllText(path + textfileName, sb.ToString())

        End If


        Dim sAppPath As String = shareFolderTagihan + csvFilename


        File.WriteAllText(path + textfileName, sb.ToString())

        ' import textfile to sheet excel
        Dim ConnectionString As String

        ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" &
                           "Data Source=" & sAppPath & ";Extended Properties=""Excel 12.0;HDR=Yes;Format=CSVDelimited"""

        Dim ExcelConnection As New System.Data.OleDb.OleDbConnection(ConnectionString)


        'CREATE SHEET DETAIL
        ExcelConnection.Open()

        Dim SQLString1 As String = "Select * INTO [Excess] FROM [Text;DATABASE=" & path & "].[" & textfileName & "]"

        Dim ExcelCommand1 As New System.Data.OleDb.OleDbCommand(SQLString1, ExcelConnection)
        ExcelCommand1.ExecuteNonQuery()
        ExcelConnection.Close()


        ' IF exist delete textfile
        If File.Exists(path + textfileName) Then
            File.Delete(path + textfileName)
        End If

    End Sub

    Public Sub GenerateDataSummary(path As String, app As Excel.Application,
                                   workbook As Excel.Workbook, sheet As Excel.Worksheet,
                                   policyNumber As String, csvFilename As String)


        dtSummary = oSelect.sp_Create_Report_Tagihan("TOTAL")


        Dim initialCatalogOleDB As String = ConfigurationManager.AppSettings("initialCatalogOleDB").ToString()
        Dim dataSourceOleDB As String = ConfigurationManager.AppSettings("dataSourceOleDB").ToString()
        Dim userIdOleDB As String = ConfigurationManager.AppSettings("userIdOleDB").ToString()
        Dim passOleDB As String = ConfigurationManager.AppSettings("passOleDB").ToString()


        Dim connection As String = "OLEDB;Provider=SQLOLEDB.1;Password=" + passOleDB +
                                   ";Persist Security Info=True;User ID=" + userIdOleDB +
                                   ";Initial Catalog=" + initialCatalogOleDB +
                                   ";Data Source=" + dataSourceOleDB

        Dim command As String = dtSummary.Rows(0).Item(0).ToString


        ' create textfile detail premi
        Dim sb As StringBuilder = New StringBuilder()
        Dim strDelimiter As String = ", "

        Dim textfileName As String = ""
        Dim policyNumberPremi As String = ""
        Dim accountName As String = ""


        ' CREATE HEADER 
        sb.Append("TypeReport")
        sb.Append(strDelimiter)
        sb.Append("countAll")
        sb.Append(strDelimiter)
        sb.Append("TotalAmount")
        sb.Append(strDelimiter)
        sb.Append("aging_less_0")
        sb.Append(strDelimiter)
        sb.Append("aging_0_30")
        sb.Append(strDelimiter)
        sb.Append("aging_31_90")
        sb.Append(strDelimiter)
        sb.Append("aging_greater_90" + System.Environment.NewLine)


        If dtSummary.Rows.Count > 0 Then

            For Each dr In dtSummary.Rows

                policyNumberPremi = dr("PolicyNumber").ToString()

                If (policyNumberPremi <> policyNumber) Then
                    Continue For
                End If


                If (policyNumberPremi = policyNumber) Then

                    sb.Append(dr("TypeReport").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("countAll").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("TotalAmount").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("aging_less_0").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("aging_0_30").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("aging_31_90").ToString())
                    sb.Append(strDelimiter)
                    sb.Append(dr("aging_greater_90").ToString() + System.Environment.NewLine)

                End If

            Next


            textfileName = "datasummary.txt"
            File.WriteAllText(path + textfileName, sb.ToString())


        End If


        Dim sAppPath As String = shareFolderTagihan + csvFilename


        File.WriteAllText(path + textfileName, sb.ToString())

        ' import textfile to sheet excel
        Dim ConnectionString As String

        ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" &
                           "Data Source=" & sAppPath & ";Extended Properties=""Excel 12.0;HDR=Yes;Format=CSVDelimited"""

        Dim ExcelConnection As New System.Data.OleDb.OleDbConnection(ConnectionString)


        'CREATE SHEET DETAIL
        ExcelConnection.Open()

        Dim SQLString1 As String = "Select * INTO [Summary] FROM [Text;DATABASE=" & path & "].[" & textfileName & "]"

        Dim ExcelCommand1 As New System.Data.OleDb.OleDbCommand(SQLString1, ExcelConnection)
        ExcelCommand1.ExecuteNonQuery()
        ExcelConnection.Close()


        ' IF exist delete textfile
        If File.Exists(path + textfileName) Then
            File.Delete(path + textfileName)
        End If

    End Sub

    Public Sub ActiveSheet(path As String, excelFilename As String)

        Dim appNew As Microsoft.Office.Interop.Excel.Application = New Microsoft.Office.Interop.Excel.Application()
        Dim xlWorkbook As Microsoft.Office.Interop.Excel.Workbook = appNew.Workbooks.Open(path + excelFilename)

        ' DELETE WORKSHEET Report Data
        xlWorkbook.Application.DisplayAlerts = False
        xlWorkbook.Sheets("Sheet1").Delete
        xlWorkbook.Application.DisplayAlerts = True


        Dim sheetExcess = CType(xlWorkbook.Sheets("Excess"), Excel.Worksheet)
        sheetExcess.Activate()
        sheetExcess.Move(After:=xlWorkbook.Worksheets(1))

        'STYLE
        For x = 1 To 20
            sheetExcess.Cells(1, x).Font.Bold = True
            sheetExcess.Cells(1, x).Interior.Color = RGB(191, 191, 191)
        Next

        sheetExcess.Cells.EntireColumn.AutoFit()

        Dim sheetPremi = CType(xlWorkbook.Sheets("Premi"), Excel.Worksheet)
        sheetPremi.Activate()
        sheetPremi.Cells.EntireColumn.AutoFit()

        For x = 1 To 16
            sheetPremi.Cells(1, x).Font.Bold = True
            sheetPremi.Cells(1, x).Interior.Color = RGB(191, 191, 191)
        Next

        sheetPremi.Cells.EntireColumn.AutoFit()

        ' TOTAL OUTSTANDING PREMI
        If ViewState("varPremiCount") IsNot Nothing Then

            Dim countPremi As Integer = Convert.ToInt32(ViewState("varPremiCount").ToString())
            Dim outstandingPremi As Decimal = Convert.ToDecimal(ViewState("varPremiOutstanding").ToString())

            sheetPremi.Cells(countPremi + 2, 10) = "Total Outstanding"
            sheetPremi.Cells(countPremi + 2, 11) = outstandingPremi

            sheetPremi.Range("K" + (countPremi + 2).ToString() + ":K" + (countPremi + 2).ToString()).NumberFormat = "#,##0"

            sheetPremi.Cells(countPremi + 2, 10).Font.Bold = True
            sheetPremi.Cells(countPremi + 2, 11).Font.Bold = True

            ViewState("varPremiCount") = Nothing
            ViewState("varPremiOutstanding") = Nothing

        End If

        ' TOTAL OUTSTANDING EXCESS CLAIM
        If ViewState("varECCount") IsNot Nothing Then

            Dim countEC As Integer = Convert.ToInt32(ViewState("varECCount").ToString())
            Dim outstandingEC As Decimal = Convert.ToDecimal(ViewState("varECOutstanding").ToString())

            sheetExcess.Cells(countEC + 2, 15) = "Total Outstanding"
            sheetExcess.Cells(countEC + 2, 16) = outstandingEC

            sheetExcess.Range("P" + (countEC + 2).ToString() + ":P" + (countEC + 2).ToString()).NumberFormat = "#,##0"

            sheetExcess.Cells(countEC + 2, 15).Font.Bold = True
            sheetExcess.Cells(countEC + 2, 16).Font.Bold = True

            ViewState("varECCount") = Nothing
            ViewState("varECOutstanding") = Nothing

        End If


        Dim sheetSummary = CType(xlWorkbook.Sheets("Summary"), Excel.Worksheet)

        sheetSummary.Cells(1, 1) = "Outstanding"
        sheetSummary.Cells(1, 2) = "Total Cases"
        sheetSummary.Cells(1, 3) = "Total Amount"
        sheetSummary.Cells(1, 4) = "< 0"
        sheetSummary.Cells(1, 5) = "0 - 30"
        sheetSummary.Cells(1, 6) = "31 - 90"
        sheetSummary.Cells(1, 7) = "> 90"

        sheetSummary.Cells(4, 1) = "T O T A L"

        sheetSummary.Cells(4, 3) = "=SUM(C2:C3)"
        sheetSummary.Cells(4, 4) = "=SUM(D2:D3)"
        sheetSummary.Cells(4, 5) = "=SUM(E2:E3)"
        sheetSummary.Cells(4, 6) = "=SUM(F2:F3)"
        sheetSummary.Cells(4, 7) = "=SUM(G2:G3)"


        'STYLE
        For x = 1 To 7
            sheetSummary.Cells(1, x).Font.Bold = True
            sheetSummary.Cells(1, x).Interior.Color = RGB(155, 194, 230)

        Next

        sheetSummary.Cells(4, 1).Font.Bold = True
        sheetSummary.Cells(4, 1).Interior.Color = RGB(155, 194, 230)

        'CREATE BORDER
        sheetSummary.Range("A1:G4").Borders.LineStyle = Excel.XlLineStyle.xlContinuous
        sheetSummary.Range("A1:G4").Borders.Weight = Excel.XlBorderWeight.xlThin

        'FORMAT NUMBER
        sheetSummary.Range("B2:G4").NumberFormat = "#,##0"

        sheetSummary.Range("A1:A1").VerticalAlignment = Excel.Constants.xlCenter
        sheetSummary.Range("B1:B1").VerticalAlignment = Excel.Constants.xlCenter
        sheetSummary.Range("C1:C1").VerticalAlignment = Excel.Constants.xlCenter
        sheetSummary.Range("A5:B4").HorizontalAlignment = Excel.Constants.xlCenter
        sheetSummary.Range("A1:G1").HorizontalAlignment = Excel.Constants.xlCenter

        sheetSummary.Cells.EntireColumn.AutoFit()

        xlWorkbook.Save()
        xlWorkbook.Close()
        appNew.Quit()

        releaseObject(sheetSummary)
        releaseObject(sheetExcess)
        releaseObject(sheetPremi)
        releaseObject(xlWorkbook)
        releaseObject(appNew)

    End Sub

    Private Sub releaseObject(ByVal obj As Object)

        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try

    End Sub





End Class