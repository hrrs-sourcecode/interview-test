﻿Imports System.Data
Imports System.Data.SqlClient

Partial Public Class ApprovalManager
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            BindGrid("")
            trDetailTitle.Visible = False
            trGridDetail.Visible = False
            trInfoDetail.Visible = False
            trDetail.Visible = False
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            BindGrid(txtCLMNUM.Text)
        End If

    End Sub
    Public Sub BindGrid(ByVal CLAMNUM As String)
        SQL = "SELECT * FROM Tbl_Approval " & _
              "WHERE [CLAIM NUMBER] LIKE '%" & CLAMNUM & "%' AND [STATUS APPROVE] = 0 ORDER BY [CLAIM NUMBER]"
        Modul.SubBindGridView(SQL, GridHeader)
    End Sub
    Public Sub BindGridDetail(ByVal CLAMNUM As String, ByVal GCOCCNO As String)
        SQL = "SELECT DISTINCT * FROM (SELECT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],SRVCCODE,INCURRED,PAYPROV,MBRSHARE,HMOSHARE,BENCDE,USER_PROFILE " & _
              "FROM Tbl_Duplicate_GCLDPF WHERE CLAMNUM='" & CLAMNUM & "' AND GCOCCNO='" & GCOCCNO & "' " & _
              "UNION " & _
              "SELECT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],SRVCCODE,INCURRED,PAYPROV,MBRSHARE,HMOSHARE,BENCDE,USER_PROFILE " & _
              "FROM TRN_DTL_SPECIAL_CASE WHERE CLAMNUM='" & CLAMNUM & "' AND GCOCCNO='" & GCOCCNO & "') a ORDER BY [CLAIM NUMBER]"

        Modul.SubBindGridView(SQL, gridDetail)
    End Sub
    Private Sub GridHeader_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridHeader.PageIndexChanging
        GridHeader.PageIndex = e.NewPageIndex
        Me.BindGrid(txtCLMNUM.Text)
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click

    End Sub

    Private Sub GridHeader_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridHeader.RowCommand
        If e.CommandName = "SelectHeader" Then
            Try
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = GridHeader.Rows(index)
                Dim myLinkButton As LinkButton
                myLinkButton = selectedRow.Cells(0).Controls(0)

                BindGridDetail(Left(myLinkButton.Text, 8), Right(myLinkButton.Text, 2))

                Session("ClaimNum") = myLinkButton.Text
                Session("Note") = selectedRow.Cells(16).Text


                trDetailTitle.Visible = True
                trGridDetail.Visible = True
                gridDetail.Visible = True
                lblDetailData.Visible = True
            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try

        End If
    End Sub

    Private Sub gridDetail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gridDetail.PageIndexChanging
        gridDetail.PageIndex = e.NewPageIndex
        Me.BindGridDetail(Left(Session("ClaimNum"), 8), Right(Session("ClaimNum"), 2))
    End Sub

    Private Sub gridDetail_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gridDetail.RowCommand
        If e.CommandName = "SelectDetail" Then
            Try
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = gridDetail.Rows(index)
                Dim myLinkButton As LinkButton
                myLinkButton = selectedRow.Cells(0).Controls(0)

                trInfoDetail.Visible = True
                trDetail.Visible = True
                txtCLMNUMDetail.Text = myLinkButton.Text
                txtSRVCCODE.Text = selectedRow.Cells(1).Text
                txtINCURRED.Text = selectedRow.Cells(2).Text
                txtPAYPROV.Text = selectedRow.Cells(3).Text
                txtMBRSHARE.Text = selectedRow.Cells(4).Text
                txtHMOSHARE.Text = selectedRow.Cells(5).Text
                txtBENCDE.Text = selectedRow.Cells(6).Text
                txtUSER_PROFILE.Text = selectedRow.Cells(7).Text
                txtNote.Text = Session("Note")

            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try

        End If
    End Sub

    Protected Sub btnApprove_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnApprove.Click
        Try
            SQL = "UPDATE Tbl_Approval SET [STATUS APPROVE]=1 WHERE [CLAIM NUMBER]='" & Session("ClaimNum") & "'"
            Modul.Eksekusi(SQL)

            SQL = "INSERT INTO Tbl_Bucket_Pembayaran SELECT *,0 as [STATUS GER],'' as REASON FROM GCLHPF WHERE CLAMNUM='" & Left(Session("ClaimNum"), 8) & "'"
            Modul.Eksekusi(SQL)

            SQL = "INSERT INTO Tbl_Bucket_Pembayaran SELECT CLMCOY,	CLAMNUM,	GCOCCNO,	CHDRNUM,	MBRNO,	DPNTNO,	CLNTCOY," & _
                  "CLNTNUM,	GCSTS,	CLAIMCUR,	CRATE,	PRODTYP,	GRSKCLS,	DTEVISIT,	DTEDCHRG,	GCDIAGCD,	PLANNO,	PREAUTNO," & _
                  "PROVORG,	AREACDE,	REFERRER,	CLAMTYPE,	TIMEHH,	TIMEMM,	CLIENT_CLAIM_REF,	GCDTHCLM,	APAIDAMT,	REQNTYPE," & _
                  "CRDTCARD,	WHOPAID,	DTEKNOWN,	GCFRPDTE,	RECVD_DATE,	MCFROM,	MCTO,	GDEDUCT,	COPAY,	MBRTYPE,	PROVNET," & _
                  "AAD,	THIRDRCVY,	THIRDPARTY,	TLMBRSHR,	TLHMOSHR,	DATEAUTH,	GCAUTHBY,	GCOPRSCD,	REVLINK,	REVERSAL_IND," & _
                  "TPRCVPND,	PENDFROM,	MMPROD,	HMOSHRMM,	TAKEUP,	DATACONV,	CLRATE,	REFNO,	UPDATE_IND,	PREMRCVY,	DATEAUTH1," & _
                  "DATEAUTH2,	GCAUTHBY1,	GCAUTHBY2,	CASHLESS,	TPAREFNO,	INWARDNO,	ICD101L,	ICD102L,	ICD103L," & _
                  "REGCLM,	GCCAUSCD,	USER_PROFILE,	JOB_NAME,	DATIME,	TLCFAMT, 0 as STATUS, '' as REASON,'' as [GER No 1] " & _
                  "FROM TRN_HDR_SPECIAL_CASE WHERE CLAMNUM='" & Left(Session("ClaimNum"), 8) & "' AND CLAMNUM NOT IN (SELECT CLAMNUM FROM GCLHPF WHERE CLAMNUM='" & Left(Session("ClaimNum"), 8) & "')"
            Modul.Eksekusi(SQL)

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            "alert('Approve Data Sukses'); window.location='ApprovalManager.aspx';", True)
        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub

    Protected Sub btnPostpone_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnPostpone.Click
        Try
            SQL = "UPDATE Tbl_Bucket_Pending SET [REASON]='05',StatusPending=0 WHERE [CLAMNUM]='" & Left(Session("ClaimNum"), 8) & "'"
            Modul.Eksekusi(SQL)

            SQL = "UPDATE TRN_HDR_SPECIAL_CASE SET [REASON]='05',StatusPending=0 WHERE [CLAMNUM]='" & Left(Session("ClaimNum"), 8) & "'"
            Modul.Eksekusi(SQL)

            SQL = "UPDATE Tbl_Approval SET [Note]='" & txtNote.Text.Trim & "',[REASON HOLD]='Hold By Manager',[STATUS APPROVE]=2 WHERE [CLAIM NUMBER]='" & Session("ClaimNum") & "'"
            Modul.Eksekusi(SQL)

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            "alert('Postpone Data Sukses'); window.location='ApprovalManager.aspx';", True)
        Catch ex As Exception
            MsgBox(ex.Message)
            Throw (ex)
        End Try
    End Sub

    Protected Sub gridDetail_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles gridDetail.SelectedIndexChanged

    End Sub
End Class