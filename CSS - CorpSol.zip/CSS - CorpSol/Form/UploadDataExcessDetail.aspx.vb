﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices
Imports System.Data.OleDb
Imports System.IO
Partial Public Class UploadDataExcessDetail
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim oInsert As New InsertBase
    Dim oSelect As New SelectBase
    Dim oUpdate As New UpdateBase
    Dim dt_duplicate As New DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub


    Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSave.Click
        If Not txtUpload.HasFile Then
            ' Handle file
            Modul.UserMsgBox(Me, "File Can't Empty !!")
            Exit Sub
        End If

        Dim strFileName As String = txtUpload.PostedFile.FileName
        Dim filename As String = Path.GetFileName(strFileName)
        Dim new_path As String = Server.MapPath("Upload\") + filename

        txtUpload.PostedFile.SaveAs(new_path)

        txtUpload.Enabled = False
        cmdSave.Enabled = False
        cmdCancel.Enabled = False

        'Dim uploadedFiles As HttpFileCollection = Request.Files
        Dim x As Integer = 0

        Dim MyConnection As OleDbConnection
        Dim MyCommand_Upload As OleDbDataAdapter


        Try

            Dim DtData_Upload As New DataTable


            MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; " & _
                                "data source='" & new_path & " '; " & "Extended Properties=Excel 12.0;")

            MyConnection.Open()

            Dim dbSchema As DataTable = MyConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
            Dim firstSheetName As String = dbSchema.Rows(0)("TABLE_NAME").ToString()

            MyCommand_Upload = New OleDbDataAdapter(String.Format("SELECT * FROM [" & firstSheetName & "]", strFileName), MyConnection)
            MyCommand_Upload.Fill(DtData_Upload)

            For i = 0 To DtData_Upload.Rows.Count
                Try
                    If i = DtData_Upload.Rows.Count Then
                        Exit For
                    End If

                    Dim vPOLICYNO As Integer = IIf(IsDBNull(DtData_Upload.Rows(i).Item("POLICY_NO")), 0, DtData_Upload.Rows(i).Item("POLICY_NO"))
                    Dim vCLAIM_NO As String = DtData_Upload.Rows(i).Item("CLAMNO").ToString
                    Dim vSTATUS_CLAIM As String = DtData_Upload.Rows(i).Item("STATUS_CLAIM").ToString
                    Dim vRECEIPT_NO1 As String = DtData_Upload.Rows(i).Item("RECEIPT_NO1").ToString
                    Dim vRECEIPT_NO2 As String = DtData_Upload.Rows(i).Item("RECEIPT_NO2").ToString
                    Dim vRECEIPT_NO3 As String = DtData_Upload.Rows(i).Item("RECEIPT_NO3").ToString
                    Dim vSTATUS_POLIS As String = DtData_Upload.Rows(i).Item("STATUS POLIS").ToString
                    Dim vGROUP_NAME As String = DtData_Upload.Rows(i).Item("GROUP NAME").ToString


                    Dt = oSelect.sp_Check_detail_EC(vPOLICYNO, vCLAIM_NO)

                    If Dt.Rows.Count > 0 Then
                        oUpdate.f_Update_Data_EC_Detail(vPOLICYNO, vCLAIM_NO, vSTATUS_CLAIM, vRECEIPT_NO1, vRECEIPT_NO2, vRECEIPT_NO3, vSTATUS_POLIS, vGROUP_NAME)
                    Else
                        oInsert.f_Insert_Data_EC_Detail(vPOLICYNO, vCLAIM_NO, vSTATUS_CLAIM, vRECEIPT_NO1, vRECEIPT_NO2, vRECEIPT_NO3, vSTATUS_POLIS, vGROUP_NAME)
                    End If

                Catch ex As Exception
                    'MsgBox(ex.Message)
                    'Throw (ex)
                    DtData_Upload = Nothing

                    MyConnection.Close()
                    System.IO.File.Delete(new_path)
                    txtUpload.Enabled = True
                    cmdSave.Enabled = True
                    cmdCancel.Enabled = True
                    Exit Sub
                End Try

            Next


            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Upload Data Sukses'); window.location='UploadDataExcessDetail.aspx';", True)

            DtData_Upload = Nothing

            MyConnection.Close()
            System.IO.File.Delete(new_path)

            txtUpload.Enabled = True
            cmdSave.Enabled = True
            cmdCancel.Enabled = True
        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw (ex)
            Exit Sub
        End Try
        '        End If
        '    Catch ex As Exception
        '    'MsgBox(ex.Message)
        '    'Throw (ex)
        'End Try
        'x += 1
        'Loop


        'System.IO.File.Delete(userPostedFile.FileName)

    End Sub

End Class