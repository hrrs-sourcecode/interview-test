﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Reflection
Imports System
Imports ExcelLibrary
Imports ExcelLibrary.SpreadSheet
Imports System.Globalization
Imports Microsoft.Office.Interop

Partial Public Class ReportSummaryAll
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Dim oSelect As New SelectBase
    Dim oModul As New ClassModul
    Dim dr As SqlDataReader
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub

    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click
        Try
            GeDataPremi()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub GeDataPremi()
        Try
            Dt = oSelect.sp_Create_Report_Summary_Premi_Pivot

            'Dim connection As String = "OLEDB;Provider=SQLOLEDB.1;Data Source=WRGCRDB01;Initial Catalog=CoprSol;User Id=corpsol_user;Password=P@ssw0rd"
            Dim connection As String = "OLEDB;Provider=SQLOLEDB.1;Password=P@ssw0rd;Persist Security Info=True;User ID=CorpSol_User;Initial Catalog=CorpSol;Data Source=WRGCRDB01"
            Dim command As String = Dt.Rows(0).Item(0).ToString
            Dim app As Excel.Application = New Microsoft.Office.Interop.Excel.Application()
            Dim workbook As Excel.Workbook = CType(app.Workbooks.Add(Type.Missing), Microsoft.Office.Interop.Excel.Workbook)
            Dim sheet As Excel.Worksheet = CType(workbook.ActiveSheet, Microsoft.Office.Interop.Excel.Worksheet)
            Dim range As Excel.Range
            Dim dt_detail As New DataTable

            If app.Application.Sheets.Count() < 1 Then
                sheet = CType(workbook.Worksheets.Add(), Excel.Worksheet)
            Else
                sheet = app.Worksheets(1)
            End If

            sheet.Name = "Detail"

            dt_detail = oSelect.sp_Create_Report_Detail_Premi_Pivot()

            If dt_detail.Rows.Count > 0 Then

                Dim i = 0

                Do While (i < dt_detail.Columns.Count)
                    sheet.Cells(1, (i + 1)) = dt_detail.Columns(i).ColumnName
                    i = (i + 1)
                Loop

                ' rows
                i = 0
                Do While (i < dt_detail.Rows.Count)
                    ' to do: format datetime values before printing
                    Dim j = 0
                    Do While (j < dt_detail.Columns.Count)
                        sheet.Cells((i + 2), (j + 1)) = dt_detail.Rows(i)(j)
                        j = (j + 1)
                    Loop

                    i = (i + 1)
                Loop

            End If

            range = sheet.Range(sheet.Cells(1, 1), sheet.Cells(dt_detail.Rows.Count + 1, dt_detail.Columns.Count))
            range.EntireColumn.AutoFit()

            Dim border As Microsoft.Office.Interop.Excel.Borders = range.Borders
            border.LineStyle = Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous

            range = sheet.Range("B1:B" & dt_detail.Rows.Count + 1)
            range.NumberFormat = "@"

            ' second
            If app.Application.Sheets.Count() < 2 Then
                sheet = CType(workbook.Worksheets.Add(), Excel.Worksheet)
            Else
                sheet = app.Worksheets(2)
            End If

            sheet.Name = "Paid"

            Dim pivotCache As Excel.PivotCache = app.ActiveWorkbook.PivotCaches().Add(Excel.XlPivotTableSourceType.xlExternal, Type.Missing)

            pivotCache.Connection = connection
            pivotCache.MaintainConnection = True
            pivotCache.CommandText = command
            pivotCache.CommandType = Excel.XlCmdType.xlCmdSql

            Dim pivotTables As Excel.PivotTables = CType(sheet.PivotTables(Type.Missing), Excel.PivotTables)

            Dim pivotTable As Excel.PivotTable = pivotTables.Add(pivotCache, app.ActiveCell, "PivotTable1", Type.Missing, Type.Missing)

            pivotTable.SmallGrid = False
            pivotTable.ShowTableStyleRowStripes = True
            pivotTable.TableStyle2 = "PivotStyleLight1"

            Dim pageField As Excel.PivotField = CType(pivotTable.PivotFields("TGL_PROSES"), Excel.PivotField)
            pageField.Orientation = Excel.XlPivotFieldOrientation.xlPageField

            Dim pageField2 As Excel.PivotField = CType(pivotTable.PivotFields("STATUS"), Excel.PivotField)
            pageField2.Orientation = Excel.XlPivotFieldOrientation.xlPageField

            Dim rowField As Excel.PivotField = CType(pivotTable.PivotFields("GROUP_NAME"), Excel.PivotField)
            rowField.Orientation = Excel.XlPivotFieldOrientation.xlRowField

            Dim rowField2 As Excel.PivotField = CType(pivotTable.PivotFields("POLICY_NUMBER"), Excel.PivotField)
            rowField2.Orientation = Excel.XlPivotFieldOrientation.xlRowField

            Dim colField As Excel.PivotField = CType(pivotTable.PivotFields("Aging Code_Paid"), Excel.PivotField)
            colField.Orientation = Excel.XlPivotFieldOrientation.xlColumnField

            pivotTable.AddDataField(pivotTable.PivotFields("PAID"), "Sum of PAID", Excel.XlConsolidationFunction.xlSum)

            ' second
            If app.Application.Sheets.Count() < 3 Then
                sheet = CType(workbook.Worksheets.Add(), Excel.Worksheet)
            Else
                sheet = app.Worksheets(3)
            End If

            sheet.Name = "Outstanding"

            Dim pivotCacheSheet2 As Excel.PivotCache = app.ActiveWorkbook.PivotCaches().Add(Excel.XlPivotTableSourceType.xlExternal, Type.Missing)

            pivotCacheSheet2.Connection = connection
            pivotCacheSheet2.MaintainConnection = True
            pivotCacheSheet2.CommandText = command
            pivotCacheSheet2.CommandType = Excel.XlCmdType.xlCmdSql

            Dim pivotTablesSheet2 As Excel.PivotTables = CType(sheet.PivotTables(Type.Missing), Excel.PivotTables)

            Dim pivotTableSheet2 As Excel.PivotTable = pivotTablesSheet2.Add(pivotCacheSheet2, app.ActiveCell, "PivotTable2", Type.Missing, Type.Missing)

            pivotTableSheet2.SmallGrid = False
            pivotTableSheet2.ShowTableStyleRowStripes = True
            pivotTableSheet2.TableStyle2 = "PivotStyleLight1"

            Dim pageFieldSheet2 As Excel.PivotField = CType(pivotTableSheet2.PivotFields("STATUS"), Excel.PivotField)
            pageFieldSheet2.Orientation = Excel.XlPivotFieldOrientation.xlPageField

            Dim rowFieldSheet2 As Excel.PivotField = CType(pivotTableSheet2.PivotFields("GROUP_NAME"), Excel.PivotField)
            rowFieldSheet2.Orientation = Excel.XlPivotFieldOrientation.xlRowField

            Dim rowField2Sheet2 As Excel.PivotField = CType(pivotTableSheet2.PivotFields("POLICY_NUMBER"), Excel.PivotField)
            rowField2Sheet2.Orientation = Excel.XlPivotFieldOrientation.xlRowField

            Dim colFieldSheet2 As Excel.PivotField = CType(pivotTableSheet2.PivotFields("Aging Code_OS"), Excel.PivotField)
            colFieldSheet2.Orientation = Excel.XlPivotFieldOrientation.xlColumnField

            pivotTableSheet2.AddDataField(pivotTableSheet2.PivotFields("OUTSTANDING"), "Sum of OUTSTANDING", Excel.XlConsolidationFunction.xlSum)



            Dim filename As String = "Report All Summary " & Strings.Right(DateTime.Now.Year.ToString, 4).PadLeft(4, "0") & DateTime.Now.Month.ToString.PadLeft(2, "0") & DateTime.Now.Day.ToString.PadLeft(2, "0") & ".xls"

            Dim sAppPath As String = Server.MapPath("Report\" + filename)
            Dim sPath As String = Request.ApplicationPath + "\Report\" + filename

            Dim TheFile As System.IO.FileInfo = New System.IO.FileInfo(sAppPath)
            If (TheFile.Exists) Then

                System.IO.File.Delete(sAppPath)

            End If

            workbook.SaveAs(sAppPath)
            workbook.Close()
            app.Quit()

            Response.ContentType = "application/vnd.ms-excel"
            Response.AddHeader("Content-Disposition", "inline; filename=" + filename)
            Response.AddHeader("X-Download-Options", "noopen")

            'Remove the charset from the Content-Type header.
            Response.Charset = ""
            Response.WriteFile(TheFile.FullName)

            Response.End()

        Catch ex As Exception
            'Throw ex
            Modul.UserMsgBox(Me, ex.Message)
        End Try
    End Sub
End Class