﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Reflection
Imports System
Imports System.IO
Imports Ionic.Zip

Partial Public Class ReportAccountBalance
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Dim dr As SqlDataReader
    Dim oSelect As New SelectBase
    Dim dt_mbrNo As New System.Data.DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            DropFill_FundType()
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub
    Public Sub DropFill_FundType()
        Dim ListTemp As ListItem

        ddlFundType.Items.Clear()
        ListTemp = New ListItem("Choose", "")
        ddlFundType.Items.Add(ListTemp)

        SQL = "SELECT DISTINCT DESCPF_TR93U_LONGDESC,ACTRPF_INVFCDE FROM IDAS_CORPSOL_TRANSACTION WHERE ACTRPF_INVFCDE NOT IN ('IN','UH') " & _
              "ORDER BY ACTRPF_INVFCDE"

        dr = Modul.getAllDatainDR(SQL)

        While dr.Read
            ListTemp = New ListItem(dr(1), dr(0))
            ddlFundType.Items.Add(ListTemp)
        End While

        dr.Close()
        Modul.SQLCn.Close()

    End Sub
    Protected Sub ddlFundType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlFundType.SelectedIndexChanged
        txtLongDesc.Text = ddlFundType.SelectedValue.ToString
    End Sub
    Protected Sub ddlReportLevel_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlReportLevel.SelectedIndexChanged
        If ddlReportLevel.SelectedValue.ToString = "Member Level" Then
            lblMember.Visible = True
            txtMemberName.Visible = True
        Else
            lblMember.Visible = False
            txtMemberName.Visible = False
        End If
    End Sub
    Protected Sub txtPolis_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtPolis.TextChanged
        Dim dt_Polis As New System.Data.DataTable
        Dim ListTemp As ListItem

        If Len(txtPolis.Text) = 8 Then
            dt_Polis = oSelect.sp_Get_Type_Polis(txtPolis.Text)

            If dt_Polis.Rows.Count = 0 Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportAccountBalance.aspx';", True)
                Exit Sub
            End If
            Session("Type") = dt_Polis.Rows(0)("Type").ToString

            If Session("Type") = "DCI" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
                ddlReportLevel.Items.Add("Member Level")
            ElseIf Session("Type") = "DBE" Then
                ddlReportLevel.Items.Clear()
                ddlReportLevel.Items.Add("Policy Level")
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan'); window.location='ReportAccountBalance.aspx';", True)
            End If

            ddlFundType.Items.Clear()

            For x = 0 To dt_Polis.Rows.Count - 1
                ListTemp = New ListItem(dt_Polis.Rows(x)("Fund"), dt_Polis.Rows(x)("Description"))
                ddlFundType.Items.Add(ListTemp)
            Next

            txtLongDesc.Text = ddlFundType.SelectedValue.ToString

        End If
    End Sub
    Protected Sub btnDownload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDownload.Click
        Try
            Dim dateFrom As DateTime
            Dim dateTo As DateTime
            Dim sFileName As String = ""

            dateFrom = CDate(Right(txtFrom.Text, 4) & "-" & Mid(txtFrom.Text, 4, 2) & "-" & Left(txtFrom.Text, 2))
            dateTo = CDate(Right(txtTo.Text, 4) & "-" & Mid(txtTo.Text, 4, 2) & "-" & Left(txtTo.Text, 2))

            If txtFrom.Text.Trim = "" Or txtTo.Text.Trim = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Tidak Boleh Kosong.'); window.location='ReportAccountBalance.aspx';", True)
                Exit Sub
            ElseIf dateTo > dateFrom.AddMonths(1) Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Transaction Date Melebihi Periode Yang Ditentukan.'); window.location='ReportAccountBalance.aspx';", True)
                Exit Sub
            ElseIf txtPolis.Text = "" Then
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Police Number Tidak Boleh Kosong.'); window.location='ReportAccountBalance.aspx';", True)
                Exit Sub
            End If

            If ddlReportLevel.SelectedValue.ToString = "Policy Level" Then
                Report_Policy_Level()
            ElseIf ddlReportLevel.SelectedValue.ToString = "Member Level" Then
                Report_Member_Level()

                dt_mbrNo.Clear()
                dt_mbrNo = oSelect.sp_Get_MemberNo(txtFrom.Text, txtTo.Text, txtPolis.Text, txtMemberName.Text, ddlFundType.SelectedItem.Text)

                Using zip As New ZipFile()
                    zip.AlternateEncodingUsage = ZipOption.AsNecessary
                    zip.AddDirectoryByName("ReportAccountBalance")

                    For x = 0 To dt_mbrNo.Rows.Count - 1

                        sFileName = "Report Account Balance " & txtPolis.Text & " - " & dt_mbrNo.Rows(x)("MBRNO") & ".xls"
                        Dim spath As String = Server.MapPath("~/File/" & sFileName)

                        zip.AddFile(spath, "ReportAccountBalance")
                    Next

                    Response.Clear()
                    Response.Buffer = True
                    Response.AddHeader("Content-Disposition", "inline; filename=" + "ReportAccountBalance.Zip")
                    Response.Charset = ""
                    Response.Cache.SetCacheability(HttpCacheability.NoCache)
                    Me.EnableViewState = False
                    Response.ContentType = "application/zip"

                    Response.AddHeader("X-Download-Options", "noopen")

                    'Remove the charset from the Content-Type header.
                    Dim style As String = "<style> .text { mso-number-format:\@; } </style> "

                    zip.Save(Response.OutputStream)

                    Dim filePaths() As String = Directory.GetFiles(Server.MapPath("~/File/"))

                    For Each filePath As String In filePaths
                        File.Delete(filePath)
                    Next

                    Response.End()

                End Using

            End If
        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    Public Sub Report_Policy_Level()
        Try
            Dim dt_report As New System.Data.DataTable

            Dim sFileName As String = ""

            dt_report = oSelect.sp_Account_Balance_Policy_Level(txtFrom.Text, txtTo.Text, txtPolis.Text, ddlFundType.SelectedItem.Text)

            If dt_report.Rows.Count > 0 Then
                sFileName = "Report Account Balance " & txtPolis.Text & ".xls"

                Dim exceltable As New StringBuilder()

                exceltable.Append("<HTML><BODY><table style=table-layout: fixed>" & _
                              "<tr><td><font size=small face=Calibri><b>RINCIAN TRANSAKSI</b></font></td>" & _
                              "<td ><font size=small face=Calibri>&nbsp;</font></td>" & _
                              "</tr><tr><td><font size=small face=Calibri><b>Nomor Polis</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("PolicyNo") & "</b></font></td>" & _
                              "</tr><tr><td><font size=small face=Calibri><b>Nama Perusahaan</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("Nama Nasabah") & "</b></font></td>" & _
                              "</tr><tr><td><font size=small face=Calibri><b>Periode</b></font></td><td><font size=small face=Calibri><b>: " & txtFrom.Text & " s/d " & txtTo.Text & "</b></font></td>" & _
                              "</tr><tr><td><font size=small face=Calibri><b>Jenis Fund</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("Tipe Fund") & "</b></font></td>" & _
                              "</tr></table><br /><TABLE style=table-layout: fixed>")

                exceltable.AppendFormat("<TR>")
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>TANGGAL TRANSAKSI</b></TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>JENIS TRANSAKSI</b></TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>JUMLAH (Rp)</b></TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>HARGA/UNIT</b></TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=200px><b>JUMLAH (UNIT)         </b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver width=200px><b>TOTAL UNIT            </b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White><b>&nbsp;</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White><b>Biaya Administrasi</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>" & dt_report.Rows(0)("Admin Charge") & " %</TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>per month</TD>"))
                exceltable.AppendFormat("</TR>")

                exceltable.AppendFormat("<TR>")
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TH>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>&nbsp;</TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White><b>AMC</b></TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>" & dt_report.Rows(0)("AMC") & " %</TD>"))
                exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>per year</TD>"))
                exceltable.AppendFormat("</TR>")

                For Each row As DataRow In dt_report.Rows
                    exceltable.AppendFormat("<TR>")

                    exceltable.AppendFormat(String.Concat("<TD>", row("TGL TRANSAKSI").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("JENIS TRANSAKSI").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("JUMLAH").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("HARGA/UNIT").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("JUMLAH UNIT").ToString(), "</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD>", row("TOTAL UNIT").ToString(), "</TD>"))

                    exceltable.AppendFormat("</TR>")
                Next

                exceltable.Append("</TABLE></td></tr></table></BODY></HTML>")
                Response.Clear()
                Response.Buffer = True
                Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
                Response.Charset = ""
                Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Me.EnableViewState = False
                Response.ContentType = "application/vnd.ms-excel"

                Response.AddHeader("X-Download-Options", "noopen")

                'Remove the charset from the Content-Type header.
                Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
                Response.Write(style)

                Response.Write(exceltable.ToString())

                Response.End()
            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan.'); window.location='ReportAccountBalance.aspx';", True)
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub Report_Member_Level()
        Try
            Dim dt_report As New System.Data.DataTable

            Dim sFileName As String = ""

            dt_mbrNo = oSelect.sp_Get_MemberNo(txtFrom.Text, txtTo.Text, txtPolis.Text, txtMemberName.Text, ddlFundType.SelectedItem.Text)

            If dt_mbrNo.Rows.Count > 0 Then

                For z = 0 To dt_mbrNo.Rows.Count - 1

                    dt_report.Clear()
                    dt_report = oSelect.sp_Account_Balance_Member_Level(txtFrom.Text, txtTo.Text, txtPolis.Text, dt_mbrNo.Rows(z)("MBRNO"), ddlFundType.SelectedItem.Text)

                    sFileName = "Report Account Balance " & txtPolis.Text & " - " & dt_mbrNo.Rows(z)("MBRNO") & ".xls"

                    Dim exceltable As New StringBuilder()

                    exceltable.Append("<HTML><BODY><table style=table-layout: fixed>" & _
                                      "<tr><td><font size=small face=Calibri><b>RINCIAN TRANSAKSI</b></font></td>" & _
                                      "<td ><font size=small face=Calibri>&nbsp;</font></td>" & _
                                      "</tr><tr><td><font size=small face=Calibri><b>Nama Peserta</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("Nama Member") & "</b></font></td>" & _
                                      "</tr><tr><td><font size=small face=Calibri><b>Nomor Polis</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("PolicyNo") & "</b></font></td>" & _
                                      "</tr><tr><td><font size=small face=Calibri><b>Nama Perusahaan</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("Nama Perusahaan") & "</b></font></td>" & _
                                      "</tr><tr><td><font size=small face=Calibri><b>Periode</b></font></td><td><font size=small face=Calibri><b>: " & txtFrom.Text & " s/d " & txtTo.Text & "</b></font></td>" & _
                                      "</tr><tr><td><font size=small face=Calibri><b>Jenis Fund</b></font></td><td><font size=small face=Calibri><b>: " & dt_report.Rows(0)("Tipe Fund") & "</b></font></td>" & _
                                      "</tr></table><br /><TABLE style=table-layout: fixed>")

                    exceltable.AppendFormat("<TR>")
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>TANGGAL TRANSAKSI</b></TH>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>JENIS TRANSAKSI</b></TH>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>JUMLAH (Rp)</b></TH>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>HARGA/UNIT</b></TH>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>JUMLAH (UNIT)</b></TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver><b>TOTAL UNIT</b></TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White><b>&nbsp;</b></TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White><b>Biaya Administrasi</b></TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>" & dt_report.Rows(0)("Admin Charge") & " %</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>per month</TD>"))
                    exceltable.AppendFormat("</TR>")

                    exceltable.AppendFormat("<TR>")
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TH>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TH>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TH>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TH>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=Silver>&nbsp;</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>&nbsp;</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White><b>AMC</b></TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>" & dt_report.Rows(0)("AMC") & " %</TD>"))
                    exceltable.AppendFormat(String.Concat("<TD align=center bgcolor=White>per year</TD>"))
                    exceltable.AppendFormat("</TR>")

                    For Each row As DataRow In dt_report.Rows
                        exceltable.AppendFormat("<TR>")

                        exceltable.AppendFormat(String.Concat("<TD>", row("TGL TRANSAKSI").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("JENIS TRANSAKSI").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("JUMLAH").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("HARGA/UNIT").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("JUMLAH UNIT").ToString(), "</TD>"))
                        exceltable.AppendFormat(String.Concat("<TD>", row("TOTAL UNIT").ToString(), "</TD>"))

                        exceltable.AppendFormat("</TR>")
                    Next

                    exceltable.Append("</TABLE></td></tr></table></BODY></HTML>")

                    Dim file As System.IO.StreamWriter = New System.IO.StreamWriter(Server.MapPath("~/File/" & sFileName))
                    file.WriteLine(exceltable.ToString)
                    file.Close()
                Next

            Else
                ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
                "alert('Data Tidak Ditemukan.'); window.location='ReportAccountBalance.aspx';", True)
            End If

        Catch ex As Exception

        End Try
    End Sub
End Class