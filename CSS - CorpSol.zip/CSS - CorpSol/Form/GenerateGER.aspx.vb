﻿Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.Office.Interop
Imports Microsoft.Office.Interop.Excel
Imports System.Reflection

Partial Public Class GenerateGER
    Inherits System.Web.UI.Page

    Dim SQL, SQL1, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindGrid("", "", "", "")
        Else
            GENERATE_GER()

            BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, txtwhopaid.Text.Trim)

        End If

    End Sub
    Public Sub BindGrid(ByVal CLAMNUM As String, ByVal CHDRNUM As String, ByVal INVOICE As String, ByVal WHOPAID As String)
        Try

            SQL = "SELECT CLAMNUM  + '-' + GCOCCNO as [CLAIM NUMBER], CHDRNUM as [POLIS NO], MBRNO as [NO PESERTA], DPNTNO as [DEPENDENT NO], CLIENT_CLAIM_REF as [INVOICE NUMBER]," & _
              "GCSTS as [STATUS], WHOPAID, TLMBRSHR as [MEMBER SHARE], TLHMOSHR as [HMO SHARE] FROM Tbl_Bucket_Pembayaran " & _
              "WHERE CLAMNUM LIKE '%" & CLAMNUM & "%' AND CHDRNUM LIKE '%" & CHDRNUM & "%' AND CLIENT_CLAIM_REF LIKE '%" & INVOICE & "%' AND WHOPAID LIKE '%" & WHOPAID & "%' " & _
              "AND CONVERT(VARCHAR(8),DATIME,112)=20160303 AND [STATUS GER]=0 ORDER BY [CLAIM NUMBER]"
            Modul.SubBindGridView(SQL, GridGER)

            Dim dt_Count As New System.Data.DataTable
            SQL = "SELECT COUNT(0) FROM Tbl_Bucket_Pembayaran " & _
                  "WHERE CLAMNUM LIKE '%" & CLAMNUM & "%' AND CHDRNUM LIKE '%" & CHDRNUM & "%' AND CLIENT_CLAIM_REF LIKE '%" & INVOICE & "%' AND WHOPAID LIKE '%" & WHOPAID & "%' " & _
                  "AND CONVERT(VARCHAR(8),DATIME,112)=20160303 AND [STATUS GER]=0"
            dt_Count = Modul.getAllDatainDT(SQL)

            lblTotRow.Text = "Total Data : " & dt_Count.Rows(0)(0).ToString().Trim & " Data "


        Catch ex As Exception

        End Try


    End Sub

    Private Sub GridGER_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridGER.PageIndexChanging
        GridGER.PageIndex = e.NewPageIndex
        BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtInvoice.Text.Trim, txtwhopaid.Text.Trim)
    End Sub

    Protected Sub btnGenerate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGenerate.Click

    End Sub

    Protected Sub GridGER_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridGER.SelectedIndexChanged

    End Sub

    Public Sub GENERATE_GER()

        Dim dt_report As New System.Data.DataTable

        dt_report.Columns.Add("Transdate")
        dt_report.Columns.Add("Policy No")
        dt_report.Columns.Add("Claim Type")
        dt_report.Columns.Add("Provorg")
        dt_report.Columns.Add("Claim No")
        dt_report.Columns.Add("Who Paid")
        dt_report.Columns.Add("Claim Client Ref No")
        dt_report.Columns.Add("First Report Date")
        dt_report.Columns.Add("Claim Form Received On")
        dt_report.Columns.Add("Member No")
        dt_report.Columns.Add("Member Name")
        dt_report.Columns.Add("Patient No")
        dt_report.Columns.Add("Patient Name")
        dt_report.Columns.Add("Admission Date")
        dt_report.Columns.Add("Discharge Date")
        dt_report.Columns.Add("Diagnosis Code")
        dt_report.Columns.Add("Procedure Code")
        dt_report.Columns.Add("Limit")
        dt_report.Columns.Add("Incurred")
        dt_report.Columns.Add("Paid")
        dt_report.Columns.Add("Cover")
        dt_report.Columns.Add("Unpaid")
        dt_report.Columns.Add("Excess")
        dt_report.Columns.Add("Remarks")
        dt_report.Columns.Add("Claim Status")
        dt_report.Columns.Add("Authorization Date")
        dt_report.Columns.Add("Submission Date")
        dt_report.Columns.Add("Payment Date")
        dt_report.Columns.Add("GER No 1")
        dt_report.Columns.Add("GER No 2")
        dt_report.Columns.Add("GER Date")
        dt_report.Columns.Add("Date Letter AXA")
        dt_report.Columns.Add("User ID")
        dt_report.Columns.Add("Tick")
        dt_report.Columns.Add("Payment Type")
        dt_report.Columns.Add("Manual")

        'Dim lblCell As Label = GridGER.Rows(0).Cells(6).FindControl("lblWHOPAID")
        'Dim lblwhopaid As String = lblCell.Text
        Dim GER As String = GenerateID()
        For Each row As GridViewRow In GridGER.Rows
            If row.RowType = DataControlRowType.DataRow Then
                Dim chkRowGER As System.Web.UI.WebControls.CheckBox = TryCast(row.Cells(0).FindControl("chkRowGER"), System.Web.UI.WebControls.CheckBox)
                If chkRowGER.Checked Then
                    Dim ClaimNumber As String = TryCast(row.Cells(2).FindControl("lblClaim"), System.Web.UI.WebControls.Label).Text
                    Dim PolisNo As String = TryCast(row.Cells(2).FindControl("lblPOLISNO"), System.Web.UI.WebControls.Label).Text
                    Dim Invoice As String = TryCast(row.Cells(2).FindControl("lblINVOICE"), System.Web.UI.WebControls.Label).Text
                    Dim WhoPaid As String = TryCast(row.Cells(2).FindControl("lblWHOPAID"), System.Web.UI.WebControls.Label).Text
                    SQL = "INSERT INTO Tbl_GER "
                    SQL1 = "SELECT CONVERT(VARCHAR(10),GETDATE(),103) as TRANSDATE,B.CHDRNUM as [POLIS NO],PRODTYP as [CLAIM TYPE],'''' + PROVORG as PROVORG," & _
                           "B.CLAMNUM  + '-' + B.GCOCCNO as [CLAIM NO],WHOPAID as [Who Paid],CLIENT_CLAIM_REF as [Claim Client Ref No],GCFRPDTE as [First Report Date]," & _
                           "RECVD_DATE as [Claim Form Received On],B.MBRNO + '-00' as [Member No],C.MBRNAME as [Member Name],B.MBRNO + '-' + D.DPNTNO as [Patient No],D.MBRNAMEED as [Patient Name]," & _
                           "CONVERT(VARCHAR(10),CONVERT(date,CAST(DTEVISIT AS VARCHAR(8))),103) as [Admission Date],CONVERT(VARCHAR(10),CONVERT(date,CAST(DTEDCHRG AS VARCHAR(8))),103) as [Discharge Date]," & _
                           "B.GCDIAGCD as [Diagnosis Code],F.SRVCCODE AS [Procedure Code],0 as [LIMIT],INCURRED, " & _
                           "CASE WHEN WHOPAID='P' THEN HMOSHARE + MBRSHARE WHEN WHOPAID='C' THEN HMOSHARE END as [PAID],HMOSHARE as [COVER]," & _
                           "CASE WHEN WHOPAID='P' THEN 0 WHEN WHOPAID='C' THEN MBRSHARE END as [UNPAID]," & _
                           "0 as [EXCESS],INVOICENO as [REMARKS],GCSTS as [CLAIM STATUS],CONVERT(VARCHAR(10),CONVERT(date,CAST(DATEAUTH AS VARCHAR(8))),103) as [AUTHORIZATION DATE]," & _
                           "'' as [SUBMISSION DATE],'' as [PAYMENT DATE],'''' + '" & GER & "' as [GER No 1],'' as [GER No 2],'' as [GER Date],'' as [Date Letter AXA],B.USER_PROFILE as [USER ID],'' as TICK,'' as [PAYMENT DATE],'' as [MANUAL]" & _
                           "FROM Tbl_Bucket_Pembayaran B LEFT JOIN ( SELECT gmhdpf.CHDRNUM,gmhdpf.MBRNO,clntpf.LSURNAME as MBRNAME FROM GMHDPF INNER JOIN CLNTPF ON GMHDPF.CLNTNUM = Clntpf.CLNTNUM " & _
                           "WHERE CLNTPF.VALIDFLAG = '1' AND gmhdpf.DPNTNO = '00') C ON B.CHDRNUM=C.CHDRNUM AND B.MBRNO=C.MBRNO LEFT JOIN ( SELECT gmhdpf.CHDRNUM,gmhdpf.DPNTNO,gmhdpf.MBRNO,clntpf.LSURNAME as MBRNAMEED " & _
                           "FROM GMHDPF INNER JOIN CLNTPF on GMHDPF.CLNTNUM = Clntpf.CLNTNUM where CLNTPF.VALIDFLAG = '1' ) D ON D.CHDRNUM=C.CHDRNUM AND D.MBRNO=C.MBRNO AND B.DPNTNO=D.DPNTNO " & _
                           "LEFT JOIN GCLDPF F ON B.CLAMNUM=F.CLAMNUM AND B.GCOCCNO=F.GCOCCNO " & _
                           "WHERE  B.CLAMNUM LIKE '%" & Left(ClaimNumber, 8).Trim & "%' AND B.CHDRNUM LIKE '%" & PolisNo.Trim & "%' AND B.CLIENT_CLAIM_REF LIKE '%" & Invoice.Trim & "%' AND B.WHOPAID LIKE '%" & WhoPaid.Trim & "%' " & _
                           "AND CONVERT(VARCHAR(8),B.DATIME,112)=20160303 AND [STATUS GER]=0"
                    Modul.Eksekusi(SQL & SQL1)

                    Dt = Modul.getAllDatainDT(SQL1)

                    For x = 0 To Dt.Rows.Count - 1
                        dt_report.Rows.Add(Dt.Rows(x).Item(0).ToString.ToUpper(), Dt.Rows(x).Item(1).ToString.ToUpper(), Dt.Rows(x).Item(2).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(3).ToString.ToUpper(), Dt.Rows(x).Item(4).ToString.ToUpper(), Dt.Rows(x).Item(5).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(6).ToString.ToUpper(), Dt.Rows(x).Item(7).ToString.ToUpper(), Dt.Rows(x).Item(8).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(9).ToString.ToUpper(), Dt.Rows(x).Item(10).ToString.ToUpper(), Dt.Rows(x).Item(11).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(12).ToString.ToUpper(), Dt.Rows(x).Item(13).ToString.ToUpper(), Dt.Rows(x).Item(14).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(15).ToString.ToUpper(), Dt.Rows(x).Item(16).ToString.ToUpper(), Dt.Rows(x).Item(17).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(18).ToString.ToUpper(), Dt.Rows(x).Item(19).ToString.ToUpper(), Dt.Rows(x).Item(20).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(21).ToString.ToUpper(), Dt.Rows(x).Item(22).ToString.ToUpper(), Dt.Rows(x).Item(23).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(24).ToString.ToUpper(), Dt.Rows(x).Item(25).ToString.ToUpper(), Dt.Rows(x).Item(26).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(27).ToString.ToUpper(), Dt.Rows(x).Item(28).ToString.ToUpper(), Dt.Rows(x).Item(29).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(30).ToString.ToUpper(), Dt.Rows(x).Item(31).ToString.ToUpper(), Dt.Rows(x).Item(32).ToString.ToUpper(), _
                                           Dt.Rows(x).Item(33).ToString.ToUpper(), Dt.Rows(x).Item(34).ToString.ToUpper(), Dt.Rows(x).Item(35).ToString.ToUpper())
                    Next

                    SQL = "UPDATE Tbl_Bucket_Pembayaran SET [STATUS GER] = 1 " & _
                          "WHERE  CLAMNUM LIKE '%" & Left(ClaimNumber, 8).Trim & "%' AND CHDRNUM LIKE '%" & PolisNo.Trim & "%' AND CLIENT_CLAIM_REF LIKE '%" & Invoice.Trim & "%' AND WHOPAID LIKE '%" & WhoPaid.Trim & "%' " & _
                          "AND CONVERT(VARCHAR(8),DATIME,112)=20160303"
                    Modul.Eksekusi(SQL)

                End If
            End If
        Next

        If dt_report.Rows.Count > 0 Then
            Dim sFileName As String = ""

            Dim sysdate As Date = Date.Now.Date

            If dt_report.Rows(0).Item(5).ToString.ToUpper = "P" Then
                sFileName = "KLAIM PROVIDER " & Replace(sysdate.ToString("dd/MM/yyyy"), "/", "") & ".xls"
            ElseIf dt_report.Rows(0).Item(5).ToString.ToUpper = "C" Then
                sFileName = "KLAIM REIMBURSEMENT " & Replace(sysdate.ToString("dd/MM/yyyy"), "/", "") & ".xls"
            End If

            Dim GridView1 As New GridView()
            GridView1.AllowPaging = False
            GridView1.DataSource = dt_report
            GridView1.DataBind()

            Response.Clear()
            Response.Buffer = True
            Response.AddHeader("Content-Disposition", "inline; filename=" + sFileName)
            Response.Charset = ""
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Me.EnableViewState = False
            Response.ContentType = "application/vnd.ms-excel"
            Dim StringWrite As New System.IO.StringWriter
            Dim HtmlWrite As New System.Web.UI.HtmlTextWriter(StringWrite)
            
            GridView1.RenderControl(HtmlWrite)

            Response.AddHeader("X-Download-Options", "noopen")

            'Remove the charset from the Content-Type header.
            Dim style As String = "<style> .text { mso-number-format:\@; } </style> "
            Response.Write(style)

            Response.Write(StringWrite.ToString())
            Response.End()
        End If

    End Sub

    Public Sub ReleaseComObject(ByVal reference As Object)
        Try
            While System.Runtime.InteropServices.Marshal.ReleaseComObject(reference) <= 0
            End While
        Catch
        End Try
    End Sub

    Private Function GenerateID()
        Dim dt As New System.Data.DataTable
        Dim mydate As Date
        Dim GERNO As Integer
        Dim numbering As String
        Dim ID As String

        mydate = Date.Now

        SQL = ""
        SQL = "SELECT MAX([GER NO 1]) FROM Tbl_GER "
        Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
        Modul.SQLAdp.Fill(dt)

        If dt.Rows(0).Item(0).ToString <> "" Then
            GERNO = Val(Microsoft.VisualBasic.Right(dt.Rows(0).Item(0).ToString, 4) + 1)
            numbering = Microsoft.VisualBasic.Right("0000" & GERNO, 4)
            ID = numbering

            If ID > 9999 Then
                ID = "0001"
            End If
        Else
            ID = "0001"
        End If

        Return ID
    End Function
End Class