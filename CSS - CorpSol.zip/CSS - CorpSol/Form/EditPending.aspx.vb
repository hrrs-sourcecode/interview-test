﻿Imports System.Data
Imports System.Data.SqlClient

Partial Public Class EditPending
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim dr As SqlDataReader
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            DropFill_Reason()
            BindGrid("", "", "", "", "")
            trDetailTitle.Visible = False
            trGridDetail.Visible = False
            trInfoDetail.Visible = False
            trDetail.Visible = False
            trInfoHistory.Visible = False
            trHistory.Visible = False
            lblEdit.Visible = False
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If

            BindGrid(txtCLMNUM.Text, txtPolis.Text, txtMember.Text, txtclientclaimref.Text, ddl_reason.SelectedValue.Trim)
            lblEdit.Visible = False
        End If

    End Sub
    Public Sub DropFill_Reason()
        Dim ListTemp As ListItem

        ddl_reason.Items.Clear()
        ListTemp = New ListItem("All", "")
        ddl_reason.Items.Add(ListTemp)

        SQL = "SELECT Reason,Reason FROM Mst_Reason"

        dr = Modul.getAllDatainDR(SQL)

        While dr.Read
            ListTemp = New ListItem(dr(1), dr(0))
            ddl_reason.Items.Add(ListTemp)
        End While

        dr.Close()
        Modul.SQLCn.Close()

    End Sub
    Public Sub BindGrid(ByVal CLAMNUM As String, ByVal POLIS As String, ByVal MEMBERNO As String, ByVal CLAIMREFNO As String, ByVal REASON As String)
        Try
            SQL = "SELECT DISTINCT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],CHDRNUM as [POLIS NO],MBRNO + '-' + DPNTNO as [NO PESERTA]," & _
                  "CLNTNUM as [NO CLIENT],GCSTS as [STATUS G400],PRODTYP as PRODUCT,CONVERT(VARCHAR,CONVERT(DATETIME,CAST(DTEVISIT as VARCHAR)),103) as [DATE VISIT]," & _
                  "D.LONGDESC as DIAGNOSA,PLANNO as [NO PLAN],PROVORG as [NO PROVIDER]," & _
                  "P.CLIENT_CLAIM_REF,P.WHOPAID,CONVERT(varchar, CAST(TLMBRSHR AS money), 1) as [MEMBER SHARE]," & _
                  "CONVERT(varchar, CAST(TLHMOSHR AS money), 1) as [HMOSHARE],P.GCAUTHBY as [AUTHORIZED BY]," & _
                  "R.Reason as [REASON HOLD],A.NOTE as NOTE FROM Tbl_Bucket_Pending P LEFT JOIN Mst_Reason R ON P.REASON=R.Code_Reason " & _
                  "LEFT JOIN DESCPF D ON 'E' + P.GCDIAGCD=D.DESCITEM LEFT JOIN Tbl_Approval A ON P.CLAMNUM=LEFT(A.[CLAIM NUMBER],8) AND P.GCOCCNO=RIGHT(A.[CLAIM NUMBER],2) " & _
                  "WHERE CLAMNUM LIKE '%" & Left(CLAMNUM, 8) & "%' AND GCOCCNO LIKE '%" & Right(CLAMNUM, 2) & "%' AND D.LONGDESC <>'NA' AND D.LONGDESC <>'N/A' AND D.DESCPFX='IT' AND D.DESCTABL='T9697' AND StatusPending=0 " & _
                  "AND CHDRNUM LIKE '%" & POLIS & "%' AND MBRNO LIKE '%" & MEMBERNO & "%' AND P.CLIENT_CLAIM_REF LIKE '%" & CLAIMREFNO & "%' AND R.REASON LIKE '%" & REASON & "%'" & _
                  "UNION " & _
                  "SELECT DISTINCT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],CHDRNUM as [POLIS NO],MBRNO + '-' + DPNTNO as [NO PESERTA]," & _
                  "CLNTNUM as [NO CLIENT],GCSTS as [STATUS G400],PRODTYP as PRODUCT,CONVERT(VARCHAR,CONVERT(DATETIME,CAST(DTEVISIT as VARCHAR)),103) as [DATE VISIT]," & _
                  "D.LONGDESC as DIAGNOSA,PLANNO as [NO PLAN],PROVORG as [NO PROVIDER]," & _
                  "P.CLIENT_CLAIM_REF,P.WHOPAID,CONVERT(varchar, CAST(TLMBRSHR AS money), 1) as [MEMBER SHARE]," & _
                  "CONVERT(varchar, CAST(TLHMOSHR AS money),1) as [HMOSHARE],P.GCAUTHBY as [AUTHORIZED BY]," & _
                  "R.Reason as [REASON HOLD],A.NOTE as NOTE FROM TRN_HDR_SPECIAL_CASE P LEFT JOIN Mst_Reason R ON P.REASON=R.Code_Reason " & _
                  "LEFT JOIN DESCPF D ON 'E' + P.GCDIAGCD=D.DESCITEM LEFT JOIN Tbl_Approval A ON P.CLAMNUM=LEFT(A.[CLAIM NUMBER],8) AND P.GCOCCNO=RIGHT(A.[CLAIM NUMBER],2) " & _
                  "WHERE CLAMNUM LIKE '%" & Left(CLAMNUM, 8) & "%' AND GCOCCNO LIKE '%" & Right(CLAMNUM, 2) & "%' AND D.LONGDESC <>'NA' AND D.LONGDESC <>'N/A' AND D.DESCPFX='IT' AND D.DESCTABL='T9697' AND StatusPending=0 " & _
                  "AND CHDRNUM LIKE '%" & POLIS & "%' AND MBRNO LIKE '%" & MEMBERNO & "%' AND P.CLIENT_CLAIM_REF LIKE '%" & CLAIMREFNO & "%' AND R.REASON LIKE '%" & REASON & "%' ORDER BY [CLAIM NUMBER]"
            Modul.SubBindGridView(SQL, GridPending)

            If GridPending.Rows.Count = 0 Then
                trDetailTitle.Visible = False
                trGridDetail.Visible = False
                trInfoDetail.Visible = False
                trDetail.Visible = False
                trInfoHistory.Visible = False
                trHistory.Visible = False
                lblEdit.Visible = False
            End If
        Catch ex As Exception
            Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
    End Sub
    Public Sub BindGridDetail(ByVal CLAMNUM As String, ByVal GCOCCNO As String)
        Try
            SQL = "SELECT DISTINCT * FROM (SELECT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],SRVCCODE,CONVERT(varchar, CAST(INCURRED AS money), 1) as INCURRED,CONVERT(varchar, CAST(PAYPROV AS money), 1) as PAYPROV,CONVERT(varchar, CAST(MBRSHARE AS money), 1) as MBRSHARE," & _
              "CONVERT(varchar, CAST(HMOSHARE AS money),1) as [HMOSHARE],BENCDE,USER_PROFILE " & _
              "FROM Tbl_Duplicate_GCLDPF WHERE CLAMNUM='" & CLAMNUM & "' AND GCOCCNO='" & GCOCCNO & "' " & _
              "UNION " & _
              "SELECT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],SRVCCODE,CONVERT(varchar, CAST(INCURRED AS money), 1) as INCURRED,CONVERT(varchar, CAST(PAYPROV AS money), 1) as PAYPROV,CONVERT(varchar, CAST(MBRSHARE AS money), 1) as MBRSHARE," & _
              "CONVERT(varchar, CAST(HMOSHARE AS money), 1)as [HMOSHARE],BENCDE,USER_PROFILE " & _
              "FROM TRN_DTL_SPECIAL_CASE WHERE CLAMNUM='" & CLAMNUM & "' AND GCOCCNO='" & GCOCCNO & "' ) a ORDER BY [CLAIM NUMBER]"

            'SQL = "SELECT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],SRVCCODE,INCURRED,PAYPROV,MBRSHARE," & _
            '      "HMOSHARE,BENCDE,USER_PROFILE FROM Tbl_Duplicate_GCLDPF WHERE CLAMNUM='" & Left(myLinkButton.Text, 8) & "' ORDER BY CLAMNUM"
            Modul.SubBindGridView(SQL, gridDetail)
        Catch ex As Exception
            Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
        

    End Sub
    Public Sub BindGridHistory(ByVal CLAMNUM As String, ByVal GCOCCNO As String)
        Try
            SQL = "SELECT DISTINCT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],CHDRNUM as [POLIS NO],MBRNO + '-' + DPNTNO as [NO PESERTA]," & _
             "CLNTNUM as [NO CLIENT],GCSTS as [STATUS G400],PRODTYP as PRODUCT,CONVERT(VARCHAR,CONVERT(DATETIME,CAST(DTEVISIT as VARCHAR)),103) as [DATE VISIT]," & _
             "D.LONGDESC as DIAGNOSA,PLANNO as [NO PLAN],PROVORG as [NO PROVIDER]," & _
             "P.CLIENT_CLAIM_REF,P.WHOPAID,CONVERT(varchar, CAST(TLMBRSHR AS money), 1) as [MEMBER SHARE]," & _
              "(CONVERT(varchar, CAST(TLHMOSHR AS money), 1) as [HMOSHARE],P.USER_PROFILE as [USER PROFILE]" & _
             "FROM GCLHPF P LEFT JOIN DESCPF D ON  P.GCDIAGCD=D.DESCITEM " & _
             "WHERE CLAMNUM LIKE '%" & CLAMNUM & "%' AND GCOCCNO='" & GCOCCNO & "' AND D.LONGDESC <>'NA' AND D.LONGDESC <>'N/A' ORDER BY [CLAIM NUMBER]"

            'SQL = "SELECT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],SRVCCODE,INCURRED,PAYPROV,MBRSHARE," & _
            '      "HMOSHARE,BENCDE,USER_PROFILE FROM Tbl_Duplicate_GCLDPF WHERE CLAMNUM='" & Left(myLinkButton.Text, 8) & "' ORDER BY CLAMNUM"
            Modul.SubBindGridView(SQL, GridHistory)
        Catch ex As Exception
            Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try

    End Sub
    Private Sub GridPending_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridPending.PageIndexChanging
        GridPending.PageIndex = e.NewPageIndex
        BindGrid(txtCLMNUM.Text, txtPolis.Text, txtMember.Text, txtclientclaimref.Text, ddl_reason.SelectedValue.Trim)
    End Sub

    Private Sub GridPending_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridPending.RowCommand
        Try
            If e.CommandName = "SelectHeader" Then
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = GridPending.Rows(index)
                Dim myLinkButton As LinkButton
                myLinkButton = selectedRow.Cells(0).Controls(0)

                Session("CLAIM NUMBER") = myLinkButton.Text
                Session("POLIS NO") = selectedRow.Cells(1).Text
                Session("NO PESERTA") = selectedRow.Cells(2).Text
                Session("NO CLIENT") = selectedRow.Cells(3).Text
                Session("STATUS G400") = selectedRow.Cells(4).Text
                Session("PRODUCT") = selectedRow.Cells(5).Text
                Session("DATE VISIT") = selectedRow.Cells(6).Text
                Session("DIAGNOSA") = selectedRow.Cells(7).Text
                Session("NO PLAN") = selectedRow.Cells(8).Text
                Session("NO PROVIDER") = selectedRow.Cells(9).Text
                Session("CLIENT_CLAIM_REF") = selectedRow.Cells(10).Text
                Session("WHOPAID") = selectedRow.Cells(11).Text
                Session("MEMBER SHARE") = selectedRow.Cells(12).Text
                Session("HMOSHARE") = selectedRow.Cells(13).Text
                Session("USER PROFILE") = selectedRow.Cells(14).Text
                Session("Reason") = selectedRow.Cells(15).Text
                Session("Note") = selectedRow.Cells(16).Text.Trim

                Session("ClaimNum") = Left(myLinkButton.Text, 8)
                Session("GCOCCNO") = Right(myLinkButton.Text, 2)

                BindGridDetail(Session("ClaimNum"), Right(myLinkButton.Text, 2))
                BindGridHistory(Session("ClaimNum"), Right(myLinkButton.Text, 2))
                
                If Session("Reason") = "Exception Policy" Then
                    txtMBRSHARE.ReadOnly = True
                    txtHMOSHARE.ReadOnly = True
                    btnEditData.Visible = False
                    btnSubmit.Visible = True
                Else
                    txtMBRSHARE.ReadOnly = False
                    txtHMOSHARE.ReadOnly = False
                    btnEditData.Visible = True
                    btnSubmit.Visible = True
                End If

                trDetailTitle.Visible = True
                trGridDetail.Visible = True
                gridDetail.Visible = True
                lblDetailData.Visible = True
                trHistory.Visible = True
                trInfoHistory.Visible = True
                GridHistory.Visible = True
                lblHistoryData.Visible = True
            End If
        Catch ex As Exception
            Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
        
    End Sub

    Private Sub gridDetail_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gridDetail.PageIndexChanging
        gridDetail.PageIndex = e.NewPageIndex
        BindGrid(txtCLMNUM.Text, txtPolis.Text, txtMember.Text, txtclientclaimref.Text, ddl_reason.SelectedValue.Trim)
    End Sub

    Private Sub gridDetail_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles gridDetail.RowCommand
        If e.CommandName = "SelectDetail" Then
            Try
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = gridDetail.Rows(index)
                Dim myLinkButton As LinkButton
                myLinkButton = selectedRow.Cells(0).Controls(0)

                trInfoDetail.Visible = True
                trDetail.Visible = True
                txtCLMNUMDetail.Text = myLinkButton.Text
                txtSRVCCODE.Text = selectedRow.Cells(1).Text
                txtINCURRED.Text = Replace(selectedRow.Cells(2).Text, ",", "")
                txtPAYPROV.Text = Replace(selectedRow.Cells(3).Text, ",", "")
                txtMBRSHARE.Text = Replace(selectedRow.Cells(4).Text, ",", "")
                txtHMOSHARE.Text = Replace(selectedRow.Cells(5).Text, ",", "")
                txtBENCDE.Text = selectedRow.Cells(6).Text
                txtNote.Text = IIf(Session("Note") = "&nbsp;", "", Session("Note"))

                If Session("Reason") = "Exception Policy" Then
                    txtMBRSHARE.ReadOnly = True
                    txtHMOSHARE.ReadOnly = True
                    btnEditData.Visible = False
                    btnSubmit.Visible = True
                Else
                    txtMBRSHARE.ReadOnly = False
                    txtHMOSHARE.ReadOnly = False
                    btnEditData.Visible = True
                    btnSubmit.Visible = True
                End If
            Catch ex As Exception
                Response.Redirect("~/Form/PageUnavailable.aspx", False)
                'MsgBox(ex.Message)
                'Throw (ex)
            End Try
            
        End If
    End Sub

    Protected Sub gridDetail_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles gridDetail.SelectedIndexChanged

    End Sub

    Protected Sub btnEditData_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnEditData.Click
        Try

            Dim _CLMNUMDetail As String = ""
            Dim _SRVCCODE As String = ""
            Dim _INCURRED As Integer = 0
            Dim _PAYPROV As Integer = 0
            Dim _MBRSHARE As Integer = 0
            Dim _HMOSHARE As Integer = 0
            Dim _BENCDE As String = ""
            Dim _USER_PROFILE As String = ""

            _CLMNUMDetail = txtCLMNUMDetail.Text.Trim
            _SRVCCODE = txtSRVCCODE.Text.Trim
            _INCURRED = txtINCURRED.Text.Trim
            _PAYPROV = txtPAYPROV.Text.Trim
            _BENCDE = txtBENCDE.Text.Trim

            If Trim(txtMBRSHARE.Text.Trim) = "" Or Trim(txtMBRSHARE.Text.Trim) = "" Then
                lblEdit.Visible = True
                lblEdit.Text = "MBRSHARE atau HMOSHARE kosong."
                Exit Sub
            Else
                _MBRSHARE = txtMBRSHARE.Text.Trim
                _HMOSHARE = txtHMOSHARE.Text.Trim
            End If

            SQL = "UPDATE Tbl_Duplicate_GCLDPF SET MBRSHARE=" & _MBRSHARE & ",HMOSHARE=" & _HMOSHARE & " WHERE CLAMNUM='" & Left(_CLMNUMDetail, 8) & "' AND SRVCCODE='" & _SRVCCODE & "' AND GCOCCNO='" & Right(_CLMNUMDetail, 2) & "'"
            Modul.Eksekusi(SQL)

            SQL = "UPDATE TRN_DTL_SPECIAL_CASE SET MBRSHARE=" & _MBRSHARE & ",HMOSHARE=" & _HMOSHARE & " WHERE CLAMNUM='" & Left(_CLMNUMDetail, 8) & "' AND SRVCCODE='" & _SRVCCODE & "' GCOCCNO='" & Right(_CLMNUMDetail, 2) & "'"
            Modul.Eksekusi(SQL)

            SQL = "SELECT DISTINCT * FROM (SELECT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],SRVCCODE,CONVERT(varchar, CAST(INCURRED AS money), 1)as INCURRED,CONVERT(varchar, CAST(PAYPROV AS money), 1)  as PAYPROV,CONVERT(varchar, CAST(MBRSHARE AS money), 1) as MBRSHARE," & _
                  "CONVERT(varchar, CAST(HMOSHARE AS money), 1) as [HMOSHARE],BENCDE,USER_PROFILE " & _
                  "FROM Tbl_Duplicate_GCLDPF WHERE CLAMNUM='" & Session("ClaimNum") & "' AND GCOCCNO='" & Session("GCOCCNO") & "' " & _
                  "UNION " & _
                  "SELECT CLAMNUM + '-' + GCOCCNO as [CLAIM NUMBER],SRVCCODE,CONVERT(varchar, CAST(INCURRED AS money), 1) as INCURRED,CONVERT(varchar, CAST(PAYPROV AS money), 1) as PAYPROV,CONVERT(varchar, CAST(MBRSHARE AS money), 1) as MBRSHARE," & _
                  "CONVERT(varchar, CAST(HMOSHARE AS money), 1) as [HMOSHARE],BENCDE,USER_PROFILE " & _
                  "FROM TRN_DTL_SPECIAL_CASE WHERE CLAMNUM='" & Session("ClaimNum") & "' AND GCOCCNO='" & Session("GCOCCNO") & "' ) a ORDER BY [CLAIM NUMBER]"
            
            Modul.SubBindGridView(SQL, gridDetail)


            lblEdit.Visible = True
            lblEdit.Text = "Update Data Sukses. Silahkan Klik Tombol Submit To Manager Untuk Meminta Approval Manager."
            

        Catch ex As Exception
            Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmit.Click
        Dim QueryCount, QueryCheck As String
        Dim dt_check, dt_count As New DataTable

        Try

            QueryCount = "SELECT CLAMNUM as CLAMNUM_DETAIL,SUM(MBRSHARE) as TLMBRSHR_DETAIL,SUM(HMOSHARE) as TLHMOSHR_DETAIL FROM Tbl_Duplicate_GCLDPF " & _
                         "WHERE CLAMNUM='" & Session("ClaimNum") & "' AND GCOCCNO='" & Session("GCOCCNO") & "' GROUP BY CLAMNUM " & _
                         "UNION " & _
                         "SELECT CLAMNUM as CLAMNUM_DETAIL,SUM(MBRSHARE) as TLMBRSHR_DETAIL,SUM(HMOSHARE) as TLHMOSHR_DETAIL FROM TRN_DTL_SPECIAL_CASE " & _
                         "WHERE CLAMNUM='" & Session("ClaimNum") & "' AND GCOCCNO='" & Session("GCOCCNO") & "' GROUP BY CLAMNUM"
            dt_count = Modul.getAllDatainDT(QueryCount)

            If Session("Reason") <> "Special Case" Then
                If dt_count.Rows.Count > 0 Then
                    Session("MBRShareHeader") = dt_count.Rows(0)(1).ToString()
                    Session("HMOShareHeader") = dt_count.Rows(0)(2).ToString()
                End If

                If Session("MEMBER SHARE") <> Session("MBRShareHeader") Or Session("HMOSHARE") <> Session("HMOShareHeader") Then
                    lblEdit.Visible = True
                    lblEdit.Text = "Jumlah Amount Detail Tidak Sesuai. Harap Check Data Kembali...!!!"
                    Exit Sub
                End If
            End If
            

            QueryCheck = "SELECT * FROM Tbl_Approval WHERE [CLAIM NUMBER]='" & Session("CLAIM NUMBER") & "'"
            dt_check.Columns.Clear()
            dt_check = Modul.getAllDatainDT(QueryCheck)


            If dt_check.Rows.Count > 0 Then
                SQL = "UPDATE Tbl_Approval SET NOTE='" & txtNote.Text.Trim & "',[STATUS APPROVE]=0 WHERE [CLAIM NUMBER]='" & Session("CLAIM NUMBER") & "'"
                Modul.Eksekusi(SQL)

                SQL = "UPDATE Tbl_Bucket_Pending SET StatusPending=1 WHERE CLAMNUM='" & Session("ClaimNum") & "' AND GCOCCNO='" & Session("GCOCCNO") & "'"
                Modul.Eksekusi(SQL)

                SQL = "UPDATE TRN_HDR_SPECIAL_CASE SET StatusPending=1 WHERE CLAMNUM='" & Session("ClaimNum") & "' AND GCOCCNO='" & Session("GCOCCNO") & "'"
                Modul.Eksekusi(SQL)
            Else
                SQL = "UPDATE Tbl_Bucket_Pending SET StatusPending=1 WHERE CLAMNUM='" & Session("ClaimNum") & "' AND GCOCCNO='" & Session("GCOCCNO") & "'"
                Modul.Eksekusi(SQL)

                SQL = "UPDATE TRN_HDR_SPECIAL_CASE SET StatusPending=1 WHERE CLAMNUM='" & Session("ClaimNum") & "' AND GCOCCNO='" & Session("GCOCCNO") & "'"
                Modul.Eksekusi(SQL)

                SQL = "INSERT INTO Tbl_Approval VALUES ('" & Session("CLAIM NUMBER") & "','" & Session("POLIS NO") & "','" & Session("NO PESERTA") & "'," & _
                "'" & Session("NO CLIENT") & "','" & Session("STATUS G400") & "','" & Session("PRODUCT") & "','" & Session("DATE VISIT") & "'," & _
                "'" & Replace(Session("DIAGNOSA"), "'", "") & "','" & Session("NO PLAN") & "','" & Session("NO PROVIDER") & "','" & Session("CLIENT_CLAIM_REF") & "'," & _
                "'" & Session("WHOPAID") & "','" & Session("MEMBER SHARE") & "','" & Session("HMOSHARE") & "','" & Session("UserName") & "','" & Session("Reason") & "'," & _
                "'" & txtNote.Text.Trim & "',0)"
                Modul.Eksekusi(SQL)
            End If
            

            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
            "alert('Submit Data Sukses'); window.location='EditPending.aspx';", True)

        Catch ex As Exception
            Response.Redirect("~/Form/PageUnavailable.aspx", False)
            'MsgBox(ex.Message)
            'Throw (ex)
        End Try

        
    End Sub

    Protected Sub GridPending_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridPending.SelectedIndexChanged

    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click

    End Sub
End Class