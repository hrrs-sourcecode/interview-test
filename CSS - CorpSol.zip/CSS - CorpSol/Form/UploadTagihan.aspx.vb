﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.DirectoryServices
Imports System.Data.OleDb

Imports System.IO
Imports OfficeOpenXml
Imports OfficeOpenXml.Style
Partial Public Class UploadTagihan
    Inherits System.Web.UI.Page

    Dim SQL As String
    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim dt_Result As New DataTable
    Dim oUpdate As New UpdateBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
        End If
    End Sub


    'Protected Sub cmdSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSave.Click
    '    If Not txtUpload.HasFile Then
    '        ' Handle file
    '        Modul.UserMsgBox(Me, "File Can't Empty !!")
    '        Exit Sub
    '    End If

    '    Dim strFileName As String = txtUpload.PostedFile.FileName
    '    Dim filename As String = Path.GetFileName(strFileName)
    '    Dim new_path As String = Server.MapPath("Upload\") + filename

    '    txtUpload.PostedFile.SaveAs(new_path)


    '    'Dim uploadedFiles As HttpFileCollection = Request.Files
    '    Dim x As Integer = 0

    '    Dim MyConnection As OleDbConnection
    '    Dim MyCommand_Upload As OleDbDataAdapter
    '    Dim nSukses As Integer = 0
    '    Dim nGagal As Integer = 0


    '    'Do Until x = uploadedFiles.Count
    '    '    Dim userPostedFile As HttpPostedFile = uploadedFiles(x)
    '    '    Try
    '    '        If (userPostedFile.ContentLength > 0) Then

    '    Try

    '        Dim DtData_Upload As New DataTable

    '        MyConnection = New OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0; " & _
    '                            "data source='" & new_path & " '; " & "Extended Properties=Excel 12.0;")

    '        MyConnection.Open()

    '        Dim dbSchema As DataTable = MyConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
    '        Dim firstSheetName As String = dbSchema.Rows(0)("TABLE_NAME").ToString()

    '        MyCommand_Upload = New OleDbDataAdapter("SELECT * FROM [" & firstSheetName & "]", MyConnection)
    '        MyCommand_Upload.Fill(DtData_Upload)

    '        MyConnection.Close()

    '        System.IO.File.Delete(new_path)

    '        'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
    '        '    "alert('" & DtData_Upload.Rows.Count & "');;", True)

    '        'Exit Sub

    '        For i = 0 To DtData_Upload.Rows.Count - 1
    '            Try


    '                Dim noPolis As String = DtData_Upload.Rows(i).Item(0).ToString()

    '                If String.IsNullOrEmpty(noPolis) Then
    '                    Exit For
    '                End If

    '                Dim vPOLISNO As String = noPolis
    '                Dim vTANGGALTAGIHAN As String = DtData_Upload.Rows(i).Item("TANGGAL TAGIHAN").ToString


    '                If DtData_Upload.Rows(i).Item("TANGGAL TAGIHAN").ToString = "" Then
    '                    vTANGGALTAGIHAN = "1900-01-01"
    '                ElseIf IsDBNull(DtData_Upload.Rows(i).Item("TANGGAL TAGIHAN").ToString) = True Then
    '                    vTANGGALTAGIHAN = "1900-01-01"
    '                Else
    '                    vTANGGALTAGIHAN = CDate(DtData_Upload.Rows(i).Item("TANGGAL TAGIHAN")).ToString("yyyy-MM-dd")
    '                End If

    '                Dim vREMARK As String = DtData_Upload.Rows(i).Item("REMARK").ToString()

    '                nSukses += 1

    '                oUpdate.f_Update_Data_Tagihan(vPOLISNO, vTANGGALTAGIHAN, vREMARK.ToUpper())


    '                'If vREMARK = "Premi" Then
    '                '    oUpdate.f_Update_Data_Tagihan(vPOLISNO, vTANGGALTAGIHAN, vREMARK)
    '                'Else
    '                '    oUpdate.f_Update_Data_Tagihan(vPOLISNO, vTANGGALTAGIHAN, vREMARK)
    '                'End If

    '            Catch ex As Exception
    '                Modul.UserMsgBox(Me, "Error On Line : " & i.ToString + 1)
    '                DtData_Upload = Nothing
    '                'Throw (ex)
    '                'Exit Sub
    '            End Try

    '        Next

    '        nGagal = DtData_Upload.Rows.Count - nSukses
    '        LblSes.Text = nSukses.ToString & " Record"
    '        LblGal.Text = nGagal.ToString & " Record"

    '        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", _
    '        "alert('Upload Data Sukses');;", True)

    '        DtData_Upload = Nothing

    '    Catch ex As Exception
    '        Modul.UserMsgBox(Me, ex.Message)
    '        'Throw (ex)
    '        'Exit Sub
    '    End Try

    '    'System.IO.File.Delete(userPostedFile.FileName)

    'End Sub
    Protected Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        btn_result.Visible = False
        If Not txtUpload.HasFile Then
            ' Handle file
            Modul.UserMsgBox(Me, "File Can't Empty !!")
            Exit Sub
        End If

        Dim strFileName As String = txtUpload.PostedFile.FileName
        Dim filename As String = Path.GetFileName(strFileName)
        Dim new_path As String = Server.MapPath("Upload\") + filename

        txtUpload.PostedFile.SaveAs(new_path)
        Dim file_excel As New FileUpload
        file_excel = txtUpload
        'Upload_File_Excel(file_excel)
        If (file_excel.HasFile AndAlso IO.Path.GetExtension(file_excel.FileName) = ".xlsx") Then
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial
            Using excel = New ExcelPackage(file_excel.PostedFile.InputStream)
                'Claim_No	Tanggal_Tagihan	Remark
                dt_Result = New DataTable
                dt_Result.Columns.Add("Claim_No")
                dt_Result.Columns.Add("Tanggal_Tagihan")
                dt_Result.Columns.Add("Remark")
                dt_Result.Columns.Add("Status")
                dt_Result.Columns.Add("Error_Message")
                Dim nSukses As Integer = 0
                Dim nGagal As Integer = 0
                Dim tbl = New DataTable()
                Dim ws = excel.Workbook.Worksheets.First()
                Dim hasHeader = True ' change it if required '
                ' create DataColumns '
                For Each firstRowCell In ws.Cells(1, 1, 1, ws.Dimension.End.Column)
                    tbl.Columns.Add(If(hasHeader,
                                       firstRowCell.Text,
                                       String.Format("Column {0}", firstRowCell.Start.Column)))
                Next
                ' add rows to DataTable '
                Dim startRow = If(hasHeader, 2, 1)
                For rowNum = startRow To ws.Dimension.End.Row
                    Dim wsRow = ws.Cells(rowNum, 1, rowNum, ws.Dimension.End.Column)
                    Dim row = tbl.NewRow()
                    For Each cell In wsRow
                        row(cell.Start.Column - 1) = cell.Text
                    Next
                    tbl.Rows.Add(row)
                Next
                '[Claim_No], [Tanggal_Tagihan], [Remark]
                Dim lstColumn As New List(Of String)
                lstColumn.Add("Claim_No")
                lstColumn.Add("Tanggal_Tagihan")
                lstColumn.Add("Remark")

                Dim iColumnCheck As Integer = 0
                If (hasHeader = True And tbl.Rows.Count() > 0) Then
                    ' check column 
                    If (tbl.Columns.Count = lstColumn.Count) Then

                        Dim iColumnIndex As Integer = 0
                        For Each Column As DataColumn In tbl.Columns
                            Dim strTblColumnName As String = Column.ColumnName.Trim.ToLower
                            Dim strLstColumnName As String = lstColumn.Item(iColumnIndex).Trim.ToLower
                            If (strTblColumnName.Equals(strLstColumnName)) Then
                                iColumnCheck = iColumnCheck + 1
                            End If
                            iColumnIndex = iColumnIndex + 1
                        Next
                    End If
                End If
                Dim hasError As Boolean = False
                If (iColumnCheck = tbl.Columns.Count) Then
                    Dim iRowsUpdate As Integer = 0

                    For Each Row As DataRow In tbl.Rows
                        Try
                            '[Claim_No], [Tanggal_Tagihan], [Remark]
                            Dim noPolis As String = Row.Item("Claim_No").ToString().Trim

                            If String.IsNullOrEmpty(noPolis) Then
                                Exit For
                            End If

                            Dim vPOLISNO As String = noPolis
                            Dim vTANGGALTAGIHAN As String = ""
                            vTANGGALTAGIHAN = Row.Item("Tanggal_Tagihan").ToString.Trim()

                            If Row.Item("Tanggal_Tagihan").ToString = "" Then
                                vTANGGALTAGIHAN = "1900/01/01"
                            ElseIf IsDBNull(Row.Item("Tanggal_Tagihan")) Then
                                vTANGGALTAGIHAN = "1900/01/01"
                            Else
                                vTANGGALTAGIHAN = Row.Item("Tanggal_Tagihan").ToString.Trim() '

                            End If

                            Dim vREMARK As String = Row.Item("REMARK").ToString()


                            Dim iRet As Integer = 0
                            iRet = oUpdate.f_Update_Data_Tagihan(vPOLISNO, vTANGGALTAGIHAN, vREMARK.ToUpper())
                            If iRet > 0 Then
                                nSukses += 1
                                'add into dt_Result as sukses
                                dt_Result.Rows.Add(vPOLISNO, vTANGGALTAGIHAN, vREMARK, "Sukses", "")
                            Else
                                'add into dt_Result as gagal
                                dt_Result.Rows.Add(vPOLISNO, vTANGGALTAGIHAN, vREMARK, "Gagal", "Data tidak ditemukan atau status sudah PAID.")
                            End If

                            'nSukses += 1
                            'Modul.UserMsgBox(Me, "Upload File Excel Success.")
                        Catch ex As Exception
                            'Modul.UserMsgBox(Me, "Error Message : " & ex.Message.ToString)
                            'Throw (ex)
                            hasError = True
                            'add into dt_Result as gagal
                            dt_Result.Rows.Add(Row.Item("Claim_No").ToString(), Row.Item("Tanggal_Tagihan").ToString(), Row.Item("REMARK").ToString(), "Gagal", ex.Message.ToString)
                            'Exit For
                        End Try
                        iRowsUpdate = iRowsUpdate + 1
                    Next

                Else
                    Modul.UserMsgBox(Me, "File Excel Columns not match.")
                    'Dim msg = String.Format("Update fail created from excel-file Columns-count:{0} Rows-count:{1} Column as Data : {2}/{3}",
                    'tbl.Columns.Count, tbl.Rows.Count, iColumnCheck, lstColumn.Count)
                    'UploadStatusLabel.Text = msg
                End If
                nGagal = 0
                nGagal = tbl.Rows.Count - nSukses
                LblSes.Text = nSukses.ToString & " Record"
                LblGal.Text = nGagal.ToString & " Record"

                tbl = Nothing
            End Using


        Else
            If (file_excel.HasFile) Then
                ' Handle file
                Modul.UserMsgBox(Me, "File Excel must with extension .xlsx only !!")
                Exit Sub
            Else
                ' Handle file
                Modul.UserMsgBox(Me, "File Upload Can't Empty !!")
                Exit Sub
            End If
        End If
        If IsDBNull(dt_Result) = False Then

            If dt_Result.Rows.Count > 1 Then
                Session.Add("dt_Result_tagihan", dt_Result)
                btn_result.Visible = True
            End If

        End If

        file_excel.Dispose()
        txtUpload.Dispose()
    End Sub
    Protected Sub Btn_Template_Click(sender As Object, e As EventArgs) Handles Btn_Template.Click
        Try
            Dim sPath As String = Server.MapPath("~\TemplateFiles\")
            Response.Clear()
            Response.Charset = ""
            Response.ContentEncoding = System.Text.Encoding.UTF8
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;filename=Template_Tanggal_Tagihan_" + Now.ToString("yyyyMMdd_HHmmss") + ".xlsx")
            'Response.AppendHeader("Content-Disposition", "attachment;filename=Template_Premi_Tahunan.xlsx")
            Response.TransmitFile(sPath & "Template_Tanggal_Tagihan.xlsx")
            Response.Flush()
            Response.End()

        Catch ex As Exception
        End Try
    End Sub

    Protected Sub btn_result_Click(sender As Object, e As EventArgs) Handles btn_result.Click
        Try
            Dim dt_Result = New DataTable
            dt_Result = TryCast(Session("dt_Result_tagihan"), DataTable)
            If IsDBNull(dt_Result) = False Then

                If dt_Result.Rows.Count > 1 Then

                    Response.Clear()
                    Response.Charset = ""
                    Response.ContentEncoding = System.Text.Encoding.UTF8
                    Response.Cache.SetCacheability(HttpCacheability.NoCache)
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    Response.AddHeader("content-disposition", "attachment;filename=Upload_Tagihan_Result_" + Now.ToString("yyyy_MM_dd") + ".xlsx")

                    Using package = New ExcelPackage()
                        Dim ws As ExcelWorksheet =
                        package.Workbook.Worksheets.Add("Upload_Tagihan_Result")
                        ws.Cells("A1").LoadFromDataTable(dt_Result, True)
                        'Adding style to the header
                        ws.Row(1).Height = 20
                        Dim headerRowStyle = ws.Row(1).Style
                        headerRowStyle.Font.Bold = True
                        headerRowStyle.Font.Color.SetColor(System.Drawing.Color.Black)
                        ws.Row(1).Style.ShrinkToFit = False
                        ws.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center
                        ws.Cells(ws.Dimension.Address).AutoFitColumns()

                        Using MS As New System.IO.MemoryStream()
                            package.SaveAs(MS)
                            MS.WriteTo(Response.OutputStream)
                        End Using
                    End Using
                    Response.Flush()
                    Response.End()

                End If

            End If
        Catch ex As Exception

        End Try
    End Sub
End Class