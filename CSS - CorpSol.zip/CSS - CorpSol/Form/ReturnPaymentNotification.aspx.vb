﻿Imports System.IO
Imports System.Net.Mail
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports PdfSharp.Pdf
Imports PdfSharp.Pdf.IO
Imports PdfSharp.Pdf.Security

Partial Public Class ReturnPaymentNotification
    Inherits System.Web.UI.Page

    Dim SQL, SQL1, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New System.Data.DataTable
    Dim Dt_GridGER As New System.Data.DataTable
    Dim Obj_Insert As New InsertBase
    'Dim CrystalReportViewer1 As New CrystalReportViewer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If

            BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtCompany.Text.Trim, ddlStatus.SelectedValue)
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If

            If ViewState("SelectedRecords") IsNot Nothing Then
                Dim dt As DataTable = DirectCast(ViewState("SelectedRecords"), DataTable)
                ViewState("SelectedRecords") = dt
            End If

        End If

    End Sub

    Protected Sub CheckBox_CheckChanged(ByVal sender As Object, ByVal e As EventArgs)
    End Sub

    Protected Sub OnPaging(ByVal sender As Object, ByVal e As GridViewPageEventArgs) Handles GridGER.PageIndexChanging
        GridGER.PageIndex = e.NewPageIndex

        BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtCompany.Text.Trim, ddlStatus.SelectedValue)
    End Sub
    Public Sub BindGrid(ByVal CLAMNUM As String, ByVal POLICYNUM As String, ByVal COMPANY As String, ByVal Status As String)
        Try

            Dim dt_Grid_GER As New DataTable

            SQL = "select * from
	            (select 
		            paysur.GUID TransId, 
		            paysur.No_Claim ClaimNo,  
		            paysur.F07PNO PolicyNumber, 
		            prf.OwnerName PIC,
		            cast(format(paysur.F07AMT, 'N', 'id-ID') as varchar(30)) Nominal, 
		            paysur.F07BBACNO AccountNumber,
		            paysur.F07BNAM AccountName,
		            paysur.Owner_Name Company,
		            paysur.Status_Data [Status],
                    paysur.f07trntyp TransType,
                    paysur.Datecreate DateCreate,
		            (select top(1) SalesEmail from ReturnPaymentNotifSalesEmail where PolicyNo = paysur.F07PNO) SalesEmail, 
		            prf.RINTERNET Email,
                    --'arif.prasetyo@axa-mandiri.co.id' Email,
		            case when (select COUNT(1) from StatusPaymentPremiHistory hst where cast(paysur.GUID as varchar(100)) = hst.TransId) > 0 then 1
		            else 0
		            end IsEmailSent
	            from 
		            [PaymentSurroundingAMFS].[dbo].[GER_det] paysur,
		            (select
			            case 
				            when a.FOR_ATT_OF = '' then 
				            case
					            when CLTSEX = 'M' then 'BPK ' + SURNAME
					            when CLTSEX = 'F' then 'IBU ' + SURNAME
					            else SURNAME
				            end 
				            else a.FOR_ATT_OF 
			            end OwnerName, 
			            b.CHDRNUM PolNum,
			            c.RINTERNET,  
			            a.CLTADDR01 addr1, 
			            a.CLTADDR02 + ' ' + a.CLTADDR03 addr2, 
			            LTRIM(RTRIM(a.CLTADDR04)) + ' ' + LTRIM(RTRIM(a.CLTADDR05)) addr3
			            --+ ' ' + CLTPCODE addr3 
		            from 
			            CLNTPF a,
			            CHDRPF b left join CLEXPF c on b.COWNNUM = c.CLNTNUM
		            where 
			            a.CLNTNUM = b.COWNNUM) prf
	            where 
		            Dept_Code = '6052549' 
		            and paysur.f07trntyp in ('KLAIM SAVING', 'REFUND PREMI')
		            and prf.PolNum = paysur.F07PNO
		            and Status_Data is not null) res"

            'SQL = "select TransId, PolicyNumber, OwnerName, cast(format(Nominal, 'N', 'id-ID') as varchar(30)) Nominal, AccountNumber, AccountName, Company, Status,
            '           GenderOwner, Addr1, EmailAddress, IsEmailSent from StatusPaymentPremi "

            If Not String.IsNullOrEmpty(CLAMNUM) Then
                SQL1 += SQL1 + String.Format(" ClaimNo like '%{0}%'", CLAMNUM)
            End If

            If Not String.IsNullOrEmpty(POLICYNUM) Then
                If Not String.IsNullOrEmpty(SQL1) Then
                    SQL1 += " and "
                End If
                SQL1 += SQL1 + String.Format(" PolicyNumber like '%{0}%'", POLICYNUM)
            End If

            If Not String.IsNullOrEmpty(COMPANY) Then
                If Not String.IsNullOrEmpty(SQL1) Then
                    SQL1 += " and "
                End If
                SQL1 += SQL1 + String.Format(" Company like '%{0}%'", COMPANY)
            End If

            If Not String.IsNullOrEmpty(Status) Then
                If Not String.IsNullOrEmpty(SQL1) Then
                    SQL1 += " and "
                End If
                SQL1 += SQL1 + String.Format(" Status = '{0}'", Status)
            End If

            If Not String.IsNullOrEmpty(SQL1) Then
                SQL = SQL + " where " + SQL1
            End If

            SQL += " order by IsEmailSent asc, DateCreate desc , SalesEmail desc, PolicyNumber asc, TransId asc "

            dt_Grid_GER = Modul.getAllDatainDT(SQL)

            GridGER.DataSource = dt_Grid_GER
            GridGER.DataBind()

            lblTotRow.Text = dt_Grid_GER.Rows.Count.ToString()


        Catch ex As Exception
            Modul.UserMsgBox(Me, ex.Message.ToString)
            Throw (ex)
        End Try
    End Sub

    Protected Sub btnGenerate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnGenerate.Click
        Try
            PROCESSINGNOTIF()
            BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtCompany.Text.Trim, ddlStatus.SelectedValue)
        Catch ex As Exception
            DebugLogger.WriteLogStamp(ex.Message)
            DebugLogger.WriteLogStamp(ex.StackTrace)
        End Try
    End Sub

    Private Sub PROCESSINGNOTIF()
        Dim userName As String = Session("UserName")
        Dim lstQuery As New List(Of String)

        For i As Integer = 0 To GridGER.Rows.Count - 1
            Dim chk As CheckBox = DirectCast(GridGER.Rows(i).FindControl("chk"), CheckBox)
            If chk.Checked Then
                Dim picEmail As String = DirectCast(GridGER.Rows(i).FindControl("Label23"), Label).Text
                Dim policyNo As String = DirectCast(GridGER.Rows(i).FindControl("Label13"), Label).Text
                Dim docId As String = DirectCast(GridGER.Rows(i).FindControl("Label9"), Label).Text
                Dim ownerName As String = DirectCast(GridGER.Rows(i).FindControl("Label15"), Label).Text
                Dim salesEmail As String = DirectCast(GridGER.Rows(i).FindControl("LinkButton2"), LinkButton).Text
                Dim transType As String = DirectCast(GridGER.Rows(i).FindControl("Label25"), Label).Text
                Dim companyName As String = DirectCast(GridGER.Rows(i).FindControl("Label19"), Label).Text

                Dim emailTo = picEmail + ";CorporateSolutions-ClientRelations@axa-mandiri.co.id"

                If policyNo(0) = "7" Then
                    emailTo = salesEmail
                End If

                If String.IsNullOrEmpty(emailTo) Then
                    Throw New Exception("Email is not valid or empty")
                End If

                'sent email
                If SendEmail(emailTo, GenerateBodyEmail(ownerName), docId, policyNo, transType, companyName) Then
                    'update premi notif
                    'UpdateStatusPaymentPremi(GridGER.Rows(i).Cells(2).Text, GridGER.Rows(i).Cells(8).Text, userName)

                    'insert premi notif history
                    CreateStatusPaymentPremiHistory(docId, userName)
                End If
            End If
        Next
    End Sub

    Private Function GenerateBodyEmail(ByVal ownerName As String) As String
        Dim result As String = ""
        result += String.Format("Dear Bapak/Ibu,")
        result += String.Format("<br/><br/><p>Terima kasih atas kepercayaan yang telah diberikan kepada PT. AXA Mandiri Financial Services (''AXA Mandiri'') untuk memberikan perlindungan asuransi bagi karyawan Anda.</p>")
        result += String.Format("<p>Berikut kami lampirkan informasi status pembayaran atas perubahan kepesertaan polis Bapak/Ibu.<br/> Silakan gunakan nomor polis Bapak/Ibu sebagai password untuk membuka lampiran.</p>")
        result += String.Format("<p>Apabila Bapak/Ibu membutuhkan penjelasan lebih lanjut, silahkan menghubungi :")
        result += String.Format("<ul class='striped-list'><li>Customer Care Centre - Corporate Solutions melalui email : CorporateSolutions@axa-mandiri.co.id</li><li>Telepon 021 2958 5400 (khusus HRD).</li></ul></p>")
        result += String.Format("<p>Atas perhatian dan kerjasama yang diberikan kepada AXA Mandiri, kami ucapkan terima kasih.</p>")
        result += String.Format("<br/><br/>Hormat kami,")
        result += String.Format("<br/><br/><b>PT AXA Mandiri Financial Services</b>")
        Return result
    End Function

    Private Function SendEmail(ByVal EmailTo As String, ByVal EmailBody As String, ByVal ClaimNo As String, ByVal DocPass As String, ByVal TransType As String, ByVal CompanyName As String)
        Dim result = True

        Dim ConSql As String = ConfigurationManager.ConnectionStrings("ConSql").ConnectionString
        Dim ccEmail As String = ConfigurationManager.AppSettings("CcEmail").ToString

        Dim smtp As String = ConfigurationManager.AppSettings("smtp").ToString
        Dim port As String = ConfigurationManager.AppSettings("port").ToString
        Dim isAuth As String = ConfigurationManager.AppSettings("isAuth").ToString
        Dim username As String = ConfigurationManager.AppSettings("username").ToString
        Dim password As String = ConfigurationManager.AppSettings("password").ToString
        Dim mailServer As String = ConfigurationManager.AppSettings("mailServer").ToString
        Dim sender As String = ConfigurationManager.AppSettings("sender").ToString
        Dim subjectEmail As String = String.Format("Notifikasi Pengembalian Premi {0}", CompanyName)

        If TransType = "KLAIM SAVING" Then
            subjectEmail = String.Format("Notifikasi Pembayaran Manfaat Polis {0}", CompanyName)
        End If

        Dim dtEmail As New DataTable

        Dim mail As MailMessage = New MailMessage()
        Dim smtpServer As SmtpClient = New SmtpClient()

        smtpServer.UseDefaultCredentials = False
        smtpServer.Credentials = New System.Net.NetworkCredential(username, password)

        smtpServer.Port = Convert.ToInt16(port)
        smtpServer.EnableSsl = False
        smtpServer.Host = smtp
        mail.From = New MailAddress(mailServer, sender)

        EmailTo.Split(";").ToList().ForEach(Sub(d) mail.To.Add(d))
        mail.CC.Add(ccEmail)

        mail.Subject = subjectEmail
        mail.Body = EmailBody
        mail.IsBodyHtml = True

        Dim filePath As String = ProtectDoc(ClaimNo, DocPass)
        'Dim filePath As String = GenerateWordDoc(ClaimNo)
        Dim attachment As New Attachment(filePath)

        'Dim attachment As New Attachment(ProtectDoc3(ClaimNo), String.Format("Letter-ReturnPaymentNotification-{0}.pdf", ClaimNo), "application/pdf")

        mail.Attachments.Add(attachment)
        smtpServer.Send(mail)

        mail.Attachments.Dispose()

        'Delete attachment from temp file
        If File.Exists(filePath) Then
            File.Delete(filePath)
        End If

        Return result

    End Function

    'Private Function ProtectDoc(ByVal CLAIMNUM As String, ByVal POLICYNUM As String) As String
    '    Dim folderPath As String = System.Web.Hosting.HostingEnvironment.MapPath("~/TempFile")
    '    Dim pathLoc As String = String.Format("{0}\Letter-ReturnPaymentNotification-{1}.pdf", folderPath, CLAIMNUM)
    '    Dim fileInfo As FileInfo = New FileInfo(pathLoc)
    '    fileInfo.Directory.Create()

    '    Using output As Stream = New FileStream(pathLoc, FileMode.Create, FileAccess.Write, FileShare.Read)
    '        Dim reader As PdfReader = New PdfReader(GenerateWordDoc(CLAIMNUM))
    '        PdfEncryptor.Encrypt(reader, output, True, POLICYNUM, POLICYNUM, PdfWriter.ALLOW_SCREENREADERS)
    '    End Using

    '    Return pathLoc
    'End Function

    Private Function ProtectDoc(ByVal CLAIMNUM As String, ByVal POLICYNUM As String) As String
        Dim folderPath As String = System.Web.Hosting.HostingEnvironment.MapPath("~/TempFile")
        Dim pathLoc As String = String.Format("{0}\Letter-ReturnPaymentNotification-{1}.pdf", folderPath, CLAIMNUM)
        Dim fileInfo As FileInfo = New FileInfo(pathLoc)
        fileInfo.Directory.Create()

        Dim document As PdfDocument = PdfReader.Open(GenerateWordDoc(CLAIMNUM))
        Dim securitySettings As PdfSecuritySettings = document.SecuritySettings

        'securitySettings.UserPassword = "user"
        securitySettings.OwnerPassword = POLICYNUM

        securitySettings.PermitAccessibilityExtractContent = False
        securitySettings.PermitAnnotations = False
        securitySettings.PermitAssembleDocument = False
        securitySettings.PermitExtractContent = False
        securitySettings.PermitFormsFill = True
        securitySettings.PermitFullQualityPrint = False
        securitySettings.PermitModifyDocument = True
        securitySettings.PermitPrint = False

        document.Save(pathLoc)

        Return pathLoc
    End Function

    Private Function GenerateWordDoc(ByVal CLAIMNUM As String) As Stream
        Dim crystalReport As New ReportDocument()
        Dim result As Stream
        Dim username As String = ConfigurationManager.AppSettings("username").ToString
        Dim password As String = ConfigurationManager.AppSettings("password").ToString

        crystalReport.Load(Server.MapPath("~/Report/return_payment.rpt"))
        crystalReport.SetParameterValue(0, CLAIMNUM)
        crystalReport.SetDatabaseLogon(username, password)
        result = crystalReport.ExportToStream(ExportFormatType.PortableDocFormat)
        Return result
    End Function

    Private Sub UpdateStatusPaymentPremi(ByVal TransID As String, ByVal TransStatus As String, ByVal UserName As String)
        Dim strQueryRollBack As String = ""
        Dim strQuery As String = ""

        strQuery = String.Format("update StatusPaymentPremi set IsEmailSent = 1, UpdatedDate = GETDATE(), UpdatedBy = '{2}' where TransId = '{0}' and Status = '{1}'", TransID, TransStatus, UserName)
        Modul.Eksekusi(strQuery)
    End Sub

    Private Sub CreateStatusPaymentPremiHistory(ByVal TransID As String, ByVal UserName As String)
        Dim strQueryRollBack As String = ""
        Dim strQuery As String = ""

        strQuery = String.Format("Insert into StatusPaymentPremiHistory values ('{0}', GETDATE(),'{1}', null, null)", TransID, UserName)
        Modul.Eksekusi(strQuery)
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click
        BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtCompany.Text.Trim, ddlStatus.SelectedValue)
        'SetData()
        'GetData()

        'Dim totMBRSHARE As Double
        'Dim totHMOSHARE As Double
        'Dim totDISCOUNT As Double

        'For x As Integer = 0 To gvSelected.Rows.Count - 1
        '    totMBRSHARE = totMBRSHARE + gvSelected.Rows(x).Cells(7).Text
        '    totHMOSHARE = totHMOSHARE + gvSelected.Rows(x).Cells(8).Text
        '    totDISCOUNT = totDISCOUNT + gvSelected.Rows(x).Cells(10).Text
        'Next

    End Sub

    Protected Sub txtCLMNUM_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtCLMNUM.TextChanged

    End Sub

    Protected Sub ddl_Page_Size_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl_Page_Size.SelectedIndexChanged
        GridGER.PageSize = Convert.ToInt32(ddl_Page_Size.SelectedValue)
        BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtCompany.Text.Trim, ddlStatus.SelectedValue)
    End Sub

    Private Sub GridGER_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles GridGER.RowDeleting
        Dim CLIENTNUMBER As String = GridGER.DataKeys(e.RowIndex).Values("CLIENT NUMBER").ToString()

        SQL = ""

        SQL = "Update Mst_EXPayment set Status=0,USERID='" & Session("username") & "',DATETIME='" & Date.Now.ToString("yyyy-MM-dd HH:mm:ss") & "'  where [Client Key]='" & CLIENTNUMBER & "'"
        If SQL <> "" Then
            Try
                Modul.Eksekusi(SQL)
                Modul.UserMsgBox(Me, "Deleted Complete !!")
                BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtCompany.Text.Trim, ddlStatus.SelectedValue)

            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try
        End If
    End Sub

    Private Sub GridGER_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GridGER.RowEditing
        GridGER.EditIndex = e.NewEditIndex
        BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtCompany.Text.Trim, ddlStatus.SelectedValue)
    End Sub

    Private Sub GridException_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GridGER.RowCancelingEdit
        GridGER.EditIndex = -1
        BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtCompany.Text.Trim, ddlStatus.SelectedValue)
    End Sub

    Private Sub GridException_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GridGER.RowUpdating

        Dim userName As String = Session("UserName")
        Dim policyNo As String = DirectCast(GridGER.Rows(GridGER.EditIndex).FindControl("label12"), Label).Text
        Dim salesEmail As String = DirectCast(GridGER.Rows(GridGER.EditIndex).FindControl("txtSalesEmail"), TextBox).Text

        SQL = String.Format("select top(1) Id from ReturnPaymentNotifSalesEmail where PolicyNo = '{0}'", policyNo)
        Dim dt_Grid_GER As New DataTable
        dt_Grid_GER = Modul.getAllDatainDT(SQL)

        If dt_Grid_GER.Rows.Count > 0 Then
            SQL = String.Format("update ReturnPaymentNotifSalesEmail set SalesEmail = '{0}', ModifiedBy ='{1}', ModifiedDate = GETDATE() where Id = '{2}'", salesEmail, userName, dt_Grid_GER.Rows(0)("Id"))
        Else
            SQL = String.Format("insert into ReturnPaymentNotifSalesEmail values ('{0}','{1}','{2}',GETDATE(),null,null)", policyNo, salesEmail, userName)
        End If

        If SQL <> "" Then
            Try
                Modul.Eksekusi(SQL)
                Modul.UserMsgBox(Me, "Updated Complete")
                GridGER.EditIndex = -1
                BindGrid(txtCLMNUM.Text.Trim, txtPolis.Text.Trim, txtCompany.Text.Trim, ddlStatus.SelectedValue)

            Catch ex As Exception
                MsgBox(ex.Message)
                Throw (ex)
            End Try
        End If
    End Sub
End Class