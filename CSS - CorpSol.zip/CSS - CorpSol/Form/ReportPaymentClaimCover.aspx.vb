﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Web

Partial Public Class ReportPaymentClaimCover
    Inherits System.Web.UI.Page

    Dim SQL, x1v9o As String
    Dim strValue() As String

    Dim Modul As New ClassModul
    Dim Dt As New DataTable
    Dim CrystalReportViewer1 As New CrystalReportViewer
    Dim oSelect As New SelectBase

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            BindGrid("")
        Else
            If Session("username") = "" Then
                Response.Redirect("~/Login.aspx", False)
                'Response.Redirect("~/Form/Header.aspx", False)
                'ScriptManager.RegisterStartupScript(Me, Me.GetType(), "redirect", "window.location='Login.aspx';", True)
                Exit Sub
            End If
            BindGrid(txtCLMNUM.Text)
        End If

    End Sub

    Public Sub BindGrid(ByVal CLAMNUM As String)
        SQL = "SELECT [Claim No] as CLAIM,[Policy No],Transdate,[Claim Status],REPLACE([GER No 1],'''','') as GER,[Member No],[Member Name]," & _
              "[Patient No],[Patient Name],CONVERT(varchar, CAST(SUM(Incurred) AS money), 1) as Incurred," & _
              "CONVERT(varchar, CAST(SUM([Total Amount]) AS money), 1) as Paid,CONVERT(varchar, CAST(SUM(Cover) AS money), 1) as Cover," & _
              "CONVERT(varchar, CAST(SUM(Unpaid) AS money), 1) as Unpaid," & _
              "[User Created] FROM Tbl_GER WHERE incurred <> cover AND [Claim No] LIKE '%" & CLAMNUM & "%' AND [Who Paid]='C' " & _
              "GROUP BY [Claim No] ,[Policy No],Transdate,[Claim Status],REPLACE([GER No 1],'''',''), [Member No],[Member Name]," & _
              "[Patient No],[Patient Name],[User Created] ORDER BY Transdate desc,[Claim No]"

        Modul.SubBindGridView(SQL, GridHeader)

        Dim dt_Count As New System.Data.DataTable
        SQL = "SELECT COUNT(0) FROM (SELECT [Claim No] As TOTAL FROM Tbl_GER WHERE incurred <> cover AND [Claim No] LIKE '%" & CLAMNUM & "%' AND [Who Paid]='C' " & _
              "GROUP BY [Claim No] ,[Policy No],Transdate,[Claim Status],REPLACE([GER No 1],'''',''), [Member No],[Member Name],[Patient No],[Patient Name],[User Created] ) a"
        dt_Count = Modul.getAllDatainDT(SQL)

        lblTotRow.Text = "Total Data : " & dt_Count.Rows(0)(0).ToString().Trim & " Data "
    End Sub

    Private Sub GridHeader_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GridHeader.PageIndexChanging
        GridHeader.PageIndex = e.NewPageIndex
        Me.BindGrid(txtCLMNUM.Text)
    End Sub

    Private Sub GridHeader_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridHeader.RowCommand
        If e.CommandName = "Download" Then
            Try

                Dim dtRefund As New DataTable
                Dim index As Integer = Convert.ToInt32(e.CommandArgument)
                Dim selectedRow As GridViewRow = GridHeader.Rows(index)
                Dim crystalReport As New ReportDocument()
                Dim NoSurat As String

                Session("ClaimNumber") = Left(selectedRow.Cells(0).Text, 8)
                Session("GCOCCNO") = Right(selectedRow.Cells(0).Text, 2)

                NoSurat = GenerateNoSurat()

                crystalReport.Load(Server.MapPath("~/Report/claim_bayar.rpt"))

                dtRefund = oSelect.LetterPaymentClaim(selectedRow.Cells(0).Text, NoSurat)

                crystalReport.SetParameterValue(0, selectedRow.Cells(0).Text)
                crystalReport.SetParameterValue(1, NoSurat)

                crystalReport.SetDataSource(dtRefund)
                CrystalReportViewer1.HasExportButton = "True"
                CrystalReportViewer1.ReportSourceID = "CrystalReportSource1"
                CrystalReportViewer1.ReportSource = crystalReport

                Dim formatType As ExportFormatType = ExportFormatType.NoFormat
                formatType = ExportFormatType.WordForWindows

                Response.AddHeader("X-Download-Options", "noopen")

                crystalReport.ExportToHttpResponse(formatType, Response, True, "Letter Payment Claim Number " & selectedRow.Cells(0).Text)

                Response.End()

            Catch ex As Exception
                'MsgBox(ex.Message)
                'Throw (ex)
            End Try
        End If
    End Sub

    Public Function GenerateNoSurat()
        Dim dt As New System.Data.DataTable
        Dim dt_NoSurat As New System.Data.DataTable
        Dim NoSurat As Integer
        Dim numbering As String
        Dim ID As String = ""

        'SQL = "DELETE FROM Tbl_NoSurat_Refund WHERE YEAR=" & Year(Date.Now) - 1 & " "
        'Modul.Eksekusi(SQL)

        SQL = "SELECT * FROM Tbl_NoSurat_Payment WHERE YEAR=" & Year(Date.Now) & " AND CLAIMNO='" & Session("ClaimNumber") & "' AND GCOCCNO='" & Session("GCOCCNO") & "' "
        Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
        Modul.SQLAdp.Fill(dt_NoSurat)

        If dt_NoSurat.Rows.Count > 0 Then
            If dt_NoSurat.Rows(0).Item(0).ToString <> "" Then
                NoSurat = Val(dt_NoSurat.Rows(0).Item(0).ToString)
                numbering = Microsoft.VisualBasic.Right("0000000" & NoSurat, 7)
                ID = numbering
            Else
                SQL = "SELECT TOP 1 NUMBER FROM Tbl_NoSurat_Payment WHERE YEAR=" & Year(Date.Now) & " ORDER BY NUMBER DESC"
                Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
                Modul.SQLAdp.Fill(dt)

                If dt.Rows.Count > 0 Then
                    If dt.Rows(0).Item(0).ToString <> "" Then
                        NoSurat = Val(dt.Rows(0).Item(0).ToString) + 1
                        numbering = Microsoft.VisualBasic.Right("0000000" & NoSurat, 7)
                        ID = numbering
                    End If
                Else
                    ID = "0000001"
                End If

                SQL = "INSERT INTO Tbl_NoSurat_Payment VALUES (" & ID & "," & Year(Date.Now) & ",'" & Session("ClaimNumber") & "','" & Session("GCOCCNO") & "','" & Session("UserName") & "','" & Date.Now.ToString("yyyy/MM/dd HH:mm:ss") & "') "
                Modul.Eksekusi(SQL)
            End If
        Else
            SQL = "SELECT TOP 1 NUMBER FROM Tbl_NoSurat_Payment WHERE YEAR=" & Year(Date.Now) & " ORDER BY NUMBER DESC"
            Modul.SQLAdp = New SqlDataAdapter(SQL, Modul.SQLConn)
            Modul.SQLAdp.Fill(dt)

            If dt.Rows.Count > 0 Then
                If dt.Rows(0).Item(0).ToString <> "" Then
                    NoSurat = Val(dt.Rows(0).Item(0).ToString) + 1
                    numbering = Microsoft.VisualBasic.Right("0000000" & NoSurat, 7)
                    ID = numbering
                End If
            Else
                ID = "0000001"
            End If

            SQL = "INSERT INTO Tbl_NoSurat_Payment VALUES (" & ID & "," & Year(Date.Now) & ",'" & Session("ClaimNumber") & "','" & Session("GCOCCNO") & "','" & Session("UserName") & "','" & Date.Now.ToString("yyyy/MM/dd HH:mm:ss") & "') "
            Modul.Eksekusi(SQL)
        End If

        Return ID

    End Function
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSearch.Click

    End Sub
End Class