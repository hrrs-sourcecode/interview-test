﻿Imports System.Configuration
Imports System.Data.SqlClient

Public Class InsertBase
    Inherits ClassModul

    Dim _connectionString As String = ConfigurationManager.ConnectionStrings("ConSql").ToString

#Region "Constanta"

    Dim const_sp_Create_MemberNo As String = "sp_Create_MemberNo"
    Dim const_sp_Insert_Data_premi As String = "sp_Upload_Data_Premi"
    Dim const_sp_Insert_Data_EC As String = "sp_Upload_Data_EC"
    Dim const_sp_Insert_Data_EC_Detail As String = "sp_Upload_Data_EC_Detail"
    Dim const_sp_Insert_Data_Premi_Detail As String = "sp_Upload_Data_Premi_Detail"
    Dim const_sp_Insert_Data_CallNote As String = "sp_Insert_CallNote"
    'new 20201228 - upload_prime_tahunan, reza
    Dim const_sp_Insert_Data_Premi_EC_Tahunan As String = "sp_Upload_Data_Premi_EC_Tahunan"
    Dim const_sp_Insert_Ger_Transaction As String = "sp_Insert_Ger_Transaction"
#End Region

    Public Function f_Create_MemberNo(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _membername As String, ByVal _fundtype As String) As Integer

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@MemberName", SqlDbType.VarChar)
        oParam(3).Value = CType(_membername, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)

        Return (ExecuteNonQuery(_connectionString, const_sp_Create_MemberNo, CommandType.StoredProcedure, oParam))


    End Function

    Public Function f_Create_CallNote(ByVal _PHONENUMBER As String, ByVal _NOTE As String, ByVal _policyno As String, ByVal _CREATEDBY As String, _
                                      ByVal _REMINDERDATE As String, ByVal _ISREMINDER As String, ByVal _TYPEID As String, ByVal _STARTTIME As String, ByVal _ENDTIME As String) As Integer

        Dim oParam(8) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@PHONENUMBER", SqlDbType.VarChar)
        oParam(0).Value = CType(_PHONENUMBER, String)

        oParam(1) = New SqlClient.SqlParameter("@NOTE", SqlDbType.VarChar)
        oParam(1).Value = CType(_NOTE, String)

        oParam(2) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@CREATEDBY", SqlDbType.VarChar)
        oParam(3).Value = CType(_CREATEDBY, String)

        oParam(4) = New SqlClient.SqlParameter("@REMINDERDATE", SqlDbType.VarChar)
        oParam(4).Value = CType(_REMINDERDATE, String)

        oParam(5) = New SqlClient.SqlParameter("@ISREMINDER", SqlDbType.VarChar)
        oParam(5).Value = CType(_ISREMINDER, String)

        oParam(6) = New SqlClient.SqlParameter("@TYPEID", SqlDbType.VarChar)
        oParam(6).Value = CType(_TYPEID, String)

        oParam(7) = New SqlClient.SqlParameter("@STARTTIME", SqlDbType.DateTime)
        oParam(7).Value = CType(_STARTTIME, String)

        oParam(8) = New SqlClient.SqlParameter("@ENDTIME", SqlDbType.DateTime)
        oParam(8).Value = CType(_ENDTIME, String)

     
        Return (ExecuteNonQuery(_connectionString, const_sp_Insert_Data_CallNote, CommandType.StoredProcedure, oParam))


    End Function

    Public Function f_Insert_Data_premi(ByVal _BILLNO As String, ByVal _BILLNOMANUAL As String, ByVal _NOTRANSAKSI As String, ByVal _PAYMENTMODE As String,
                                        ByVal _POLICYNO As Integer, ByVal _ACCOUNTNAME As String, ByVal _EFFECTIVEDATE As Date, ByVal _PRODUCT As String,
                                        ByVal _TOTALMEMBER As Integer, ByVal _PREMIUMAMOUNT As Double, ByVal _ADDITION As Double, ByVal _DELETION As Double,
                                        ByVal _CHANGEPLAN As Double, ByVal _FEE_ASO As Double, ByVal _ASO As Double, ByVal _BY_KARTU As Double, ByVal _PAID As Double,
                                        ByVal _OUTSTANDING As Double, ByVal _ISSUE_DATE As Date, ByVal _TYPE_OF_ENDORSMENT As String, ByVal _TGL_BAYAR As Date,
                                        ByVal _TGL_BAYAR2 As Date, ByVal _TGL_BAYAR3 As Date,
                                        ByVal _TGL_INPUTG400 As Date, ByVal _RECEIPT As String, ByVal _RCL As Double, ByVal _REMARK_COLLECTION As String,
                                        ByVal _KETERANGAN As String, ByVal _STATUS As String, ByVal _TGL_PENAGIHAN_PREMI As Date, ByVal _TGL_PENAGIHAN_PREMI2 As Date,
                                        ByVal _TGL_PENAGIHAN_PREMI3 As Date, ByVal _Reason As String, ByVal _TGL_PROSES As Date, ByVal _Uploaded_By As String, ByVal _user As String,
                                        ByVal _INVOICE_DATE As Date
        ) As Integer


        Dim oParam(36) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@BILLNO", SqlDbType.VarChar)
        oParam(0).Value = CType(_BILLNO, String)

        oParam(1) = New SqlClient.SqlParameter("@BILLNOMANUAL", SqlDbType.VarChar)
        oParam(1).Value = CType(_BILLNOMANUAL, String)

        oParam(2) = New SqlClient.SqlParameter("@NOTRANSAKSI", SqlDbType.VarChar)
        oParam(2).Value = CType(_NOTRANSAKSI, String)

        oParam(3) = New SqlClient.SqlParameter("@PAYMENTMODE", SqlDbType.VarChar)
        oParam(3).Value = CType(_PAYMENTMODE, String)

        oParam(4) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(4).Value = CType(_POLICYNO, Integer)

        oParam(5) = New SqlClient.SqlParameter("@ACCOUNTNAME", SqlDbType.VarChar)
        oParam(5).Value = CType(_ACCOUNTNAME, String)

        oParam(6) = New SqlClient.SqlParameter("@EFFECTIVEDATE", SqlDbType.Date)
        oParam(6).Value = CType(_EFFECTIVEDATE, Date)

        oParam(7) = New SqlClient.SqlParameter("@PRODUCT", SqlDbType.VarChar)
        oParam(7).Value = CType(_PRODUCT, String)

        oParam(8) = New SqlClient.SqlParameter("@TOTALMEMBER", SqlDbType.Int)
        oParam(8).Value = CType(_TOTALMEMBER, Integer)

        oParam(9) = New SqlClient.SqlParameter("@PREMIUMAMOUNT", SqlDbType.Float)
        oParam(9).Value = CType(_PREMIUMAMOUNT, Double)

        oParam(10) = New SqlClient.SqlParameter("@ADDITION", SqlDbType.Float)
        oParam(10).Value = CType(_ADDITION, Double)

        oParam(11) = New SqlClient.SqlParameter("@DELETION", SqlDbType.Float)
        oParam(11).Value = CType(_DELETION, Double)

        oParam(12) = New SqlClient.SqlParameter("@CHANGEPLAN", SqlDbType.Float)
        oParam(12).Value = CType(_CHANGEPLAN, Double)

        oParam(13) = New SqlClient.SqlParameter("@FEE_ASO", SqlDbType.Float)
        oParam(13).Value = CType(_FEE_ASO, Double)

        oParam(14) = New SqlClient.SqlParameter("@ASO", SqlDbType.Float)
        oParam(14).Value = CType(_ASO, Double)

        oParam(15) = New SqlClient.SqlParameter("@BY_KARTU", SqlDbType.Float)
        oParam(15).Value = CType(_BY_KARTU, Double)

        oParam(16) = New SqlClient.SqlParameter("@PAID", SqlDbType.Float)
        oParam(16).Value = CType(_PAID, Double)

        oParam(17) = New SqlClient.SqlParameter("@OUTSTANDING", SqlDbType.Float)
        oParam(17).Value = CType(_OUTSTANDING, Double)

        oParam(18) = New SqlClient.SqlParameter("@ISSUE_DATE", SqlDbType.Date)
        oParam(18).Value = CType(_ISSUE_DATE, Date)

        oParam(19) = New SqlClient.SqlParameter("@TYPE_OF_ENDORSMENT", SqlDbType.VarChar)
        oParam(19).Value = CType(_TYPE_OF_ENDORSMENT, String)

        oParam(20) = New SqlClient.SqlParameter("@TGL_BAYAR", SqlDbType.Date)
        oParam(20).Value = CType(_TGL_BAYAR, Date)

        oParam(21) = New SqlClient.SqlParameter("@TGL_BAYAR2", SqlDbType.Date)
        oParam(21).Value = CType(_TGL_BAYAR2, Date)

        oParam(22) = New SqlClient.SqlParameter("@TGL_BAYAR3", SqlDbType.Date)
        oParam(22).Value = CType(_TGL_BAYAR3, Date)

        oParam(23) = New SqlClient.SqlParameter("@TGL_INPUTG400", SqlDbType.Date)
        oParam(23).Value = CType(_TGL_INPUTG400, Date)

        oParam(24) = New SqlClient.SqlParameter("@RECEIPT", SqlDbType.VarChar)
        oParam(24).Value = CType(_RECEIPT, String)

        oParam(25) = New SqlClient.SqlParameter("@RCL", SqlDbType.Float)
        oParam(25).Value = CType(_RCL, Double)

        oParam(26) = New SqlClient.SqlParameter("@REMARK_COLLECTION", SqlDbType.VarChar)
        oParam(26).Value = CType(_REMARK_COLLECTION, String)

        oParam(27) = New SqlClient.SqlParameter("@KETERANGAN", SqlDbType.VarChar)
        oParam(27).Value = CType(_KETERANGAN, String)

        oParam(28) = New SqlClient.SqlParameter("@STATUS", SqlDbType.VarChar)
        oParam(28).Value = CType(_STATUS, String)

        oParam(29) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_PREMI", SqlDbType.Date)
        oParam(29).Value = CType(_TGL_PENAGIHAN_PREMI, Date)

        oParam(30) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_PREMI2", SqlDbType.Date)
        oParam(30).Value = CType(_TGL_PENAGIHAN_PREMI2, Date)

        oParam(31) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_PREMI3", SqlDbType.Date)
        oParam(31).Value = CType(_TGL_PENAGIHAN_PREMI3, Date)

        oParam(32) = New SqlClient.SqlParameter("@Reason", SqlDbType.VarChar)
        oParam(32).Value = CType(_Reason, String)

        oParam(33) = New SqlClient.SqlParameter("@TGL_PROSES", SqlDbType.Date)
        oParam(33).Value = CType(_TGL_PROSES, Date)

        oParam(34) = New SqlClient.SqlParameter("@UploadedBy", SqlDbType.VarChar)
        oParam(34).Value = CType(_Uploaded_By, String)

        oParam(35) = New SqlClient.SqlParameter("@user", SqlDbType.VarChar)
        oParam(35).Value = CType(_user, String)

        ' NEW 2020/12/23 - INVOICE_DATE
        oParam(36) = New SqlClient.SqlParameter("@INVOICE_DATE", SqlDbType.Date)
        oParam(36).Value = CType(_INVOICE_DATE, Date)


        Return (ExecuteNonQuery(_connectionString, const_sp_Insert_Data_premi, CommandType.StoredProcedure, oParam))


    End Function

    Public Function f_Insert_Data_EC(ByVal _POLICYNO As Integer, ByVal _COMPANYNAME As String, ByVal _PIC_NAME As String, ByVal _NO_PHONE As String, ByVal _EMAIL As String, ByVal _ADDRESS As String,
                                     ByVal _CLAIMTYPE As String, ByVal _CLAIM_NO As String, ByVal _CLAIM_CLIENT_REF_NO As String, ByVal _MEMBER_NO As String, ByVal _MEMBER_NAME As String,
                                     ByVal _PETIRNT_NO As String, ByVal _PATIENT_NAME As String, ByVal _RECEIVED_DATE As Date, ByVal _Provider As String, ByVal _ADMISSION_DATE As Date,
                                     ByVal _DISCHARGE_DATE As Date, ByVal _BIAYA_PERAWATAN As Double, ByVal _YANG_DITANGGUNG As Double, ByVal _TOTAL_EXCESS As Double, ByVal _TGL_PENAGIHAN_EXCESS As Date,
                                     ByVal _TGL_PENAGIHAN_EXCESS2 As Date, ByVal _TGL_PENAGIHAN_EXCESS3 As Date, ByVal _TGL_BAYAR As Date, ByVal _TGL_BAYAR2 As Date, ByVal _TGL_BAYAR3 As Date,
                                     ByVal _SEQ As String, ByVal _REMARK_COLLECTION As String,
                                     ByVal _Paid As Double, ByVal _OUTSTANDING As Double, ByVal _Reason As String, ByVal _Status As String, ByVal _TGL_PROSES As Date, ByVal _NO_RCL As String,
                                     ByVal _TGL_PENGIRIMAN_HARDCOPY As String, ByVal _NO_INVOICE As String, ByVal _Uploaded_By As String, ByVal _user As String,
                                     ByVal _INVOICE_DATE As Date
        ) As Integer


        Dim oParam(38) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(0).Value = CType(_POLICYNO, Integer)

        oParam(1) = New SqlClient.SqlParameter("@COMPANYNAME", SqlDbType.VarChar)
        oParam(1).Value = CType(_COMPANYNAME, String)

        oParam(2) = New SqlClient.SqlParameter("@PIC_NAME", SqlDbType.VarChar)
        oParam(2).Value = CType(_PIC_NAME, String)

        oParam(3) = New SqlClient.SqlParameter("@NO_PHONE", SqlDbType.VarChar)
        oParam(3).Value = CType(_NO_PHONE, String)

        oParam(4) = New SqlClient.SqlParameter("@EMAIL", SqlDbType.VarChar)
        oParam(4).Value = CType(_EMAIL, String)

        oParam(5) = New SqlClient.SqlParameter("@ADDRESS", SqlDbType.VarChar)
        oParam(5).Value = CType(_ADDRESS, String)

        oParam(6) = New SqlClient.SqlParameter("@CLAIMTYPE", SqlDbType.VarChar)
        oParam(6).Value = CType(_CLAIMTYPE, String)

        oParam(7) = New SqlClient.SqlParameter("@CLAIM_NO", SqlDbType.VarChar)
        oParam(7).Value = CType(_CLAIM_NO, String)

        oParam(8) = New SqlClient.SqlParameter("@CLAIM_CLIENT_REF_NO", SqlDbType.VarChar)
        oParam(8).Value = CType(_CLAIM_CLIENT_REF_NO, String)

        oParam(9) = New SqlClient.SqlParameter("@MEMBER_NO", SqlDbType.VarChar)
        oParam(9).Value = CType(_MEMBER_NO, String)

        oParam(10) = New SqlClient.SqlParameter("@MEMBER_NAME", SqlDbType.VarChar)
        oParam(10).Value = CType(_MEMBER_NAME, String)

        oParam(11) = New SqlClient.SqlParameter("@PETIRNT_NO", SqlDbType.VarChar)
        oParam(11).Value = CType(_PETIRNT_NO, String)

        oParam(12) = New SqlClient.SqlParameter("@PATIENT_NAME", SqlDbType.VarChar)
        oParam(12).Value = CType(_PATIENT_NAME, String)

        oParam(13) = New SqlClient.SqlParameter("@RECEIVED_DATE", SqlDbType.Date)
        oParam(13).Value = CType(_RECEIVED_DATE, Date)

        oParam(14) = New SqlClient.SqlParameter("@Provider", SqlDbType.VarChar)
        oParam(14).Value = CType(_Provider, String)

        oParam(15) = New SqlClient.SqlParameter("@ADMISSION_DATE", SqlDbType.Date)
        oParam(15).Value = CType(_ADMISSION_DATE, String)

        oParam(16) = New SqlClient.SqlParameter("@DISCHARGE_DATE", SqlDbType.Date)
        oParam(16).Value = CType(_DISCHARGE_DATE, Date)

        oParam(17) = New SqlClient.SqlParameter("@BIAYA_PERAWATAN", SqlDbType.Float)
        oParam(17).Value = CType(_BIAYA_PERAWATAN, Double)

        oParam(18) = New SqlClient.SqlParameter("@YANG_DITANGGUNG", SqlDbType.Float)
        oParam(18).Value = CType(_YANG_DITANGGUNG, Double)

        oParam(19) = New SqlClient.SqlParameter("@TOTAL_EXCESS", SqlDbType.Float)
        oParam(19).Value = CType(_TOTAL_EXCESS, Double)

        oParam(20) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_EXCESS", SqlDbType.Date)
        oParam(20).Value = CType(_TGL_PENAGIHAN_EXCESS, Date)

        oParam(21) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_EXCESS2", SqlDbType.Date)
        oParam(21).Value = CType(_TGL_PENAGIHAN_EXCESS2, Date)

        oParam(22) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_EXCESS3", SqlDbType.Date)
        oParam(22).Value = CType(_TGL_PENAGIHAN_EXCESS3, Date)

        oParam(23) = New SqlClient.SqlParameter("@TGL_BAYAR", SqlDbType.Date)
        oParam(23).Value = CType(_TGL_BAYAR, Date)

        oParam(24) = New SqlClient.SqlParameter("@TGL_BAYAR2", SqlDbType.Date)
        oParam(24).Value = CType(_TGL_BAYAR2, Date)

        oParam(25) = New SqlClient.SqlParameter("@TGL_BAYAR3", SqlDbType.Date)
        oParam(25).Value = CType(_TGL_BAYAR3, Date)

        oParam(26) = New SqlClient.SqlParameter("@SEQ", SqlDbType.VarChar)
        oParam(26).Value = CType(_SEQ, String)

        oParam(27) = New SqlClient.SqlParameter("@REMARK_COLLECTION", SqlDbType.VarChar)
        oParam(27).Value = CType(_REMARK_COLLECTION, String)

        oParam(28) = New SqlClient.SqlParameter("@Paid", SqlDbType.Float)
        oParam(28).Value = CType(_Paid, Double)

        oParam(29) = New SqlClient.SqlParameter("@OUTSTANDING", SqlDbType.Float)
        oParam(29).Value = CType(_OUTSTANDING, Double)

        oParam(30) = New SqlClient.SqlParameter("@Reason", SqlDbType.VarChar)
        oParam(30).Value = CType(_Reason, String)

        oParam(31) = New SqlClient.SqlParameter("@Status", SqlDbType.VarChar)
        oParam(31).Value = CType(_Status, String)

        oParam(32) = New SqlClient.SqlParameter("@TGL_PROSES", SqlDbType.Date)
        oParam(32).Value = CType(_TGL_PROSES, Date)

        oParam(33) = New SqlClient.SqlParameter("@NO_RCL", SqlDbType.VarChar)
        oParam(33).Value = CType(_NO_RCL, String)

        oParam(34) = New SqlClient.SqlParameter("@TGL_PENGIRIMAN_HARDCOPY", SqlDbType.Date)
        oParam(34).Value = CType(_TGL_PENGIRIMAN_HARDCOPY, Date)

        oParam(35) = New SqlClient.SqlParameter("@NO_INVOICE", SqlDbType.VarChar)
        oParam(35).Value = CType(_NO_INVOICE, String)

        oParam(36) = New SqlClient.SqlParameter("@Uploaded_By", SqlDbType.VarChar)
        oParam(36).Value = CType(_Uploaded_By, String)

        oParam(37) = New SqlClient.SqlParameter("@user", SqlDbType.VarChar)
        oParam(37).Value = CType(_user, String)

        ' NEW 2020/12/23 - INVOICE_DATE
        oParam(38) = New SqlClient.SqlParameter("@INVOICE_DATE", SqlDbType.Date)
        oParam(38).Value = CType(_INVOICE_DATE, Date)

        Return (ExecuteNonQuery(_connectionString, const_sp_Insert_Data_EC, CommandType.StoredProcedure, oParam))


    End Function

    Public Function f_Insert_Data_EC_Detail(ByVal _POLICYNO As Integer, ByVal _CLAIM_NO As String, ByVal _STATUS_CLAIM As String, _
                                            ByVal _RECEIPT_NO1 As String, ByVal _RECEIPT_NO2 As String, ByVal _RECEIPT_NO3 As String, _
                                            ByVal _STATUS_POLIS As String, ByVal _GROUP_NAME As String) As Integer


        Dim oParam(7) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(0).Value = CType(_POLICYNO, Integer)

        oParam(1) = New SqlClient.SqlParameter("@CLAIM_NO", SqlDbType.VarChar)
        oParam(1).Value = CType(_CLAIM_NO, String)

        oParam(2) = New SqlClient.SqlParameter("@STATUS_CLAIM", SqlDbType.VarChar)
        oParam(2).Value = CType(_STATUS_CLAIM, String)

        oParam(3) = New SqlClient.SqlParameter("@RECEIPT_NO1", SqlDbType.VarChar)
        oParam(3).Value = CType(_RECEIPT_NO1, String)

        oParam(4) = New SqlClient.SqlParameter("@RECEIPT_NO2", SqlDbType.VarChar)
        oParam(4).Value = CType(_RECEIPT_NO2, String)

        oParam(5) = New SqlClient.SqlParameter("@RECEIPT_NO3", SqlDbType.VarChar)
        oParam(5).Value = CType(_RECEIPT_NO3, String)

        oParam(6) = New SqlClient.SqlParameter("@STATUS_POLIS", SqlDbType.VarChar)
        oParam(6).Value = CType(_STATUS_POLIS, String)

        oParam(7) = New SqlClient.SqlParameter("@GROUP_NAME", SqlDbType.VarChar)
        oParam(7).Value = CType(_GROUP_NAME, String)

        Return (ExecuteNonQuery(_connectionString, const_sp_Insert_Data_EC_Detail, CommandType.StoredProcedure, oParam))


    End Function

    Public Function f_Insert_Data_Premi_Detail(ByVal _POLICYNO As Integer, ByVal _STATUS_POLIS As String, ByVal _GROUP_NAME As String) As Integer


        Dim oParam(2) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(0).Value = CType(_POLICYNO, Integer)

        oParam(1) = New SqlClient.SqlParameter("@STATUS_POLIS", SqlDbType.VarChar)
        oParam(1).Value = CType(_STATUS_POLIS, String)

        oParam(2) = New SqlClient.SqlParameter("@GROUP_NAME", SqlDbType.VarChar)
        oParam(2).Value = CType(_GROUP_NAME, String)



        Return (ExecuteNonQuery(_connectionString, const_sp_Insert_Data_Premi_Detail, CommandType.StoredProcedure, oParam))


    End Function

    ' new 20201228 - upload_prime_tahunan, reza
    ' sp_Upload_Data_Premi_Tahunan -> sp_Upload_Data_Premi_EC_Tahunan 
    Public Function f_Insert_Data_Premi_Tahunan(ByVal POLICY_NUMBER As Integer, ByVal PREMI_TAHUNAN As Double) As Integer

        Dim oParam(1) As SqlParameter

        oParam(0) = New SqlParameter("@POLICY_NUMBER", SqlDbType.Int)
        oParam(0).Value = POLICY_NUMBER

        oParam(1) = New SqlParameter("@PREMI_TAHUNAN", SqlDbType.Float)
        oParam(1).Value = PREMI_TAHUNAN

        Return (ExecuteNonQuery(_connectionString, const_sp_Insert_Data_Premi_EC_Tahunan, CommandType.StoredProcedure, oParam))

    End Function
    ' new 20210108 - create ger by transaction
    Public Function f_Execute_Text_Transaction(ByVal strQuery As String) As Integer

        Dim oParam(0) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@query_text", SqlDbType.NVarChar)
        oParam(0).Value = CType(strQuery, String)

        Return (ExecuteNonQuery(_connectionString, const_sp_Insert_Ger_Transaction, CommandType.StoredProcedure, oParam))

    End Function
End Class
