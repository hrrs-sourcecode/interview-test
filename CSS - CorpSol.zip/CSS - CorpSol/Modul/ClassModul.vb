﻿Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Color

Public Class ClassModul
    Public SQLConn As String = ConfigurationManager.ConnectionStrings("ConSql").ConnectionString
    Public SQLCn As New SqlConnection(ConfigurationManager.ConnectionStrings("ConSql").ConnectionString)
    'Public SQLCon As String = ConfigurationManager.ConnectionStrings("ConnSql").ConnectionString
    Public AppID As String = "1"
    Public SQL As String
    Public SQLCmd As New SqlCommand
    Public SQLAdp As New SqlDataAdapter
    Public dt As New DataTable
    Public ds As New DataSet
    Public dExpDate As Date
    Public cStatusExp As String
#Region " Public Properties "

    ''' <summary>
    ''' Gets or sets the string used to open a SQL Server database.
    ''' </summary>
    ''' <returns>The connection string that includes the source database name, and other parameters needed to establish the initial connection.</returns>
    Public Property ConnectionString() As String
        Get
            Return SQLConn
        End Get
        Set(ByVal value As String)
            SQLConn = value
        End Set
    End Property

#End Region

#Region "Assign Parameters"

    Private Sub AssignParameters(ByVal cmd As SqlCommand, ByVal parameterValues() As Object)
        If Not (cmd.Parameters.Count - 1 = parameterValues.Length) Then Throw New ApplicationException("Stored procedure's parameters and parameter values does not match.")
        Dim i As Integer
        For Each param As SqlParameter In cmd.Parameters
            If Not (param.Direction = ParameterDirection.Output) AndAlso Not (param.Direction = ParameterDirection.ReturnValue) Then
                param.Value = parameterValues(i)
                i += 1
            End If
        Next

    End Sub

    Private Sub AssignParameters(ByVal cmd As SqlCommand, ByVal cmdParameters() As SqlParameter)
        If (cmdParameters Is Nothing) Then Exit Sub
        For Each p As SqlParameter In cmdParameters
            cmd.Parameters.Add(p)
        Next
    End Sub

#End Region

#Region "Execute Non Query"

    Public Function ExecuteNonQuery(ByVal conn As String, ByVal cmd As String, ByVal cmdType As CommandType, Optional ByVal parameters() As SqlParameter = Nothing) As Integer
        Dim connection As SqlConnection = Nothing
        Dim transaction As SqlTransaction = Nothing
        Dim command As SqlCommand = Nothing
        Dim res As Integer = -1
        Try
            connection = New SqlConnection(conn)
            command = New SqlCommand(cmd, connection)
            command.CommandTimeout() = 7200
            command.CommandType = cmdType
            Me.AssignParameters(command, parameters)
            connection.Open()
            'transaction = connection.BeginTransaction()
            'command.Transaction = transaction
            res = command.ExecuteNonQuery()
            'transaction.Commit()
        Catch ex As Exception
            'If Not (transaction Is Nothing) Then
            '    transaction.Rollback()
            'End If
            'Throw New Data.DataException(ex.Message, ex.InnerException)
            Throw New Exception(ex.Message, ex.InnerException)
        Finally
            If Not (connection Is Nothing) AndAlso (connection.State = ConnectionState.Open) Then connection.Close()
            If Not (command Is Nothing) Then command.Dispose()
            If Not (transaction Is Nothing) Then transaction.Dispose()
        End Try
        Return res
    End Function

#End Region

    Public Sub ShowFocus(ByVal xPage As Page, ByVal NamaField As Object)
        Dim xScr As String = "<script>document.getElementById('" & NamaField.ClientID & "').focus();</script>"
        If (Not xPage.ClientScript.IsStartupScriptRegistered("Pesan")) Then
            xPage.ClientScript.RegisterStartupScript(xPage.GetType, "Pesan", xScr)
        End If
    End Sub
    Public Sub ShowMessage(ByVal xPage As Page, ByVal xScript As String)
        Dim xScr As String = "<script>alert(' " & xScript & " ');</script>"
        If (Not xPage.ClientScript.IsStartupScriptRegistered("Pesan")) Then
            xPage.ClientScript.RegisterStartupScript(xPage.GetType, "Pesan", xScr)
        End If
    End Sub
    Public Function base64Encode(ByVal sData As String) As String
        Try
            Dim encData_byte As Byte() = New Byte(sData.Length - 1) {}
            encData_byte = System.Text.Encoding.UTF8.GetBytes(sData)
            Dim encodedData As String = Convert.ToBase64String(encData_byte)
            Return (encodedData)
        Catch ex As Exception
            Throw (New Exception("Error in base64Encode" & ex.Message))
        End Try
    End Function

    Public Function base64Decode(ByVal sData As String) As String
        Dim encoder As New System.Text.UTF8Encoding
        Dim utf8Decode As System.Text.Decoder = encoder.GetDecoder()
        Dim todecode_byte As Byte() = Convert.FromBase64String(sData)
        Dim charCount As Integer = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length)
        Dim decode_char As Char() = New Char(charCount - 1) {}
        utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decode_char, 0)
        Dim result As String = New [String](decode_char)
        Return result
    End Function
    Public Function FillDataset(ByVal cmd As String, ByVal cmdType As CommandType, Optional ByVal parameters() As SqlParameter = Nothing) As DataTable
        Dim connection As SqlConnection = Nothing
        Dim command As SqlCommand = Nothing
        Dim sqlda As SqlDataAdapter = Nothing
        Dim res As New DataTable
        Try
            connection = New SqlConnection(SQLConn)
            command = New SqlCommand(cmd, connection)
            command.CommandType = cmdType
            AssignParameters(command, parameters)
            sqlda = New SqlDataAdapter(command)

            command.CommandTimeout() = 7200

            sqlda.Fill(res)
        Catch ex As Exception
            Throw New Data.DataException(ex.Message, ex.InnerException)
        Finally
            If Not (connection Is Nothing) Then connection.Dispose()
            If Not (command Is Nothing) Then command.Dispose()
            If Not (sqlda Is Nothing) Then sqlda.Dispose()
        End Try
        Return res
    End Function
    Public Function UploadFiles(ByVal xPage As Page, ByRef ViewS As Object, ByVal upload As FileUpload, ByVal path As String) As String
        'Dim path As String = Server.MapPath("~\Form\Upload\")
        Dim fileOK As Boolean = False
        Try
            If upload.HasFile Then
                'If upload.PostedFile.ContentLength > 1048576 Then
                '    xPage.ClientScript.RegisterStartupScript(Me.GetType(), "pesan", "alert('Maximum file size exceeded!');", True)
                '    Return 1
                'End If
                Dim fileExtension As String
                fileExtension = System.IO.Path.GetExtension(upload.FileName).ToLower()
                'for type file uploaded
                Dim allowedExtensions As String() = _
                    {".xls"}
                For i As Integer = 0 To allowedExtensions.Length - 1
                    If fileExtension = allowedExtensions(i) Then
                        fileOK = True
                    End If
                Next
                If fileOK Then
                    Try
                        ViewS("path") = CStr(Now.Day) & CStr(Now.Month) & CStr(Now.Year) & CStr(Now.Hour) & CStr(Now.Minute) & CStr(Now.Second) & upload.FileName
                        upload.PostedFile.SaveAs(path & CStr(Now.Day) & CStr(Now.Month) & CStr(Now.Year) & CStr(Now.Hour) & CStr(Now.Minute) & CStr(Now.Second) & upload.FileName)
                    Catch ex As Exception
                        xPage.ClientScript.RegisterStartupScript(Me.GetType(), "pesan", "alert('File could not be uploaded!');", True)
                        Return 1
                    End Try
                Else
                    xPage.ClientScript.RegisterStartupScript(Me.GetType(), "pesan", "alert('Cannot accept files of this type!');", True)
                    Return 1
                End If

            Else
                xPage.ClientScript.RegisterStartupScript(Me.GetType(), "pesan", "alert('No file uploaded!');", True)
                Return 1
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return 1
        End Try
        Return 0
    End Function

    Public Sub Eksekusi(ByRef Sql As System.String)
        Dim SQLCn As New SqlConnection(ConfigurationManager.ConnectionStrings("ConSql").ConnectionString)
        Try
            SQLCn.Open()
            SQLCmd = New SqlCommand(Sql, SQLCn)
            SQLCmd.ExecuteNonQuery()
            SQLCn.Close()
            SQLCmd.Dispose()
            SQLCn.Dispose()
        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw ex
        Finally
            If SQLCn.State = ConnectionState.Open Then
                SQLCn.Close()
            End If
        End Try
    End Sub

    Public Sub ExecuteWithReturn(ByRef Sql As System.String, ByRef strRet As System.String)
        Dim SQLCn As New SqlConnection(ConfigurationManager.ConnectionStrings("ConSql").ConnectionString)
        Try
            SQLCn.Open()
            SQLCmd = New SqlCommand(Sql, SQLCn)
            SQLCmd.ExecuteNonQuery()
            SQLCn.Close()
            SQLCmd.Dispose()
            SQLCn.Dispose()
            strRet = "done"
        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw ex
            strRet = ex.Message.ToString
        Finally
            If SQLCn.State = ConnectionState.Open Then
                SQLCn.Close()
            End If

        End Try
    End Sub

    Public Sub SubBindGrid(ByVal sql As String, ByVal Grid As DataGrid)
        Try
            dt = New DataTable()
            dt = getAllDatainDT(sql)
            'SQLAdp = New SqlDataAdapter(sql, SQLConn)
            'SQLAdp.Fill(dt)

            Grid.DataSource = dt
            'Grid.VirtualItemCount = dt.Rows.Count

            Grid.DataBind()
            dt.Clear()
            'SQLAdp.Dispose()

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw ex
        End Try
    End Sub
    Public Sub SubBindGridView(ByVal sql As String, ByVal Grid As GridView)

        Try
            SQLAdp = New SqlDataAdapter(sql, SQLConn)
            SQLAdp.Fill(ds)

            Grid.DataSource = ds
            'Grid.VirtualItemCount = dt.Rows.Count

            Grid.DataBind()
            ds.Clear()
            SQLAdp.Dispose()

        Catch ex As Exception
            'MsgBox(ex.Message)
            'Throw ex
        End Try
    End Sub
    Public Sub Grd(ByRef Grid As System.Web.UI.WebControls.DataGrid)
        Grid.Width = Unit.Empty
        Grid.BorderColor = Black
        Grid.BorderWidth = Unit.Point(1)
        Grid.HeaderStyle.BackColor = White
        Grid.HeaderStyle.ForeColor = Black
        Grid.HeaderStyle.Font.Bold = True
        Grid.HeaderStyle.Font.Size = FontUnit.Point(9)
        Grid.ItemStyle.BackColor = White
        Grid.ItemStyle.ForeColor = Black
        Grid.ItemStyle.Font.Size = FontUnit.Point(9)
        Grid.AlternatingItemStyle.Font.Size = FontUnit.Point(9)
    End Sub
    ' This method fixes non literal controls in the DataGrid
    Public Sub ClearControls(ByVal ctrl As Control)
        Dim i As Integer
        For i = ctrl.Controls.Count - 1 To 0 Step i - 1
            ClearControls(ctrl.Controls(i))
        Next
        Dim ctrlType As Type = ctrl.GetType()
        If Not ctrlType.Name = "TableCell" Then
            If Not ctrl.GetType().GetProperty("SelectedItem") Is Nothing Then
                Dim literal As LiteralControl = New LiteralControl
                ctrl.Parent.Controls.Add(literal)
                Try
                    literal.Text = CType(ctrl.GetType().GetProperty("SelectedItem").GetValue(ctrl, Nothing), String)
                Catch
                End Try
                ctrl.Parent.Controls.Remove(ctrl)
            ElseIf Not ctrl.GetType().GetProperty("Text") Is Nothing Then
                Dim literal As LiteralControl = New LiteralControl
                ctrl.Parent.Controls.Add(literal)
                literal.Text = CType(ctrl.GetType().GetProperty("Text").GetValue(ctrl, Nothing), String)
                ctrl.Parent.Controls.Remove(ctrl)
            End If
        End If
    End Sub
    ' Formats the exported DataGrid 
    Public Sub FormatExportedGrid(ByVal DtGrid1 As DataGrid)
        DtGrid1.HeaderStyle.Height = Unit.Pixel(20)
    End Sub
    Public Function FixSingleQuote1(ByVal Input As String) As String
        Dim oldSingleQuote As String = "'"
        'Dim newSingleQuote As String = "\'"
        Dim newSingleQuote As String = ""
        Dim Output As String = ""
        'Return Chr(39) & Input.Replace("'"c, "\'") & Chr(39)
        'Return Chr(39) & Input.Replace("'"c, "''") & Chr(39)
        'Output = Chr(39) & Replace(Input, oldSingleQuote, newSingleQuote) & Chr(39) '<-- As of 2008-07-08 by Ted Palmer
        Output = Replace(Input, oldSingleQuote, newSingleQuote)
        Return Output '<-- As of 2008-07-08 by Ted Palmer
    End Function 'FixSingleQuote1
    'MessageBox
    Public Sub UserMsgBox(ByVal F As Object, ByVal sMsg As String)
        Dim sb As New StringBuilder()
        Dim oFormObject As System.Web.UI.Control = Nothing
        Try
            sMsg = sMsg.Replace("'", "\'")
            sMsg = sMsg.Replace(Chr(34), "\" & Chr(34))
            sMsg = sMsg.Replace(vbCrLf, "\n")
            sMsg = "<script language='javascript'>alert('" & sMsg & "');</script>"
            sb = New StringBuilder()
            sb.Append(sMsg)
            For Each oFormObject In F.Controls
                If TypeOf oFormObject Is HtmlForm Then
                    Exit For
                End If
            Next
            oFormObject.Controls.AddAt(oFormObject.Controls.Count, New LiteralControl(sb.ToString()))
        Catch ex As Exception

        End Try
    End Sub
    Public Function getAllDatainDR(ByVal query As String) As SqlDataReader
        'Dim conn As New OracleConnection
        Dim cmd As New SqlCommand
        Dim dr As SqlDataReader

        SQLCn.ConnectionString = SQLConn
        SQLCmd.CommandText = query
        SQLCmd.Connection = SQLCn

        Try
            SQLCn.Open()
            dr = SQLCmd.ExecuteReader()
            Return dr
        Catch ex As Exception
            Console.WriteLine(ex.Message)
            dr = Nothing
            Return dr
            SQLCn.Close()
        Finally
            'SQLCn.Close()
        End Try
    End Function
    Public Function getAllDatainDT(ByVal query As String) As DataTable
        SQLCmd.Connection = SQLCn
        SQLCmd.CommandText = query
        SQLCmd.CommandTimeout = 0
        SQLAdp.SelectCommand = SQLCmd
        Dim dt_res = New DataTable
        Try
            'dt.Clear()
            SQLCn.Open()
            SQLAdp.Fill(dt_res)
            Return dt_res
        Catch ex As Exception
            'MsgBox(ex.Message)
            Return New DataTable
        Finally
            SQLCn.Close()
        End Try
    End Function
    Public Sub AddMail()

    End Sub
    Public Sub SQLBulkCopy(ByVal _dt As DataTable, ByVal _tablename As String)
        Using bulkCopy As SqlBulkCopy = _
              New SqlBulkCopy(SQLCn)
            bulkCopy.DestinationTableName = _tablename

            Try
                SQLCn.Open()
                ' Write from the source to the destination.
                'bulkCopy.ColumnMappings.Add(0, 0)
                'bulkCopy.ColumnMappings.Add(1, 1)
                bulkCopy.WriteToServer(_dt)

            Catch ex As Exception
                Console.WriteLine(ex.Message)

            Finally
                SQLCn.Close()
            End Try

        End Using

    End Sub
    Public Sub writeJava(ByVal xPage As Page, ByVal xScript As String)
        'ShowMessage(Me, "alert('Text');document.getElementById('" & NamaField.ClientID & "').focus();")
        Dim xScr As String = "<script>" & xScript & "</script>"
        If (Not xPage.ClientScript.IsStartupScriptRegistered("Java")) Then
            xPage.ClientScript.RegisterStartupScript(xPage.GetType, "Java", xScr)
        End If
    End Sub
    'Public Sub GetExpDate(ByVal dIssueDate As String)
    '    dExpDate = ""
    '    cStatusExp = ""

    '    If IsDate(DateSerial(Right(dt.Rows(0)("Issuedate"), 4), Mid(dt.Rows(0)("Issuedate"), 4, 2), Left(dt.Rows(0)("Issuedate"), 2))) = True Then
    '        dExpDate = DateAdd(DateInterval.Month, 2, DateSerial(Right(dt.Rows(0)("Issuedate"), 4), Mid(dt.Rows(0)("Issuedate"), 4, 2), Left(dt.Rows(0)("Issuedate"), 2)))
    '        If dExpDate < DateSerial(Year(Now), Month(Now), Day(Now)) Then
    '            cStatusExp = "Polis has Expired!"
    '            cStatusPolis = "T"
    '        Else
    '            cStatusExp = ""
    '        End If
    '    Else
    '        cStatusExp = "Format Tanggal Issue salah!"
    '    End If
    'End Sub
End Class

