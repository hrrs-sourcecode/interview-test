﻿Imports System.Configuration
Imports System.Data.SqlClient

Public Class UpdateBase
    Inherits ClassModul

    Dim _connectionString As String = ConfigurationManager.ConnectionStrings("ConSql").ToString

#Region "Constanta"

    Dim const_sp_Update_Data_Premi As String = "sp_Update_Data_Premi"
    Dim const_sp_Update_Data_EC As String = "sp_Update_Data_EC"
    Dim const_sp_Update_Data_Premi_Detail As String = "sp_Update_Data_Premi_Detail"
    Dim const_sp_Update_Data_EC_Detail As String = "sp_Update_Data_EC_Detail"

    Dim const_sp_Update_Data_Tagihan As String = "sp_Update_Tanggal_Tagihan"

#End Region

    Public Function f_Update_Data_premi(ByVal _BILLNO As String, ByVal _BILLNOMANUAL As String, ByVal _NOTRANSAKSI As String, ByVal _PAYMENTMODE As String,
                                        ByVal _POLICYNO As Integer, ByVal _ACCOUNTNAME As String, ByVal _EFFECTIVEDATE As String, ByVal _PRODUCT As String,
                                        ByVal _TOTALMEMBER As Integer, ByVal _PREMIUMAMOUNT As Double, ByVal _ADDITION As Double, ByVal _DELETION As Double,
                                        ByVal _CHANGEPLAN As Double, ByVal _FEE_ASO As Double, ByVal _ASO As Double, ByVal _BY_KARTU As Double, ByVal _PAID As Double,
                                        ByVal _OUTSTANDING As Double, ByVal _ISSUE_DATE As String, ByVal _TYPE_OF_ENDORSMENT As String, ByVal _TGL_BAYAR As String,
                                        ByVal _RECEIPT As String, ByVal _RCL As String, ByVal _REMARK_COLLECTION As String,
                                        ByVal _STATUS As String, ByVal _TGL_PENAGIHAN_PREMI As String, ByVal _TGL_PENAGIHAN_PREMI2 As String,
                                        ByVal _TGL_PENAGIHAN_PREMI3 As String, ByVal _TGL_UPLOAD As String,
                                        ByVal _Reason As String, ByVal _TGL_PROSES As String, ByVal _TGL_BAYAR2 As String,
                                        ByVal _TGL_BAYAR3 As String, ByVal _USER As String, ByVal _BILLNO_OLD As String,
                                        ByVal _INVOICE_DATE As String
        ) As Integer


        Dim oParam(35) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@BILLNO", SqlDbType.VarChar)
        oParam(0).Value = CType(_BILLNO, String)

        oParam(1) = New SqlClient.SqlParameter("@BILLNOMANUAL", SqlDbType.VarChar)
        oParam(1).Value = CType(_BILLNOMANUAL, String)

        oParam(2) = New SqlClient.SqlParameter("@NOTRANSAKSI", SqlDbType.VarChar)
        oParam(2).Value = CType(_NOTRANSAKSI, String)

        oParam(3) = New SqlClient.SqlParameter("@PAYMENTMODE", SqlDbType.VarChar)
        oParam(3).Value = CType(_PAYMENTMODE, String)

        oParam(4) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(4).Value = CType(_POLICYNO, Integer)

        oParam(5) = New SqlClient.SqlParameter("@ACCOUNTNAME", SqlDbType.VarChar)
        oParam(5).Value = CType(_ACCOUNTNAME, String)

        oParam(6) = New SqlClient.SqlParameter("@EFFECTIVEDATE", SqlDbType.VarChar)
        oParam(6).Value = CType(_EFFECTIVEDATE, String)

        oParam(7) = New SqlClient.SqlParameter("@PRODUCT", SqlDbType.VarChar)
        oParam(7).Value = CType(_PRODUCT, String)

        oParam(8) = New SqlClient.SqlParameter("@TOTALMEMBER", SqlDbType.Int)
        oParam(8).Value = CType(_TOTALMEMBER, Integer)

        oParam(9) = New SqlClient.SqlParameter("@PREMIUMAMOUNT", SqlDbType.Float)
        oParam(9).Value = CType(_PREMIUMAMOUNT, Double)

        oParam(10) = New SqlClient.SqlParameter("@ADDITION", SqlDbType.Float)
        oParam(10).Value = CType(_ADDITION, Double)

        oParam(11) = New SqlClient.SqlParameter("@DELETION", SqlDbType.Float)
        oParam(11).Value = CType(_DELETION, Double)

        oParam(12) = New SqlClient.SqlParameter("@CHANGEPLAN", SqlDbType.Float)
        oParam(12).Value = CType(_CHANGEPLAN, Double)

        oParam(13) = New SqlClient.SqlParameter("@FEE_ASO", SqlDbType.Float)
        oParam(13).Value = CType(_FEE_ASO, Double)

        oParam(14) = New SqlClient.SqlParameter("@ASO", SqlDbType.Float)
        oParam(14).Value = CType(_ASO, Double)

        oParam(15) = New SqlClient.SqlParameter("@BY_KARTU", SqlDbType.Float)
        oParam(15).Value = CType(_BY_KARTU, Double)

        oParam(16) = New SqlClient.SqlParameter("@PAID", SqlDbType.Float)
        oParam(16).Value = CType(_PAID, Double)

        oParam(17) = New SqlClient.SqlParameter("@OUTSTANDING", SqlDbType.Float)
        oParam(17).Value = CType(_OUTSTANDING, Double)

        oParam(18) = New SqlClient.SqlParameter("@ISSUE_DATE", SqlDbType.VarChar)
        oParam(18).Value = CType(_ISSUE_DATE, String)

        oParam(19) = New SqlClient.SqlParameter("@TYPE_OF_ENDORSMENT", SqlDbType.VarChar)
        oParam(19).Value = CType(_TYPE_OF_ENDORSMENT, String)

        oParam(20) = New SqlClient.SqlParameter("@TGL_BAYAR", SqlDbType.VarChar)
        oParam(20).Value = CType(_TGL_BAYAR, String)

        oParam(21) = New SqlClient.SqlParameter("@TGL_BAYAR2", SqlDbType.VarChar)
        oParam(21).Value = CType(_TGL_BAYAR2, String)

        oParam(22) = New SqlClient.SqlParameter("@TGL_BAYAR3", SqlDbType.VarChar)
        oParam(22).Value = CType(_TGL_BAYAR3, String)

        oParam(23) = New SqlClient.SqlParameter("@RECEIPT", SqlDbType.VarChar)
        oParam(23).Value = CType(_RECEIPT, String)

        oParam(24) = New SqlClient.SqlParameter("@RCL", SqlDbType.VarChar)
        oParam(24).Value = CType(_RCL, String)

        oParam(25) = New SqlClient.SqlParameter("@REMARK_COLLECTION", SqlDbType.VarChar)
        oParam(25).Value = CType(_REMARK_COLLECTION, String)

        oParam(26) = New SqlClient.SqlParameter("@STATUS", SqlDbType.VarChar)
        oParam(26).Value = CType(_STATUS, String)

        oParam(27) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_PREMI", SqlDbType.VarChar)
        oParam(27).Value = CType(_TGL_PENAGIHAN_PREMI, String)

        oParam(28) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_PREMI2", SqlDbType.VarChar)
        oParam(28).Value = CType(_TGL_PENAGIHAN_PREMI2, String)

        oParam(29) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_PREMI3", SqlDbType.VarChar)
        oParam(29).Value = CType(_TGL_PENAGIHAN_PREMI3, String)

        oParam(30) = New SqlClient.SqlParameter("@TGL_UPLOAD", SqlDbType.VarChar)
        oParam(30).Value = CType(_TGL_UPLOAD, String)

        oParam(31) = New SqlClient.SqlParameter("@Reason", SqlDbType.VarChar)
        oParam(31).Value = CType(_Reason, String)

        oParam(32) = New SqlClient.SqlParameter("@TGL_PROSES", SqlDbType.VarChar)
        oParam(32).Value = CType(_TGL_PROSES, String)

        oParam(33) = New SqlClient.SqlParameter("@USER", SqlDbType.VarChar)
        oParam(33).Value = CType(_USER, String)

        oParam(34) = New SqlClient.SqlParameter("@BILLNO_OLD", SqlDbType.VarChar)
        oParam(34).Value = CType(_BILLNO_OLD, String)

        ' NEW 2020/12/23 - INVOICE_DATE
        oParam(35) = New SqlClient.SqlParameter("@INVOICE_DATE", SqlDbType.VarChar)
        oParam(35).Value = CType(_INVOICE_DATE, String)

        Return (ExecuteNonQuery(_connectionString, const_sp_Update_Data_Premi, CommandType.StoredProcedure, oParam))


    End Function

    Public Function f_Update_Data_EC(ByVal _POLICYNO As Integer, ByVal _COMPANYNAME As String, ByVal _PIC_NAME As String, ByVal _NO_PHONE As String, ByVal _EMAIL As String, ByVal _ADDRESS As String,
                                     ByVal _CLAIMTYPE As String, ByVal _CLAIM_NO As String, ByVal _CLAIM_CLIENT_REF_NO As String, ByVal _MEMBER_NO As String, ByVal _MEMBER_NAME As String,
                                     ByVal _PETIRNT_NO As String, ByVal _PATIENT_NAME As String, ByVal _RECEIVED_DATE As String, ByVal _Provider As String, ByVal _ADMISSION_DATE As String,
                                     ByVal _DISCHARGE_DATE As String, ByVal _BIAYA_PERAWATAN As Double, ByVal _YANG_DITANGGUNG As Double, ByVal _TOTAL_EXCESS As Double, ByVal _TGL_PENAGIHAN_EXCESS As String,
                                     ByVal _TGL_PENAGIHAN_EXCESS2 As String, ByVal _TGL_PENAGIHAN_EXCESS3 As String, ByVal _TGL_BAYAR As String, ByVal _SEQ As String, ByVal _REMARK_COLLECTION As String,
                                     ByVal _Paid As Double, ByVal _OUTSTANDING As Double, ByVal _Reason As String, ByVal _Status As String, ByVal _TGL_PROSES As String, ByVal _NO_RCL As String,
                                     ByVal _TGL_BAYAR2 As String, ByVal _TGL_BAYAR3 As String, ByVal _NO_INVOICE As String, ByVal _USER As String,
                                     ByVal _INVOICE_DATE As String
        ) As Integer


        Dim oParam(36) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(0).Value = CType(_POLICYNO, Integer)

        oParam(1) = New SqlClient.SqlParameter("@COMPANYNAME", SqlDbType.VarChar)
        oParam(1).Value = CType(_COMPANYNAME, String)

        oParam(2) = New SqlClient.SqlParameter("@PIC_NAME", SqlDbType.VarChar)
        oParam(2).Value = CType(_PIC_NAME, String)

        oParam(3) = New SqlClient.SqlParameter("@NO_PHONE", SqlDbType.VarChar)
        oParam(3).Value = CType(_NO_PHONE, String)

        oParam(4) = New SqlClient.SqlParameter("@EMAIL", SqlDbType.VarChar)
        oParam(4).Value = CType(_EMAIL, String)

        oParam(5) = New SqlClient.SqlParameter("@ADDRESS", SqlDbType.VarChar)
        oParam(5).Value = CType(_ADDRESS, String)

        oParam(6) = New SqlClient.SqlParameter("@CLAIMTYPE", SqlDbType.VarChar)
        oParam(6).Value = CType(_CLAIMTYPE, String)

        oParam(7) = New SqlClient.SqlParameter("@CLAIM_NO", SqlDbType.VarChar)
        oParam(7).Value = CType(_CLAIM_NO, String)

        oParam(8) = New SqlClient.SqlParameter("@CLAIM_CLIENT_REF_NO", SqlDbType.VarChar)
        oParam(8).Value = CType(_CLAIM_CLIENT_REF_NO, String)

        oParam(9) = New SqlClient.SqlParameter("@MEMBER_NO", SqlDbType.VarChar)
        oParam(9).Value = CType(_MEMBER_NO, String)

        oParam(10) = New SqlClient.SqlParameter("@MEMBER_NAME", SqlDbType.VarChar)
        oParam(10).Value = CType(_MEMBER_NAME, String)

        oParam(11) = New SqlClient.SqlParameter("@PETIRNT_NO", SqlDbType.VarChar)
        oParam(11).Value = CType(_PETIRNT_NO, String)

        oParam(12) = New SqlClient.SqlParameter("@PATIENT_NAME", SqlDbType.VarChar)
        oParam(12).Value = CType(_PATIENT_NAME, String)

        oParam(13) = New SqlClient.SqlParameter("@RECEIVED_DATE", SqlDbType.VarChar)
        oParam(13).Value = CType(_RECEIVED_DATE, String)

        oParam(14) = New SqlClient.SqlParameter("@Provider", SqlDbType.VarChar)
        oParam(14).Value = CType(_Provider, String)

        oParam(15) = New SqlClient.SqlParameter("@ADMISSION_DATE", SqlDbType.VarChar)
        oParam(15).Value = CType(_ADMISSION_DATE, String)

        oParam(16) = New SqlClient.SqlParameter("@DISCHARGE_DATE", SqlDbType.VarChar)
        oParam(16).Value = CType(_DISCHARGE_DATE, String)

        oParam(17) = New SqlClient.SqlParameter("@BIAYA_PERAWATAN", SqlDbType.Float)
        oParam(17).Value = CType(_BIAYA_PERAWATAN, Double)

        oParam(18) = New SqlClient.SqlParameter("@YANG_DITANGGUNG", SqlDbType.Float)
        oParam(18).Value = CType(_YANG_DITANGGUNG, Double)

        oParam(19) = New SqlClient.SqlParameter("@TOTAL_EXCESS", SqlDbType.Float)
        oParam(19).Value = CType(_TOTAL_EXCESS, Double)

        oParam(20) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_EXCESS", SqlDbType.VarChar)
        oParam(20).Value = CType(_TGL_PENAGIHAN_EXCESS, String)

        oParam(21) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_EXCESS2", SqlDbType.VarChar)
        oParam(21).Value = CType(_TGL_PENAGIHAN_EXCESS2, String)

        oParam(22) = New SqlClient.SqlParameter("@TGL_PENAGIHAN_EXCESS3", SqlDbType.VarChar)
        oParam(22).Value = CType(_TGL_PENAGIHAN_EXCESS3, String)

        oParam(23) = New SqlClient.SqlParameter("@TGL_BAYAR", SqlDbType.VarChar)
        oParam(23).Value = CType(_TGL_BAYAR, String)

        oParam(24) = New SqlClient.SqlParameter("@TGL_BAYAR2", SqlDbType.VarChar)
        oParam(24).Value = CType(_TGL_BAYAR2, String)

        oParam(25) = New SqlClient.SqlParameter("@TGL_BAYAR3", SqlDbType.VarChar)
        oParam(25).Value = CType(_TGL_BAYAR3, String)

        oParam(26) = New SqlClient.SqlParameter("@SEQ", SqlDbType.VarChar)
        oParam(26).Value = CType(_SEQ, String)

        oParam(27) = New SqlClient.SqlParameter("@REMARK_COLLECTION", SqlDbType.VarChar)
        oParam(27).Value = CType(_REMARK_COLLECTION, String)

        oParam(28) = New SqlClient.SqlParameter("@Paid", SqlDbType.Float)
        oParam(28).Value = CType(_Paid, Double)

        oParam(29) = New SqlClient.SqlParameter("@OUTSTANDING", SqlDbType.Float)
        oParam(29).Value = CType(_OUTSTANDING, Double)

        oParam(30) = New SqlClient.SqlParameter("@Reason", SqlDbType.VarChar)
        oParam(30).Value = CType(_Reason, String)

        oParam(31) = New SqlClient.SqlParameter("@Status", SqlDbType.VarChar)
        oParam(31).Value = CType(_Status, String)

        oParam(32) = New SqlClient.SqlParameter("@TGL_PROSES", SqlDbType.VarChar)
        oParam(32).Value = CType(_TGL_PROSES, String)

        oParam(33) = New SqlClient.SqlParameter("@NO_RCL", SqlDbType.VarChar)
        oParam(33).Value = CType(_NO_RCL, String)

        oParam(34) = New SqlClient.SqlParameter("@INVOICE", SqlDbType.VarChar)
        oParam(34).Value = CType(_NO_INVOICE, String)

        oParam(35) = New SqlClient.SqlParameter("@USER", SqlDbType.VarChar)
        oParam(35).Value = CType(_USER, String)

        ' NEW 2020/12/23 - INVOICE_DATE
        oParam(36) = New SqlClient.SqlParameter("@INVOICE_DATE", SqlDbType.VarChar)
        oParam(36).Value = CType(_INVOICE_DATE, String)


        Return (ExecuteNonQuery(_connectionString, const_sp_Update_Data_EC, CommandType.StoredProcedure, oParam))


    End Function

    Public Function f_Update_Data_Premi_Detail(ByVal _POLICYNO As Integer, ByVal _STATUSPOLIS As String, ByVal _GROUPNAME As String) As Integer


        Dim oParam(2) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(0).Value = CType(_POLICYNO, Integer)

        oParam(1) = New SqlClient.SqlParameter("@STATUS_POLIS", SqlDbType.VarChar)
        oParam(1).Value = CType(_STATUSPOLIS, String)

        oParam(2) = New SqlClient.SqlParameter("@GROUP_NAME", SqlDbType.VarChar)
        oParam(2).Value = CType(_GROUPNAME, String)

        Return (ExecuteNonQuery(_connectionString, const_sp_Update_Data_Premi_Detail, CommandType.StoredProcedure, oParam))

    End Function

    Public Function f_Update_Data_EC_Detail(ByVal _POLICYNO As Integer, ByVal _CLAIM_NO As String, ByVal _STATUS_CLAIM As String, _
                                            ByVal _RECEIPT_NO1 As String, ByVal _RECEIPT_NO2 As String, ByVal _RECEIPT_NO3 As String, _
                                            ByVal _STATUS_POLIS As String, ByVal _GROUP_NAME As String) As Integer


        Dim oParam(7) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(0).Value = CType(_POLICYNO, Integer)

        oParam(1) = New SqlClient.SqlParameter("@CLAIM_NO", SqlDbType.VarChar)
        oParam(1).Value = CType(_CLAIM_NO, String)

        oParam(2) = New SqlClient.SqlParameter("@STATUS_CLAIM", SqlDbType.VarChar)
        oParam(2).Value = CType(_STATUS_CLAIM, String)

        oParam(3) = New SqlClient.SqlParameter("@RECEIPT_NO1", SqlDbType.VarChar)
        oParam(3).Value = CType(_RECEIPT_NO1, String)

        oParam(4) = New SqlClient.SqlParameter("@RECEIPT_NO2", SqlDbType.VarChar)
        oParam(4).Value = CType(_RECEIPT_NO2, String)

        oParam(5) = New SqlClient.SqlParameter("@RECEIPT_NO3", SqlDbType.VarChar)
        oParam(5).Value = CType(_RECEIPT_NO3, String)

        oParam(6) = New SqlClient.SqlParameter("@STATUS_POLIS", SqlDbType.VarChar)
        oParam(6).Value = CType(_STATUS_POLIS, String)

        oParam(7) = New SqlClient.SqlParameter("@GROUP_NAME", SqlDbType.VarChar)
        oParam(7).Value = CType(_GROUP_NAME, String)

        Return (ExecuteNonQuery(_connectionString, const_sp_Update_Data_EC_Detail, CommandType.StoredProcedure, oParam))

    End Function

    Public Function f_Update_Data_Tagihan(ByVal _UNIQUECODE As String, ByVal _TANGGALTAGIH As String, ByVal _REMARK As String) As Integer

        Dim oParam(2) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@UNIQUECODE", SqlDbType.VarChar)
        oParam(0).Value = CType(_UNIQUECODE, String)

        oParam(1) = New SqlClient.SqlParameter("@TANGGALTAGIH", SqlDbType.VarChar)
        oParam(1).Value = CType(_TANGGALTAGIH, String)

        oParam(2) = New SqlClient.SqlParameter("@REMARK", SqlDbType.VarChar)
        oParam(2).Value = CType(_REMARK, String)

        Return (ExecuteNonQuery(_connectionString, const_sp_Update_Data_Tagihan, CommandType.StoredProcedure, oParam))

    End Function
End Class
