﻿Imports System.Configuration
Imports System.Data.SqlClient

Public Class SelectBase
    Inherits ClassModul

    Dim _connectionString As String = ConfigurationManager.ConnectionStrings("ConSql").ToString

#Region "Constanta"

    Dim const_sp_Redeem_And_Subscribe As String = "sp_Redeem_and_Subscribe"
    Dim const_sp_Asset_Value_Mutation As String = "sp_Asset_Value_Mutation"
    Dim const_sp_Rebate_Policy As String = "sp_Rebate_Policy_Level"
    Dim const_sp_Rebate_Member As String = "sp_Rebate_Member_Level"
    Dim const_sp_Account_Balance_Policy As String = "sp_Account_Balance_Policy_Level"
    Dim const_sp_Account_Balance_Member_Level As String = "sp_Account_Balance_Member_Level"
    Dim const_sp_Monthly_Asset As String = "sp_Monthly_Asset"
    Dim const_sp_Monthly_Asset_Groping As String = "sp_Monthly_Asset_Grouping_Fund"
    Dim const_sp_Report_Transaction As String = "sp_Report_Transaction"
    Dim const_sp_Sub_Report_Transaction As String = "sp_Sub_Report_Transaction"
    Dim const_sp_Sub_Report_Transaction_Member As String = "sp_Sub_Report_Transaction_Member"
    Dim const_sp_Get_Type_Policy As String = "sp_Cek_Type_Policy"
    Dim const_sp_Get_MemberNo As String = "sp_Get_MemberNo"
    Dim const_sp_Letter_Payment_Claim As String = "sp_Letter_Payment_Claim"
    Dim const_sp_Letter_Pengembalian_Claim As String = "sp_Letter_Pengembalian_Claim"
    Dim const_sp_check_rebate As String = "sp_cek_rebate"
    Dim const_sp_New_Report_Transaction As String = "sp_Transaction_New_Report"
    Dim const_sp_Sub_New_Report_Transaction_Contribution_Type As String = "sp_Get_Contribution_Type"
    Dim const_sp_Sub_New_Report_Transaction_Fund As String = "sp_Get_Fund_Policy"
    Dim const_sp_Sub_New_Report_Transaction As String = "sp_Sub_Transaction_New_Report"
    Dim const_sp_get_detail_premi As String = "sp_Get_Detail_Premi"
    Dim const_sp_get_detail_EC As String = "sp_Get_Detail_EC"
    Dim const_sp_Bind_Report_EC_Detail As String = "sp_Bind_Report_EC_Detail"
    Dim const_sp_Create_Report_EC_Detail As String = "sp_Create_Report_EC_Detail"
    Dim const_sp_Create_Report_Premi_Detail As String = "sp_Create_Report_Premi"
    Dim const_sp_Create_Report_Tagihan_Detail As String = "sp_Create_Report_Tagihan"
    Dim const_sp_Check_detail_EC As String = "sp_Check_detail_EC"
    Dim const_sp_Check_detail_Premi As String = "sp_Check_detail_Premi"
    Dim const_sp_Create_Report_Premi_Summary_Pivot As String = "sp_Create_Report_Premi_Summary_Pivot"
    Dim const_sp_Create_Report_Premi_Detail_Pivot As String = "sp_Create_Report_Premi_Detail_Pivot"
    Dim const_sp_Create_Report_EC_Summary_Pivot As String = "sp_Create_Report_EC_Summary_Pivot"
    Dim const_sp_Create_Report_EC_Detail_Pivot As String = "sp_Create_Report_EC_Detail_Pivot"
    'new 20201228 - upload_prime_tahunan, reza
    Dim const_sp_get_detail_premi_tahunan As String = "sp_Get_Detail_Premi_Tahunan"

    Dim const_sp_Create_Data_Penutupan_Layanan_Premi As String = "sp_Create_Data_Penutupan_Layanan_Premi"
    Dim const_sp_Create_Data_Penutupan_Layanan_EC As String = "sp_Create_Data_Penutupan_Layanan_EC"
#End Region

    Public Function sp_Asset_Value_Mutation(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _levelrpt As String, ByVal _fundtype As String, ByVal _membername As String, ByVal _memberno As String) As DataTable

        Dim oParam(6) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@levelrpt", SqlDbType.VarChar)
        oParam(3).Value = CType(_levelrpt, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)

        oParam(5) = New SqlClient.SqlParameter("@membername", SqlDbType.VarChar)
        oParam(5).Value = CType(_membername, String)

        oParam(6) = New SqlClient.SqlParameter("@memberno", SqlDbType.VarChar)
        oParam(6).Value = CType(_memberno, String)

        Return FillDataset(const_sp_Asset_Value_Mutation, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Redeem_And_Subscribe(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _levelrpt As String, ByVal _fundtype As String, ByVal _membername As String, ByVal _memberno As String) As DataTable

        Dim oParam(6) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@levelrpt", SqlDbType.VarChar)
        oParam(3).Value = CType(_levelrpt, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)

        oParam(5) = New SqlClient.SqlParameter("@membername", SqlDbType.VarChar)
        oParam(5).Value = CType(_membername, String)

        oParam(6) = New SqlClient.SqlParameter("@memberno", SqlDbType.VarChar)
        oParam(6).Value = CType(_memberno, String)

        Return FillDataset(const_sp_Redeem_And_Subscribe, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Rebate_Policy_Level(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(3) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(3).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_Rebate_Policy, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Rebate_Member_Level(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _memberno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@memberno", SqlDbType.VarChar)
        oParam(3).Value = CType(_memberno, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_Rebate_Member, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Get_Type_Polis(ByVal _PolisyNo As String) As DataTable

        Dim oParam(0) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@PolicyNo", SqlDbType.VarChar)
        oParam(0).Value = CType(_PolisyNo, String)

        Return FillDataset(const_sp_Get_Type_Policy, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Get_MemberNo(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _membername As String, ByVal _fundtype As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@MemberName", SqlDbType.VarChar)
        oParam(3).Value = CType(_membername, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_Get_MemberNo, CommandType.StoredProcedure, oParam)
    End Function
    Public Function sp_Account_Balance_Policy_Level(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(3) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(3).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_Account_Balance_Policy, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Account_Balance_Member_Level(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _memberno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@memberno", SqlDbType.VarChar)
        oParam(3).Value = CType(_memberno, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_Account_Balance_Member_Level, CommandType.StoredProcedure, oParam)
    End Function
    Public Function sp_Monthly_Asset(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(3) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(3).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_Monthly_Asset, CommandType.StoredProcedure, oParam)
    End Function
    Public Function sp_Monthly_Asset_Grouping(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(3) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(3).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_Monthly_Asset_Groping, CommandType.StoredProcedure, oParam)
    End Function
    Public Function sp_New_Report_Transaction(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _memberno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@memberno", SqlDbType.VarChar)
        oParam(3).Value = CType(_memberno, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)


        Return FillDataset(const_sp_New_Report_Transaction, CommandType.StoredProcedure, oParam)
    End Function
    Public Function sp_Sub_New_Report_Transaction_Contribution_Type(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _memberno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@memberno", SqlDbType.VarChar)
        oParam(3).Value = CType(_memberno, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_Sub_New_Report_Transaction_Contribution_Type, CommandType.StoredProcedure, oParam)
    End Function
    Public Function sp_Sub_New_Report_Transaction_Fund(ByVal _policyno As String, ByVal _startdate As String, ByVal _enddate As String) As DataTable

        Dim oParam(2) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(0).Value = CType(_policyno, String)

        oParam(1) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(1).Value = CType(_startdate, String)

        oParam(2) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(2).Value = CType(_enddate, String)


        Return FillDataset(const_sp_Sub_New_Report_Transaction_Fund, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Sub_New_Report_Transaction(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _memberno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@memberno", SqlDbType.VarChar)
        oParam(3).Value = CType(_memberno, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_Sub_New_Report_Transaction, CommandType.StoredProcedure, oParam)
    End Function
    Public Function sp_Report_Transaction(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _memberno As String, ByVal _fundtype As String, ByVal _lvlrpt As String) As DataTable

        Dim oParam(5) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@memberno", SqlDbType.VarChar)
        oParam(3).Value = CType(_memberno, String)

        oParam(4) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(4).Value = CType(_fundtype, String)

        oParam(5) = New SqlClient.SqlParameter("@levelrpt", SqlDbType.VarChar)
        oParam(5).Value = CType(_lvlrpt, String)

        Return FillDataset(const_sp_Report_Transaction, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Sub_Report_Transaction(ByVal _startdate As String, ByVal _enddate As String, ByVal _fundtype As String, ByVal _policyno As String) As DataTable

        Dim oParam(3) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(2).Value = CType(_fundtype, String)

        oParam(3) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(3).Value = CType(_policyno, String)

        Return FillDataset(const_sp_Sub_Report_Transaction, CommandType.StoredProcedure, oParam)
    End Function
    Public Function sp_Sub_Report_Transaction_Member(ByVal _startdate As String, ByVal _enddate As String, ByVal _fundtype As String, ByVal _policyno As String, ByVal _memberno As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(2).Value = CType(_fundtype, String)

        oParam(3) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(3).Value = CType(_policyno, String)

        oParam(4) = New SqlClient.SqlParameter("@memberno", SqlDbType.VarChar)
        oParam(4).Value = CType(_memberno, String)

        Return FillDataset(const_sp_Sub_Report_Transaction_Member, CommandType.StoredProcedure, oParam)
    End Function
    Public Function LetterPaymentClaim(ByVal _CLAMNO As String, ByVal _NOSURAT As String) As DataTable
        Dim oParam(1) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@CLAMNO", SqlDbType.VarChar)
        oParam(0).Value = CType(_CLAMNO, String)

        oParam(1) = New SqlClient.SqlParameter("@NOSURAT", SqlDbType.VarChar)
        oParam(1).Value = CType(_NOSURAT, String)

        Return FillDataset(const_sp_Letter_Payment_Claim, CommandType.StoredProcedure, oParam)

    End Function
    Public Function LetterRefundClaim(ByVal _CLAMNO As String, ByVal _NOSURAT As String) As DataTable
        Dim oParam(1) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@CLAMNO", SqlDbType.VarChar)
        oParam(0).Value = CType(_CLAMNO, String)

        oParam(1) = New SqlClient.SqlParameter("@NOSURAT", SqlDbType.VarChar)
        oParam(1).Value = CType(_NOSURAT, String)

        Return FillDataset(const_sp_Letter_Pengembalian_Claim, CommandType.StoredProcedure, oParam)

    End Function
    Public Function sp_check_rebate(ByVal _startdate As String, ByVal _enddate As String, ByVal _policyno As String, ByVal _fundtype As String) As DataTable

        Dim oParam(3) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@startdate", SqlDbType.VarChar)
        oParam(0).Value = CType(_startdate, String)

        oParam(1) = New SqlClient.SqlParameter("@enddate", SqlDbType.VarChar)
        oParam(1).Value = CType(_enddate, String)

        oParam(2) = New SqlClient.SqlParameter("@policyno", SqlDbType.VarChar)
        oParam(2).Value = CType(_policyno, String)

        oParam(3) = New SqlClient.SqlParameter("@fundtype", SqlDbType.VarChar)
        oParam(3).Value = CType(_fundtype, String)

        Return FillDataset(const_sp_check_rebate, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_get_detail_premi(ByVal _billno As String) As DataTable

        Dim oParam(0) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@BILL_NO", SqlDbType.VarChar)
        oParam(0).Value = CType(_billno, String)

        Return FillDataset(const_sp_get_detail_premi, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_get_detail_EC(ByVal _claimno As String) As DataTable

        Dim oParam(0) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@CLAIM_NO", SqlDbType.VarChar)
        oParam(0).Value = CType(_claimno, String)

        Return FillDataset(const_sp_get_detail_EC, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Bind_Report_EC_Detail(ByVal _policyno As String, ByVal _startdate As String, ByVal _enddate As String, ByVal _reason As String, ByVal _status As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICY_NO", SqlDbType.VarChar)
        oParam(0).Value = CType(_policyno, String)

        oParam(1) = New SqlClient.SqlParameter("@TGL_UPLOADFROM", SqlDbType.VarChar)
        oParam(1).Value = CType(_startdate, String)

        oParam(2) = New SqlClient.SqlParameter("@TGL_UPLOADTO", SqlDbType.VarChar)
        oParam(2).Value = CType(_enddate, String)

        oParam(3) = New SqlClient.SqlParameter("@REASON", SqlDbType.VarChar)
        oParam(3).Value = CType(_reason, String)

        oParam(4) = New SqlClient.SqlParameter("@STATUS", SqlDbType.VarChar)
        oParam(4).Value = CType(_status, String)

        Return FillDataset(const_sp_Bind_Report_EC_Detail, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Create_Report_EC_Detail(ByVal _policyno As String, ByVal _startdate As String, ByVal _enddate As String, ByVal _reason As String, ByVal _status As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICY_NO", SqlDbType.VarChar)
        oParam(0).Value = CType(_policyno, String)

        oParam(1) = New SqlClient.SqlParameter("@TGL_UPLOADFROM", SqlDbType.VarChar)
        oParam(1).Value = CType(_startdate, String)

        oParam(2) = New SqlClient.SqlParameter("@TGL_UPLOADTO", SqlDbType.VarChar)
        oParam(2).Value = CType(_enddate, String)

        oParam(3) = New SqlClient.SqlParameter("@REASON", SqlDbType.VarChar)
        oParam(3).Value = CType(_reason, String)

        oParam(4) = New SqlClient.SqlParameter("@STATUS", SqlDbType.VarChar)
        oParam(4).Value = CType(_status, String)

        Return FillDataset(const_sp_Create_Report_EC_Detail, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Create_Report_Premi_Detail(ByVal _policyno As String, ByVal _status As String, ByVal _reason As String) As DataTable

        Dim oParam(2) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.VarChar)
        oParam(0).Value = CType(_policyno, String)

        oParam(1) = New SqlClient.SqlParameter("@REASON", SqlDbType.VarChar)
        oParam(1).Value = CType(_reason, String)

        oParam(2) = New SqlClient.SqlParameter("@STATUS", SqlDbType.VarChar)
        oParam(2).Value = CType(_status, String)

        Return FillDataset(const_sp_Create_Report_Premi_Detail, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Check_detail_EC(ByVal _policyno As String, ByVal _claimno As String) As DataTable

        Dim oParam(1) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(0).Value = CType(_policyno, Integer)

        oParam(1) = New SqlClient.SqlParameter("@CLAIM_NO", SqlDbType.VarChar)
        oParam(1).Value = CType(_claimno, String)

        Return FillDataset(const_sp_Check_detail_EC, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Check_detail_Premi(ByVal _policyno As String) As DataTable

        Dim oParam(0) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.Int)
        oParam(0).Value = CType(_policyno, Integer)

        Return FillDataset(const_sp_Check_detail_Premi, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Create_Report_Summary_Premi_Pivot() As DataTable

        Return FillDataset(const_sp_Create_Report_Premi_Summary_Pivot, CommandType.StoredProcedure)
    End Function

    Public Function sp_Create_Report_Detail_Premi_Pivot() As DataTable

        Return FillDataset(const_sp_Create_Report_Premi_Detail_Pivot, CommandType.StoredProcedure)
    End Function

    Public Function sp_Create_Report_Summary_EC_Pivot() As DataTable

        Return FillDataset(const_sp_Create_Report_EC_Summary_Pivot, CommandType.StoredProcedure)
    End Function

    Public Function sp_Create_Report_Detail_EC_Pivot() As DataTable

        Return FillDataset(const_sp_Create_Report_EC_Detail_Pivot, CommandType.StoredProcedure)
    End Function


    Public Function sp_Create_Report_Tagihan(ByVal _typeReport As String) As DataTable

        Dim oParam(0) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@TYPEREPORT", SqlDbType.VarChar)
        oParam(0).Value = CType(_typeReport, String)

        Return FillDataset(const_sp_Create_Report_Tagihan_Detail, CommandType.StoredProcedure, oParam)
    End Function

    'new 20201228 - upload_prime_tahunan, reza
    ' gak dipakai karena di sp insert sudah ada filter ifexist
    Public Function sp_get_detail_premi_tahunan(ByVal POLICY_NUMBER As String) As DataTable

        Dim oParam(0) As SqlParameter

        oParam(0) = New SqlParameter("@POLICY_NUMBER", SqlDbType.VarChar)
        oParam(0).Value = POLICY_NUMBER

        Return FillDataset(const_sp_get_detail_premi_tahunan, CommandType.StoredProcedure, oParam)
    End Function

    Public Function sp_Create_Data_Penutupan_Layanan_Premi(ByVal _policyno As String, ByVal _status As String, ByVal _reason As String) As DataTable

        Dim oParam(2) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICYNO", SqlDbType.VarChar)
        oParam(0).Value = CType(_policyno, String)

        oParam(1) = New SqlClient.SqlParameter("@REASON", SqlDbType.VarChar)
        oParam(1).Value = CType(_reason, String)

        oParam(2) = New SqlClient.SqlParameter("@STATUS", SqlDbType.VarChar)
        oParam(2).Value = CType(_status, String)

        Return FillDataset(const_sp_Create_Data_Penutupan_Layanan_Premi, CommandType.StoredProcedure, oParam)
    End Function
    Public Function sp_Create_Data_Penutupan_Layanan_EC(ByVal _policyno As String, ByVal _startdate As String, ByVal _enddate As String, ByVal _reason As String, ByVal _status As String) As DataTable

        Dim oParam(4) As SqlParameter

        oParam(0) = New SqlClient.SqlParameter("@POLICY_NO", SqlDbType.VarChar)
        oParam(0).Value = CType(_policyno, String)

        oParam(1) = New SqlClient.SqlParameter("@TGL_UPLOADFROM", SqlDbType.VarChar)
        oParam(1).Value = CType(_startdate, String)

        oParam(2) = New SqlClient.SqlParameter("@TGL_UPLOADTO", SqlDbType.VarChar)
        oParam(2).Value = CType(_enddate, String)

        oParam(3) = New SqlClient.SqlParameter("@REASON", SqlDbType.VarChar)
        oParam(3).Value = CType(_reason, String)

        oParam(4) = New SqlClient.SqlParameter("@STATUS", SqlDbType.VarChar)
        oParam(4).Value = CType(_status, String)

        Return FillDataset(const_sp_Create_Data_Penutupan_Layanan_EC, CommandType.StoredProcedure, oParam)
    End Function

End Class
