﻿var TableActionProvider = {

    // get the table row of the event
    getEventTableRow: function(evt) {
        var ctrl = EventManager.getInputObject(evt);
        while (ctrl != null) {
            var tagName = ctrl.tagName.toLowerCase();
            if (tagName == "body") return null;
            if (tagName == "tr") break;
            ctrl = ctrl.parentNode;
        }
        return ctrl;
    },

    add: function(ctrl, backgroundColor, color, startRow, actionFunction, useSingleClick) {
        if (typeof (ctrl) == "string")
            ctrl = document.getElementById(ctrl);

        if (ctrl != null && ctrl.tagName.toLowerCase() == "table") {
            this.ctrl = ctrl;
            this.ctrl.style.cursor = "hand";
            this.ctrl.rowColor = color;
            this.ctrl.rowBackgroundColor = backgroundColor;
            this.ctrl.actionFunction = actionFunction;

            if (startRow == null) startRow = 0;
            this.ctrl.startRow = startRow;
            this.ctrl.currentRow = -1;

            EventManager.Add(this.ctrl, "mouseover", this.onMouseOver);
            EventManager.Add(this.ctrl, "mouseout", this.onMouseOut);

            if (useSingleClick)
                EventManager.Add(this.ctrl, "click", this.onAction);
            else
                EventManager.Add(this.ctrl, "dblclick", this.onAction);

            // loop through rows and save original color and backgroundColor
            for (var i = 0; i < this.ctrl.rows.length; i++) {
                this.ctrl.rows[i].color = this.ctrl.rows[i].style.color;
                this.ctrl.rows[i].backgroundColor = this.ctrl.rows[i].style.backgroundColor;
            }
        }
    },

    onMouseOver: function(evt) {
        var row = TableActionProvider.getEventTableRow(evt);
        if (row != null) {
            var ctrl = row.parentNode.parentNode;
            ctrl.currentRow = row.rowIndex;

            // set hovering color
            if (row.rowIndex >= ctrl.startRow) {
                row.style.backgroundColor = ctrl.rowBackgroundColor;
                row.style.color = ctrl.rowColor;
            }
        }
    },

    onMouseOut: function(e) {
        var row = TableActionProvider.getEventTableRow(e);
        if (row != null) {
            var ctrl = row.parentNode.parentNode;
            ctrl.currentRow = row.rowIndex;

            // restore original color
            if (row.rowIndex >= ctrl.startRow) {
                row.style.backgroundColor = row.backgroundColor;
                row.style.color = row.color;
            }
        }
    },

    onAction: function(e) {
        var row = TableActionProvider.getEventTableRow(e);
        if (row != null) {
            // get table
            var ctrl = row.parentNode.parentNode;
            ctrl.currentRow = row.rowIndex;

            if (row.rowIndex >= ctrl.startRow) {
                // perform action function and exit if one exist
                var actionFunction = ctrl.actionFunction;
                if (actionFunction != null && typeof (actionFunction) == "function") {
                    actionFunction(row);
                }
                else {

                    // else try to click the first clickable object
                    var clicked = false;
                    var cellElements = row.cells[0].all;
                    if (cellElements == null)
                        cellElements = row.cells[0].childNodes;

                    for (var i = 0; clicked == false && i < cellElements.length; i++) {
                        var child = cellElements[i];
                        var inputObj = EventManager.getInputObject(e);

                        // action directly on object so no need to click.
                        if (child == inputObj) {
                            clicked = true;
                            break;
                        }

                        var tagName = child.tagName.toLowerCase();
                        if (tagName == "a") {
                            if (child.click) {
                                child.click();
                                clicked = true;
                            }
                            else if (child.href) {
                                window.open(child.href, child.target ? child.target : '_self');
                                clicked = true;
                            }
                        }
                        else if (tagName == "input") {
                            switch (child.type) {
                                case "button":
                                case "submit":
                                case "radio":
                                case "checkbox":
                                    if (child.click) {
                                        child.click();
                                        clicked = true;
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                    } // for loop	
                }
            } // if valid row
        }
    } // onAction
};