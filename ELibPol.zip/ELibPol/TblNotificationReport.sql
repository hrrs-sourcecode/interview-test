USE [E-Library-Policy]
GO

/****** Object:  Table [dbo].[NotificationReport]    Script Date: 4/1/2022 9:43:52 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[NotificationReport](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DocumentID] [varchar](10) NOT NULL,
	[DepartmentID] [varchar](10) NULL,
	[DivisionID] [varchar](10) NULL,
	[Receiver] [varchar](max) NULL,
	[Subject] [varchar](max) NULL,
	[ApplicationName] [varchar](20) NOT NULL,
	[NotifLabel] [varchar](10) NULL,
	[IsSent] [bit] NULL,
	[Result] [varchar](max) NULL,
	[CreatedBy] [varchar](50) NULL,
	[CreatedDate] [datetime] NULL,
 CONSTRAINT [PK_NotificationReport] PRIMARY KEY NONCLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


