USE [E-Library-Policy]
GO

/****** Object:  Table [dbo].[Department]    Script Date: 4/1/2022 9:39:58 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Department](
	[DepartmentID] [int] IDENTITY(1,1) NOT NULL,
	[DivisionID] [varchar](50) NOT NULL,
	[DepartmentName] [varchar](50) NULL,
	[PICUsername] [varchar](50) NULL,
	[IsActive] [bit] NULL,
	[IsNotif] [bit] NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedBy] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
	[DeptHeadEmail] [varchar](max) NULL,
 CONSTRAINT [PK_Department] PRIMARY KEY NONCLUSTERED 
(
	[DepartmentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


