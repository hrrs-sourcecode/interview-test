﻿using System.Collections.Generic;

namespace MailNotification.Services.Interface
{
    public interface ILibraryNotificationService
    {
        string SentEmailNotification();
    }
}