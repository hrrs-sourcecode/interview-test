﻿using E_LibraryPolicy.Constatnt;
using MailNotification.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailNotification
{
    class Regulatory
    {
        public static List<MailDTO> ListNotif()
        {
            Entities db = new Entities();
            var ruleSet = db.Settings.Where(x => x.ApplicationName == SettingConst.Regulatory
                            && x.Key != SettingConst.DaysName).ToList();

            var weekly = ruleSet.Where(x => x.Frequency == SettingConst.Weekly).Select(x => Convert.ToInt32(x.Value));
            var monthly = ruleSet.Where(x => x.Frequency == SettingConst.Monthly).Select(x => Convert.ToInt32(x.Value));
            var quarterly = ruleSet.Where(x => x.Frequency == SettingConst.Quarterly).Select(x => Convert.ToInt32(x.Value));
            var halfyearly = ruleSet.Where(x => x.Frequency == SettingConst.HalfYearly).Select(x => Convert.ToInt32(x.Value));
            var yearly = ruleSet.Where(x => x.Frequency == SettingConst.Weekly).Select(x => Convert.ToInt32(x.Value));

            var year = DateTime.Now.Year;
            var month = DateTime.Now.Month;
            var now = DateTime.Now.AddMonths(1);

            //quarter check
            var currentQuarter = (DateTime.Now.Month - 1) / 3 + 1;
            var startQuarter = new DateTime(now.Year, (currentQuarter - 1) * 3 + 1, 1);
            var endQuarter = startQuarter.AddMonths(3).AddDays(-1);

            //halfyear
            var startHalfYear = new DateTime(DateTime.Today.Year, 1 + 6 * (DateTime.Today.Month / 7), 1);
            var endHalfYear = new DateTime(DateTime.Today.Year + DateTime.Today.Month / 7, 7 - 6 * (DateTime.Today.Month / 7), 1).AddDays(-1);

            //halfyear check
            var listData = (from dept in db.Departments
                            join DR in db.DepartmentRegulatories on dept.DepartmentID equals DR.DepartmentID
                            where dept.IsActive == true && DR.IsActive == true && dept.IsNotif == true
                            && DR.RegulatoryCategory.IsActive == true && (
                            //once
                            (DR.Schedulle == SettingConst.Once && DbFunctions.DiffDays(DR.Value, now) == 0
                            && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && DR.RegulatoryApprovals.Any(y => y.IsReviewed == true))))
                            || //monthly
                            (DR.Schedulle == SettingConst.Monthly && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && (!(DR.RegulatoryApprovals.Any(y => y.SubmissionDate.Value.Month == now.Month && y.IsReviewed == true)))))
                            && monthly.Any(x => x == DbFunctions.DiffDays(now, DR.Value)))
                            || //quarterly
                            (DR.Schedulle == SettingConst.Quarterly && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && (!(DR.RegulatoryApprovals.Any(y => y.SubmissionDate.Value >= startQuarter
                           && y.SubmissionDate.Value <= endQuarter && y.IsReviewed != true)))))
                            && quarterly.Any(x => x == DbFunctions.DiffDays(now, DR.Value)))
                            || //halfyearly
                            (DR.Schedulle == SettingConst.HalfYearly && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && (!(DR.RegulatoryApprovals.Any(y => y.SubmissionDate.Value >= startHalfYear
                            && y.SubmissionDate.Value <= endHalfYear && y.IsReviewed != true)))))
                            && halfyearly.Any(x => x == DbFunctions.DiffDays(now, DR.Value)))
                            || //yearly
                            (DR.Schedulle == SettingConst.Yearly && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && (!(DR.RegulatoryApprovals.Any(y => y.SubmissionDate.Value.Year == now.Year && y.IsReviewed == true)))))
                            && yearly.Any(x => x == DbFunctions.DiffDays(now, DR.Value)))
                            )
                            select new
                            {
                                dept.DepartmentID,
                                DR.DepartmentRegulatoryID,
                                Days = DbFunctions.DiffDays(now, DR.Value),
                                Frequency = DR.Schedulle
                            }).ToList();

            var docDepartment = new List<MailDTO>();
            //grouping berdasarkan department dan cek eskalasi
            if (listData.Count > 0)
            {
                foreach (var item in listData)
                {
                    var isEscalate = false;
                    var temp = docDepartment.Where(x => x.DepartmentID == item.DepartmentID).FirstOrDefault();
                    var setting = db.Settings.Where(x => x.ApplicationName == SettingConst.Regulatory
                                                    && x.Value == item.Days.ToString() && x.Frequency == item.Frequency).FirstOrDefault();
                    //cek apakah tanggal dibawah min
                    if (setting == null)
                    {
                        var tmpSetting = db.Settings.Where(x => x.ApplicationName == SettingConst.Library
                                && x.Key != SettingConst.DaysName).ToList().Select(x => Convert.ToInt32(x.Value)).Min();
                        if (tmpSetting > item.Days)
                            isEscalate = true;
                    }

                    if (temp != null)
                    {
                        temp.DepartmentRegulatoryID.Add(item.DepartmentRegulatoryID);
                        temp.Frequency += ", " + item.Frequency;
                        //kalau sudah true tdk perlu di rubah
                        if (!temp.IsEscalate)
                            temp.IsEscalate = isEscalate;
                    }
                    else
                    {
                        var newItem = new MailDTO();
                        newItem.DepartmentID = item.DepartmentID;
                        newItem.DepartmentRegulatoryID = new List<int>() { item.DepartmentRegulatoryID };
                        newItem.IsEscalate = isEscalate;
                        newItem.Frequency = item.Frequency;
                        docDepartment.Add(newItem);

                    }
                }
            };
            return docDepartment;
        }
        public static void NotifyRegulatory()
        {
            Entities db = new Entities();
            var ruleSet = db.Settings.Where(x => x.ApplicationName == SettingConst.Regulatory
                            && x.Key != SettingConst.DaysName).ToList();

            var weekly = ruleSet.Where(x => x.Frequency == SettingConst.Weekly).Select(x => Convert.ToInt32(x.Value));
            var monthly = ruleSet.Where(x => x.Frequency == SettingConst.Monthly).Select(x => Convert.ToInt32(x.Value));
            var quarterly = ruleSet.Where(x => x.Frequency == SettingConst.Quarterly).Select(x => Convert.ToInt32(x.Value));
            var halfyearly = ruleSet.Where(x => x.Frequency == SettingConst.HalfYearly).Select(x => Convert.ToInt32(x.Value));
            var yearly = ruleSet.Where(x => x.Frequency == SettingConst.Weekly).Select(x => Convert.ToInt32(x.Value));

            var year = DateTime.Now.Year;
            var month = DateTime.Now.Month;
            var now = DateTime.Now.AddMonths(1);

            //quarter check
            var currentQuarter = (DateTime.Now.Month - 1) / 3 + 1;
            var startQuarter = new DateTime(now.Year, (currentQuarter - 1) * 3 + 1, 1);
            var endQuarter = startQuarter.AddMonths(3).AddDays(-1);

            //halfyear
            var startHalfYear = new DateTime(DateTime.Today.Year, 1 + 6 * (DateTime.Today.Month / 7), 1);
            var endHalfYear = new DateTime(DateTime.Today.Year + DateTime.Today.Month / 7, 7 - 6 * (DateTime.Today.Month / 7), 1).AddDays(-1);

            //halfyear check
            var listData = (from dept in db.Departments
                            join DR in db.DepartmentRegulatories on dept.DepartmentID equals DR.DepartmentID
                            where dept.IsActive == true && DR.IsActive == true && dept.IsNotif == true
                            && DR.RegulatoryCategory.IsActive == true && (
                            //once
                            (DR.Schedulle == SettingConst.Once && DbFunctions.DiffDays(DR.Value, now) == 0
                            && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && DR.RegulatoryApprovals.Any(y => y.IsReviewed == true))))
                            || //monthly
                            (DR.Schedulle == SettingConst.Monthly && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && (!(DR.RegulatoryApprovals.Any(y => y.SubmissionDate.Value.Month == now.Month && y.IsReviewed == true)))))
                            && monthly.Any(x => x == DbFunctions.DiffDays(now, DR.Value)))
                            || //quarterly
                            (DR.Schedulle == SettingConst.Quarterly && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && (!(DR.RegulatoryApprovals.Any(y => y.SubmissionDate.Value >= startQuarter
                           && y.SubmissionDate.Value <= endQuarter && y.IsReviewed != true)))))
                            && quarterly.Any(x => x == DbFunctions.DiffDays(now, DR.Value)))
                            || //halfyearly
                            (DR.Schedulle == SettingConst.HalfYearly && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && (!(DR.RegulatoryApprovals.Any(y => y.SubmissionDate.Value >= startHalfYear
                            && y.SubmissionDate.Value <= endHalfYear && y.IsReviewed != true)))))
                            && halfyearly.Any(x => x == DbFunctions.DiffDays(now, DR.Value)))
                            || //yearly
                            (DR.Schedulle == SettingConst.Yearly && (!DR.RegulatoryApprovals.Any() || (DR.RegulatoryApprovals.Any()
                            && (!(DR.RegulatoryApprovals.Any(y => y.SubmissionDate.Value.Year == now.Year && y.IsReviewed == true)))))
                            && yearly.Any(x => x == DbFunctions.DiffDays(now, DR.Value)))
                            )
                            select new
                            {
                                dept.DepartmentID,
                                DR.DepartmentRegulatoryID,
                                Days = DbFunctions.DiffDays(now, DR.Value),
                                Frequency = DR.Schedulle
                            }).ToList();

            var docDepartment = new List<MailDTO>();
            //grouping berdasarkan department dan cek eskalasi
            foreach (var item in listData)
            {
                var isEscalate = false;
                var temp = docDepartment.Where(x => x.DepartmentID == item.DepartmentID).FirstOrDefault();
                var setting = db.Settings.Where(x => x.ApplicationName == SettingConst.Regulatory
                                                && x.Value == item.Days.ToString() && x.Frequency == item.Frequency).FirstOrDefault();
                //cek apakah tanggal dibawah min
                if (setting == null)
                {
                    var tmpSetting = db.Settings.Where(x => x.ApplicationName == SettingConst.Library
                            && x.Key != SettingConst.DaysName).ToList().Select(x => Convert.ToInt32(x.Value)).Min();
                    if (tmpSetting > item.Days)
                        isEscalate = true;
                }

                if (temp != null)
                {
                    temp.DepartmentRegulatoryID.Add(item.DepartmentRegulatoryID);
                    temp.Frequency += ", " + item.Frequency;
                    //kalau sudah true tdk perlu di rubah
                    if (!temp.IsEscalate)
                        temp.IsEscalate = isEscalate;
                }
                else
                {
                    var newItem = new MailDTO();
                    newItem.DepartmentID = item.DepartmentID;
                    newItem.DepartmentRegulatoryID = new List<int>() { item.DepartmentRegulatoryID };
                    newItem.IsEscalate = isEscalate;
                    newItem.Frequency = item.Frequency;
                    docDepartment.Add(newItem);

                }
            }

            foreach (var item in docDepartment)
            {
                var department = db.Departments.Find(item.DepartmentID);
                var listReceiver = new List<string>();

                var listDoc = db.DepartmentRegulatories.Where(x => item.DepartmentRegulatoryID.Any(y => y == x.DepartmentRegulatoryID)).ToList();

                var PIC = db.Users.Find(department.PICUsername);
                listReceiver.Add(PIC.Email);
                if (item.IsEscalate)
                {
                    listReceiver.AddRange(
                        db.Users.Where(x => x.DepartmentID == item.DepartmentID
                        && (x.IsChief == true || x.IsVice == true)).Select(x => x.Email));
                }
                //list document combined

                MailHelper mailHelper = new MailHelper();
                StreamReader sr = new StreamReader("MailTemplateRegulatory.html");
                string body = sr.ReadToEnd();
                var count = 1;
                var template = "<tr><td>{no}</td><td>{name}</td><td>{category}</td><td>{regulation}</td>" +
                    "<td>{addressee}</td><td>{frequency}</td><td>{duedate}</td></tr>";
                if (listDoc != null)
                {
                    var tmp = "";
                    foreach (var doc in listDoc)
                    {
                        tmp += template.Replace("{no}", count.ToString())
                                        .Replace("{name}", doc.ReportName)
                                        .Replace("{category}", doc.RegulatoryCategory.RegulatoryCategoryName)
                                        .Replace("{regulation}", doc.Regulation)
                                        .Replace("{addressee}", doc.Addressee)
                                        .Replace("{frequency}", doc.Schedulle)
                                        .Replace("{duedate}", doc.Value.Value.ToString("dd/MM/yyyy"));
                        count++;
                    }
                    body = body.Replace("{body}", tmp);
                    body = body.Replace("{name}", department.DepartmentName);
                    body = body.Replace("{date}", now.ToString("MMMM"));
                    mailHelper.SendMail("Submit Regulatory Document Reminder",
                            body, listReceiver, null, SettingConst.Regulatory,
                            string.Join(",", listDoc.Select(x => x.ReportName)), item.Frequency);
                }

            }
        }
    }
}
