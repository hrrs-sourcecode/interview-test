﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MailNotification.Model
{
    public class MailDTO
    {
        public int DepartmentID { get; set; }
        public List<int> DocumentID { get; set; }
        public List<int> DepartmentRegulatoryID { get; set; }
        public bool IsEscalate { get; set; }
        public string Frequency { get; set; }
    }
    public class Mail_By_PIC_DTO
    {
        public string PIC_Name { get; set; }
        public string PIC_Email { get; set; }
        public int DepartmentID { get; set; }
        public List<Document> LstDoc { get; set; }
        public bool IsEscalate { get; set; }
        public string Frequency { get; set; }
    }
}
