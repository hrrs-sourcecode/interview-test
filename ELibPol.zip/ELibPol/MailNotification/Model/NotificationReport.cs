﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailNotification.Model
{
    public class NotificationReport
    {
        public string DocumentID { get; set; }
        public string DepartmentID { get; set; }
        public string DivisionID { get; set; }
        public string Receiver { get; set; }
        public string Subject { get; set; }
        public string Application { get; set; }
        public string NotifLabel { get; set; }
        public bool IsSent { get; set; }
        public string Result { get; set; }
        public string CreatedBy { get; set; }
        public int LevelNotif { get; set; }
        public string PIC_Email { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
