﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailNotification.Model
{
    public class DocumentNotification
    {
        public string DocumentID { get; set; }
        public string DocNo { get; set; }
        public string NotifLabel { get; set; }
        public string Title { get; set; }
        public DateTime ExpiredDate { get; set; }
        public string PIC_Name { get; set; }
        public string PIC_Email { get; set; }
        public string DepartmentID { get; set; }
        public string DeptHeadUserName { get; set; }
        public string DeptHeadEmail { get; set; }
        public string DivisionID { get; set; }
        public string DivHeadUsername { get; set; }
        public string DivHeadEmail { get; set; }
        public string DocumentPath { get; set; }
    }
}
