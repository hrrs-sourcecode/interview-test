﻿using System.Collections.Generic;
using MailNotification.Model;

namespace MailNotification.Repositories.Interface
{
    public interface ILibraryNotificationRepository
    {
        IList<DocumentNotification> GetExpiredDocumentNotificationList();

        string SaveNotificationReport(IList<NotificationReport> listNotif);
    }
}