﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailNotification.Repositories
{
    public abstract class RepoHelper
    {
        protected virtual DataTable DataReaderWithSP(string strConnection, string strSPName, DataTable dtParam)
        {
            DataTable dtRet = new DataTable();
            using (SqlConnection connection = new SqlConnection(strConnection))
            {
                SqlCommand command = new SqlCommand(strSPName, connection);
                command.CommandType = CommandType.StoredProcedure;
                if (dtParam != null)
                {
                    int i = 0;
                    foreach (DataRow item in dtParam.Rows)
                    {
                        // convert dat type as varchar
                        SqlDbType dataType = SqlDbType.VarChar;
                        command.Parameters.Add(item[0].ToString(), dataType).Value = item[1];
                        i++;
                    }
                }

                command.Connection.Open();
                SqlDataAdapter adp = new SqlDataAdapter(command);
                adp.Fill(dtRet);
                adp.Dispose();
                command.Connection.Close();
            }
            return dtRet;
        }
    }
}
