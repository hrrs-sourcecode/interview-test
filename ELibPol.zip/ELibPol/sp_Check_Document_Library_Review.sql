USE [E-Library-Policy]
GO

/****** Object:  StoredProcedure [dbo].[sp_Check_Document_Library_Review]    Script Date: 4/1/2022 9:47:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_Check_Document_Library_Review]          
      
AS          
          
BEGIN          
           
SELECT 
	dep.[DepartmentID],dep.[DepartmentName],dep.[PICUsername],dep.[IsActive] as [dep_IsActive]
	,dep.[IsNotif],dep.[DeptHeadEmail]
	,doc.[DocumentID],doc.[Title],doc.[DocumentTypeID],doc.[AttachmentPath]
	,doc.[DocumentPath],doc.[EffectiveDate],doc.[Keywords],doc.[Number],doc.[ExpiredDate]
	,doc.[IsReviewed],doc.[IsApproved],doc.[ApprovedBy],doc.[ReviewedBy],doc.[Comments]
	,doc.[CreatedBy],doc.[CreatedDate],doc.[ModifiedBy],doc.[ModifiedDate],doc.[PIC_Name]
	,doc.[PIC_Email],doc.[IsActive] as [doc_IsActive]
	,DATEDIFF(day, convert(date,convert(varchar, getdate(), 23),23), convert(date,doc.ExpiredDate,23)) as [DATE_DIFF]
FROM  [dbo].[Department] dep
INNER JOIN  [dbo].[Document] doc
ON doc.DepartmentID = dep.DepartmentID
WHERE doc.ExpiredDate is not null 
and (
doc.IsReviewed is null
  and convert(date,doc.EffectiveDate,23) <=  convert(date,convert(varchar, getdate(), 23),23)
	  and (
		DATEDIFF(day, convert(date,convert(varchar, getdate(), 23),23), convert(date,doc.ExpiredDate,23)) = 60
		or
		DATEDIFF(day, convert(date,convert(varchar, getdate(), 23),23), convert(date,doc.ExpiredDate,23)) = 30
		or
		DATEDIFF(day, convert(date,convert(varchar, getdate(), 23),23), convert(date,doc.ExpiredDate,23)) % 7 = 0
	  )
  )
and (doc.NotifiedDate is null or convert(date,convert(varchar, doc.NotifiedDate, 23),23) != convert(date,convert(varchar, getdate(), 23),23))
and doc.isActive = 1
ORDER BY DATEDIFF(day, convert(date,convert(varchar, getdate(), 23),23), convert(date,doc.ExpiredDate,23)) ASC;
          
END
GO


