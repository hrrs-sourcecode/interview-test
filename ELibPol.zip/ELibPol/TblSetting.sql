USE [E-Library-Policy]
GO

/****** Object:  Table [dbo].[Setting]    Script Date: 4/1/2022 9:46:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Setting](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Key] [varchar](100) NULL,
	[Value] [varchar](max) NULL,
	[ApplicationName] [varchar](50) NULL,
	[Frequency] [varchar](50) NULL,
	[IsEscalate] [bit] NULL,
	[Description] [varchar](max) NULL,
	[IsStatic] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
 CONSTRAINT [PK_Setting] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


