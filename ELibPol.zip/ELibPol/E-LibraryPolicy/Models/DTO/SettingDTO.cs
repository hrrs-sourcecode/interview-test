﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Models.DTO
{
    public class SettingDTO
    {
        public int ID { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
        public string ApplicationName { get; set; }
        public string Frequency { get; set; }
        public Nullable<bool> IsEscalate { get; set; }
        public string Description { get; set; }
        public Nullable<bool> IsStatic { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
    }
}