﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Models.DTO
{
    public class UserDTO
    {
        public string Username { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Position { get; set; }
        public Nullable<bool> IsChief { get; set; }
        public Nullable<bool> IsVice { get; set; }
        public Nullable<int> DepartmentID { get; set; }
        public string DepartmentName
        {
            get
            {
                using (var db = new Entities())
                {
                    if (DepartmentID != null)
                    {
                        return db.Departments.Find(DepartmentID).DepartmentName;
                    }
                }
                return "";
            }
            set { }
        }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}