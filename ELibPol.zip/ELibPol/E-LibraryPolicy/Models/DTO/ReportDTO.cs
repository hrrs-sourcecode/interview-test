﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Models.DTO
{
    public class ReportDTO
    {
        public string Number { get; set; }
        public string Title { get; set; }
        public string Category { get; set; }
        public string Department { get; set; }
        public string  PIC { get; set; }
        public string EffectiveDate { get; set; }
        public string  ReviewDate { get; set; }
        public string IsReviewed { get; set; }
        public string IsApproved { get; set; }
    }
}