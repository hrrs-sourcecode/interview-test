﻿using E_LibraryPolicy.Constatnt;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Models.DTO
{
    public class DepartmentRegulatoryDTO
    {
        public int DepartmentRegulatoryID { get; set; }
        public Nullable<int> DepartmentID { get; set; }
        public string ReportName { get; set; }
        public Nullable<int> RegulatoryCategoryID { get; set; }
        public string Regulation { get; set; }
        public string Addressee { get; set; }
        public string Schedulle { get; set; }
        public bool IsFixed { get; set; }
        public DateTime Value { get; set; }
        public string Remarks { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<System.DateTime> LastRunDate { get; set; }
        public string LastRunMessage { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string DepartmentName
        {
            get
            {
                using (Entities db = new Entities())
                {
                    return db.Departments.Find(DepartmentID).DepartmentName;
                }
            }
        }
        public string RegulatoryName
        {
            get
            {
                using (Entities db = new Entities())
                {
                    return db.RegulatoryCategories.Find(RegulatoryCategoryID).RegulatoryCategoryName;
                }
            }
        }
    }
}