﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;

namespace E_LibraryPolicy.Models.DTO
{
    public class RegulatoryApprovalDTO
    {
        public int RegulatoryApprovalID { get; set; }
        public Nullable<int> DepartmentRegulatoryID { get; set; }
        public string Title { get; set; }
        public string FilePath { get; set; }
        public Nullable<bool> IsReviewed { get; set; }
        public string ReviewBy { get; set; }
        public string Status { get; set; }
        public Nullable<System.DateTime> SubmissionDate { get; set; }
        public string SubmissionComment { get; set; }
        public string ReviewComment { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string RegulatoryName
        {
            get
            {
                using (Entities db = new Entities())
                {
                    try
                    {
                        var departmentRegulatory = db.DepartmentRegulatories.Find(DepartmentRegulatoryID);
                        Regulation = departmentRegulatory.Regulation;
                        ReportName = departmentRegulatory.ReportName;
                        Addressee = departmentRegulatory.Addressee;
                        DueDate = departmentRegulatory.Value.Value.ToString("dd-MM-yyyy");
                        return departmentRegulatory.RegulatoryCategory.RegulatoryCategoryName;
                    }
                    catch { return ""; }

                }
            }
        }
        public string Regulation { get; set; }
        public string Addressee { get; set; }
        public string ReportName { get; set; }
        public string DueDate { get; set; }
        [IgnoreMap]
        public HttpPostedFileBase File { get; set; }
    }
}