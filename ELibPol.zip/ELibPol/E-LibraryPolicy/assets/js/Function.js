﻿const dateTime = (new Date()).toISOString().slice(0, 19).replace(/-/g, "/").replace("T", " ");

function Create(entity, data, url) {
    data["CreatedDate"] = dateTime
    data["CreatedBy"] = username;
    $.ajax({
        type: 'POST',
        url: url,
        data: JSON.stringify(data),
        contentType: 'application/json; charset=utf-8',
        dataType: "json",
        success: function (response) {
            if (response == "Success") {
                $("#tableData").DataTable().draw();
                Swal.fire(
                    'Success',
                    'Adding new ' + entity,
                    'success'
                );
                $('#modal').modal('hide');
                $('#form-modal')[0].reset();
            }
            else {
                Swal.fire(
                    'Failed',
                    'something went wrong, message :' + response,
                    'error'
                );
            }
        },
        error: function (xhr) {
            $('#modal').modal('hide');
            alert(xhr);
            console.log(xhr);
        }
    });
}

function Edit(entity, data, url) {
    data["ModifiedDate"] = dateTime
    data["ModifiedBy"] = username;
    console.log(data);
    $.ajax({
        type: 'POST',
        url: url,
        data: JSON.stringify(data),
        contentType: 'application/json; charset=utf-8',
        dataType: "json",
        success: function (response) {
            console.log(response["data"]);
            if (response == "Success") {
                $("#tableData").DataTable().draw();
                Swal.fire(
                    'Success',
                    'Selected ' + entity + ' change is saved',
                    'success'
                );
                $('#modal').modal('hide');
                $('#form-modal')[0].reset();
            }
            else {
                Swal.fire(
                    'Failed',
                    'something went wrong, message :' + response,
                    'error'
                );
            }
        },
        error: function (error) {
            $('#modal').modal('hide');
            alert(xhr);
            console.log(xhr);
        }
    });
}

function Delete(entity, id, url, primaryName) {
    Swal.fire({
        title: 'Are you sure want to delete this ' + entity + '?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result['value'] == true) {
            var data = {};
            data[primaryName] = id;
            $.ajax({
                type: 'POST',
                url: url,
                data: JSON.stringify(data),
                contentType: 'application/json; charset=utf-8',
                dataType: "json",
                success: function (response) {
                    if (response == "Success") {
                        $("#tableData").DataTable().draw();
                        Swal.fire(
                            'Deleted!',
                            'Selected ' + entity + ' has been deleted.',
                            'success'
                        );
                    }
                    else {
                        Swal.fire(
                            'Failed',
                            'something went wrong, message :' + response,
                            'error'
                        );
                    }
                },
                error: function (xhr) {
                    $('#modal').modal('hide');
                    alert(xhr);
                    console.log(xhr);
                }
            });
        }
    })
    return false;

}

(function ($) {
    $.fn.serializeFormToObject = function () {
        var data = $(this).serializeArray();
        $(':disabled[name]', this).each(function () {
            data.push({ name: this.name, value: $(this).val() })
        });
        $('input[type=checkbox]:not(:checked)', this).each(function () {
            data.push({ name: this.name, value: $(this).val() })
        });
        var obj = {};
        data.map(function (x) { obj[x.name] = x.value });
        return obj;
    }
})(jQuery);