﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using E_LibraryPolicy.Constatnt;
using E_LibraryPolicy.Models;

namespace E_LibraryPolicy.CustomAuth
{
    /// <summary>
    /// Propertis membership yang digunakan pada kemananan User
    /// </summary>
    public class CustomMembershipUser : MembershipUser
    {
        #region User Properties

        /// <summary>
        /// Propertis yang digunakan dalam identitas login User
        /// </summary>
        public string Username { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public string EmployeeNumber { get; set; }
        public int DepartmentID { get; set; }
        public bool IsAdminLibrary { get; set; }
        public bool IsAdminRegulatory { get; set; }
        public bool IsPIC { get; set; }
        public bool IsChief { get; set; }
        public bool IsVice { get; set; }
        #endregion       

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        public CustomMembershipUser(User user) : base("CustomMembership", user.Username, user.Name, user.Email, string.Empty, string.Empty, true, false, DateTime.Now, DateTime.Now, DateTime.Now, DateTime.Now, DateTime.Now)
        {
            Username = user.Username;
            Name = user.Name;
            Email = user.Email;
            Position = user.Position;
            DepartmentID = user.DepartmentID.HasValue ? user.DepartmentID.Value : 0;
            EmployeeNumber = user.Name;
            IsAdminRegulatory = user.Position == UserConst.AdminRegulatory || user.Position == UserConst.SuperAdmin;
            IsAdminLibrary = user.Position == UserConst.AdminLibrary || user.Position == UserConst.SuperAdmin;
            IsChief = user.IsChief.HasValue? user.IsChief.Value : false;
            IsVice = user.IsVice.HasValue ? user.IsVice.Value : false;
        }
        #region UnUsed
        #endregion

    }
}