﻿using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;

namespace E_LibraryPolicy
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        protected void Application_PostAuthenticateRequest(Object sender, EventArgs e)
        {
            string cookieName = WebConfigurationManager.AppSettings["CookieName"];
            HttpCookie authCookie = Request.Cookies[cookieName];
            if (authCookie != null)
            {
                FormsAuthenticationTicket authTicket = FormsAuthentication.Decrypt(authCookie.Value);
                var serializeModel = JsonConvert.DeserializeObject<CustomSerializeModel>(authTicket.UserData);
                if (serializeModel != null)
                {
                    CustomPrincipal principal = new CustomPrincipal(authTicket.Name);

                    principal.Username = serializeModel.Username;
                    principal.Name = serializeModel.Name;
                    principal.Position = serializeModel.Position;
                    principal.DepartmentID = serializeModel.DepartmentID;
                    principal.IsAdminLibrary = serializeModel.IsAdminLibrary;
                    principal.IsAdminRegulatory = serializeModel.IsAdminRegulatory;
                    principal.IsUserLibrary = serializeModel.IsUserLibrary;
                    principal.IsUserRegulatory = serializeModel.IsUserRegulatory;
                    principal.IsPIC = serializeModel.IsPIC;
                    principal.IsChief = serializeModel.IsChief;
                    principal.IsVice = serializeModel.IsVice;

                    principal.EmployeeNumber = serializeModel.EmployeeNumber;
                    HttpContext.Current.User = principal;
                }
            }
            else
            {
                HttpContext.Current.User = null;
            }
        }
    }
}
