﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_LibraryPolicy.Constatnt
{
    public class UserConst
    {
        public const string AdminLibrary = "AdminLibrary";
        public const string UserLibrary = "UserLibrary";
        public const string AdminRegulatory = "AdminRegulatory";
        public const string UserRegulatory = "UserRegulatory";
        public const string SuperAdmin = "SuperAdmin";

    }
}