﻿using AutoMapper;
using E_LibraryPolicy.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Reflection;
using System.Web;

namespace E_LibraryPolicy.Helper
{
    public class DataObjectHelper
    {
        public object GetPropValue(object src, string propName)
        {
            try
            {
                return src.GetType().GetProperty(propName).GetValue(src, null);
            }
            catch { return null; }

        }

        public void SetPropertyValue(object obj, string propName, object value)
        {
            obj.GetType().GetProperty(propName).SetValue(obj, value, null);
        }

        public void MapDataObject(Object target, Object source)
        {
            foreach (var prop in target.GetType().GetProperties())
            {
                var targetValue = GetPropValue(target, prop.Name);
                var sourceValue = GetPropValue(source, prop.Name);
                if (!targetValue.Equals(sourceValue))
                {
                    SetPropertyValue(target, prop.Name, sourceValue);
                }
            }
        }

        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == 
                    typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);               
                dataTable.Columns.Add(prop.Name, type);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            return dataTable;
        }

        public List<TResult> MapEntityDTO<TFrom, TResult>(IQueryable<TFrom> entry)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<TFrom, TResult>();
            });
            var iMapper = config.CreateMapper();
            var result = iMapper.Map<IQueryable<TFrom>, List<TResult>>(entry);
            return result;
        }

        public TResult MapEntityDTO<TFrom, TResult>(TFrom entry)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<TFrom, TResult>();
            });
            var iMapper = config.CreateMapper();
            var result = iMapper.Map<TFrom, TResult>(entry);
            return result;
        }
    }
    public class MailHelper
    {
        Entities db = new Entities();
        public string SendMail(string title, string body, List<string> to, List<string> cc, string app, string docIdentifier, string frequency)
        {
            try
            {
                string smtp = ConfigurationManager.AppSettings["smtp"];
                string port = ConfigurationManager.AppSettings["port"];
                string mailSender = ConfigurationManager.AppSettings["mailSender"];

                MailMessage mail = new MailMessage();
                SmtpClient smtpServer = new SmtpClient();

                smtpServer.Port = (int) Convert.ToInt32(port);
                smtpServer.EnableSsl = false;
                smtpServer.Host = smtp;
                mail.From = new MailAddress(mailSender, "Compliance AMFS");
                foreach (var item in to)
                {
                    mail.To.Add(new MailAddress(item));
                }
                if (cc != null)
                {
                    foreach (var item in cc)
                    {
                        mail.CC.Add(new MailAddress(item));
                    }
                }
                mail.Subject = title;
                mail.Body = body;
                mail.IsBodyHtml = true;

                smtpServer.Send(mail);
            }
            catch (Exception ex)
            {
                LogScheduller(string.Join(",", to), app, docIdentifier, false, ex.Message, frequency);
                return ex.Message;
            }

            LogScheduller(string.Join(",", to), app, docIdentifier, true, "Success", frequency);
            return "Success";
        }

        public void LogScheduller(string receiver, string app, string subject, bool isSent, string result, string frequency)
        {
            var log = new SchedullerReport();
            log.Receiver = receiver;
            log.Applications = app;
            log.IsSent = isSent;
            log.Result = result;
            log.Subject = subject;
            log.Frequency = frequency;
            log.CreatedDate = DateTime.Now;

            db.SchedullerReports.Add(log);
            db.SaveChanges();
        }
    }
}