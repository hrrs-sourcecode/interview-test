﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Constatnt;

namespace E_LibraryPolicy.Controllers
{
    [CustomAuthorize (IsAdminLibrary = true, IsAdminRegulatory = true)]
    public class SettingsController : AbstractController<Setting, SettingDTO>
    {
        protected override IQueryable<Setting> FilterData(string searchValue, IQueryable<Setting> List)
        {
            var user = (CustomPrincipal)User;
            if (user.IsAdminRegulatory && !user.IsAdminLibrary)
            {
                List = List.Where(x => x.ApplicationName == SettingConst.Regulatory);
            }
            else if (user.IsAdminLibrary && !user.IsAdminRegulatory)
            {
                List = List.Where(x => x.ApplicationName == SettingConst.Library);
            }
            else if(!user.IsAdminRegulatory && !user.IsAdminLibrary)
            {
                List = Enumerable.Empty<Setting>().AsQueryable();
            }

            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                List = List.Where(x => x.Key.ToLower().Contains(searchValue) 
                                || x.Value.ToLower().Contains(searchValue)
                                || x.Description.ToLower().Contains(searchValue));
            }
            return List;
        }
    }
}

