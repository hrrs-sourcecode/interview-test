﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using E_LibraryPolicy.Constatnt;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Helper;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;
using System.Linq.Dynamic;
using System.IO;
using System.Web.Configuration;
using ClosedXML.Excel;
using System.Reflection;

namespace E_LibraryPolicy.Controllers
{
    public class DepartmentRegulatoriesController : AbstractController<DepartmentRegulatory, DepartmentRegulatoryDTO>
    {
        private Entities db = new Entities();
        DataObjectHelper dataHelper = new DataObjectHelper();

        [CustomAuthorize(IsAdminRegulatory = true)]
        public override ActionResult Index()
        {
            ViewBag.DepartmentID = new SelectList(db.Departments.Where(x=>x.IsActive == true), "DepartmentID", "DepartmentName");
            ViewBag.RegulatoryCategoryID = new SelectList(db.RegulatoryCategories.Where(x =>x.IsActive == true), "RegulatoryCategoryID", "RegulatoryCategoryName");
            return View();
        }

        protected override IQueryable<DepartmentRegulatory> FilterData(string searchValue, IQueryable<DepartmentRegulatory> List)
        {
            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                List = List.Where(x => x.Department.DepartmentName.ToLower().Contains(searchValue)
                || x.RegulatoryCategory.RegulatoryCategoryName.ToLower().Contains(searchValue)
                || x.ReportName.ToLower().Contains(searchValue)
                || x.Addressee.ToLower().Contains(searchValue)
                || x.Regulation.ToLower().Contains(searchValue));
            }
            return List;
        }

        public ActionResult DocumentSubmission()
        {
            var user = (CustomPrincipal)User;
            if(user.IsAdminRegulatory || user.IsVice || user.IsChief || user.IsPIC)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Home", "Documents");
            }
        }

        [HttpPost]
        public virtual ActionResult GetDocumentList()
        {
            var user = (CustomPrincipal)User;
            int start = Convert.ToInt32(Request.Form["start"]);
            int lenght = Convert.ToInt32(Request.Form["length"]);
            string searchValue = Request.Form["search[value]"];
            string column = Request.Form["order[0][column]"];
            string sortCoulmnName = Request.Form["columns[" + column + "][data]"];
            string sortDirection = Request.Form["order[0][dir]"];

            var allData = db.DepartmentRegulatories.Where(x=> x.Department.IsActive == true && x.IsActive == true).AsQueryable();
            if (!user.IsAdminRegulatory)
            {
                allData = allData.Where(x => x.DepartmentID == user.DepartmentID);
            }
            var total = allData.Count();
            var totalFiltered = total;

            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                allData = allData.Where(x => x.RegulatoryCategory.RegulatoryCategoryName.ToLower().Contains(searchValue));
            }
            try
            {
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }
            catch
            {
                //custom sorting by name
                sortCoulmnName = Request.Form["columns[" + column + "][name]"];
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }
            totalFiltered = allData.Count();

            allData = allData.Skip(start).Take(lenght).AsQueryable();

            var result = dataHelper.MapEntityDTO<DepartmentRegulatory, RegulatorySubmitDTO>(allData);

            return Json(new { data = result.ToList(), draw = Request.Form["draw"], recordsFiltered = totalFiltered, recordsTotal = total });
        }

        [HttpGet]
        public ActionResult GetFile(string path)
        {
            return File(path, "application/pdf");
        }

        [HttpPost]
        public ActionResult SubmitDocuments(RegulatoryApprovalDTO entry)
        {
            try
            {
                string dir = WebConfigurationManager.AppSettings["DocumentDirectoryPath"];
                dir = Server.MapPath(dir);
                if (entry.File != null)
                {
                    var fileName = Path.GetFileName(entry.File.FileName);
                    Guid guid = Guid.NewGuid();
                    var path = Path.Combine(dir, guid.ToString() + ".pdf");
                    entry.File.SaveAs(path);
                    entry.FilePath = path;
                }
                var result = dataHelper.MapEntityDTO<RegulatoryApprovalDTO, RegulatoryApproval>(entry);
                result.CreatedBy = User.Identity.Name;
                result.CreatedDate = DateTime.Now;
                db.RegulatoryApprovals.Add(result);
                db.SaveChanges();

                return Json("Success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }

        [CustomAuthorize(IsAdminRegulatory = true)]
        public ActionResult ReportRegulatories()
        {
            return View();
        }

        [HttpPost]
        public virtual ActionResult GetReportList()
        {
            var user = (CustomPrincipal)User;
            int start = Convert.ToInt32(Request.Form["start"]);
            int lenght = Convert.ToInt32(Request.Form["length"]);
            string searchValue = Request.Form["search[value]"];
            string column = Request.Form["order[0][column]"];
            string sortCoulmnName = Request.Form["columns[" + column + "][data]"];
            string sortDirection = Request.Form["order[0][dir]"];

            var allData = from DR in db.DepartmentRegulatories
                          join deparment in db.Departments
                          on DR.DepartmentID equals deparment.DepartmentID 
                          join RA in db.RegulatoryApprovals on DR.DepartmentRegulatoryID equals RA.DepartmentRegulatoryID into tmp
                          from RA in tmp.DefaultIfEmpty()
                          select new RegulatoryReportDTO()
                          {
                              ReportName = DR.ReportName,
                              DepartmentName = deparment.DepartmentName,
                              RegulatoryName = DR.RegulatoryCategory.RegulatoryCategoryName,
                              Regulation = DR.Regulation,
                              Addressee = DR.Addressee,
                              Schedulle = DR.Schedulle,
                              Status = string.IsNullOrEmpty(RA.Status) ? "Not Yet Submited" : RA.Status,
                              SubmissionDate = RA !=null ? RA.SubmissionDate : null,
                              SubmissionComment = RA.SubmissionComment,
                              CreatedDate = RA !=null ? RA.CreatedDate : null
                          };

            var total = allData.Count();
            var totalFiltered = total;

            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                allData = allData.Where(x => x.ReportName.ToLower().Contains(searchValue)
                                        || x.RegulatoryName.ToLower().Contains(searchValue)
                                        || x.RegulatoryName.ToLower().Contains(searchValue)
                                        || x.Addressee.ToLower().Contains(searchValue)
                                        || x.Schedulle.ToLower().Contains(searchValue)
                                        || x.Status.ToLower().Contains(searchValue)
                                        || x.SubmissionComment.ToLower().Contains(searchValue));
            }

            try
            {
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }
            catch
            {
                //custom sorting by name
                sortCoulmnName = Request.Form["columns[" + column + "][name]"];
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }
            totalFiltered = allData.Count();

            allData = allData.Skip(start).Take(lenght).AsQueryable();

            return Json(new { data = allData.ToList(), draw = Request.Form["draw"], recordsFiltered = totalFiltered, recordsTotal = total });
        }

        public ActionResult DownloadReport()
        {
            var allData = (from DR in db.DepartmentRegulatories
                          join deparment in db.Departments
                          on DR.DepartmentID equals deparment.DepartmentID
                          join RA in db.RegulatoryApprovals on DR.DepartmentRegulatoryID equals RA.DepartmentRegulatoryID into tmp
                          from RA in tmp.DefaultIfEmpty()
                          select new RegulatoryReportDTO()
                          {
                              ReportName = DR.ReportName,
                              DepartmentName = deparment.DepartmentName,
                              RegulatoryName = DR.RegulatoryCategory.RegulatoryCategoryName,
                              Regulation = DR.Regulation,
                              Addressee = DR.Addressee,
                              Schedulle = DR.Schedulle,
                              Status = string.IsNullOrEmpty(RA.Status) ? "Not Yet Submited" : RA.Status,
                              SubmissionDate = RA != null ? RA.SubmissionDate : null,
                              SubmissionComment = RA.SubmissionComment,
                              CreatedDate = RA != null ? RA.CreatedDate : null
                          }).ToList();

            DataObjectHelper helper = new DataObjectHelper();
            var dt = helper.ToDataTable(allData);
            XLWorkbook wb = new XLWorkbook();

            wb.Worksheets.Add(dt, "Regulatory Report");
            MemoryStream mSteream = new MemoryStream();
            wb.SaveAs(mSteream);
            return File(mSteream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Regulatory Report.xls");
        }
    }
}
