﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;

namespace E_LibraryPolicy.Controllers
{
    [CustomAuthorize]
    public class HomeController : AbstractController<Division, DivisionDTO>
    {
        Entities db = new Entities();
        public override ActionResult Index()
        {
            IList<DivisionDTO> divList = new List<DivisionDTO>();

            EntityToDTOBulk(db.Divisions.Where(x => x.IsActive.Value))
                .ForEach(x =>
               {
                   divList.Add(new DivisionDTO { DivisionID = x.DivisionID, DivisionName = x.DivisionName, DepartmentCount = db.Departments.Count(z => z.DivisionID == x.DivisionID.ToString()) , DepartmentActiveCount = db.Departments.Count(z => z.DivisionID == x.DivisionID.ToString() && z.IsActive.Value)   });
               });

            ViewBag.DivisionList = divList;

            ViewBag.AllDocuments = new DepartmentDTO
            {
                DepartmentName = "All Documents",
                DepartmentID = -1,
                FileCount = db.Documents.Where(x => x.IsActive == true).Count(),
                FileApprovedCount = db.Documents.Where(x => x.IsApproved == true && x.IsActive == true).Count()
            };

            return View();
        }

        public ActionResult Dashboard()
        {
            return View();
        }
    }
}