﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.DirectoryServices;
using System.Linq;
using System.Net;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;
using System.Net.Mail;

namespace E_LibraryPolicy.Controllers
{
    //[CustomAuthorize(IsAdminRegulatory = true, IsAdminLibrary =true)]
    public class DepartmentsController : AbstractController<Department, DepartmentDTO>
    {
        Entities db = new Entities();
        public override ActionResult Index()
        {
            ViewBag.DivisionID = new SelectList(db.Divisions.Where(x => x.IsActive == true), "DivisionID", "DivisionName");
            return View();
        }

        public ActionResult Dashboard(string divisionID)
        {
            var dept = db.Departments.Where(x => x.IsActive == true && x.DivisionID == divisionID).AsQueryable();
            var departmentList = EntityToDTOBulk(dept);
            foreach (var item in departmentList)
            {
                var doc = db.Documents.Where(x => x.DepartmentID == item.DepartmentID);
                item.FileCount = doc.Count();
                item.FileApprovedCount = doc.Where(x => x.IsApproved == true && x.IsReviewed == true && x.DocumentType.IsActive == true).Count();
            }
            departmentList.Insert(0, new DepartmentDTO()
            {
                DepartmentName = "All Department",
                DepartmentID = -1,
                FileCount = departmentList.Select(x => x.FileCount).Sum(),
                FileApprovedCount = departmentList.Select(x => x.FileApprovedCount).Sum()
            });
            ViewBag.DepartmentList = departmentList;
            return View();
        }

        protected override IQueryable<Department> FilterData(string searchValue, IQueryable<Department> List)
        {
            if (!string.IsNullOrEmpty(searchValue))
            {
                return List.Where(x => x.DepartmentName.Contains(searchValue) ||
                                        x.PICUsername.Contains(searchValue));
            }
            return List;
        }

        public override ActionResult Create(DepartmentDTO entry)
        {
            return Json(CreteEditFunctions(entry));
        }

        public override ActionResult Edit(DepartmentDTO entry)
        {
            return Json(CreteEditFunctions(entry));
        }

        private string CreteEditFunctions(DepartmentDTO entry)
        {
            try
            {
                using (Entities db = new Entities())
                {
                    //check if PIC already exist
                    //if (!string.IsNullOrEmpty(entry.PICUsername) && !db.Users.Any(x => x.Username == entry.PICUsername))
                    //{
                    //    string domain = WebConfigurationManager.AppSettings["ActiveDirectoryUrl"];
                    //    string ldapUser = WebConfigurationManager.AppSettings["ADUsername"];
                    //    string ldapPassword = WebConfigurationManager.AppSettings["ADPassword"];
                    //    using (DirectoryEntry dirEntry = new DirectoryEntry(domain, ldapUser, ldapPassword))
                    //    {
                    //        DirectorySearcher search = new DirectorySearcher(dirEntry);

                    //        search.Filter = "(SAMAccountName=" + entry.PICUsername + ")";
                    //        search.PropertiesToLoad.Add("name");
                    //        search.PropertiesToLoad.Add("mail");
                    //        search.PropertiesToLoad.Add("department");
                    //        search.PropertiesToLoad.Add("title");
                    //        search.PropertiesToLoad.Add("EMPLOYEENUMBER");

                    //        SearchResult searchResult = search.FindOne();

                    //        User newUser = new Models.User();
                    //        var test = searchResult.Properties["mail"];
                    //        newUser.Name = (String)searchResult.Properties["name"][0];
                    //        newUser.Username = entry.PICUsername;
                    //        newUser.Email = (String)searchResult.Properties["mail"][0];
                    //        newUser.Position = searchResult.Properties.Contains("title") ? (String)searchResult.Properties["title"][0] : "";
                    //        newUser.CreatedBy = User.Identity.Name;
                    //        newUser.CreatedDate = DateTime.Now;
                    //        db.Users.Add(newUser);
                    //    }
                    //}
                    string strRet = "";

                    var data = DTOToEntity(entry);
                    var dbEntry = db.Entry(data);

                    if (entry.DepartmentID == 0)
                    {
                        data.CreatedBy = User.Identity.Name;
                        data.CreatedDate = DateTime.Now;
                        dbEntry.State = EntityState.Added;
                    }
                    else
                    {
                        Department prevDepartment = db.Departments.FirstOrDefault(x => x.DepartmentID == entry.DepartmentID);

                        //prevDepartment = DTOToEntity(entry);
                        prevDepartment.DepartmentName = entry.DepartmentName;
                        prevDepartment.DeptHeadEmail = entry.DeptHeadEmail;
                        prevDepartment.PICUsername = entry.PICUsername;
                        prevDepartment.DivisionID = entry.DivisionID;
                        prevDepartment.IsActive = entry.IsActive;
                        prevDepartment.IsNotif = entry.IsNotif;
                        prevDepartment.ModifiedBy = User.Identity.Name;
                        prevDepartment.ModifiedDate = DateTime.Now;
                    }

                    db.SaveChanges();
                    strRet = "Success";

                    return strRet;
                }
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }

        }

        public override ActionResult GetList()
        {
            int total = 0;
            int totalFiltered = 0;
            IList<DepartmentDTO> result = new List<DepartmentDTO>();
            db.Departments.ToList()
                .ForEach(x =>
                {
                    result.Add(new DepartmentDTO
                    {
                        DepartmentID = x.DepartmentID,
                        DepartmentName = x.DepartmentName,
                        DivisionID = x.DivisionID,
                        DivisionName = db.Divisions.FirstOrDefault(z => z.DivisionID.ToString() == x.DivisionID ).DivisionName,
                        DeptHeadEmail = x.DeptHeadEmail,
                        PICUsername = x.PICUsername,
                        IsActive = x.IsActive,
                        IsNotif = x.IsNotif
                    });
                });

            //result = result.Where(x => x.GetType().GetProperties().Where(prop => (prop.GetValue(x).ToString()).Contains(searchValue)).Ge.Contains(searchValue))
            totalFiltered = result.Count;
            total = result.Count;

            return Json(new { data = result.ToList(), draw = Request.Form["draw"], recordsFiltered = totalFiltered, recordsTotal = total });
        }

        //[HttpGet]
        //public ActionResult CheckUserAD(string username)
        //{
        //    bool result = false;
        //    string domain = WebConfigurationManager.AppSettings["ActiveDirectoryUrl"];
        //    string ldapUser = WebConfigurationManager.AppSettings["ADUsername"];
        //    string ldapPassword = WebConfigurationManager.AppSettings["ADPassword"];
        //    using (DirectoryEntry entry = new DirectoryEntry(domain, ldapUser, ldapPassword))
        //    {
        //        DirectorySearcher search = new DirectorySearcher(entry);

        //        search.Filter = "(SAMAccountName=" + username + ")";
        //        SearchResult searchResult = search.FindOne();
        //        if (searchResult != null)
        //            result = true;
        //    }
        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}
        //public static bool IsValidEmail(string email)
        //{
        //    if (string.IsNullOrWhiteSpace(email))
        //        return false;
        //    try
        //    {
        //        MailAddress m = new MailAddress(email);

        //        return true;
        //    }
        //    catch (FormatException)
        //    {
        //        return false;
        //    }
        //}

        //public static bool IsValidEmail(string email)
        //{
        //    if (string.IsNullOrWhiteSpace(email))
        //        return false;

        //    try
        //    {
        //        // Normalize the domain
        //        email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
        //                              RegexOptions.None, TimeSpan.FromMilliseconds(200));

        //        // Examines the domain part of the email and normalizes it.
        //        string DomainMapper(Match match)
        //        {
        //            // Use IdnMapping class to convert Unicode domain names.
        //            var idn = new IdnMapping();

        //            // Pull out and process domain name (throws ArgumentException on invalid)
        //            string domainName = idn.GetAscii(match.Groups[2].Value);

        //            return match.Groups[1].Value + domainName;
        //        }
        //    }
        //    catch (RegexMatchTimeoutException e)
        //    {
        //        return false;
        //    }
        //    catch (ArgumentException e)
        //    {
        //        return false;
        //    }

        //    try
        //    {
        //        return Regex.IsMatch(email,
        //            @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
        //            RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
        //    }
        //    catch (RegexMatchTimeoutException)
        //    {
        //        return false;
        //    }
        //}
    }
}
