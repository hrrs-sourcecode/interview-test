﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.DirectoryServices;
using System.Linq;
using System.Net;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;
using System.Net.Mail;

namespace E_LibraryPolicy.Controllers
{
    //[CustomAuthorize(IsAdminRegulatory = true, IsAdminLibrary =true)]
    public class DivisionsController : AbstractController<Division, DivisionDTO>
    {
        protected override IQueryable<Division> FilterData(string searchValue, IQueryable<Division> List)
        {
            if (!string.IsNullOrEmpty(searchValue))
            {
                return List.Where(x => x.DivisionName.Contains(searchValue) ||
                                        x.DivHeadUsername.Contains(searchValue));
            }
            return List;
        }

        public override ActionResult Create(DivisionDTO entry)
        {
            return Json(CreateEditFunctions(entry));
        }

        public override ActionResult Edit(DivisionDTO entry)
        {
            return Json(CreateEditFunctions(entry));
        }

        private string CreateEditFunctions(DivisionDTO entry)
        {
            try
            {
                using (Entities db = new Entities())
                {
                    string strRet = "";
                    var data = DTOToEntity(entry);
                    var dbEntry = db.Entry(data);

                    // Create 
                    if (entry.DivisionID == 0)
                    {
                        data.CreatedBy = User.Identity.Name;
                        data.CreatedDate = DateTime.Now;
                        dbEntry.State = EntityState.Added;                       
                    }

                    // Edit
                    else
                    {
                        Division prevDivision = db.Divisions.FirstOrDefault(x => x.DivisionID == entry.DivisionID);

                        prevDivision.DivisionName = entry.DivisionName;
                        prevDivision.DivHeadUsername = entry.DivHeadUsername;
                        prevDivision.DivHeadEmail = entry.DivHeadEmail;
                        prevDivision.IsActive = entry.IsActive;
                        prevDivision.IsNotif = entry.IsNotif;
                        prevDivision.ModifiedBy = User.Identity.Name;
                        prevDivision.ModifiedDate = DateTime.Now;
                    }

                    db.SaveChanges();
                    strRet = "Success";

                    return strRet;
                }
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
        }
    }
}
