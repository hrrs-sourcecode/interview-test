﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.DirectoryServices;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using E_LibraryPolicy.CustomAuth;
using E_LibraryPolicy.Models;
using E_LibraryPolicy.Models.DTO;
using Newtonsoft.Json;
using AutoMapper;
using System.Linq.Dynamic;

namespace E_LibraryPolicy.Controllers
{
    //[CustomAuthorize(IsAdminLibrary = true, IsAdminRegulatory = true, IsUserLibrary = true, IsUserRegulatory = true)]
    public class UsersController : AbstractController<User, UserDTO>
    {
        private Entities db = new Entities();
        public ActionResult Home(string appName)
        {
            ViewBag.DepartmentID = new SelectList(db.Departments.Where(x => x.IsActive == true), "DepartmentID", "DepartmentName");
            IList<KeyValuePair<string, string>> roleList = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("AdminRegulatory","Admin"),
                new KeyValuePair<string, string>("AdminLibrary","Admin"),
                new KeyValuePair<string, string>("UserRegulatory","User"),
                new KeyValuePair<string, string>("UserLibrary","User")
            };
            ViewBag.RolesList = new SelectList(roleList.Where(x => x.Key.Contains(appName)).ToList(), "Key","Value");
            ViewBag.AppName = appName;
            return View("~/Views/Users/Index.cshtml");
        }

        [HttpGet]
        public ActionResult CheckUserAD(string username)
        {
            if (db.Users.Any(x => x.Username == username))
                return Json("Exist", JsonRequestBehavior.AllowGet);

            return GetUserAD(username);
        }

        [HttpGet]
        public ActionResult GetUserAD (string username)
        {
            if (Session["LoginSession"] == null)
            {
                return Json("Expired", JsonRequestBehavior.AllowGet);
            }
            LoginView model = JsonConvert.DeserializeObject<LoginView>(Session["LoginSession"].ToString());

            string domain = WebConfigurationManager.AppSettings["ActiveDirectoryUrl"];
            string ldapUser = model.UserName; 
            string ldapPassword = model.Password;
            using (DirectoryEntry entry = new DirectoryEntry(domain, ldapUser, ldapPassword))
            {
                DirectorySearcher search = new DirectorySearcher(entry);

                search.Filter = "(SAMAccountName=" + username + ")";
                search.PropertiesToLoad.Add("name");
                search.PropertiesToLoad.Add("mail");
                search.PropertiesToLoad.Add("department");
                search.PropertiesToLoad.Add("title");
                search.PropertiesToLoad.Add("employeenumber");
                search.PropertiesToLoad.Add("manager");

                SearchResult searchResult = search.FindOne();
                if (searchResult != null)
                {
                    User userModel = new User()
                    {
                        Username = ldapUser,
                        Name = (String)searchResult.Properties["name"][0],
                        Position = searchResult.Properties.Contains("title") ? (String)searchResult.Properties["title"][0] : "",
                        Email = searchResult.Properties.Contains("mail") ? (String)searchResult.Properties["mail"][0] : "",
                        EmployeeNumber = searchResult.Properties.Contains("employeenumber") ? (String)searchResult.Properties["employeenumber"][0] : ""
                    };
                    return Json(userModel, JsonRequestBehavior.AllowGet);
                }
                return Json(null, JsonRequestBehavior.AllowGet);
            }
        }

        protected override IQueryable<User> FilterData(string searchValue, IQueryable<User> List)
        {
            if (!string.IsNullOrEmpty(searchValue))
            {
                searchValue = searchValue.ToLower();
                List = List.Where(x => x.Username.ToLower().Contains(searchValue)||
                x.Email.ToLower().Contains(searchValue) ||
                x.Position.ToLower().Contains(searchValue) ||
                x.Department.DepartmentName.ToLower().Contains(searchValue));
            }
            return List;
        }

        public ActionResult GetUser(string roleName)
        {
            IList<User> listUser = db.Users.Where(x => x.Position == "SuperAdmin" || x.Position == roleName).ToList();
            
            return Json(new { data = listUser , draw = Request.Form["draw"], recordsFiltered = listUser.Count, recordsTotal = listUser.Count });
        }

        public ActionResult GetListUserByAppName (string appName)
        {
            int start = Convert.ToInt32(Request.Form["start"]);
            int lenght = Convert.ToInt32(Request.Form["length"]);
            string searchValue = Request.Form["search[value]"];
            string column = Request.Form["order[0][column]"];
            string sortCoulmnName = Request.Form["columns[" + column + "][data]"];
            string sortDirection = Request.Form["order[0][dir]"];

            var allData = GetDataValue();
            var total = allData.Count();
            var totalFiltered = total;

            allData = FilterData(searchValue, allData);
            allData = allData.Where(x => x.Position.Contains(appName));

            totalFiltered = allData.Count();

            try
            {
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }
            catch
            {
                //custom sorting by name
                sortCoulmnName = Request.Form["columns[" + column + "][name]"];
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }


            allData = allData.Skip(start).Take(lenght).AsQueryable();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<User, UserDTO>();
            });
            var iMapper = config.CreateMapper();
            var result = iMapper.Map<IQueryable<User>, List<UserDTO>>(allData);

            return Json(new { data = result.ToList(), draw = Request.Form["draw"], recordsFiltered = totalFiltered, recordsTotal = total });
        }
    }
}
