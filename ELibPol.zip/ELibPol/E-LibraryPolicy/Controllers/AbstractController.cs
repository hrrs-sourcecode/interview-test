﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using E_LibraryPolicy.Models;
using System.Linq.Dynamic;
using AutoMapper;
using System.Data.Entity;
using E_LibraryPolicy.CustomAuth;

namespace E_LibraryPolicy.Controllers
{
    [CustomAuthorize]
    public class AbstractController<TEntity, TEntityDTO> : Controller
        where TEntity : class
    {
        private Entities db = new Entities();
        // GET: Abstract
        public virtual ActionResult Index()
        {
            return View();
        }
        public virtual ActionResult Create(TEntityDTO entry)
        {
            try
            {
                
                var data = DTOToEntity(entry);

                var result = db.Set<TEntity>().Add(data);
                db.Entry(data).State = EntityState.Added;
                db.SaveChanges();
                return Json("Success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }
        public virtual ActionResult Edit(TEntityDTO entry)
        {
            try
            {
                var data = DTOToEntity(entry);

                db.Set<TEntity>().Attach(data);
                var dbEntry = db.Entry(data);

                foreach (var property in dbEntry.OriginalValues.PropertyNames)
                {
                    if (dbEntry.CurrentValues.GetValue<object>(property) != null)
                    {
                        dbEntry.Property(property).IsModified = true;
                    }
                }
                //dbEntry.State = EntityState.Modified;
                db.SaveChanges();
                return Json("Success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }

        }
        public virtual ActionResult Delete(TEntityDTO entry)
        {
            try
            {
                var data = DTOToEntity(entry);

                db.Set<TEntity>().Attach(data);
                db.Entry(data).State = EntityState.Deleted;
                db.SaveChanges();
                return Json("Success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }

        public virtual IQueryable<TEntity> GetDataValue()
        {
            return db.Set<TEntity>().AsQueryable();
        }

        [HttpPost]
        public virtual ActionResult GetList()
        {
            int start = Convert.ToInt32(Request.Form["start"]);
            int lenght = Convert.ToInt32(Request.Form["length"]);
            string searchValue = Request.Form["search[value]"];
            string column = Request.Form["order[0][column]"];
            string sortCoulmnName = Request.Form["columns[" + column + "][data]"];
            string sortDirection = Request.Form["order[0][dir]"];

            var allData = GetDataValue();
            var total = allData.Count();
            var totalFiltered = total;

            allData = FilterData(searchValue, allData);
            totalFiltered = allData.Count();

            try
            {
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }
            catch
            {
                //custom sorting by name
                sortCoulmnName = Request.Form["columns[" + column + "][name]"];
                allData = allData.OrderBy(sortCoulmnName + " " + sortDirection).AsQueryable();
            }
            

            allData = allData.Skip(start).Take(lenght).AsQueryable();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<TEntity, TEntityDTO>();
            });
            var iMapper = config.CreateMapper();
            var result = iMapper.Map<IQueryable<TEntity>, List<TEntityDTO>>(allData);

            return Json(new { data = result.ToList(), draw = Request.Form["draw"], recordsFiltered = totalFiltered, recordsTotal = total });
        }

        protected virtual IQueryable<TEntity> FilterData(string searchValue, IQueryable<TEntity> List)
        {
            return List;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        protected TEntity DTOToEntity(TEntityDTO entry)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<TEntityDTO, TEntity>();
            });
            var iMapper = config.CreateMapper();
            var data = iMapper.Map<TEntityDTO, TEntity>(entry);
            return data;
        }

        protected List<TEntityDTO> EntityToDTOBulk(IQueryable<TEntity> entry)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<TEntity, TEntityDTO>();
            });
            var iMapper = config.CreateMapper();
            var result = iMapper.Map<IQueryable<TEntity>, List<TEntityDTO>>(entry);
            return result;
        }
    }
}