USE [E-Library-Policy]
GO

/****** Object:  Table [dbo].[DepartmentRegulatory]    Script Date: 4/1/2022 9:41:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DepartmentRegulatory](
	[DepartmentRegulatoryID] [int] IDENTITY(1,1) NOT NULL,
	[DepartmentID] [int] NULL,
	[ReportName] [varchar](max) NULL,
	[RegulatoryCategoryID] [int] NULL,
	[Regulation] [varchar](max) NULL,
	[Addressee] [varchar](100) NULL,
	[Schedulle] [varchar](10) NULL,
	[IsFixed] [bit] NULL,
	[Value] [datetime] NULL,
	[IsActive] [bit] NULL,
	[Remarks] [varchar](max) NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


