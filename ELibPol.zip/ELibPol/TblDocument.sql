USE [E-Library-Policy]
GO

/****** Object:  Table [dbo].[Document]    Script Date: 4/1/2022 9:42:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Document](
	[DocumentID] [int] IDENTITY(1,1) NOT NULL,
	[DepartmentID] [int] NULL,
	[Title] [varchar](50) NULL,
	[DocumentTypeID] [int] NULL,
	[AttachmentPath] [varchar](max) NULL,
	[DocumentPath] [varchar](max) NULL,
	[EffectiveDate] [date] NULL,
	[Keywords] [varchar](max) NULL,
	[Number] [varchar](50) NULL,
	[ExpiredDate] [date] NULL,
	[IsReviewed] [bit] NULL,
	[IsApproved] [bit] NULL,
	[ApprovedBy] [varchar](50) NULL,
	[ReviewedBy] [varchar](50) NULL,
	[Comments] [varchar](max) NULL,
	[CreatedBy] [varchar](50) NULL,
	[CreatedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
	[PIC_Name] [varchar](100) NULL,
	[PIC_Email] [varchar](max) NULL,
	[IsActive] [bit] NULL,
	[NotifiedDate] [datetime] NULL,
 CONSTRAINT [PK_Document] PRIMARY KEY NONCLUSTERED 
(
	[DocumentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


