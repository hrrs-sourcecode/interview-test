USE [E-Library-Policy]
GO

/****** Object:  Table [dbo].[RegulatoryCategory]    Script Date: 4/1/2022 9:44:46 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RegulatoryCategory](
	[RegulatoryCategoryID] [int] IDENTITY(1,1) NOT NULL,
	[RegulatoryCategoryName] [varchar](100) NULL,
	[IsActive] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL
) ON [PRIMARY]
GO


