USE [E-Library-Policy]
GO

/****** Object:  Table [dbo].[RegulatoryType]    Script Date: 4/1/2022 9:45:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RegulatoryType](
	[RegulatoryTypeID] [int] IDENTITY(1,1) NOT NULL,
	[RegulatoryTypeName] [varchar](100) NULL,
	[IsActive] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
 CONSTRAINT [PK_RegulatoryType] PRIMARY KEY CLUSTERED 
(
	[RegulatoryTypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


