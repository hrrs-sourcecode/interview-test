USE [E-Library-Policy]
GO

/****** Object:  Table [dbo].[RegulatoryApproval]    Script Date: 4/1/2022 9:44:17 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RegulatoryApproval](
	[RegulatoryApprovalID] [int] IDENTITY(1,1) NOT NULL,
	[DepartmentRegulatoryID] [int] NULL,
	[Title] [varchar](150) NULL,
	[FilePath] [varchar](max) NULL,
	[IsReviewed] [bit] NULL,
	[ReviewBy] [varchar](50) NULL,
	[Status] [varchar](50) NULL,
	[SubmissionDate] [date] NULL,
	[SubmissionComment] [varchar](max) NULL,
	[ReviewComment] [varchar](max) NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


